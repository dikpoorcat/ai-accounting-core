"""One fixed-source affected group, separate from timing and old checkpoints."""
import ast
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

W = Path(__file__).resolve().parents[1]
assert Path(sys.prefix).resolve() == W / '.tmp-kernel-venv'
prefix = W / '.tmp/stage9-open-scope-affected-regression-20261004'
files = '''test_dashboard_projection.py
test_dashboard_funds_alignment.py
test_dashboard_workforce_assets.py
test_dashboard_owner_presentation.py
test_dashboard_contract_boundaries.py
test_dashboard_bounded_reads.py
test_dashboard_deferred.py
test_dashboard_business_queries.py
test_dashboard_identity_attribution.py
test_dashboard_voucher_adapter.py
test_dashboard_quarterly_sources.py
test_reports.py
test_reports_bounded_reads.py
test_report_projection.py
test_query_reads.py
test_t7_snapshot_reuse.py
test_integrity_content.py
test_open_scope_relation_proof_reuse.py'''.splitlines()
nodes = '''test_maintenance.py::test_source_damage_cannot_be_repaired_or_disguised
test_maintenance.py::test_index_repair_restores_missing_close_marker_without_waiving_frozen_roots
test_runtime_backup.py::test_initial_portable_round_trip_and_rollover_are_verified
test_runtime_backup.py::test_evidence_corruption_is_detected_before_backup_is_published
test_offline_upgrade.py::test_nonempty_v1_frozen_adoption_survives_changed_v2_current_model
test_offline_upgrade.py::test_v1_identity_correction_is_verified_after_current_expense_model_changes
test_offline_upgrade.py::test_v1_frozen_opening_and_cumulative_identity_survive_changed_v2_methods_and_helpers
test_close_review_transport.py::test_review_uses_exact_preview_and_survives_freeze_and_service_restart
test_replay_close_range.py::test_replay_schema_keeps_ordinary_close_password_contract'''.splitlines()
selection = ['tests/kernel/' + item for item in files + nodes]
assert len(selection) == len(set(selection))
for item in selection:
    name, _, node = item.partition('::')
    path = W / name
    assert path.is_file(), name
    if node:
        assert any(isinstance(x, ast.FunctionDef) and x.name == node
                   for x in ast.parse(path.read_text(encoding='utf-8')).body), item
paths = {item.partition('::')[0] for item in selection}
paths.update(item.relative_to(W).as_posix() for item in (W/'src/ai_accounting/kernel').rglob('*.py'))
hashes = {name:hashlib.sha256((W/name).read_bytes()).hexdigest() for name in sorted(paths)}
source_manifest = json.loads((W/'.tmp/stage9-build-source-open-scope-group-candidate-20261004/source-manifest.json').read_text(encoding='utf-8'))
assert source_manifest['sha256'] == '24b9b8b65723cee8c6982b1f41235dce380e62788db33f100176f92c714571fc'
for name, value in hashes.items():
    assert source_manifest['files'][name] == value, name
for suffix in ('.json','.log','.xml'):
    assert not prefix.with_suffix(suffix).exists()
command = [sys.executable,'-X','utf8','-m','pytest','-q',*selection,
           '--junitxml='+str(prefix.with_suffix('.xml'))]
started=time.time()
print(json.dumps({'status':'started','files':len(files),'nodes':len(nodes),
                  'source_sha256':source_manifest['sha256'],'timing_acceptance':False}),flush=True)
with prefix.with_suffix('.log').open('x',encoding='utf-8') as log:
    result=subprocess.run(command,cwd=W,stdout=log,stderr=subprocess.STDOUT)
receipt={'started_unix':started,'elapsed_seconds':time.time()-started,
         'exit_code':result.returncode,'source_sha256':source_manifest['sha256'],
         'command':command,'files_before':hashes,
         'files_unchanged':all(hashlib.sha256((W/name).read_bytes()).hexdigest()==value for name,value in hashes.items()),
         'timing_acceptance':False,'old_checkpoint_inherited':False}
prefix.with_suffix('.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({key:value for key,value in receipt.items() if key not in ('command','files_before')}),flush=True)
assert receipt['files_unchanged']
sys.exit(result.returncode)
