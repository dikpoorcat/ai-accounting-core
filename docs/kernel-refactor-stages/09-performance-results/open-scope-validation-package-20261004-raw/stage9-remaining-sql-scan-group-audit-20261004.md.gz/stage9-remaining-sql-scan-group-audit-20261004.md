# Stage 9 remaining SQL scan group audit

2026-10-04. Read-only source/recorded-diagnostic audit. Only this note is written;
no implementation, tests, database/service operations or new measurement.

## Core findings saved first

Initial supplied diagnostics identify source dd8601e985cb6bed14f9bc0746bb5b387a20f9355ecd69e1e5ebae729b746a96.
Root then supplied `.tmp/stage9-open-scope-group-work-after-20261004.json`, source
24b9b8b65723cee8c6982b1f41235dce380e62788db33f100176f92c714571fc, and its before /
comparison files. Current work numbers below now come from that AFTER file,
which has six observations: context and the five pages; each has
actual_work.counters and actual_work.sql aggregated by statement. The older HTTP
file has worker stage/call profiles and is used only for callgraph context.
The bank
summary-only window split was ALREADY present in dd86: it cannot be counted as
a remaining optimization or credited again. No timing gain is inferred.

The three strongest remaining source-backed groups are:

| Group | Recorded statement work | Actual responsibility / excess |
|---|---|---|
| Funds materialized summary+page windows | Movement first-account query: 264,900 VM, 21 returned rows, 7,275 bytes, one call. Bank summary+page query: 154,500 VM, 21 rows, 6,886 bytes, one call. | Full account totals, internal-transfer classification and reconciliation partition totals remain necessary. Page detail windows/sort currently run before account/filter/page narrowing; most of that detail work is unnecessary for a 20-row page. |
| Quarterly frozen-flow exact classification headers | `SELECT f.id,f.digest,f.period,s.kind,c.voucher_version_id FROM json_each(?) ... ORDER BY ids.value`: 12 calls, 187,600 VM, 4,932 rows, 784,188 bytes. | Every monthly root's named header/membership check is necessary. SQL/header work can be batched across those authenticated monthly roots in one owned snapshot. Equal aggregate row counts do NOT prove identical reference IDs; diagnostics omit arguments, so exact overlap is unproven. |
| Employee roster candidate discovery before exact head selection | Recursive publication-period locator: 129,900 VM, 50 rows, 1,140 bytes. Role `objects AS MATERIALIZED` locator: 86,100 VM, 50 rows, 4,640 bytes. | Complete people/month/open/withdrawn/corrected/missing-source/frozen discovery remains necessary. Publication driver reads the whole relevant posting month before applying requested payroll kinds; role driver starts at role rather than requested kind/entity. Small outputs hide broad scanned intermediates. |

These are concrete candidate responsibilities, not permission to delete business
proofs or introduce a trusted caller flag. Their performance impact on current
source still requires root's future controlled work comparison.

## Provenance and all page callers

Compared current files byte-for-byte to the diagnostic's stored source tree
`.tmp/stage9-build-source-surviving-read-consumers-fixed-20261003`: dashboard_funds,
dashboard_reads, report_flow, report_open_contribution, reports and
settlement_projection are identical. Thus their specific SQL responsibilities
remain observable in current source; query_reads normal relations have changed.
The recorded 23 read_report_flow Python calls include 11 successful same-period
cache hits and 12 physical monthly reads, not 23 SQL reruns. Inclusive profile
times overlap; do not add them or subtract a whole function's time as savings.

| Entry | Recorded total VM / returned rows / bytes | Main relevant chain |
|---|---|---|
| context | 10,900 / 96 / 850 | Dashboard.context -> _periods: distinct actual fact/voucher/current/material months. 10,800 VM, 48 rows, 384 bytes; independent period_close listing 100 VM. This is a small discovery responsibility, not a full business scan. |
| brief | 836,900 / 14,332 / 7,219,039 | Dashboard.brief -> month_journal/account_amounts and brief money/workforce/settlement summaries. Whole-month journal: 114,800 VM, 1,005 rows, 454,060 bytes; exact saved source header+outcome load: 45,200 VM, 1,006 rows, 1,238,406 bytes. Full-month money proof remains required for totals, even if only 20 activities display. |
| funds_first | 1,196,200 / 9,364 / 3,144,297 | Dashboard.funds -> dashboard_funds.funds -> FundsRead.account_summary/movements and bank_summary -> _sql_summary_page. This work run uses native first-account selection, not HTTP selected-account refresh. |
| employees | 751,600 / 4,969 / 3,939,194 | Dashboard.employees -> _employees -> payroll roster candidate discovery / exact adopted heads and payroll metrics; shared settlement summaries also consume all required obligations. |
| assets | 538,100 / 6,402 / 5,732,164 | Dashboard.assets -> _assets -> adopted asset/member/head scopes and settlement/frozen asset slices. Exact-kind adopted-head ranking: 61,500 VM, 96 rows, 27,121 bytes; 95 scoped voucher rows cost 49,400 VM/50,713 bytes. Many histories are required for asset adoption and cannot become a current-month-only filter. |
| quarterly_report | 917,100 / 22,863 / 10,395,853 | Dashboard.quarterly_report -> Reports._report -> party_balance_nets/stored_month -> read_report_flow plus open selected lines/contributions. Year-to-date flow is a real output responsibility, not only the selected quarter's rows. |

All five pages recorded the exact terminal open-scope support read at roughly
85,800 VM/1,006 rows/675,440 bytes, plus the opposite missing-source probe at
38,300 VM with zero returned rows. Those remain necessary fullselection guards.
The OLD dd86 p.* reverse query at 23,100 VM/1,005 rows/204,675 bytes has now lost
its normal-head rows through this group's implemented reuse; the review/reversal
residual still exists and must be kept. Do not list removed normal rows again.
Cross-page repeated scope reads occur in separate requests/snapshots; they do
not authorize persistent success caching.

## 1. Funds: separate complete summary proof from bounded detail windows

Concrete SQL: `WITH source_rows AS MATERIALIZED (...), summary_rows AS
MATERIALIZED (...), filtered_rows AS MATERIALIZED (...), page_rows AS (... ORDER
BY page_key LIMIT ?)`. Source movement SQL creates `row_number() OVER(PARTITION
BY event_id ORDER BY effect_index)` for every effect, then transfer aggregates,
then account summary and page sorting. Bank source SQL creates `count(*) OVER`
and `sum(abs(signed_fen)) OVER` partitioned by reconciliation/source before the
page limit. `_sql_summary_page` separately scans materialized source/filtered rows
for total_count, filtered_count and cursor_present.

Current bank `page_request is None` already uses bank_summary_source without
those detail windows. Funds page with statement page_request still uses
bank_source with full windows. `source_row_count` and source_rows_total_fen are
consumed by bank batch presentation, so deleting them changes actual behavior.

Recommended next implementation: retain a narrow complete base source for
summary/state/internal-transfer/account selection and count/cursor semantics;
select bounded page keys; derive bank partition counts/totals only for the
displayed rows' exact `(reconciliation_calculation_id,source_kind,source_id)`
partitions over the SAME authenticated complete base source. Compute each
distinct displayed partition once; duplicate/ambiguous matches retain their
existing special cases. This is a candidate experiment, not established redundant
work: the partitions define actual page semantics, and their scans may already
be the cheapest way to prove those totals. Merely filtering before a window makes
partition totals wrong. For movements, local_index is defined over nonzero money
effects, so preserve page-key numbering across the full event; target relevant
events after global account/transfer summary rather than renumbering filtered
effects. Summary-only brief already uses proved effects/_verified_money_summary
where eligible, and must retain its overflow/independent fallback.

Main risk is losing global counts or internal transfer identification across two
accounts. A narrower page must not delete the opposite publication guard, event
selection/adoption, original reversal source, zero-state saved input or full
bank reconciliation proof. Existing MATERIALIZED scans may still outperform two
separate source queries on small books; VM/rows comparison, not SQL call count,
must decide. No savings estimate is provided.

## 2. Report flow: batch exact immutable headers across authenticated months

Current `read_report_flow` binds each stored body to that close's private roots,
decodes complete monthly data, then executes the exact-ID classification-header
query. It checks missing/id/kind/voucher binding/digest AND each month's own
`fact.period == period OR voucher_version_id in source_vouchers`. Success cache
is keyed by month. Reports._report's YTD monthly loop and
report_projection._party_balance_nets_uncached.stored_month share that cache.

The 12 reads are distinct frozen months needed for party balance/year flows.
The supplied statement aggregation cannot establish repeated IDs; assuming
4,932/12 means identical facts would be invalid. Still, a private current-owned
batch can authenticate requested roots first, gather union exact fact IDs, read
all physical headers once, and perform the SAME per-month identity/membership/
digest checks. Cache each month only after the group succeeds, or preserve
explicit independent-success boundaries. This can reduce driver calls and any
actual repeated IDs, but may not materially reduce VM if all IDs are disjoint.
Do not change stored frozen root content, limit year flows to the quarter, or
skip fact/header checking merely because a root authenticated its recorded IDs.

Historical v1 owns report_flow_v1 via content_history_context.report_flow_reader;
candidate batch must explicitly require the current reader/content codec, owned
connection/token/transaction. Independent/full source rebuild stays unchanged.

## 3. Employee discovery: requested kind before broad intermediate scans

`_payroll_roster_candidates` currently enumerates distinct publication periods,
materializes all publications for selected/open months, and only then joins
subject/calculation to filter requested payroll kinds. The role seed query uses
entity_current_role `(role,period DESC,fact_id DESC)` or recorded counterpart;
`kind IN requested` is a residual filter, and DISTINCT entity_id requires whole
role-range discovery. The subsequent per-person latest-fact lookup uses the
more appropriate `(entity_id,role,kind,period DESC,fact_id DESC)` index.

Recommended next implementation: drive normal candidates from requested kinds
through subject_kind and publication_subject before materialization; preserve a
separate bounded orphan/missing-kind/missing-subject branch so damaged records
cannot vanish. Keep selected/open, withdrawn, identity-corrected, missing current
publication and full frozen month zero-line branches. Role seeds can be obtained
from exact kind/subject facts and their actual role records, then checked against
the same whole-person directory fallback. Existing indexes may support this
without schema changes; compare query plan/work later rather than adding an
index speculatively. Frozen asset head ranking similarly deserves examination,
but its smaller 61,500-VM scope is lower priority and its independent references
make blind period/kind narrowing unsafe.

## Related contribution and period aggregation groups

Quarterly open contribution SQL already requests only missing calculation IDs:
two calls return 1,004 rows/3,322,180 bytes at 24,100 VM. Successful contributions
are cached per calculation, so the two different consumers (`_unfrozen_voucher_ids`
and `_party_delta`) are not evidence of duplicate complete-body reads. The whole
anchor-bound content, parents and resolution remain required for those consumers.
The current owned source-byte witness path and decoded contribution cache have
different meanings. Do not revive the withdrawn journal contribution candidate
or propose parsing less merely from a large byte count. A useful later query
would inspect exact miss sets, but that evidence is not in the supplied files.

`settlement_projection._read_seals` verifies full ordered period contributions:
the same exact-month 14-column json_group_array returns one 451,669-byte value at
46,100 VM, observed on brief/employees/assets. The publication ID array adds
19,500 VM/70,941 bytes in assets. Row consumers then read actual s.*: brief and
employees 72,300 VM/1,246 rows/521,477 bytes; assets 14,000 VM and zero returned
matching consumer rows. Assets thus verifies a whole month's settlement seal
even when its own narrower consumer returns no rows. This is necessary today:
the only authenticating seal is period-wide, and a filtered projection cannot
prove omitted matching rows are absent.

Potential future responsibility split: within one owned request, carry the
verified exact-period rows when the business consumer already needs all of them,
or prove narrow hit absence through an independent source locator BEFORE omitting
period authentication. Preserve all14 fields/order, publication completeness and
source digest checks; no trust in the filtered repairable projection. Returning
all rows instead of one JSON seal may increase rows/bytes on assets and is not
automatically an optimization. `_verified_settlement_periods` already avoids
same-request repeat verification, so this is not a cache-miss bug.

## Public and independent boundaries

Service._dispatch maps dashboard_brief/funds/employees/assets/quarterly_report to
the same Dashboard methods. Local CLI and MCP commands reaching these methods
can share an actual owned QueryReads snapshot; direct Reports/BusinessQueries
entries benefit only where they establish one. Main page/context/detail calls
have separate selected scopes, and preparation deferred/complete is not the same
workload. The HTTP diagnostic shows dashboard dispatch dominating its worker
for measured brief/quarterly requests; authorization/binding/response stages
remain separate and inclusive times are not additive.

Close integrity uses verify_close_integrity's independent complete source path.
Full integrity calls _check_sources; Maintenance._repair verifies before/after
and independently rebuilds report_flow and settlement projections. Backup
_verify_connection invokes the registered bundle verifier; restore verifies the
package before publication. Their current/v1 complete rebuild responsibilities
must not consume a new ordinary narrow receipt as full successful verification.
Fixed v1 source adapters, source fingerprints and frozen bytes remain immutable.
No candidate here requires changing released schema, identities or current real
company databases. Root's completed open-scope comparison reports five pages each
remove 2,006 rows/288,522 bytes and 31,000-31,200 VM, with unchanged SQL counts and
all decode/outcome-body work. Six complete business response hashes agree after
normalizing only exact source-bound read_context.read_version and clock. This
audit reads that root-produced evidence; it performs no independent measurement.
Candidate groups' stated current SQL metrics were re-read from AFTER and retain
the same values as dd86 because those SQL statements were not changed.
