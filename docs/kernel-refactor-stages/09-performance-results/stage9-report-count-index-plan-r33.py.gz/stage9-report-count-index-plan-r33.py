"""Compare four exact ID-join plans on the isolated synthetic DB copy."""

import ctypes
import hashlib
import json
import sqlite3
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp/stage9-build-source-r33-release"
BOOK = ROOT / ".tmp/stage9-release-main-48-verified-r32.json"
CLONE = ROOT / ".tmp/stage9-report-count-covering-r33/company.sqlite"
OUTPUT = ROOT / ".tmp/stage9-report-count-index-plan-analyzed-r33.json"


class IOCounters(ctypes.Structure):
    _fields_ = [(name, ctypes.c_uint64) for name in (
        "read_operation_count", "write_operation_count", "other_operation_count",
        "read_transfer_count", "write_transfer_count", "other_transfer_count",
    )]


def process_read_bytes():
    counters = IOCounters()
    kernel = ctypes.windll.kernel32
    kernel.GetCurrentProcess.restype = ctypes.c_void_p
    kernel.GetProcessIoCounters.argtypes = (ctypes.c_void_p, ctypes.POINTER(IOCounters))
    if not kernel.GetProcessIoCounters(kernel.GetCurrentProcess(), ctypes.byref(counters)):
        return None
    return counters.read_transfer_count


def measured(connection, sql, params):
    vm = 0

    def progress():
        nonlocal vm
        vm += 100
        return 0

    connection.set_progress_handler(progress, 100)
    before = process_read_bytes()
    cpu = time.process_time_ns()
    wall = time.perf_counter_ns()
    rows = connection.execute(sql, params).fetchall()
    after = process_read_bytes()
    sample = {
        "vm_approx": vm,
        "cpu_ms": (time.process_time_ns() - cpu) / 1e6,
        "wall_ms": (time.perf_counter_ns() - wall) / 1e6,
        "process_read_bytes": None if before is None or after is None else after - before,
        "rows": rows,
        "returned_bytes": len(json.dumps(rows, separators=(",", ":")).encode()),
    }
    connection.set_progress_handler(None, 0)
    return sample


def main():
    if OUTPUT.exists() or not CLONE.exists():
        raise RuntimeError("Missing clone or output already exists")
    book = json.loads(BOOK.read_text(encoding="utf-8"))
    sys.path.insert(0, str(SOURCE / "src"))
    from ai_accounting.kernel.daemon import _prepare_static_runtime
    from ai_accounting.kernel.engine import Engine
    from ai_accounting.kernel.query_reads import QueryReads
    from ai_accounting.kernel.reports import Reports, ReportClassification, ReportIncomeTaxConfirmation
    from ai_accounting.kernel.storage import Store
    from ai_accounting.kernel.types import canonical

    bundle = _prepare_static_runtime()[0]
    ident = book["company"]
    original = Store(ident["path"], bundle, ident["id"], ident["database_id"], taxpayer_id=ident["taxpayer_id"])
    engine = Engine(original)
    with QueryReads.snapshot(engine) as reads:
        plan = Reports(engine)._report(2019, 4, source="open", connection=reads.connection, reads=reads)
    ids = plan["report_fact_ids"]
    params = (ReportClassification.kind, ReportIncomeTaxConfirmation.kind, canonical(ids))
    variants = {
        "natural_after_analyze": (None, None),
        "original_pk_pair": ("sqlite_autoindex_fact_revision_1", "sqlite_autoindex_subject_1"),
        "fact_cover_only": ("stage9_cover_fact_id_subject", "sqlite_autoindex_subject_1"),
        "subject_cover_only": ("sqlite_autoindex_fact_revision_1", "stage9_cover_subject_id_kind"),
        "both_cover": ("stage9_cover_fact_id_subject", "stage9_cover_subject_id_kind"),
    }
    results = {name: {"samples": []} for name in variants}
    with sqlite3.connect(f"file:{CLONE.as_posix()}?mode=ro", uri=True) as connection:
        for name, (fact_index, subject_index) in variants.items():
            sql = (
                "SELECT count(*) FILTER (WHERE s.kind=?),count(*) FILTER (WHERE s.kind=?) "
                "FROM json_each(?) ids "
                f"JOIN fact_revision f {'INDEXED BY ' + fact_index if fact_index else ''} ON f.id=ids.value "
                f"JOIN subject s {'INDEXED BY ' + subject_index if subject_index else ''} ON s.id=f.subject_id"
            )
            results[name]["eqp"] = [tuple(row) for row in connection.execute("EXPLAIN QUERY PLAN " + sql, params)]
            results[name]["sql"] = sql
        for cycle in range(3):
            order = list(variants) if cycle % 2 == 0 else list(reversed(variants))
            for name in order:
                results[name]["samples"].append(measured(connection, results[name]["sql"], params))
    baseline = results["original_pk_pair"]["samples"][0]["rows"]
    for item in results.values():
        item["same_result"] = all(sample["rows"] == baseline for sample in item["samples"])
    output = {
        "status": "diagnostic",
        "source": str(SOURCE), "verified_book_report": str(BOOK), "clone": str(CLONE),
        "plan_ids": len(ids), "plan_digest": hashlib.sha256(canonical(ids).encode()).hexdigest(),
        "variants": results,
        "note": "Explicit index hints only inside independent copied DB. Not usable as released schema without a new contract.",
    }
    OUTPUT.write_text(json.dumps(output, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(OUTPUT)


if __name__ == "__main__":
    main()
