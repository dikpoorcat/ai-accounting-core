"""r73 successful head relation overlap diagnostic; no acceptance timing."""
from pathlib import Path
import json, sys, traceback, collections
w=Path(__file__).resolve().parents[1]
src=w/'.tmp/stage9-build-source-owner-r73-release'
sys.path.insert(0,str(src/'scripts'))
from stage9_source import configure_source
configure_source(src,w)
from ai_accounting.kernel.catalog import Catalog
from ai_accounting.kernel.dashboard import Dashboard
from ai_accounting.kernel.daemon import _prepare_static_runtime
from ai_accounting.kernel.engine import Engine
from ai_accounting.kernel.resident_reads import ResidentReadPool
from ai_accounting.kernel import query_reads as qr, business_queries as bq
from ai_accounting.kernel.publication import CONTENT_FIELDS
book=json.loads((w/'.tmp/stage9-owner-main48-r63-verified.json').read_text('utf-8'))
assert book['status']=='complete' and book['integrity']['status']=='verified' and not book['integrity']['limitations']
root=Path(book['root']); assert root==w/'.tmp/stage9-owner-main48-r63'
_prepare_static_runtime(); catalog=Catalog(root); pool=ResidentReadPool()
with catalog.connection(read_only=True) as connection:
    row=dict(connection.execute('SELECT * FROM company WHERE id=?',(book['company']['id'],)).fetchone())
    store=catalog._bound_store(row,read_pool=pool)
engine=Engine(store); dash=Dashboard(engine,company_name=row['name'],companies=[row])
original=qr.verify_current_publication_voucher_heads
seen={}; tokens=[]; calls=[]; operation=None

def wrapped(connection, publications):
    publications=tuple(publications)
    reads=qr._active_fact_reads.get(); owned=qr._owns_current_selector_snapshot(reads,connection)
    token=reads._snapshot_token if reads is not None else None
    if token not in tokens: tokens.append(token)
    token_index=tokens.index(token)
    signatures={p['id']:tuple(p[k] for k in CONTENT_FIELDS) for p in publications}
    previous=seen.setdefault(token_index,{})
    overlap=set(signatures)&previous.keys()
    stack=traceback.extract_stack(limit=8)[:-1]
    item={'operation':operation,'snapshot_token':token_index,'owned':owned,'company':book['company']['id'],
          'caller':[f'{Path(f.filename).name}:{f.lineno}:{f.name}' for f in stack],
          'input_count':len(publications),'distinct_count':len(signatures),'same_token_prior_success_overlap':sorted(overlap),
          'same_signature_overlap_count':sum(previous[i]==signatures[i] for i in overlap),
          'rows':[{'id':p['id'],'mode':p['mode'],'posting_period':p['posting_period'],
                   'previous_publication_id':p['previous_publication_id'],'signature':list(signatures[p['id']])} for p in publications]}
    calls.append(item)
    try: result=original(connection,publications)
    except BaseException as exc:
        item['status']='failed'; item['error']=repr(exc); raise
    else:
        item['status']='success'
        if owned: previous.update(signatures)
        return result
qr.verify_current_publication_voucher_heads=wrapped
bq.verify_current_publication_voucher_heads=wrapped
out={'scope':'r73_read_only_head_scope_overlap_diagnostic_not_acceptance','source':str(src),'root':str(root),'calls':calls,'operations':{}}
try:
    for operation,call in [('brief',lambda:dash.brief('2019-12',limit=20)),('assets',lambda:dash.assets('2019-12',limit=20)),('reports',lambda:dash.quarterly_report(2019,4,preparation='deferred'))]:
        try:
            result=call(); out['operations'][operation]={'status':'success','schema_version':result.get('schema_version')}
        except BaseException as exc: out['operations'][operation]={'status':'failed','error':repr(exc),'traceback':traceback.format_exc()}
        current=[c for c in calls if c['operation']==operation]
        print(json.dumps({'operation':operation,'status':out['operations'][operation]['status'],'calls':[{'token':c['snapshot_token'],'input':c['input_count'],'overlap':len(c['same_token_prior_success_overlap']),'exact_overlap':c['same_signature_overlap_count'],'caller':c['caller'][-2:],'status':c['status']} for c in current]}),flush=True)
finally:
    pool.close()
    with (w/'.tmp/stage9-r73-head-repeated-scope-probe.json').open('x',encoding='utf-8') as handle: json.dump(out,handle,ensure_ascii=False,indent=2)