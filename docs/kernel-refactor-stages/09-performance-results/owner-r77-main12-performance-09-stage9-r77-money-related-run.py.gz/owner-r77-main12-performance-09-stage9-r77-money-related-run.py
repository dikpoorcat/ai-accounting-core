from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root / 'scripts'))
from snapshot_stage9_source import _inventory

paths = [
 'tests/kernel/test_funds_verified_money_effects.py',
 'tests/kernel/test_funds_required_summary_work.py',
 'tests/kernel/test_funds_source_integrity.py',
 'tests/kernel/test_funds_summary_page.py',
 'tests/kernel/test_dashboard_funds_alignment.py',
 'tests/kernel/test_owner_brief_amounts.py',
 'tests/kernel/test_v1_stored_json_isolation.py',
]
prefix = root / '.tmp/stage9-r77-money-related'
log, report, command, xml = [prefix.with_suffix(s) for s in ('.log','.json','.command.txt','.xml')]
if any(path.exists() for path in (log, report, command, xml)):
    raise RuntimeError('related receipt already exists')
before = _inventory(root)
args = [sys.executable, '-X', 'utf8', '-m', 'pytest', *paths,
        '-q', '--junitxml=' + str(xml)]
command.write_text(subprocess.list2cmdline(args) + '\n', encoding='utf-8')
start = time.perf_counter()
with log.open('x', encoding='utf-8') as stream:
    result = subprocess.run(args, cwd=root, stdout=stream, stderr=subprocess.STDOUT)
after = _inventory(root)
def checksum(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()
data = {'returncode': result.returncode, 'elapsed_seconds': time.perf_counter()-start,
        'tests': paths, 'source_before_sha256': checksum(before),
        'source_after_sha256': checksum(after), 'source_unchanged': before == after,
        'scope': 'r77 verified money effects affected regressions, not frontend or browser acceptance'}
with report.open('x', encoding='utf-8') as stream:
    json.dump(data, stream, indent=2)
print(json.dumps(data), flush=True)
if before != after:
    raise RuntimeError('source changed during fixed related group')
raise SystemExit(result.returncode)
