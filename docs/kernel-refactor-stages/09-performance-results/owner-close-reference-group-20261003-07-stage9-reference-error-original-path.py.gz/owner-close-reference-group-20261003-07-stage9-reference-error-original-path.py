"""Observe original pinned rejection codes with unchanged synthetic preparation."""
import hashlib
import json
from pathlib import Path
import sys

workspace = Path(__file__).resolve().parents[1]
source = workspace / '.tmp/stage9-build-source-owner-close-proof-groups-20261003-release'
sys.dont_write_bytecode = True
sys.path[:0] = [str(source / 'scripts')]
import stage9_source
stage9_source.configure_source(source, workspace)
sys.path[:0] = [str(source / 'tests/kernel')]
from test_employee_adopted_period_scopes import prepare
from test_engine import engine as engine_fixture
from ai_accounting.kernel.query_reads import QueryReads
from ai_accounting.kernel.contracts import KernelError
from tempfile import TemporaryDirectory
import snapshot_stage9_source

manifest = json.loads((source / 'source-manifest.json').read_text(encoding='utf-8'))
assert manifest['sha256'] == '8cc0b0300835a7359aa0399dd78714f048abeef6debc5f2acc3a858c33b384d8'
before = snapshot_stage9_source._inventory(source)
assert before == manifest['files']
output = workspace / '.tmp/stage9-reference-error-original-path.json'
assert not output.exists()
result = {'source_sha256': manifest['sha256'], 'observations': []}
for change in ('related', 'invalid_period'):
    with TemporaryDirectory(prefix='stage9-original-reference-', dir=workspace / '.tmp') as directory:
        engine = engine_fixture.__wrapped__(Path(directory))
        prepare(engine)
        with QueryReads.snapshot(engine) as reads:
            references = [dict(row) for row in reads.connection.execute(
                "SELECT * FROM close_reference WHERE path IN ('adopted_results[*].calculation_id','adopted_results[*].fact_id','vouchers[*].id','vouchers[*].calculation_id') ORDER BY close_period,path,position"
            )]
            last = max(row['close_period'] for row in references)
            if change == 'related':
                next(row for row in references if row['close_period'] == last and row['path'] == 'vouchers[*].id')['related_id'] = 'wrong-related'
            else:
                references[-1]['close_period'] = True
            try:
                reads.verify_close_references(references)
            except KernelError as error:
                result['observations'].append({'change': change, 'code': error.code, 'details': error.details})
            else:
                raise AssertionError('Damaged reference accepted by original path')
assert snapshot_stage9_source._inventory(source) == before
result['source_inventory_equal'] = True
output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result, ensure_ascii=False))
