import hashlib
import json
import sqlite3
from pathlib import Path
from ai_accounting.kernel.dashboard_funds import _BANK_IDENTITY_SCALARS_SQL

profile = json.loads(Path('.tmp/stage9-resident-r68-main48-profile.json').read_text(encoding='utf-8'))
sql = next(row['statement'] for row in profile['operations']['funds']['work']['sql']
           if row['statement'].startswith('SELECT c.id,c.period,CASE c.kind'))
root = Path(profile['root'])
db = next(root.glob('*/company.sqlite'))
connection = sqlite3.connect(db.as_uri() + '?mode=ro', uri=True)
connection.execute('BEGIN')
ids = sorted(row[0] for row in connection.execute(
    "SELECT c.id FROM calculation_publication p JOIN calculation c ON c.id=p.calculation_id "
    "WHERE c.kind IN('bank_statement','bank_reconciliation') AND p.posting_period<=?",
    (connection.execute('SELECT max(posting_period) FROM calculation_publication').fetchone()[0],),
))
parameters = (json.dumps(ids, ensure_ascii=False, sort_keys=True, separators=(',', ':')),)
statements = {
    'original': sql,
    'fact_pk': _BANK_IDENTITY_SCALARS_SQL,
    'role_postfilter': sql.replace("r.role='bank_account'", "+r.role='bank_account'"),
    'verify_hits': 'SELECT * FROM entity_reference_recorded WHERE fact_id IN (SELECT value FROM json_each(?))',
}
fact_ids = [row[0] for row in connection.execute(
    'SELECT fact_id FROM json_each(?) ids JOIN calculation c ON c.id=ids.value', parameters)]
results = {}
for name, query in statements.items():
    params = (json.dumps(fact_ids, separators=(',', ':')), ) if name == 'verify_hits' else parameters
    plan = [list(row) for row in connection.execute('EXPLAIN QUERY PLAN ' + query, params)]
    count = [0]
    connection.set_progress_handler(lambda: count.__setitem__(0, count[0] + 1) or 0, 100)
    rows = list(connection.execute(query, params))
    connection.set_progress_handler(None, 0)
    byte_count = sum(len(v.encode('utf-8')) if isinstance(v, str) else len(v) if isinstance(v, bytes)
                     else 0 if v is None else 8 for row in rows for v in row)
    results[name] = {'plan': plan, 'vm_steps_100_quantized': count[0] * 100,
                     'returned_rows': len(rows), 'returned_value_bytes': byte_count,
                     'result_digest': hashlib.sha256(repr(rows).encode()).hexdigest()}
results['metadata'] = {'database': str(db), 'actual_requested_ids': len(ids),
                       'parameter_bytes': len(parameters[0].encode()),
                       'parameter_sha256': hashlib.sha256(parameters[0].encode()).hexdigest()}
connection.rollback()
connection.close()
Path('.tmp/stage9-bank-role-plan-r69.json').write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(results, ensure_ascii=False, indent=2))
