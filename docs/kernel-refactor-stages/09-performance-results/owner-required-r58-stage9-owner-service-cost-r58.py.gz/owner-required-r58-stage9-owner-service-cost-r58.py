from pathlib import Path
import cProfile, importlib, json, pstats, sys, time
w=Path(__file__).resolve().parents[1]
src=w/'.tmp/stage9-build-source-owner-r57-release'
sys.path.insert(0,str(src/'scripts'))
from stage9_source import configure_source
configure_source(src,w)
# Private overlay diagnostic, never a sealed build or page acceptance.
for name in ('query_reads','close_storage','dashboard_reads','reports'):
 m=importlib.import_module('ai_accounting.kernel.'+name)
 f=w/'src/ai_accounting/kernel'/(name+'.py')
 exec(compile(f.read_bytes(),str(f),'exec'),m.__dict__)
from ai_accounting.kernel.daemon import _prepare_static_runtime
from ai_accounting.kernel.service import LocalService
from pydantic import SecretStr
book=json.loads((w/'.tmp/stage9-owner-main12-r57-verified.json').read_text('utf-8'))
assert book['source']==str(src) and book['status']=='complete'
root=Path(book['root']); assert root.is_relative_to(w/'.tmp')
app=LocalService(root,enable_read_pool=True,_static_runtime=_prepare_static_runtime())
output=w/'.tmp/stage9-owner-service-cost-r58.json'
result={'scope':'private_overlay_resident_dispatch_diagnostic_not_browser_acceptance','source':str(src),'book':str(root),'profiles':{},'normal_dispatch_ms':{}}
try:
 with app.catalog.connection(read_only=True) as c:
  names=[r[0] for r in c.execute('SELECT login_name FROM security_owner')]
 assert names==['synthetic-stage9-owner']
 token=app.security.login(names[0],SecretStr('Synthetic-stage9-browser-only-2026')).session_token
 specs={'context':('dashboard_context',{'company_id':book['company']['id']}),
 'brief':('dashboard_brief',{'company_id':book['company']['id'],'period':'2016-12','limit':20,'preparation':'deferred'}),
 'employees':('dashboard_employees',{'company_id':book['company']['id'],'period':'2016-12','limit':20,'preparation':'deferred'}),
 'reports':('dashboard_quarterly_report',{'company_id':book['company']['id'],'year':2016,'quarter':4,'preparation':'deferred'})}
 for label,(cmd,payload) in specs.items():
  def op(): return app.dispatch(cmd,payload,session_token=token,response_format='http_json')
  op()
  prof=cProfile.Profile();raw=prof.runcall(op)
  rows=sorted(pstats.Stats(prof).stats.items(),key=lambda p:p[1][3],reverse=True)[:55]
  result['profiles'][label]=[{'function':str(Path(k[0]).name)+':'+str(k[1])+':'+k[2],'calls':v[1],'own_ms':v[2]*1000,'inclusive_ms':v[3]*1000} for k,v in rows]
  result['normal_dispatch_ms'][label]=[]
  for _ in range(3):
   start=time.perf_counter();op();result['normal_dispatch_ms'][label].append((time.perf_counter()-start)*1000)
  print(json.dumps({'page':label,'ms':result['normal_dispatch_ms'][label],'bytes':len(raw)}),flush=True)
  output.write_text(json.dumps(result,ensure_ascii=False,indent=2),'utf-8')
finally:
 if 'token' in locals(): app.security.logout(token)
 app.close()
 output.write_text(json.dumps(result,ensure_ascii=False,indent=2),'utf-8')
