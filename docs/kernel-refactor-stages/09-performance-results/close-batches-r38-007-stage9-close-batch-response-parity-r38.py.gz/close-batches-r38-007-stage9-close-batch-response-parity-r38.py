import hashlib
import importlib.util
import json
from pathlib import Path

root = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('native_ab', root / 'stage9-native-close-batch-ab.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

def differences(a, b, path=()):
    if isinstance(a, dict) and isinstance(b, dict):
        for key in sorted(a.keys() | b.keys()):
            yield from differences(a.get(key), b.get(key), path + (key,))
    elif isinstance(a, list) and isinstance(b, list):
        if len(a) != len(b):
            yield path + ('length',), len(a), len(b)
        for index, (left, right) in enumerate(zip(a, b)):
            yield from differences(left, right, path + (index,))
    elif a != b:
        yield path, a, b

rows = []
for months in (12, 48):
    for name in ('context', 'brief', 'funds', 'employees', 'assets', 'reports'):
        paths = [root / f'stage9-remaining-profile-{revision}-{months}-{name}.response.json'
                 for revision in ('r37', 'r38')]
        before, after = [json.loads(path.read_text(encoding='utf-8')) for path in paths]
        changed = list(differences(before, after))
        rows.append({
            'months': months, 'page': name,
            'raw_sha256': [hashlib.sha256(path.read_bytes()).hexdigest() for path in paths],
            'differences': [{'path': '.'.join(map(str, path)), 'before': a, 'after': b}
                            for path, a, b in changed],
            'only_allowed_differences': all(path in module.NON_BUSINESS_PATHS for path, _, _ in changed),
            'business_equal': module.comparable(before) == module.comparable(after),
        })
report = {'source_before': 'r37', 'source_after': 'r38',
          'allowed_changes': sorted('.'.join(path) for path in module.NON_BUSINESS_PATHS),
          'read_version_reason': 'Dashboard._read_context includes PROGRAM_VERSION; new code must invalidate old read tokens.',
          'rows': rows}
path = root / 'stage9-close-batch-response-parity-r38-v2.json'
path.open('x', encoding='utf-8').write(json.dumps(report, ensure_ascii=False, indent=2))
print([(row['months'], row['page'], row['business_equal'], row['only_allowed_differences']) for row in rows])
assert all(row['business_equal'] and row['only_allowed_differences'] for row in rows)
