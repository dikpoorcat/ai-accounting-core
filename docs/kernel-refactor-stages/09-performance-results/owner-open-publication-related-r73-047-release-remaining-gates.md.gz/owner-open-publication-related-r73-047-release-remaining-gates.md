# 第 9 阶段正式交付剩余收口（2026-10-02）

本页是当前源码与已有回执的整理，不是验收通过声明。本次只读源码、测试和已保存报告，没有运行测试、建库、升级、冻结或构包。先由主线程完成性能验收，再执行正式发布步骤。所有待执行命令只针对明确的隔离合成资料；不指向真实公司根。

当前固定 r70 已完成主12、主48及独立12月的注册完整核验：四项 coverage 均 verified、limitations=[]，各自真实当前开放月预览通过，见[内容与边界记录](owner-r70-content-and-boundaries.md)。主48五页真实浏览器30次刷新仍失败：**37／150次≥500ms**，简报25、资产8、报表4，资金与员工本轮无超线，见[浏览器失败组](owner-main48-browser-r70.md)。r71 银行相关受影响组84项已通过，包含原新增窄组9项，不相加；资产metadata／前向凭证护栏五文件103项已通过实际范围，原fixture和窄组失败保留；后续reverse pointer＋version＋lines缺失的source-only／repair漏检已证实，完整源／repair护栏相关55项随后通过；普通页独立前向护栏205原组保持200 passed／5 failed；生产窄公开守卫恢复既有分类后79项定向通过，不把原组回写通过。r71隔离固定候选已构造，主48 native诊断报表有≥500ms；current full integrity未运行、无本轮30次browser。r71候选固定身份与实际诊断已保存，但这些结果不构成全部受影响组或整页通过，见[展示读取范围记录](owner-display-read-scope-r71.md)。当前r73发布关系／资产重复读取统一289项通过；固定隔离候选六路native各3次均<500ms，仅诊断，主48当前完整核验进行中、browser30次未验，见[公共读取集中记录](owner-publication-proof-reuse-r72.md)。原r72的287失败及r71各组保留原身份，不相加。阶段未完成。

r67 固定回归 **132 passed / 2 failed** 的两项错误分类已在最小受影响组修正通过；后续主体缺失组 **37 passed / 2 failed** 修正后仅四个分类用例复验通过。各自原失败和局部回执保留历史身份，不改写为整组成功。旧季度 **126 passed / 1 failed** 与单例补跑同样独立保留。各组先验证新改动及实际风险，收敛后固定源码统一验收；没有新修改、新失败或新风险不重复相同大套。

## 当前确切状态

- `src/ai_accounting/kernel/schema_bundle.py:18-19` 仍是 `STATUS="draft" / VERSION=0`。合同目录实际只有公司／目录 `draft.json` 与已声明的开发来源 JSON；正式 `company/v1.json`、`catalog/v1.json`、`content-v1.json` 不存在。
- r49 等固定 `released/1` 合成源码、非空候选库和只读私有模块覆载是不同证据。前两者不是仓库正式冻结，覆载结果更不能记为固定候选验收。源码清单、合同指纹、构造来源和核验来源必须分别记录。
- 首次冻结引导、合同文件选择和源码／包构建身份的 26 项已有真实回执：26 passed、1 Windows 解码警告、40.81 秒；补 `-X utf8` 后严格单例 1 passed、29.33 秒、无该警告。见 `.tmp/stage9-contract-files-r46-results.json`，它是工具回执摘录，没有完整 stdout/JUnit，不冒充原始日志。
- draft 专用 fixture 已隔离：`draft_bundle_fixture.py`、development upgrade／rollover、replay-close 与 production verifier coverage。近期季度集中组为 **126 passed / 1 failed，354.06 秒**；六个 draft 相关模块的 74 项均通过。唯一旧季度载荷断言修正后只补跑该单例，1 passed、6.20 秒。见 `.tmp/stage9-quarterly-sources-results.json` 和对应完整 log/JUnit；不能改称原组 127 全过。旧 `formal-v1-switch-audit-r32.md` 与阶段主文档所列“生产 draft 断言待修”已被此组完成。

## 入口、已验证边界与缺口

| 项目 | 当前实现和证据性质 | 仍需实际收口 |
| --- | --- | --- |
| 正式合同创建与不覆盖 | `export_kernel_schema_contracts.py:15-65,79-107` 先算三份正文，再用 `open("x")` 独占创建；任何已存在目标拒绝，写入失败只移除本次创建文件。`test_schema_contract_export.py` 覆盖预计算失败、竞争／已存在目标、部分最后文件写入回滚、只读 check；`test_package_contract_selection.py:203` 在复制源码中经真实 subprocess 完成 candidate → 首次 freeze → check，缺少已登记合同会改变 build 并使工厂拒绝。 | 实现和隔离真实脚本路径已验证；仓库正式冻结尚未执行。性能／结构固定后切选择器、一次创建三件、核正文／SHA、只读 check；不得回写已发布 v1。 |
| 正式运行拒绝 draft／旧体系 | `versions.py:214-222` 仅接受与当前合同相同 status/version；允许旧版只适用于已登记的 released 历史。`production_bundle()` released 分支先校验固定 v1 内容合同，工厂无合同即拒绝。`daemon.py:197-199,437-439` 启动前检查全部登记库。现有 schema、foundation 测试覆盖无标识／旧身份／SQL 原文不匹配；`test_released_cli_startup_rejection.py` 已新增真实复制源码首次 freeze/check 后的 CLI／daemon 负测：draft目录、正式目录登记draft公司、旧目录、同版本公司DDL漂移、两公司合法隔离v2混版，各两个实际入口均拒绝，文件SHA／身份／登记／版本／安全行不变，无新服务元数据；只容许空协调锁。 | 这10项覆盖由8项通过＋最后修复fixture后2项定向通过组成，不是原10项全过。缺合同已由首次冻结引导单例证明工厂拒绝。最终正式源码／包对应验证仍待性能收敛后执行，复制源码结果不冒充正式包。只调用 `check_root_current` 不能冒充子进程 daemon 验收。 |
| 显式 offline upgrade | `cli.py:71-81` 直接调用 `offline_upgrade.upgrade_root`，不通过 LocalService 创建／恢复。`offline_upgrade.py:131-303` 要求 released、已有目录、完整身份和已完成目录操作；锁外预检、持 `.resident.lock` 后再次来源完整核验；公司逐库事务，目录最后迁移，源／目标按登记版本核验并比对保留历史。**不是跨库原子迁移，也不自动备份。** | 入口已实现。最终包同版 upgrade 重复执行与真实 daemon 锁拒绝待执行；大库迁移／历史摘要成本未验证。正式生产工厂目前没有 v2 合同或 migration steps，不能宣称存在正式跨版迁移产品。开发调整有独立 `upgrade-development`，不是 draft→released 转换。 |
| 公司／目录失败重试、混版启动 | `test_offline_upgrade.py:95` 经 `cli.main()` 合成 v1→v2，第二公司故障后第一公司提交，混版 `check_root_current` 拒绝，再试跳过已完成库、目录最后完成；`:153` 目标核验故障公司回滚／缺源核验器拒绝；`:181` 目录故障后公司保留、重试跳过。历史保留组覆盖证据／权威业务／任务回执／目录安全历史篡改回滚和合法新增列。 | 这些是隔离 bundle + 故障注入，不是两个正式发行包。保留原 140 项历史回执；源码收敛后按下面定向组合验收，不运行假生产 v2。最终包还应证明确实启用 released 专用烟测。 |
| 非空 v1 独立解码和领域读取 | `content_v1.py:459-563` 从固定 descriptor 重建 stored models／reference declarations，核自己的摘要及固定 v1 模块源码摘要，`verify_v1_company` 进入 `historical_content(1)`；历史上下文分派固定 source encoding、唯一键 JSON、关账、期初、清偿、报表、资料、查重、position 等读取。`test_offline_upgrade.py:198,404,422,470,654` 覆盖未来当前模型、日期类型、期初、累计和修订规则改变；`test_v1_stored_json_isolation.py` 覆盖已加载当前 decoder／别名抛错仍完成非空 v1 核验及重复键拒绝。 | 已有隔离非空测试与主12/48、独立120旧候选回执；最终正式工厂和包中重验尚未完成。v1 使用共享完整核验编排，不是全部实现另拷一套；今后改公共编排或版本分派仍要做漂移回归。此次未发现可据以扩修的真实旧源误解码路径，不把“存在 v1 文件”当领域独立性证明。 |
| 运行包文件／构建身份 | `contract_files.py` 共享明确合同选择；build 哈希有效 kernel/payroll/shared Python 及选定合同，缺合同带精确相对名的缺失标记；包 manifest 含 source_build_id，并比对复制前后源码与包运行 build。packager 在复制前共同拒绝既有 output/ZIP/relocated/verification JSON，验证报告用 open("x") 独占创建；精确文件清单/SHA，拒绝业务库、env 和宿主依赖；ZIP 重定位后受控包内解释器自检。 | 四目标护栏及inventory本轮11项通过（stdout0.65秒），包含四目标各自既存拒绝且原件不变；这是早拒绝测试，不是实际完整构包。Ruff初次仅E501，换行修后tool stdout通过，无独立Ruff日志；原件见[目标护栏manifest](owner-package-targets-r71-manifest.json)。文件选择与身份已有各自定向回执；本轮改动后没有最终独立包。使用新输出且禁止 `--skip-validation`，保存完整构包 stdout/stderr、ZIP/manifest/source inventory SHA、verification JSON。Python3.12.13/SQLite3.53.1 是脚本实际门禁。 |
| 包内升级自检与 MCP | `verify_local_package.py:1988-2034` 经默认启动器建立独立默认根，released 才执行 `verify_daemon_upgrade_rejection`：实际 CLI 返回 service_active、PID和健康不变、目录不变。`:2221-2259` 另验 harness 锁、停服务后的两次同版 CLI；`:2038-2102` 是真实 stdio 客户端初始化／list_tools／业务查询。`stage9_package_agent_harness.py` 提供实际 AI 经包内 CLI/MCP 的请求回执和原生批准转接。两历史开发包为 draft，跳过 released upgrade 专用分支。 | 最终 released 包自检及实际 AI MCP 复验均未完成；握手、自检辅助函数和 mock subprocess 测试不是实际 AI。按当前用户模型要求和任务复杂度选模型，历史 GPT-6 Sol 记录不是未来固定模型要求。 |
| 规模与性能证据 | r70主12／主48／独立12当前注册完整核验及真实开放月预览已完成；主48真实浏览器37／150超线，尚未达标。r71银行相关组84项通过且已包含原新增9项，资产metadata／前向护栏103项通过其实际范围，后续完整源／repair护栏55项通过其实际范围，普通页205原组200通过／5分类断言失败且selected-source含两份前端变化，分类修复后79定向通过且该次source清单一致；r71隔离候选已固定，主48native诊断有报表超500ms，current full integrity未运行／本轮30次browser未验；正式v1完整组／性能未验，未成为新固定候选验收。旧独立120完整核验、旧候选240/1536MiB mixed原件的完整核验／备份恢复／内存诊断及evidence工具微型流程各保留原来源身份；大样本承接dry-run不是当前目标完整核验。r73统一289项通过，固定候选六路native诊断成功；当前主48完整核验进行中、browser30次未验，见[公共读取记录](owner-publication-proof-reuse-r72.md)。period digest集合遍历1处及close map全构造2处为只读候选，未修改／未计时。HTTP与插桩不是浏览器纯计时。 | 最终固定正式源码下，主／独立120完整核验及240/1536MiB两档完整 verify/backup/restore/restored_verify、前台影响均需对应报告。五页30次、冷开、切换和按需详情由主线程性能任务验收，不能借历史、局部工作量或覆载诊断替代。 |

## 可执行顺序和命令

以下是**待执行**清单，本次未运行。顺序为：三组修正收敛后固定代码，统一完成受影响验证及阶段性能门槛；冻结正式 v1；对冻结后源码执行升级／固定 v1 历史组和主／独立 120 月完整核验；完成两档原件规模证据；构建自验证正式包；最后由实际 AI 通过该包 MCP 完成隔离合成业务验收。冻结或构包后若源码、静态产物或运行条件变化，重做受影响步骤。输出路径须不存在，所有 root 都是隔离合成根；不使用真实公司根。PowerShell 在仓库根运行，本机 Python 必须用仓库环境。

1. 性能与结构收敛、固定组通过后，审阅只读候选，再将 `schema_bundle.STATUS/VERSION` 切为 released/1 并一次性冻结。选择器变化会改变 build。冻结后保存三份合同正文摘要及 SHA、最终源码清单与 production bundle 身份；随后只读检查并运行正式合同选择／拒绝测试。合同创建后不得覆盖或重建。

```powershell
.tmp-kernel-venv/Scripts/python.exe scripts/export_kernel_schema_contracts.py --candidate-v1 > .tmp/stage9-final-v1-candidate.json
# 性能完成后按本阶段已批准计划先修改 STATUS/VERSION；不要先调用 production_bundle 引导冻结。
.tmp-kernel-venv/Scripts/python.exe scripts/export_kernel_schema_contracts.py --freeze-v1
.tmp-kernel-venv/Scripts/python.exe scripts/export_kernel_schema_contracts.py --check
.tmp-kernel-venv/Scripts/python.exe -X utf8 -m pytest tests/kernel/test_schema_contract_export.py tests/kernel/test_package_contract_selection.py tests/kernel/test_stage9_production_verifier_coverage.py tests/kernel/test_schema_bundles.py tests/kernel/test_migration_contracts.py tests/kernel/test_released_cli_startup_rejection.py -q --junitxml=.tmp/stage9-final-contracts.xml
```

输入是最终源码及候选合同；冻结输出为 `company/v1.json`、`catalog/v1.json`、`content-v1.json`。candidate、freeze 和 check 只验证合同生成、结构和指纹，不证明性能、非空 v1 领域解码或最终运行包。

2. 运行结构／内容／升级保留组。已有测试可以复用，不删旧业务断言，也不把真实生产工厂注入可接受 draft 的旁路。上表明确正式运行负测已用复制源码完成；最终产物发生相关实现变化时纳入 `test_released_cli_startup_rejection.py` 对应复验；同一个最终源码组跑完后只重验新改范围。

```powershell
.tmp-kernel-venv/Scripts/python.exe -m pytest tests/kernel/test_offline_upgrade.py tests/kernel/test_offline_upgrade_history_preservation.py tests/kernel/test_stage9_backup_upgrade_history.py tests/kernel/test_v1_stored_json_isolation.py tests/kernel/test_history_reads_v1_warm_cache.py tests/kernel/test_versions_recovery.py -q --junitxml=.tmp/stage9-final-upgrade-history.xml
.tmp-kernel-venv/Scripts/python.exe -m pytest tests/kernel/test_stage9_package_file_inventory.py tests/kernel/test_stage9_package_upgrade_smoke.py tests/kernel/test_stage9_package_parallel_smoke.py tests/kernel/test_stage9_package_owner_contracts.py -q --junitxml=.tmp/stage9-final-package-helper-tests.xml
```

这两组的 isolated/mock/fault 路径标签必须保留。比如 package_upgrade_smoke 模拟 subprocess 和目录状态，不能替代下方真实包自检。正式首版没有合法旧 released 源库时，同版 upgrade 只应 verified_skip；不为演示升级而向生产登记合成 v2。固定 v1 历史读取须由最终 released 工厂对隔离非空 v1 合成库执行完整核验；通用 helper、draft 夹具或仅存在 v1 文件都不算证据。生产工厂目前没有正式跨版 v2 migration steps，不能把同版锁拒绝或 verified_skip 描述成跨版本升级能力。

3. 已完成同结构合成根的独立注册核验使用真实 `--verify-only` 入口，不能把复制／build-only/逐表日志当完整核验。下面两个变量必须绑定已经完成构造的主／独立120合成根；`$releaseSource` 必须绑定本次最终封存的正式源码目录，不绑定私有覆载。

```powershell
.tmp-kernel-venv/Scripts/python.exe scripts/benchmark_stage9.py --source $releaseSource --workspace . --root $main120Root --output .tmp/stage9-final-main120-verified.json --months 120 --employees 50 --businesses 1000 --read-existing --verify-only
.tmp-kernel-venv/Scripts/python.exe scripts/benchmark_stage9_independent.py --source $releaseSource --workspace . --root $independent120Root --output .tmp/stage9-final-independent120-verified.json --months 120 --objects 50 --businesses 1000 --resume --verify-only
.tmp-kernel-venv/Scripts/python.exe scripts/benchmark_stage9_evidence.py --source $releaseSource --workspace . --root .tmp/stage9-final-evidence240 --output .tmp/stage9-final-evidence240.json --size-mib 240 --profile mixed
.tmp-kernel-venv/Scripts/python.exe scripts/benchmark_stage9_evidence.py --source $releaseSource --workspace . --root .tmp/stage9-final-evidence1536 --output .tmp/stage9-final-evidence1536.json --size-mib 1536 --profile mixed
```

Evidence 默认 `--foreground http`，报告只能说明默认前台HTTP；如需浏览器前台，显式加 `--foreground browser --node $node --playwright-module $playwrightModule`，按工具实际诊断范围解释。两档分别保存原件分布、digest、ZIP摘要和实际服务树同采样峰值，不能相加各进程各自历史峰值。

脚本预检按 mixed 档位估算约需 `4 × size + 512 MiB` 可用内存：240 MiB 档约 1,472 MiB，1536 MiB 档约 6,656 MiB。输入是分别新建的合成根和最终源码；预期输出是完整 verify／backup／restore／restored-verify 报告、原件与 ZIP 摘要及同时间服务树内存样本。资源不足时记录未执行，不降低档位或改用真实资料。默认测 HTTP 前台读取，不能替代浏览器整页 500ms 验收。

4. 用最终源码及正式静态产物构包；输出名只是待用示例，output目录、ZIP、relocated目录或verification JSON任一已存在均拒绝，须另选全新名称。以下会执行包内完整自检，因此不与浏览器纯计时并行。

```powershell
.tmp-kernel-venv/Scripts/python.exe scripts/package_local_kernel.py --output .tmp/stage9-final-released-v1
Get-FileHash -Algorithm SHA256 .tmp/stage9-final-released-v1/manifest.json
Get-FileHash -Algorithm SHA256 .tmp/stage9-final-released-v1.zip
```

应产生 `.tmp/stage9-final-released-v1-verification.json` 和 `-relocated`；报告须 status=passed、manifest/runtime/source_build_id一致、database_formats为released/1，并包含非空 `packaged_offline_upgrade`。单独再次运行包自检只在需要排错且其validation目录不存在时使用包内 `runtime/python.exe -I -B -X utf8 tools/verify_local_package.py`；不要在已有验收根重复创建或覆盖。

包启动器 `.cmd/.ps1` 仅在 FINANCE_DATA_ROOT 未设置时默认选包内 `data/kernel-released`；`daemon.default_root()` 本身要求明确环境变量或 `--root`，不按目录名推断正式版本。默认根由自检在重定位副本中创建，不是软件 ZIP 中预装账务。

5. 经该包实际 MCP 复验。先按 `stage9_package_agent_harness.py` 的 `host()` 入口准备新 `.tmp/stage9-final-agent`：`seed.json` 必须为 status=complete、root 精确指向该目录/data、含一个明确开放月份的完整合成报告，数据库版本与包一致。host 会在该隔离根 provision 合成负责人并启动 HTTP 与包内 stdio MCP；握手及其简报／资金自检不等于实际 AI 子智能体完成验收。实际 AI 必须连接该 host，经 MCP 工具完成已准备请求并保存原始请求、返回和任务记录。关账时另走 harness 的 `native` 通道提交明确 approve 请求，保留批准回执；只可使用该合成根的测试凭据。

```powershell
.tmp/stage9-final-released-v1/runtime/python.exe -I -X utf8 tests/kernel/stage9_package_agent_harness.py host .tmp/stage9-final-agent .tmp/stage9-final-released-v1
# host运行期间，实际AI提交已准备的类型化请求；示例文件由该复验任务生成。
.tmp/stage9-final-released-v1/runtime/python.exe -I -X utf8 tests/kernel/stage9_package_agent_harness.py call .tmp/stage9-final-agent .tmp/stage9-final-agent/request.json
# 如关账需要负责人密码批准，使用当前预览对应的明确 approve 请求走 native 通道：
.tmp/stage9-final-released-v1/runtime/python.exe -I -X utf8 tests/kernel/stage9_package_agent_harness.py native .tmp/stage9-final-agent .tmp/stage9-final-agent/approve-request.json
```

仅启动 host 不算复验完成。需要实际业务工具回执证明公司切换、工资／月结、丢响应查询、更正、办理、备份恢复和停止边界；原生批准只消费当前准确预览，不能脚本猜审批结果。现有 harness 的 host 会 provision 合成负责人，所以必须是隔离合成根，绝不指向现有服务／真实身份。

最后按每项真实回执更新路线图和46项状态。任何冻结／构包后修正若改变已测实现、静态产物或运行条件，补对应受影响验证；不把上面的待执行命令写成已通过，不以旧失败后局部通过改写初次整组结果。

## 真实 released CLI／daemon 负测回执

新增文件 `tests/kernel/test_released_cli_startup_rejection.py`，生产代码未改；测试中的合法v2通过独立合成增量合同和真实 `versions.upgrade` 构造并核验，只属于fixture。复制源码工厂只接受当前released1、只登记released1／v1核验器，不把该v2写到其生产合同目录。

初轮10个setup errors、21.93秒是新fixture误把保留draft合同映射条目视作运行可接受版本；修正后6 failed/4 passed、70.14秒，6项因新fixture原生SQLite重建非私有sidecar／旧文件权限在格式门禁之前被拒绝。改用现有私有目录／文件／连接后2 failed/8 passed、71.72秒；最后2项是Store.create正确拒绝旧sidecar的fixture创建错误，改为全新draft公司独立登记、未替换任何文件。只补跑该2项：2 passed、8 deselected、33.83秒。所有初失败保留；不改写任一整组结果。Ruff最终通过。

实际最后两条命令：

```powershell
.tmp-kernel-venv/Scripts/python.exe -X utf8 -m pytest tests/kernel/test_released_cli_startup_rejection.py -q --junitxml=.tmp/stage9-released-cli-rejection-repaired.xml
.tmp-kernel-venv/Scripts/python.exe -X utf8 -m pytest tests/kernel/test_released_cli_startup_rejection.py -q -k draft_company --junitxml=.tmp/stage9-released-cli-rejection-draft-company.xml
```

完整每轮stdout／JUnit及命令、错误边界见 `.tmp/stage9-released-cli-rejection-results.json`。没有正式freeze仓库、构完整包、启动真实根或停止既有服务。五类×两实际入口的拒绝均已覆盖，最终源码／包交付仍按本页剩余项验收。
