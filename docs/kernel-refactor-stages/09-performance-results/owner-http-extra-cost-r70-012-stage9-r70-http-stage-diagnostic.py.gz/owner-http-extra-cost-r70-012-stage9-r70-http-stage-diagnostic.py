"""Contended fixed-r70 synthetic public HTTP stage diagnostic; no acceptance claim."""

from __future__ import annotations

import cProfile
import hashlib
import json
import pstats
import sys
import threading
import time
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from pathlib import Path

WORKSPACE = Path(__file__).resolve().parents[1]
SOURCE = WORKSPACE / ".tmp/stage9-build-source-owner-r70-release"
ROOT = WORKSPACE / ".tmp/stage9-owner-main12-r43"
BOOK = WORKSPACE / ".tmp/stage9-owner-main12-r70-verified.json"
OUTPUT = WORKSPACE / ".tmp/stage9-r70-http-stage-diagnostic.json"
SOURCE_SHA = "402024802800938685bfb59983e6d717ae32fa55c555bad0a3ced3f3d8a8e404"
BOOK_SHA = "44bc771e602f52b67fb9ede8fcc2f27798bcb6bccfb444afc898e261d7e5e348"
COMPANY_SHA = "c9f9f7051bca67f1241ee5c89676fb9476bc819dc8f92c1a0c0bd1e940f459cb"
CATALOG_SHA = "b484d315272bb64de3856b458f04d2d4881da05db7552250864260916c69a4ee"
CONTENT_SHA = "ac6d042b8478d87add37376fab5e5c9b4ae99b6ccab89c1e2f52678b779fe5f8"
COMPANY_ID = "c73e4f4d144340c98ade475b8dd8c8b9"
DATABASE_ID = "6cc5f6cbe6cd402ebdfd072195398780"
TAXPAYER = "91310000123456789S"
PERIOD = "2016-12"
EXPECTED_STATE = [1, 514, 336, 80, 12058, 0]
COVERAGE = {key: "verified" for key in (
    "sources", "historical_adoption", "projections", "read_indexes"
)}


def sha(path):
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def load_json(path):
    return json.loads(path.read_text("utf-8"))


def guard_book():
    if sha(BOOK) != BOOK_SHA:
        raise ValueError("Pinned main12 report bytes changed")
    book = load_json(BOOK)
    company = {
        "id": COMPANY_ID, "taxpayer_id": TAXPAYER, "name": "阶段九合成规模企业",
        "path": str(ROOT / TAXPAYER / "company.sqlite"), "database_id": DATABASE_ID,
    }
    if (
        ROOT.parent != WORKSPACE / ".tmp"
        or book.get("root") != str(ROOT)
        or book.get("source") != str(SOURCE)
        or book.get("company") != company
        or book.get("status") != "complete"
        or book.get("requested_months") != 12
        or book.get("employee_count") != 50
        or book.get("monthly_business_count") != 1000
        or book.get("business_count") != 12000
        or book.get("distribution") != "mixed_cumulative"
        or book.get("default_page_limit") != 20
        or book.get("integrity", {}).get("status") != "verified"
        or book["integrity"].get("limitations") != []
        or book["integrity"].get("coverage") != COVERAGE
        or book.get("integrity_contract") != {
            "family": "ai-accounting-kernel/2", "kind": "company", "status": "released",
            "version": 1, "fingerprint": COMPANY_SHA,
        }
        or len(book.get("months", [])) != 12
        or len(book.get("snapshots", {})) != 12
    ):
        raise ValueError("Pinned synthetic report identity, contract or dimensions changed")
    for index, month in enumerate(book["months"]):
        period = f"2016-{index + 1:02d}"
        snapshot = book["snapshots"].get(period, {})
        if (month.get("period") != period or month.get("business_count") != 1000
                or month.get("closed") is not (index < 11)
                or snapshot.get("closed") is not (index < 11)
                or not snapshot.get("owner_confirmation") or not snapshot.get("preview_digest")):
            raise ValueError("Pinned synthetic month or original snapshot changed")
    current = book.get("verified_open_preview", {})
    if (current.get("source") != str(SOURCE) or current.get("company_id") != COMPANY_ID
            or current.get("database_id") != DATABASE_ID or current.get("period") != PERIOD
            or current.get("state") != EXPECTED_STATE
            or current.get("epochs") != {"accounting": 514, "material": 336, "management": 80}
            or current.get("construction_preview_digest")
            != book["snapshots"][PERIOD]["preview_digest"] or not current.get("digest")):
        raise ValueError("Pinned current preview proof changed")
    return book


def profile_rows(profile):
    result = []
    for (filename, line, name), (_, calls, own, cumulative, _) in pstats.Stats(profile).stats.items():
        result.append({
            "function": f"{Path(filename).name}:{line}:{name}", "calls": calls,
            "own_ms": own * 1000, "inclusive_ms": cumulative * 1000,
        })
    return sorted(result, key=lambda value: value["inclusive_ms"], reverse=True)[:100]


def main():
    if OUTPUT.exists():
        raise FileExistsError("Preserve previous stage diagnostic output")
    for path in WORKSPACE.joinpath(".tmp").glob("stage9-r70-http-stage-diagnostic-*.prof"):
        raise FileExistsError("Preserve previous profiler artifacts")
    book = guard_book()
    sys.path.insert(0, str(SOURCE / "scripts"))
    from snapshot_stage9_source import _digest, _inventory
    manifest = load_json(SOURCE / "source-manifest.json")
    inventory = _inventory(SOURCE)
    if (manifest.get("status") != "complete" or manifest.get("target") != str(SOURCE)
            or manifest.get("sha256") != SOURCE_SHA or manifest.get("files") != inventory
            or manifest.get("file_count") != len(inventory) or _digest(inventory) != SOURCE_SHA):
        raise ValueError("Fixed r70 inventory changed")
    from stage9_source import configure_source, require_source_module
    configure_source(SOURCE, WORKSPACE)
    from pydantic import SecretStr, TypeAdapter
    from ai_accounting.kernel import command_schema, response_contracts, runtime
    from ai_accounting.kernel import resident_reads
    from ai_accounting.kernel.security import service as security_service
    from ai_accounting.kernel.catalog import Catalog
    from ai_accounting.kernel.daemon import _prepare_static_runtime
    from ai_accounting.kernel.http import create_server
    from ai_accounting.kernel.schema_bundle import production_bundle
    from ai_accounting.kernel.service import LocalService
    from ai_accounting.kernel.versions import database_format, verify_schema
    for module, relative in (
        (runtime, "runtime.py"), (resident_reads, "resident_reads.py"),
        (response_contracts, "response_contracts.py"),
    ):
        require_source_module(module, SOURCE, "src/ai_accounting/kernel/" + relative)
    bundle = production_bundle()
    if (bundle.status != "released" or bundle.current_versions != {"company": 1, "catalog": 1}
            or bundle.current("company")["sha256"] != COMPANY_SHA
            or bundle.current("catalog")["sha256"] != CATALOG_SHA
            or load_json(SOURCE / "src/ai_accounting/kernel/schema_contracts/content-v1.json")
            ["sha256"] != CONTENT_SHA):
        raise ValueError("Pinned released contracts changed")

    app = None
    server = None
    server_thread = None
    token = None
    restored = []
    observations = {}
    samples = []
    local = threading.local()
    records_lock = threading.Lock()
    modes = {}
    pool_labels = {}
    report = {
        "status": "failed", "scope": "public_http_stage_diagnostic_not_acceptance",
        "preparation_load": "main48 preview/instrument task could overlap script preparation",
        "measurement_load": "root reported all heavy sessions ended before measured requests",
        "source": str(SOURCE), "source_sha256": SOURCE_SHA,
        "report": str(BOOK), "report_sha256": BOOK_SHA, "root": str(ROOT),
        "company_id": COMPANY_ID, "database_id": DATABASE_ID, "period": PERIOD,
        "contract_fingerprints": {"company": COMPANY_SHA, "catalog": CATALOG_SHA,
                                  "content": CONTENT_SHA},
        "method": "real loopback public GET via urllib Bearer; warm3 per route, one stages sample, "
                  "one handler-thread cProfile sample, one context/main concurrent pair per page",
        "limitations": [
            "Preparation overlap and measured-stage load are separate; no pure 30-sample claim",
            "Each measured mode is one sample, never a browser/native acceptance distribution",
            "Nested stage wall times overlap and must not be summed",
            "thread_cpu_ms excludes other request threads; cProfile adds overhead",
            "pool PRAGMA page_count/cache_size are diagnostic reads included in handler total",
            "urllib JSON parsing is Python and measures no browser Ajv/Vue/render cost",
            "close-review is unprepared; no preview_close or preview/cache construction",
            "TCP_NODELAY control was negative; frame staircases do not prove transport delay",
        ],
    }

    def record_event(name, started, cpu, **fields):
        record = getattr(local, "record", None)
        if record is not None:
            record["stages"].append({
                "name": name, "wall_ms": (time.perf_counter() - started) * 1000,
                "thread_cpu_ms": (time.thread_time() - cpu) * 1000, **fields,
            })

    def install(owner, name, label, *, auth=False, auth_only=False):
        original = getattr(owner, name)

        def wrapped(*args, **kwargs):
            if auth_only and not getattr(local, "auth_depth", 0):
                return original(*args, **kwargs)
            started, cpu = time.perf_counter(), time.thread_time()
            if auth:
                local.auth_depth = getattr(local, "auth_depth", 0) + 1
            try:
                return original(*args, **kwargs)
            finally:
                if auth:
                    local.auth_depth -= 1
                record_event(label, started, cpu)

        setattr(owner, name, wrapped)
        restored.append((owner, name, original))

    def exact_state():
        with app.catalog.connection(read_only=True) as connection:
            connection.execute("BEGIN")
            verify_schema(connection, bundle=bundle, kind="catalog")
            if [dict(row) for row in connection.execute("SELECT * FROM company")] != [book["company"]]:
                raise ValueError("Exact catalog company changed")
            owners = [row[0] for row in connection.execute("SELECT login_name FROM security_owner")]
            if owners != ["synthetic-stage9-owner"]:
                raise ValueError("Only the existing known synthetic owner is accepted")
        store = app.catalog.bind(COMPANY_ID, read_pool=app.read_pool)
        with store.connection(read_only=True) as connection:
            connection.execute("BEGIN")
            if database_format(connection, bundle=bundle) != book["integrity_contract"]:
                raise ValueError("Actual installed company contract changed")
            if list(connection.execute("SELECT * FROM state WHERE id=1").fetchone()) != EXPECTED_STATE:
                raise ValueError("Exact synthetic state changed")
            actual_identity = dict(connection.execute(
                "SELECT company_id,taxpayer_id,database_id FROM identity WHERE id=1"
            ).fetchone())
            if actual_identity != {"company_id": COMPANY_ID, "taxpayer_id": TAXPAYER,
                                   "database_id": DATABASE_ID}:
                raise ValueError("Exact synthetic database identity changed")

    try:
        app = LocalService(ROOT, enable_read_pool=True, _static_runtime=_prepare_static_runtime())
        exact_state()
        login = app.security.login("synthetic-stage9-owner", SecretStr(
            "Synthetic-stage9-browser-only-2026"
        ))
        token = login.session_token
        server, _capability = create_server(
            app, port=0, static_directory=SOURCE / "src/ai_accounting/static/dashboard"
        )
        handler = server.RequestHandlerClass
        original_get = handler.do_GET

        def observed_get(self):
            ident = self.headers.get("X-Stage9-Diagnostic-ID")
            mode = modes.get(ident, "warm")
            record = None if mode == "warm" else {
                "request_id": ident, "mode": mode, "thread_id": threading.get_ident(),
                "path": urllib.parse.urlsplit(self.path).path, "stages": [], "pool": [],
            }
            local.record = record
            started, cpu = time.perf_counter(), time.thread_time()
            profiler = cProfile.Profile() if mode == "cprofile" else None
            if profiler:
                profiler.enable()
            try:
                return original_get(self)
            finally:
                if profiler:
                    profiler.disable()
                if record is not None:
                    record["handler_wall_ms"] = (time.perf_counter() - started) * 1000
                    record["handler_thread_cpu_ms"] = (time.thread_time() - cpu) * 1000
                    if profiler:
                        artifact = WORKSPACE / f".tmp/stage9-r70-http-stage-diagnostic-{ident}.prof"
                        profiler.dump_stats(str(artifact))
                        record["profile_artifact"] = str(artifact)
                        record["profile_top"] = profile_rows(profiler)
                    with records_lock:
                        observations[ident] = record
                local.record = None

        handler.do_GET = observed_get
        restored.append((handler, "do_GET", original_get))
        original_reply = handler.reply

        def observed_reply(self, status, body, *args, **kwargs):
            record = getattr(local, "record", None)
            if record is not None:
                record["response_status"] = status
                record["response_bytes"] = len(body)
            started, cpu = time.perf_counter(), time.thread_time()
            try:
                return original_reply(self, status, body, *args, **kwargs)
            finally:
                record_event("handler_reply", started, cpu)

        handler.reply = observed_reply
        restored.append((handler, "reply", original_reply))
        install(command_schema, "validate_command", "validate_command")
        install(security_service.SecurityService, "authorize", "authorize", auth=True)
        install(security_service, "connect", "auth_connect", auth_only=True)
        install(runtime._PrivateConnection, "commit", "auth_commit", auth_only=True)
        install(Catalog, "bind", "catalog_bind")
        install(Catalog, "_bound_store", "catalog_bound_store")
        install(LocalService, "dispatch", "service_dispatch_total")
        install(LocalService, "_dispatch", "service_dispatch_body")
        install(LocalService, "dashboard_context", "dashboard_context_body")
        install(response_contracts, "validate_response", "validate_response")
        install(TypeAdapter, "dump_json", "response_dump_json")
        original_transaction = security_service.SecurityService._transaction

        @contextmanager
        def observed_transaction(self):
            cm = original_transaction(self)
            started, cpu = time.perf_counter(), time.thread_time()
            connection = cm.__enter__()
            record_event("auth_transaction_enter", started, cpu)
            try:
                yield connection
            except BaseException:
                exc = sys.exc_info()
                started, cpu = time.perf_counter(), time.thread_time()
                try:
                    suppressed = cm.__exit__(*exc)
                finally:
                    record_event("auth_transaction_exit", started, cpu)
                if not suppressed:
                    raise
            else:
                started, cpu = time.perf_counter(), time.thread_time()
                try:
                    cm.__exit__(None, None, None)
                finally:
                    record_event("auth_transaction_exit", started, cpu)

        security_service.SecurityService._transaction = observed_transaction
        restored.append((security_service.SecurityService, "_transaction", original_transaction))
        original_borrow = resident_reads.ResidentReadPool.borrow

        @contextmanager
        def observed_borrow(self, store):
            started, cpu = time.perf_counter(), time.thread_time()
            cm = original_borrow(self, store)
            connection = cm.__enter__()
            record_event("pool_borrow_enter", started, cpu)
            record = getattr(local, "record", None)
            if record is not None:
                with records_lock:
                    key = id(connection)
                    if key not in pool_labels:
                        pool_labels[key] = f"physical_connection_{len(pool_labels) + 1}"
                    label = pool_labels[key]
                pragma_started, pragma_cpu = time.perf_counter(), time.thread_time()
                record["pool"].append({
                    "physical_connection": label, "python_connection_id": key,
                    "page_count": connection.execute("PRAGMA page_count").fetchone()[0],
                    "cache_size": connection.execute("PRAGMA cache_size").fetchone()[0],
                })
                record_event("pool_diagnostic_pragmas", pragma_started, pragma_cpu)
            try:
                yield connection
            except BaseException:
                exc = sys.exc_info()
                started, cpu = time.perf_counter(), time.thread_time()
                try:
                    suppressed = cm.__exit__(*exc)
                finally:
                    record_event("pool_borrow_exit", started, cpu)
                if not suppressed:
                    raise
            else:
                started, cpu = time.perf_counter(), time.thread_time()
                try:
                    cm.__exit__(None, None, None)
                finally:
                    record_event("pool_borrow_exit", started, cpu)

        resident_reads.ResidentReadPool.borrow = observed_borrow
        restored.append((resident_reads.ResidentReadPool, "borrow", original_borrow))
        server_thread = threading.Thread(target=server.serve_forever, daemon=True)
        server_thread.start()
        base = f"http://127.0.0.1:{server.server_port}/api/dashboard/"
        authorization = "Bearer " + token.get_secret_value()

        def request(action, parameters, *, ident, mode, barrier=None):
            modes[ident] = mode
            req = urllib.request.Request(base + action + "?" + urllib.parse.urlencode(parameters),
                                         headers={"Authorization": authorization,
                                                  "X-Stage9-Diagnostic-ID": ident})
            if barrier is not None:
                barrier.wait(timeout=15)
            started, cpu = time.perf_counter(), time.thread_time()
            with urllib.request.urlopen(req, timeout=120) as response:
                status, raw = response.status, response.read()
            wall_ms, cpu_ms = ((time.perf_counter() - started) * 1000,
                              (time.thread_time() - cpu) * 1000)
            parse_started = time.perf_counter()
            payload = json.loads(raw)
            parse_ms = (time.perf_counter() - parse_started) * 1000
            if status != 200 or not isinstance(payload, dict):
                raise ValueError("Actual public HTTP request failed")
            if action == "context":
                if payload["current_company"]["company_id"] != COMPANY_ID:
                    raise ValueError("Public context company mismatch")
            elif action == "close-review":
                if payload["company_id"] != COMPANY_ID or payload["period"] != PERIOD:
                    raise ValueError("Public close-review identity mismatch")
                if payload["state"] != "unprepared" or payload["owner_review"] is not None:
                    raise ValueError("Diagnostic must not consume a prepared preview")
            else:
                if payload["read_context"]["company_id"] != COMPANY_ID:
                    raise ValueError("Public dashboard company mismatch")
                if action == "quarterly-report":
                    if (payload["period"]["year"], payload["period"]["quarter"]) != (2016, 4):
                        raise ValueError("Public report quarter mismatch")
                    if [value["key"] for value in payload["statements"]] != [
                        "balance_sheet", "profit_statement", "cash_flow_statement"
                    ]:
                        raise ValueError("Full three-statement response required")
                else:
                    if payload["selected_period"]["key"] != PERIOD or payload["data"] is None:
                        raise ValueError("Public dashboard period/data mismatch")
                    for collection in payload["data"]["collections"].values():
                        page = collection["page"]
                        if len(collection["items"]) != min(20, page["filtered_count"]):
                            raise ValueError("Default collection must retain 20-row first page")
            return {
                "request_id": ident, "mode": mode, "action": action, "status": status,
                "response_bytes": len(raw), "response_sha256": hashlib.sha256(raw).hexdigest(),
                "client_receive_wall_ms": wall_ms, "client_receive_thread_cpu_ms": cpu_ms,
                "client_python_json_parse_ms": parse_ms,
                **({"review_state": payload["state"]} if action == "close-review" else {}),
            }

        month = {"company_id": COMPANY_ID, "period": PERIOD,
                 "preparation": "deferred", "limit": 20}
        specs = [("context", {"company_id": COMPANY_ID})]
        specs += [(name, dict(month)) for name in ("brief", "funds", "employees", "assets")]
        specs.append(("quarterly-report", {"company_id": COMPANY_ID, "year": 2016,
                                            "quarter": 4, "preparation": "deferred"}))
        for action, parameters in specs:
            for number in range(3):
                request(action, parameters, ident=f"warm-{action}-{number}", mode="warm")
            print(json.dumps({"phase": "warm3_complete", "action": action}), flush=True)
        report["measured_stages_start_epoch_ms"] = time.time() * 1000
        for mode in ("stages", "cprofile"):
            for action, parameters in specs:
                samples.append(request(action, parameters, ident=f"{mode}-{action}", mode=mode))
                print(json.dumps({"phase": mode, "action": action, "status": "complete"}),
                      flush=True)
        concurrent = []
        for action, parameters in specs[1:]:
            barrier = threading.Barrier(2)
            started = time.perf_counter()
            with ThreadPoolExecutor(max_workers=2) as executor:
                context_future = executor.submit(request, "context", specs[0][1],
                                                  ident=f"pair-{action}-context",
                                                  mode="concurrent", barrier=barrier)
                main_future = executor.submit(request, action, parameters,
                                               ident=f"pair-{action}-main",
                                               mode="concurrent", barrier=barrier)
                paired = [context_future.result(), main_future.result()]
            samples.extend(paired)
            concurrent.append({"main_action": action,
                               "client_pair_wall_ms": (time.perf_counter() - started) * 1000,
                               "request_ids": [sample["request_id"] for sample in paired]})
            print(json.dumps({"phase": "concurrent_context_main", "action": action,
                              "status": "complete"}), flush=True)
        samples.append(request("close-review", {"company_id": COMPANY_ID, "period": PERIOD},
                               ident="aux-close-review", mode="stages"))
        report["measured_stages_end_epoch_ms"] = time.time() * 1000
        server.shutdown()
        server_thread.join(timeout=5)
        server.server_close()
        server = None
        if set(observations) != {sample["request_id"] for sample in samples}:
            raise ValueError("Every measured public request needs its handler record")
        for sample in samples:
            if sample["response_bytes"] != observations[sample["request_id"]]["response_bytes"]:
                raise ValueError("Public response byte count mismatch")
        exact_state()
        guard_book()
        report.update(status="complete", business_state_identity_unchanged=True,
                      samples=samples, requests=observations, concurrent_pairs=concurrent,
                      physical_connections=pool_labels, warmups_per_route=3,
                      total_measured_requests=len(samples), total_warm_requests=18)
    except BaseException as error:
        report.update(error_type=type(error).__name__, samples=samples, requests=observations)
        raise
    finally:
        for owner, name, original in reversed(restored):
            setattr(owner, name, original)
        if server is not None:
            server.shutdown()
            server.server_close()
        if server_thread is not None:
            server_thread.join(timeout=5)
        if app is not None:
            try:
                if token is not None:
                    app.security.logout(token)
                    report["own_session_logged_out"] = True
            finally:
                app.close()
        with OUTPUT.open("x", encoding="utf-8") as handle:
            json.dump(report, handle, ensure_ascii=False, indent=2)
        print(json.dumps({"status": report["status"], "output": str(OUTPUT),
                          "measured_requests": len(samples),
                          "own_session_logged_out": report.get("own_session_logged_out", False)}),
              flush=True)


if __name__ == "__main__":
    main()
