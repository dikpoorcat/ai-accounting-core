"""Fixed-code SQLite page-cache diagnostic; never browser acceptance."""
from pathlib import Path
import gc
import hashlib
import json
import sys
import time

workspace = Path(__file__).resolve().parents[1]
source = workspace / '.tmp/stage9-build-source-owner-r69-release'
sys.path.insert(0, str(source / 'scripts'))
from stage9_source import configure_source
configure_source(source, workspace)
from ai_accounting.kernel import resident_reads
from ai_accounting.kernel.catalog import Catalog
from ai_accounting.kernel.dashboard import Dashboard
from ai_accounting.kernel.daemon import _prepare_static_runtime
from ai_accounting.kernel.engine import Engine
from ai_accounting.kernel.resident_reads import ResidentReadPool
from benchmark_stage9_boundaries import _rss_bytes

book = json.loads((workspace / '.tmp/stage9-owner-main48-r63-verified.json').read_text('utf-8'))
assert book['status'] == 'complete' and book['integrity']['status'] == 'verified'
assert not book['integrity']['limitations']
root = Path(book['root'])
assert root == workspace / '.tmp/stage9-owner-main48-r63'
_prepare_static_runtime()
catalog = Catalog(root)
out = {
    'scope': 'native_physical_SQLite_page_cache_diagnostic_not_browser_acceptance',
    'source': str(source), 'root': str(root),
    'source_sha256': '600fc82ccf6437c28c81c03ff56d04ddb0abaf07446782535ffb0dc29baa8af8',
    'current_source_full_integrity': 'not_run',
    'prior_verification_source': book['source'],
    'gc_policy': {'threshold': gc.get_threshold(), 'enabled': gc.isenabled()},
    'normalization': 'Only context.generated_at, brief.data.generated_at and reports.checked_at are excluded from equality.',
    'rounds': [],
}
expected = {}
initial = resident_reads.READ_PAGE_CACHE_KIB
try:
    for cache_mib in (64, 128, 256, 256, 128, 64):
        resident_reads.READ_PAGE_CACHE_KIB = cache_mib * 1024
        pool = ResidentReadPool()
        try:
            with catalog.connection(read_only=True) as connection:
                row = dict(connection.execute('SELECT * FROM company WHERE id=?',
                                               (book['company']['id'],)).fetchone())
                store = catalog._bound_store(row, read_pool=pool)
            dashboard = Dashboard(Engine(store), company_name=row['name'], companies=[row])
            operations = {
                'context': dashboard.context,
                'brief': lambda: dashboard.brief('2019-12', limit=20),
                'funds': lambda: dashboard.funds('2019-12', limit=20),
                'employees': lambda: dashboard.employees('2019-12', limit=20),
                'assets': lambda: dashboard.assets('2019-12', limit=20),
                'reports': lambda: dashboard.quarterly_report(2019, 4, preparation='deferred'),
            }
            current = {'cache_mib': cache_mib, 'operations': {},
                       'rss_before': _rss_bytes()}
            for name, call in operations.items():
                for _ in range(3):
                    call()
                timings = []
                hashes = []
                for _ in range(5):
                    started = time.perf_counter()
                    result = call()
                    timings.append((time.perf_counter() - started) * 1000)
                    if name == 'brief' and result.get('data') is not None:
                        result['data'].pop('generated_at', None)
                    if name == 'context':
                        result.pop('generated_at', None)
                    if name == 'reports':
                        result.pop('checked_at', None)
                    hashed = hashlib.sha256(json.dumps(
                        result, ensure_ascii=False, sort_keys=True, separators=(',', ':')
                    ).encode('utf-8')).hexdigest()
                    expected.setdefault(name, hashed)
                    if hashed != expected[name]:
                        raise AssertionError(f'{name} output changed under physical page cache')
                    hashes.append(hashed)
                current['operations'][name] = {'native_ms': timings, 'response_hashes': hashes}
                print(json.dumps({'round': len(out['rounds']), 'cache_mib': cache_mib,
                                  'page': name, 'native_ms': timings}), flush=True)
            current['rss_after'] = _rss_bytes()
            with store.connection(read_only=True) as connection:
                current['actual_cache_size'] = connection.execute('PRAGMA cache_size').fetchone()[0]
            out['rounds'].append(current)
        finally:
            pool.close()
finally:
    resident_reads.READ_PAGE_CACHE_KIB = initial
    with (workspace / '.tmp/stage9-page-cache-r69-diagnostic.json').open('x', encoding='utf-8') as handle:
        json.dump(out, handle, ensure_ascii=False, indent=2)
