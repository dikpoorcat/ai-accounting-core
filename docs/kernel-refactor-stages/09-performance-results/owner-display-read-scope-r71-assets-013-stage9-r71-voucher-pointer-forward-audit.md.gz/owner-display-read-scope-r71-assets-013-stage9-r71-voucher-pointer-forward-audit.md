# r71 当前发布到凭证头的独立只读审计

审计方式：GPT-6.1 Sol / high；只读当前源码和既有回执。未运行测试、SQL、服务或计时；未修改生产。以下行号是本次读取位置，其他 agent 正在修改源文件。

## 已有实际证据与公共根因

- `.tmp/stage9-r71-current-voucher-pointer-common-initial.log`：bank / payroll / ordinary × accounting / current_publication，删除开放非零来源的 `voucher_current` 后 6 项未抛错误。
- `.tmp/stage9-r71-current-voucher-pointer-pages-repair1.log`：bank、payroll 的 funds、quarterly_report 均打印 `returned_success: true`；brief 均返回 `content_integrity_failed`。这些是既有回执，本审计没有重跑。
- `.tmp/stage9-r71-current-voucher-pointer-common-repair1.log`：公共业务头修复后 13 passed，但日志仍明确打印 funds / quarterly_report 成功。测试中页面打印不是拒绝断言，因此不能把 13 passed 当这两条路径已修。

共同原因是候选集合先从现有凭证版本／指针构造，缺失指针在选择阶段消失，随后只对幸存的 ID 核验发布关系。

1. `query_reads.selected_voucher_sql:270` 的 `selected` 条件约 421 行：开放凭证要求 `EXISTS voucher_current(version_id=v.id)`；最终还 JOIN basis calculation。它是选择器，不是完整性证明。
2. `query_reads.verify_current_voucher_publications:88` 只接收调用者传入版本 ID；约 119 行再次仅保留 `current_version_id IS NOT NULL`。调用者即使传入一个已失去当前指针的物理版本，也不能从返回空集合推出合法撤清。
3. `_selected_current_voucher_publications:141` 接收已选头，验证快照、开放月、行期间和后续发布关系；不能证明候选之外不存在被遗漏的发布。其成功也不能填补上述缺口。
4. `publication.verify_record:33` 和 `QueryReads.verify_publication_periods:592` 证明发布记录内容摘要；不证明当前凭证头存在。`verify_selected_voucher_adoptions:565` 只核命中的冻结版本，不负责开放发布的缺失候选。

## 消费者与已有保护

| 入口／调用点 | 现状与处理决定 |
| --- | --- |
| `dashboard_reads.Journal._sql:1044` → `selected_voucher_sql` | `len`、summary、totals、page、hydrate、account_amounts 全部共用。账户候选先由物理 voucher_line/version 定位，最后仍被 current predicate 排除；hydrate 元数据检查无法发现消失的来源。应在公共 SQL 构造入口前做 scope 的前向核验，不给每个页面补特判。 |
| brief → `dashboard._brief_amounts:2499` → `month_journal.account_amounts:1230` | 已有整月所选集合、逐行结果／采用核验和 `monthly_account` 等价比较；现有真实负例由金额比较拒绝。保留该独立检查，不能因此认为 selector 已证明候选完整。 |
| funds → `FundsRead.account_summary:462` → `movements:415`／`events:336` → Journal | 金额、独立期初、零账户、statement 的身份核验仍必要。资金事件只核选中来源；`period_balances.verify_selected_balances:287` 核封签、发布覆盖和来源 digest，但没有 voucher_current 关系。已见真实漏检。 |
| employees／assets | `Calculations.selected` → BusinessQueries._selected_accounting 已进入新的 `_current_accounting_heads:775`；资产 owner metadata 也独立调用该函数。其他资产 acquisition／历史消费及员工指标仍有 Journal SQL 路径，应由同一公共职责覆盖。没有声明所有五页的所有分支都实测了缺失指针。 |
| `report_projection._authoritative_rows:123` | 精确开放月由 selector + voucher_line INNER JOIN 产生 17 字段来源；约 173/177 行只核已出现版本。party delta、sync、compare、source_rows 都沿此路径。须在选择行之前核精确开放月；17 字段持久格式不改，closed 分支仍用冻结权威。 |
| `Reports._report:1058`／`_account_totals:904` | 无 close 的开放金额直接读 monthly_account；有 close 时使用 posted_account_totals。季度逻辑还有 frozen-flow、party 不可用／unknown-account 回退，不能假设每次都经过 `_authoritative_rows`。开放报告的累计金额入口也需同一 guard，范围为本报告实际消费的开放 posting periods；closed 报告不能用今天的当前头替代冻结采用。 |
| CLI / MCP / report export / browser | `service.py:728-764` 同一 Reports / Dashboard / BusinessQueries 分派；在内核公共职责修复即可，无需适配层重复核验。 |

## 完整核验、关账、维修、备份并非全部已有前向保护

已有完整独立检查必须保留，但准确区分其职责：

- `publication.verify_publication_chain:239` 核链、发布 mode、业务 identity 和 `calculation_current`，不枚举 voucher_current 的期望集合。
- `integrity._check_heads:1190` 核**存在的** fact/calculation/voucher 头与目标身份；删除一条 voucher_current 本身不会被该 LEFT JOIN 检查发现。
- `change_journal.verify_journal:239` 独立重建 fact、calculation 当前头，publication 全记录覆盖；未登记／重建 voucher_current 头。
- `integrity._check_sources:272` 完整核结果、封签、依赖、来源和历史凭证行。约 455-481 行 `publication_lines_unrepresented` 用所有历史非冲正 voucher_version 的 `(voucher_id, subject, posting_period, lines)` 集合证明行曾存在，没有要求该版本仍是当前头。这与 no-impact 历史复用一致，却不能单独发现丢失 current pointer。
- `verify_integrity` 默认 `require_projections` 会比较当前指针导出的金额与存储投影；本类单删除通常能由不一致拒绝，**不是独立前向证明**。冻结 `_check_closes` 另核完整 voucher 集合和采用，不可缩减。
- `verify_close_integrity:1538` 保留全科目投影检查、来源、冻结及报告根；当前 IDs 的驱动仍含 calculation_current/voucher_current。单删指针的金额差异有兜底，不能据此豁免 authority 的缺失关系检查。
- `Maintenance._repair:46` 前置 `verify_integrity(include_projections=False, include_indexes=False)` 刻意不依赖待修投影；之后 `projections.expected_projections:29` 又从实际 voucher_current 构造金额。静态上前置没有该独立缺失头证明，存在把头缺失当成正确 authority 重建的风险。**本审计未实测维修最终是否被其他保护拒绝，不能报已证实维修成功／数据损失。** 应在源核验边界拒绝此类缺失，而非等待投影比较。
- `backup._verify_connection:147` 调注册 company verifier → schema_bundle.verify_company_with_registry → verify_integrity。当前正常备份保持默认完整检查；同一当前格式 authority guard 能覆盖独立前向检查，不应仅在 HTTP 上修。

## 最小整类建议（待 root 集中授权；本轮未实施）

复用／提取 `_current_accounting_heads` 已新增的 header／terminal、发布到当前 voucher LEFT lookup 职责，置于 connection-aware 的公共 authority helper；`QueryReads` 可以薄适配，但无 owned snapshot 的 core 调用也必须独立执行。资产成员的 owner/member 采用职责留在 BusinessQueries，不搬成通用框架。

检查顺序必须保持：

1. 按实际 cutoff / 精确 posting months / subjects / kinds 界定消费 scope。由 calculation_current 和独立 terminal publication 双向定位，LEFT JOIN 保留缺 calculation、fact、subject、publication、current version 的候选。不能使用 selected rows／幸存 voucher IDs 当期望全集，也不能用未认证的 calc kind 排除损坏身份。
2. 认证完整发布字段及 source/head identity、终端 successor 和 current binding。先认证真实 publication 的期间再排除未来来源；缺 publication 仍保留已有 source-period 缺失检查。withdrawn 的合法空 calc／空 voucher／空 current 不等同损坏空头。
3. 对开放消费的非空 `p.voucher_id`，独立 LEFT 查对应 current version，验证 logical voucher、period、非 reversal、source/publication/current-head 关系。当前版本缺失时，只对这批**异常精确 ID**严格读取完整 outcome bytes，判定合法 cleared 的 `lines == []`；非空 lines 必须拒绝。清零后 publication 可以合法保留旧 reserved voucher_id，不能直接要求所有非空 voucher_id 都有指针。
4. no-impact 可采用旧 calculation 的 voucher version；复用现有 `_verify_current_voucher_publication_rows` 的 original/current publication 检查。现有 account_amounts 的完整行与 original／basis outcome 等价证明继续保留，header guard 不替代这一证明。pub.voucher_id 为 NULL 的合法零／非会计结果不得全量升级为正文核验；若需要证明 NULL 与非空结果的矛盾，应使用原消费方已有严格 body，不能因本项修复无界解析所有 state-only 历史。
5. closed 月份继续由独立冻结 adopted/voucher 目录、封签和严格 header 确定，不要求当前 terminal 代表旧采用。固定 v1 走原 reader 和原定义。

挂接点：Journal._sql 的所有选择共享入口；report_projection._authoritative_rows 的 open 精确月入口；Reports 的开放累计金额边界（不能只改 party）；当前格式 integrity._check_sources 完成既有 source 证明后执行同一 forward check，能直接复用当次已严格解码 outcomes。BQueries 也消费同一实现，避免两套清零/no-impact/未来语义。

`selected_voucher_sql` 本身无 connection，且 position_v1 使用它，保持纯 SQL 构造。不要把 guard 改成 INNER JOIN 过滤，不增加跨请求缓存、public proof flag、存储合同或新源 root；成功只允许复用既有 exact publication/body 证明，不把候选/header success 升格为 adopted/body proof。先不添加新的 scope-success 缓存；若 root 后续需要同请求复用，另审其完整 scope／精确月份和 whole-batch success 语义。

## 版本及最小后续验证边界

`content_v1.verify_v1_company:559` 同时使用 `historical_content(1)` 和 `v1_registry().content_version=1`。新增 guard 必须像已有 `_owns_current_selector_snapshot` 同时检查 current publication/close reader 和 content_version != 1，避免共享 integrity 在历史验证时执行新规则。`report_projection_v1._authoritative_rows:74` 使用模块自身 selector，`position_v1` 自有 selected journal；保留原路径。普通 unowned **当前格式**调用应独立运行检查，不能仅因没有 QueryReads owned lease 而跳过。

无需机械大套。复用现有 bank/payroll/ordinary 及 asset owner fixture，将页面打印升级为明确拒绝断言；补 pure Journal count/totals/rows 和 direct Reports（party 不可用／unknown-account 回退）缺失指针拒绝；合法 cleared/no-impact/future/closed_review 控制继续相等。再做一项 repair 前置拒绝且业务／维修 revision 未改变、一项 registered current backup verifier拒绝、固定 v1分派隔离。错 version／period／subject／original publication 关系用同组现有小 fixture，冷与同事务先成功后损坏分别断言，确保失败不发布成功 proof。需要实际工作量回执证明正常大量来源只读头、仅异常缺失指针读正文；不借此声明页面 500ms 已达标。

未验证：维修最终结果、未覆盖页的全部分页分支、同时多处删源及 pointer 的组合、本建议的 SQL plan/VM/性能。这些不是已证实缺陷，也不构成全库正文加载要求。
