"""Pure timing control for this owned synthetic main48 run only."""
import ctypes
from ctypes import wintypes
import json, subprocess, time
from pathlib import Path

workspace = Path(__file__).resolve().parents[1]
output = workspace / '.tmp/stage9-owner-current-consumption-main48-harness-repair-pure-control-20261003.json'
assert not output.exists()
kernel = ctypes.WinDLL('kernel32', use_last_error=True)
nt = ctypes.WinDLL('ntdll')
kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
kernel.OpenProcess.restype = wintypes.HANDLE
kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
kernel.WaitForSingleObject.restype = wintypes.DWORD
kernel.CloseHandle.argtypes = [wintypes.HANDLE]
nt.NtSuspendProcess.argtypes = [wintypes.HANDLE]
nt.NtSuspendProcess.restype = ctypes.c_long
nt.NtResumeProcess.argtypes = [wintypes.HANDLE]
nt.NtResumeProcess.restype = ctypes.c_long

class FILETIME(ctypes.Structure):
    _fields_ = [('low', wintypes.DWORD), ('high', wintypes.DWORD)]

kernel.GetProcessTimes.argtypes = [wintypes.HANDLE, *([ctypes.POINTER(FILETIME)] * 4)]

def times(handle):
    values = [FILETIME() for _ in range(4)]
    assert kernel.GetProcessTimes(handle, *[ctypes.byref(v) for v in values])
    return dict(zip(('creation', 'exit', 'kernel', 'user'),
                    [v.high * 2**32 + v.low for v in values]))

def processes():
    command = 'Get-CimInstance Win32_Process | Select-Object ProcessId,ParentProcessId,CommandLine | ConvertTo-Json -Compress'
    result = subprocess.run(['powershell', '-NoProfile', '-Command', command],
                            capture_output=True, text=True, check=True)
    return {p['ProcessId']: p for p in json.loads(result.stdout)}

parents = {
    13520: (54044, 'benchmark_stage9_browser.py', 'stage9-draft-runtime-main120-20261003'),
    29828: (13520, 'benchmark_stage9_browser.py', 'stage9-draft-runtime-main120-20261003'),
    51132: (58128, 'stage9_package_agent_harness.py', 'stage9-final-draft-agent-fix1-20261003'),
    27232: (52292, 'stage9_restore_agent_harness.py', 'stage9-final-draft-agent-restore-20261003'),
    39716: (23008, 'stage9_restore_agent_harness.py', 'stage9-final-draft-agent-current-runtime-20261003'),
    5244: (46856, 'stage9_restore_agent_harness.py', 'stage9-final-draft-agent-current-runtime-published-20261003'),
}
state = {'status': 'started', 'scope': 'owned_synthetic_only', 'started_epoch': time.time(), 'targets': {}}
handles, paused = {}, []
try:
    inventory = processes()
    for pid, (parent, script, marker) in parents.items():
        item = inventory[pid]
        assert item['ParentProcessId'] == parent and script in item['CommandLine'] and marker in item['CommandLine']
    child_pids = [pid for pid, item in inventory.items() if item['ParentProcessId'] in (51132, 27232, 39716, 5244)]
    for pid in [*parents, *child_pids]:
        handle = kernel.OpenProcess(0x0800 | 0x0400 | 0x00100000, False, pid)
        assert handle
        handles[pid] = handle
        assert kernel.WaitForSingleObject(handle, 0) == 258
        assert nt.NtSuspendProcess(handle) == 0
        paused.append(pid)
        state['targets'][str(pid)] = {'before': times(handle), 'parent': inventory[pid]['ParentProcessId']}
    prefix = workspace / '.tmp/stage9-owner-current-consumption-main48-harness-repair-20261003'
    ready = Path(str(prefix) + '-timing.ready.json')
    start = Path(str(prefix) + '-timing.start.json')
    report = Path(str(prefix) + '-browser.json')
    assert ready.exists() and not start.exists() and not report.exists()
    signal = json.loads(ready.read_text(encoding='utf-8'))
    assert signal['pid'] == 55948 and Path(signal['output']).resolve() == report.resolve()
    browser_item = inventory[55948]
    assert browser_item['ParentProcessId'] == 35992 and 'stage9-owner-current-consumption-main48-harness-repair-20261003' in browser_item['CommandLine']
    browser = kernel.OpenProcess(0x0400 | 0x00100000, False, 55948)
    assert browser
    try:
        time.sleep(3)
        state['window_started_epoch'] = time.time()
        with start.open('x', encoding='utf-8') as stream:
            json.dump({'status': 'pure_timing_released', 'owned_synthetic_paused': paused, 'epoch': time.time()}, stream)
        print(json.dumps({'status': 'pure_browser_started', 'pid': 55948}), flush=True)
        deadline = time.monotonic() + 420
        while kernel.WaitForSingleObject(browser, 1000) == 258:
            assert time.monotonic() < deadline, 'Browser timeout'
        result = json.loads(report.read_text(encoding='utf-8'))
        state.update(window_finished_epoch=time.time(), result_status=result['status'])
    finally:
        kernel.CloseHandle(browser)
    for pid in paused:
        record = state['targets'][str(pid)]
        record['after'] = times(handles[pid])
        record['cpu_unchanged'] = all(record['before'][k] == record['after'][k] for k in ('kernel', 'user'))
        assert record['cpu_unchanged']
    state['status'] = 'timing_finished'
except BaseException as error:
    state.update(status='control_failed', error={'type': type(error).__name__, 'message': str(error)})
    raise
finally:
    for pid in reversed(paused):
        state['targets'][str(pid)]['resume_status'] = nt.NtResumeProcess(handles[pid])
    for handle in handles.values():
        kernel.CloseHandle(handle)
    state['finished_epoch'] = time.time()
    with output.open('x', encoding='utf-8') as stream:
        json.dump(state, stream, indent=2)
    print(json.dumps({'status': state['status'], 'output': str(output)}), flush=True)
    assert all(state['targets'][str(pid)]['resume_status'] == 0 for pid in paused)
