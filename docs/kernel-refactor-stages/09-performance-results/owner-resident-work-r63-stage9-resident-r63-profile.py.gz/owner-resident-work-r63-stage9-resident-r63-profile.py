from pathlib import Path
import cProfile
import json
import pstats
import sys
import time

w = Path(__file__).resolve().parents[1]
src = w / '.tmp/stage9-build-source-owner-r63-release'
sys.path.insert(0, str(src / 'scripts'))
from stage9_source import configure_source
configure_source(src, w)
from ai_accounting.kernel.catalog import Catalog
from ai_accounting.kernel.dashboard import Dashboard
from ai_accounting.kernel.engine import Engine
from ai_accounting.kernel.resident_reads import ResidentReadPool
from stage9_metrics import measure_work

book = json.loads((w / '.tmp/stage9-owner-main12-r63-verified.json').read_text('utf-8'))
assert book['status'] == 'complete' and book['source'] == str(src)
assert book['integrity']['status'] == 'verified' and not book['integrity']['limitations']
root = Path(book['root'])
assert root.is_relative_to(w / '.tmp')
catalog = Catalog(root)
pool = ResidentReadPool()
with catalog.connection(read_only=True) as connection:
    row = dict(connection.execute('SELECT * FROM company WHERE id=?',
                                  (book['company']['id'],)).fetchone())
    store = catalog._bound_store(row, read_pool=pool)
engine = Engine(store)
dash = Dashboard(engine, company_name=row['name'], companies=[row])
out = {'scope':'fixed_r63_resident_profile_and_work_diagnostic_not_browser_acceptance',
       'source':str(src),'root':str(root),'operations':{}}
operations = {'brief':lambda:dash.brief('2016-12',limit=20),
              'funds':lambda:dash.funds('2016-12',limit=20),
              'employees':lambda:dash.employees('2016-12',limit=20),
              'assets':lambda:dash.assets('2016-12',limit=20),
              'reports':lambda:dash.quarterly_report(2016,4,preparation='deferred')}
try:
    for name, call in operations.items():
        for _ in range(3): call()
        normal=[]
        for _ in range(3):
            start=time.perf_counter();call();normal.append((time.perf_counter()-start)*1000)
        prof=cProfile.Profile();prof.runcall(call)
        prof.dump_stats(str(w / f'.tmp/stage9-resident-r63-{name}.prof'))
        rows=sorted(pstats.Stats(prof).stats.items(),key=lambda p:p[1][3],reverse=True)
        work,_=measure_work(engine,call)
        out['operations'][name]={'native_ms':normal,'work':work,
            'profiles':[{'function':str(Path(k[0]).name)+':'+str(k[1])+':'+k[2],
                         'calls':v[1],'own_ms':v[2]*1000,'inclusive_ms':v[3]*1000}
                        for k,v in rows[:180]]}
        print(json.dumps({'page':name,'native_ms':normal,'counters':work['counters']}),flush=True)
    with (w / '.tmp/stage9-resident-r63-profile.json').open('x',encoding='utf-8') as handle:
        json.dump(out,handle,ensure_ascii=False,indent=2)
finally:
    pool.close()
