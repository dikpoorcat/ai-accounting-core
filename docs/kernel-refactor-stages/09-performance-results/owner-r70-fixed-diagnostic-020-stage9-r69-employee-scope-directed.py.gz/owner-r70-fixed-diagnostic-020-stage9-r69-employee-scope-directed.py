"""One necessary branch group; preserve the full command, log and XML."""
import json
import subprocess
import sys
from pathlib import Path

workspace = Path(__file__).resolve().parents[1]
employee = 'tests/kernel/test_employee_roster_scope.py::'
asset = 'tests/kernel/test_adopted_asset_head_locator.py::'
nodes = [employee + name for name in (
    'test_default_roster_authenticates_witnesses_and_month_money_without_all_history',
    'test_old_zero_wage_and_retired_employee_remain_in_complete_roster',
    'test_future_posting_does_not_become_a_frozen_roster_witness',
    'test_unused_old_body_stays_outside_roster_but_history_core_and_backup_reject_it',
)]
for period, warm in [('2026-01', False), ('2026-02', True)]:
    for missing in ('publication', 'calculation', 'redirected_fact', 'subject', 'fact_revision'):
        nodes.append(employee + f'test_zero_line_frozen_witness_cannot_disappear_with_missing_mutable_source[{period}-{missing}-{warm}]')
for warm in (False, True):
    for missing in ('publication', 'calculation'):
        nodes.append(employee + f'test_current_zero_wage_requires_its_exact_publication_and_calculation[{missing}-{warm}]')
        nodes.append(employee + f'test_current_zero_wage_without_frozen_anchor_requires_exact_source[{missing}-{warm}-1]')
    nodes.append(employee + f'test_current_zero_wage_without_frozen_anchor_missing_subject_is_not_absence[{warm}]')
    nodes.append(employee + f'test_selected_frozen_wage_rejects_a_damaged_reference_type[{warm}]')
    for changed in ('missing_role', 'source_digest'):
        nodes.append(employee + f'test_open_zero_wage_role_damage_is_proved_from_the_required_month[{changed}-{warm}]')
for changed in ('missing_item', 'redirected_item'):
    nodes.append(employee + f'test_actual_correction_scope_is_authenticated_before_narrowing_roster[{changed}]')
nodes += [asset + name for name in (
    'test_legitimate_asset_withdrawal_then_close_matches_empty_core',
    'test_unpublished_activation_members_keep_the_exact_owner_lane',
)]
command = [sys.executable, '-m', 'pytest', *nodes, '-q', '-s',
           '--junitxml=.tmp/stage9-r69-employee-scope-directed.xml']
(workspace / '.tmp/stage9-r69-employee-scope-directed.command.json').write_text(json.dumps({
    'scope': 'same-class scope change necessary branch validation, not full suite or native',
    'nodes': len(nodes), 'command': command,
}, indent=2, ensure_ascii=False), 'utf-8')
with (workspace / '.tmp/stage9-r69-employee-scope-directed.log').open('w', encoding='utf-8') as log:
    completed = subprocess.run(command, cwd=workspace, stdout=log, stderr=subprocess.STDOUT, check=False)
print(json.dumps({'exit_code': completed.returncode, 'nodes': len(nodes)}), flush=True)
raise SystemExit(completed.returncode)
