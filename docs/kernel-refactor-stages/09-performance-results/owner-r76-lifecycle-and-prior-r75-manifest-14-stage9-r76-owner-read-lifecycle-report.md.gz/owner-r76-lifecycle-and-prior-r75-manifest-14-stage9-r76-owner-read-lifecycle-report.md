# 请求读取生命周期审计与窄修复

GPT-6.1 Sol/medium。静态范围覆盖五页、CLI/MCP公共dispatch、关账预览/提交、完整核验、维修、备份和固定v1。不运行服务、浏览器、性能测量、GC观察或GC策略，不操作真实资源、不提交。先向主任务列修改清单，得到授权后仅修3处生命周期并新增必要合成回归。

## 明确证据与改动

current close_review.py:1048原直接_position(_Snapshot(...))，脱离Dashboard._snapshot的finally。_Snapshot拥有Journal、Calculations、ClosedPeriods、DashboardMetadata、Records、Management等，这些都指回snapshot；calculation_cache中CalculationView也指回snapshot。position返回纯金额/状态结构后，循环可暂留Engine/Store/QueryReads及实际加载的事实、核算、历史。不是service持有的不可回收泄漏，属于等cyclic GC才释放的不必要请求图。

已改current build_owner_review为构造snapshot→完整_position→finally调用已有release。_frozen_position已有结果路径不构造临时视图。成功/异常都清视图，保持活动position及调用方事务。

固定v1 close_review_integrity_v1.py:1095的PositionInputsV1原持有_V1SelectedJournal，journal.inputs反向引用；还持有V1Reads和可选verified close prefix（用于正常本事务源核验）。position_v1返回后这组来源不再需要，但循环仍可滞留。已给PositionInputsV1增加release，v1 owner builder同样完整计算后finally调用。不会改变固定历史规则、金额、采用关系、清除活动prefix或回写冻结bytes。两文件均在content-v1 source digest范围，新隔离candidate必须重新生成和校验新内容指纹；原合同没有修改，不能沿用旧8abd。

## 必要边界与全局对照

- 五页/业务详情：Dashboard._snapshot dashboard.py:1621/1653已有finally release，不改。QueryReads.snapshot query_reads.py:836/856 reset ContextVar、清同snapshot全部事实/结果/关系/已验证证明及报告cache、解除authorizer；release不提前进入活动读取。
- Lazy mapping：dashboard_metadata.py:201 Projection只持records和无捕获row投影lambda；Records/Management/FrozenManagementIds通过snapshot形成已知cycle，属于snapshot释放范围，不代表返回正文带lazygetter。dashboard_reads.py:929 CalculationView/JournalRow同属临时视图。query_reads.py:1543 raw lambda与bound getter仅供同步关系resolver，query_semantics.py:117/741返回普通dict/list/set，不把getter存在结果；未发现可回指QueryReads的长期结果闭包。
- 服务/public CLI/MCP：service.py:366每请求新Engine/Store；dispatch commit_guard lambda持service/authority是请求活动所需，没有service→engine注册容器。局部command bound-method表随_dispatch返回消失。Current ClosePreviewIntent close_preview.py:52只存身份/版本tuple、摘要bytes与签名；service.py:449最多128，替换同月旧intent，close与service.close清理。它不引用manifest、Engine或Snapshot，fullcache移除解决长期manifest保留，但不自动消除上述临时视图cycle。
- 读池：resident_reads.py:102/151最多4连接；idle条目只有路径、inode签名和连接。borrow finally清authorizer/trace/progress callback、rollback后归还；不存Store/Engine/业务响应。SQLite页cache属于有界数据库页驻留，不能把它或gc tracked总数当成业务泄漏。
- 完整核验与backup：integrity.py:1317/1147根据验证flags进入owner financial-position重建，current/v1两处修复覆盖；schema_bundle.py:157建立本次验证Engine，backup.py:149调用verifier返回摘要/count。VerifiedCloseArchive仅存已核验压缩月体、连接与lease，_CloseLookup无archive反向环；verified_source_lease finally复位ContextVar并close见证，不是service业务cache。核验期间source/decoded_closes/verified_position_prefix属于必要活动来源，不能提前clear。
- 维修：Maintenance preverify和postverify部分flags关闭financial-position；真正进入owner重建者同修复覆盖。read_indexes repair保存来源身份与触发器SQL到本次局部，未发现长期闭包。不能为减驻留绕过维修源核验/事务。
- 固定v1：content_v1.v1_registry lru_cache(maxsize=1)缓存规则/模型，historical_content finally复位版本ContextVar；没有将每公司事实存入全局registry。Inputs↔journal是明确局部cycle，已统一断开。

## 验证与未验证

新4项生命周期回归在真实合成current预览和已冻结v1样例上比较完整owner review；成功弱引用立即消失，异常traceback仍必要持view时其__dict__已空，丢弃traceback后立即消失；无gc.collect。位置计算中源仍有效，返回后caller transaction仍有效。最初v1测试夹具仅open preview，因无period_close构造失败2项；改用正常合成freeze后4项通过，未为测试伪造已关闭标记。

合并定向10项9通过1失败。新4全部通过、既有v1 selector4项全部通过、payroll parse2项1通过1失败；失败在test_close_review_payroll_parse_reuse.py:141最后Dashboard业务详情缺payroll_confirmation字段，前面的current/v1来源cards、解析次数、金额核对都通过。完整失败stdout保存在stage9-r76-owner-read-lifecycle-tests.log。三处生命周期代码没有改业务详情字段；该当前分支失败已通知主任务处理。

未量化释放对象数/RSS/延迟收益，不能由82860 tracked断言泄漏。异常traceback或调用者主动保留结果本身属于必要外部存活；constructor尚未成功时不进入本次finally，未做故障注入。没有大回归或新candidate，原r73/r75及旧raw manifest不冒充新source历史核验。
