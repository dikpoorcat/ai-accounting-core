"""Fixed-source, synthetic-only native report CPU diagnosis, not acceptance timing."""
import cProfile
import json
import os
from pathlib import Path
import pstats
import sys

root = Path(__file__).resolve().parents[1]
source = root / '.tmp/stage9-build-source-r33-release'
report_path = root / '.tmp/stage9-release-main-48-verified-r32.json'
report = json.loads(report_path.read_text(encoding='utf-8'))
assert report['status'] == 'complete'
assert Path(sys.prefix).resolve() == (root / '.tmp-kernel-venv').resolve()
sys.path[:0] = [str(source / 'src'), str(source / 'tests/kernel')]
os.environ['STAGE9_WORKSPACE_ROOT'] = str(root)
from stage9_book import MixedBook
from ai_accounting.kernel.daemon import _prepare_static_runtime
from ai_accounting.kernel.dashboard import Dashboard

_prepare_static_runtime()
book = MixedBook.resume(Path(report['root']))
page = Dashboard(book.engine)
value = page.quarterly_report(2019, 4, preparation='deferred')
profile = cProfile.Profile()
profile.enable()
value = page.quarterly_report(2019, 4, preparation='deferred')
profile.disable()
print('source', source, 'book proof source', report['source'])
print('Native serial deferred report; source contracts same, not r33 full-book verification.')
stats = pstats.Stats(profile).sort_stats('cumtime')
stats.print_stats(65)
stats.print_callees('party_balance_rows|_party_delta|read_report_flow|read_open_contributions|_verify_anchored_source_bytes|browser_report_details')
profile.dump_stats(str(root / '.tmp/stage9-report-profile-r33.pstats'))
