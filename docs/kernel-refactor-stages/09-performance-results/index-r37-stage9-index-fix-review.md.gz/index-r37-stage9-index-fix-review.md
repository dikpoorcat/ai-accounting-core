# Stage 9 index #1: narrow SQL fix review

Compared the workspace with `.tmp/stage9-build-source-r36-release` for only
`reports.py`, `frozen_material.py`, `close_storage_v1.py`, `report_flow.py`, and
`report_flow_v1.py`. This was a source and read-only plan review; no source,
database, or test was changed or run by this review.

| Changed site | Semantic review |
| --- | --- |
| `reports.py:1321-1327` fallback classification references | Only the three joins after `json_each(?) ids` changed to `CROSS JOIN`. The `f.id=ids.value`, subject-kind and classification-version predicates, the period/voucher `OR`, and all three parameters retain their positions. The enclosing set still removes duplicate references; an empty ID array still yields an empty set. |
| `frozen_material.py:269-287` frozen version proof | Both source and other-material branches retain the same `ON` predicates, `(canonical(identifiers), kind)` binding, selected source/fact columns, empty-list early return, and `len(rows)` integrity check. Duplicate IDs are rejected before SQL, while duplicate matching rows would still cause the length check to fail. The returned groups remain sets, so row order was never observable. |
| `frozen_material.py:303-312` sealed frozen count | All four joins changed together. The count still includes any duplicate match, retains `(frozen_ids, kind)`, and still compares with `len(identifiers)` before the full current/frozen set difference. The latter broad comparison is intentional and unchanged. |
| `close_storage_v1.py:165-194` released-v1 frozen proof | Same predicates, parameter order, empty-list early return, row-count integrity check, and grouped sets as the current proof. This historical path is used when verifying saved close storage, including backup/restore and offline-upgrade content verification. |
| `report_flow.py:110-125` and `report_flow_v1.py:100-115` reference extraction | The exact `ids.value` join, kind filter, voucher/period `OR`, three bound parameters, `DISTINCT`, and `ORDER BY f.id` are unchanged. Empty IDs remain empty; duplicate input IDs and matching rows are still removed by `DISTINCT` before tuple construction. |

SQLite treats `CROSS JOIN ... ON predicate` as an inner join with the stated
predicate while preserving the written join order. Each changed query has only
inner joins in the affected chain, so NULL equality continues to reject rows,
and no outer-join null extension or predicate scope was changed. Every old
predicate remains attached to the same pair of tables. No actual semantic
defect was found in these diffs.

The same-file exact-ID candidates left as ordinary joins were checked on the
reseeded 12-month database: `frozen_material.py:349` eligible frozen IDs,
`:365` sealed source evidence, and `reports.py:2067` job source existence all
plan as `SCAN json_each/requested` followed by indexed ID lookups. They do not
show the `subject.kind → fact_revision(subject_id) → json_each` reversal.
The other owned integrity/storage/current-and-v1 paths remain covered by
`.tmp/stage9-index-integrity-scope.md` and its raw plan archive. Full-history
verification and current/frozen whole-set comparison remain deliberately broad.

Limitation: this review checks SQL equivalence and representative read-only
plans, not executed result sets or the final release gate. The reseeded
48-month staging database was previously locked for some diagnostics, so its
full verification remains with the main Stage 9 run.
