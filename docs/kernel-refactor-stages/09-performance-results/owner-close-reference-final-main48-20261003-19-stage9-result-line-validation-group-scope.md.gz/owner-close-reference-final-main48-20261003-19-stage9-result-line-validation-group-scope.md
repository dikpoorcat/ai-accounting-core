# 保存结果行校验：同类静态范围

本次仅读当前源码与已保存的 6688 main12/main48 native 原件，不运行新 probe、测试、DB 或页面计时，不修改生产源码。结论：简报默认路径中“verify_selected_content 已严格校验 lines，Journal 又做一次”的前提不成立；现有局部 result_lines memo 已消除同 calculation ID 的重复标准化，没有当前证据支持新增 snapshot lines cache。

## 实际证明职责

`query_reads.py:1624 verify_selected_content` 按精确 ID 读取 calculation/fact/subject/seal 头，验证事实正文、来源身份和结果 digest，调用的是 `integrity._object`。`_object` 只负责版本化 JSON 解码、重复成员规则和顶层 dict；它不是 `_outcome`，不调用 `_lines`。批内全部成功后才更新 `_verified_source_contents`，这个现有 map 是正文/封签证明，不能解释成分录行语义证明。

`stored_json.verify_outcome_bytes` 同样只检验精确保存 JSON 的重复成员/解码与摘要，不校验 lines 的账户、类型、借贷或平衡。raw SHA 相等本身不允许跳重复成员；本组不改变独立 anchor 或普通结果解码规则。

`QueryReads.metadata` 的 state 标量投影以及 `_decoded_outcomes` 路径至多检查顶层 dict、lines 是 list、opening 是 bool，并提供 line_count/opening。`calculations`/`raw_calculations` 缓存 raw dict，`Store.calculation` 提取 values 构造只含 values 的 Calculation；这些不是严格 Line 验证。写入时构造 contracts.Line/Outcome 的检查也不能代替从数据库重新读取后的核验。`query_semantics._lines` 和固定 query_relations_v1._lines 只是读取 outcome.lines 的访问器，与 integrity._lines 不同。

`integrity.py:45 _lines` 才严格检查 list、逐行精确四字段集合、非空字符串 account、严格 int 借贷、非负且一侧为正、cashflow 的 null/非空字符串、opening 禁 cashflow、signed64 checked、中间累计上界与借贷平衡，返回标准化四元组列表。空 lines 合法；opening_lines 是另一语义，不能共享 opening=False 证明。不能只依据行数、摘要或 Python 的宽松数值相等省略这些检查。

## 简报真实调用链与原件

`Dashboard.brief → _brief_amounts → month_journal.account_amounts` 是生产唯一 account_amounts 调用链。它选择整月实际正式凭证与必要原凭证，保留 current/frozen 采用、源 publication、identity 及原凭证追溯，然后取得 verify_selected_content 的正文。`dashboard_reads.py:1386 result_lines` 在本次 account_amounts 的局部 expected_lines 中按 calculation_id memo，第一次才调用 `_lines`。同 owner 与 adopted basis 两次比较命中这个局部 map；冻结采用和无影响复核的新 basis 不可错误合并成旧 owner ID。

已有原件：

- `.tmp/stage9-owner-main48-reference-group-native-work.json`，源 SHA `6688df6c46f5416ca03917def0d29a701cb20e8ae45b962c59df4a1290f8da62`，旧 1c37/029 qualification 只绑定合成样本；current_source_full_verification=false。
- `.tmp/stage9-owner-main12-reference-group-native-work.json`，同 sealed 源，旧 1c37/066 qualification 只绑定样本；同样不是当前内容资格或浏览器验收。

两样本 brief 均有 result_lines **2010** 次、integrity._lines **1006** 次、integrity._object **1009** 次、verify_selected_content **6** 次；完整源码函数计数中没有 integrity._outcome 调用。这里实际已把第二次 result_lines 的约一半访问变成 memo hit；不能把 2010 个访问当成 2010 次标准化。1006 次严格 _lines 与正文采用证明是不同职责，未发现先由 _outcome 校验再调用的实际路径。不同 owner/basis 的具体 ID 交集没有本轮另探针，不将计数差额推断成某个唯一业务种类。

brief 保存结果返回都是 1016 行、完整 JSON 解码 1015 次；12/48 结果正文字节分别 961815/994988，所有 SQL 返回字节分别 7831042/10165621。_lines 重用只能影响 Python 标准化，不能直接减少这些 SQL/正文返回/JSON 解码量；不可把约 10MB 都归到该函数。两规模每月业务量相同，_lines 次数不随闭期从 11 增至 47 增长，主要随目标月正式凭证及独立采用 basis 增长。

保存 cProfile 的 _lines 累计诊断值为 12 月约 37.77ms、48 月约 34.61ms；result_lines 约 39.95/36.63ms，其中本地 memo 函数自身约 2ms。这些来自独立插桩 reread，并有 qualification 背景任务，不是正常 dispatch 预算或页面净延迟。未做新的收益测量，不据此安排实现或大套测试。

## 必须保留的独立比较

account_amounts 实际 voucher_line 来自另一张正式表，仍要检查连续 line_no、严格 int 借贷、非空与 total、publication posting period/voucher identity；与规范保存结果完整四元组相等后才能继承结果的完整 shape/平衡证明。actual 不匹配时调用 `_lines(... component='voucher')` 保留原 malformed-line 诊断，再拒绝 mismatch。这是失败分支的独立凭证核验，不是正常路径重复。原凭证核验及借贷翻转、frozen voucher header/adopted result metadata、当前 basis 精确相等、金额 checked、monthly_account 投影对照均保留。

新 basis/无影响复核、冲正、空结果和冻结源必须按真实 ID 分开；仅 syntax/digest 已通过的正文仍需第一次严格 lines 核验。来自 verify_outcome_bytes、metadata、raw_calculations、保存 SQL 标量或不同事务的对象不能冒充 result_lines proof。

## 公共调用方及历史边界

| 范围 | 判断 |
| --- | --- |
| 简报默认/恢复凭证列表/活动/精确焦点 | account_amounts 严格校验一次并供现有 summary/verified rows 复用；分页 hydrate 与来源关联仍原职责。单独页与按需分支没有先执行该 proof 时不能借它；生产仅一个 account_amounts caller，本轮不发现同 snapshot 第二个真实汇总重算入口。 |
| 资金、员工、资产 | 多处 verify_selected_content/verify_outcome_bytes/metadata 分别证明来源、余额 effects 或状态，不能概括成 _lines proof。上述两份默认 native 的三个页面均没有 integrity._lines 调用；新增普遍 strict-lines cache 会先增资格与成本，无当前复用收益证据。 |
| 报表 | 默认 native 没有 integrity._lines/_outcome 调用；1004 contribution 解码及 report lines/parent/source binding 是另一证明职责，不能以 Journal 的 lines proof 代替。report semantics/project_immutable_lines 的名字相似不是重复标准化证据。 |
| CLI/MCP/HTTP | Service 的 dashboard_brief 进入同 Dashboard；本组静态结论不依赖传输。业务/publication、报告与 maintenance 命令仍各自独立证明；没有外部 already-verified 参数。未逐个命令动态采样。 |
| 来源完整核验、period close、fullverify | integrity._check_sources 对 calculation 调 `_outcome`：验证完整 outcome 的 values/balances、普通 lines、opening/ opening_lines，并另验证依赖/identity/采用。之后对实际 voucher 独立调 `_lines`，非冲正 expected 也对同 decoded calculation.lines 再调 `_lines`，这是源码可见的局部重复标准化；实际 voucher 检查本身必要。默认两份样本没有这条 calculation _outcome 重复路径；本次不为独立完整核验另改算法，也不把它列作当前页面瓶颈。 |
| repair、backup/restore | Maintenance 写事务及 schema_bundle/backup 独立 verifier 使用完整源核验。不能把另一个 read snapshot 的正文/lines cache 当证明；事务、原子失败和独立投影/目录复验保持。该局部重复的实际规模及收益未测。 |
| fixed content-v1 | integrity 的 JSON、checked、sum_fen、年月等经 content_history_context 固定版本路由；history_reads_v1 与固定格式路径不参与 current owned cache 方案。既有历史重复成员、金额及采用规则不变。 |

## 技术取舍与验证位置

当前不实施：Journal 唯一正常路径已经使用最窄局部 result_lines memo；先从 verify_selected_content 偷借 proof 会漏掉严格行语义，把所有来源正文都升级为 lines proof 则扩大消费范围，新增 snapshot cache 也没有第二次真实标准化的证据。

若今后独立完整核验确实成为当前授权热点，职责内的最窄候选是 `_check_sources` 自己保留 `_outcome` 首次产出的规范行，在同一调用局部使用其精确 calculation ID/对象，避免该函数内部 expected 的再标准化；实际 voucher 校验、opening 规则、输出与失败顺序不变。它不是当前简报优化方案，不能跨调用/事务/版本传播，未证明工作量或收益。本次不实现、不新增测试。

现有可读测试位置：test_owner_brief_amounts 的 off-page 来源/冻结采用、open replacement/no-impact 与冲正；test_journal_original_source_scope 的真实原凭证与 no-impact adoption 损坏；test_journal_summary_proof_reuse 的失败不签发 summary/headers；test_integrity_content 的历史源、line mismatch、total mismatch、空结果与 repair；test_stored_json_selection 的重复成员/等价非 canonical；test_v1_stored_json_isolation 的固定 verifier 隔离。仅静态查看位置/相应路径，不将此前通过数当本次验收，未增加或运行测试。
