"""Private cloned-DB response parity after covering indexes, with schema gate noted."""

import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp/stage9-build-source-r33-release"
BOOK = ROOT / ".tmp/stage9-release-main-48-verified-r32.json"
CLONE = ROOT / ".tmp/stage9-report-count-covering-r33/company.sqlite"
BASELINE = ROOT / ".tmp/stage9-report-count-covering-r33.json"
OUTPUT = ROOT / ".tmp/stage9-report-count-full-response-r33.json"


def scrub(value):
    if isinstance(value, dict):
        return {k: scrub(v) for k, v in value.items() if k not in {"generated_at", "checked_at", "read_version"}}
    if isinstance(value, list):
        return [scrub(item) for item in value]
    return value


def main():
    if OUTPUT.exists():
        raise RuntimeError("Preserve prior result")
    sys.path.insert(0, str(SOURCE / "src"))
    from ai_accounting.kernel.daemon import _prepare_static_runtime
    from ai_accounting.kernel.dashboard import Dashboard
    from ai_accounting.kernel.engine import Engine
    from ai_accounting.kernel.storage import Store
    from ai_accounting.kernel.permissions import adopt_private_file

    book = json.loads(BOOK.read_text(encoding="utf-8"))
    baseline = json.loads(BASELINE.read_text(encoding="utf-8"))
    ident = book["company"]
    for suffix in ("-shm", "-wal"):
        sidecar = Path(str(CLONE) + suffix)
        if sidecar.exists():
            adopt_private_file(sidecar)
    store = Store(CLONE, _prepare_static_runtime()[0], ident["id"], ident["database_id"], taxpayer_id=ident["taxpayer_id"])

    def cloned_schema_diagnostic_only(connection):
        # The two private test indexes and ANALYZE intentionally change SQLite
        # structure, so a released schema contract cannot accept this clone.
        # Preserve company binding; all report content/read proof remains active.
        row = connection.execute("SELECT company_id,database_id,taxpayer_id FROM identity WHERE id=1").fetchone()
        if row is None or tuple(row) != (ident["id"], ident["database_id"], ident["taxpayer_id"]):
            raise RuntimeError("Clone company identity changed")

    store.validate_connection = cloned_schema_diagnostic_only
    response = scrub(Dashboard(Engine(store)).quarterly_report(2019, 4, preparation="deferred"))
    encoded = json.dumps(response, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    result = {
        "status": "private_diagnostic",
        "source": str(SOURCE),
        "clone": str(CLONE),
        "schema_contract_validation": "bypassed for the intentionally changed private clone only",
        "company_identity_validation": "retained",
        "business_content_checks": "production report code unchanged",
        "response_digest": hashlib.sha256(encoded.encode()).hexdigest(),
        "baseline_digest": baseline["baseline_full_response_sha256"],
        "response_equal_except_generated_checked_readversion": hashlib.sha256(encoded.encode()).hexdigest() == baseline["baseline_full_response_sha256"],
        "classification_count": response.get("classification_count"),
        "income_tax_confirmation_count": response.get("income_tax_confirmation_count"),
    }
    OUTPUT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(OUTPUT)


if __name__ == "__main__":
    main()
