# Stage 9 金额、往来与公共读取组只读审查

## 决定

本轮不新增 production 缓存，不改 Journal、QueryReads、report contribution 或 frozen-v1。已有输入格式组与已验证非负合计组由根节点集中回归；根节点后续报告受影响 316 项回归 PASS，本审查未重跑该组，也不能把该结果当作新的浏览器 500ms 验收。

当前热点主要是有实际消费者的必要来源、正文、凭证行与冻结采用核验。没有证明可以删除大批重复正文解码或不消费的结果字段。确认存在 `selected_open_line` 对一个贡献的完整 `rows` 遍历，但目前只列为小候选，实际集合大小分布和构造索引后的净收益未证实。

采用 GPT-6.1 Sol / high，遵守仓库 AGENTS.md。只写本审查和独占 boundedprobe 文件；未修改生产、tests、docs、真实资料、服务、合同、身份或数据库，未提交 Git。未重试已回退审查 24 方案，未重复另一智能体负责的 `integrity._lines` 与非负合计修改。

## 证据边界

封存源为 `.tmp/stage9-build-source-surviving-read-consumers-fixed-20261003`，manifest 的 SHA 为 `dd8601e985cb6bed14f9bc0746bb5b387a20f9355ecd69e1e5ebae729b746a96`，753 文件。源码判断基于仓库对应读取代码及该封存源的已有真实 HTTP profile：

- `.tmp/stage9-dd86-http-pipeline-diagnostic-20261004-fix1.json`
- `.tmp/stage9-dd86-http-pipeline-diagnostic-20261004-analysis.json`（文件名没有 `fix1-analysis`）
- `.tmp/stage9-dd86-http-pipeline-diagnostic-20261004-fix1.py`

真实 HTTP 诊断没有 active close preview，仅证明其局部分支。根节点记录真实 main48 browser 为 150 success、50 次 >=500ms（brief 19 / reports 30 / funds 1），500ms 口径不降低。根另核 browser ResourceTiming 的简报、报表 render tail 约 22–37ms，主要剩余在 TTFB；当前报表前端实际传 `preparation=deferred`，安全字段筛选未保留参数不能解释为参数缺失。本审查没有重跑 HTTP、browser、150 次计时、preview、qualification、建库或完整核验。

instrumented profile 的 self / inclusive 时间仅用于定位；父子累计时间重叠，不能加总或换算成可节省时间。没有本轮查询计划、VM steps 或返回行字节证据；旧 r74/r76 的统计只作历史职责参考，不伪装为当前 dd86 实测。

## Journal 与 brief 的实际结果

`dashboard._brief_amounts`（2567）调用 `dashboard_reads.Journal.account_amounts`（1289），消费全部账户双边金额，与本月 `monthly_account` 的非零 debit/credit 精确比较，再计算收入、费用、结果并检查未映射月末余额及期初未建立状态。分页 20 行不缩小整月金额证明。

必须保留：精确整月 current/frozen selection、正式 publication/current head、封签与事实正文、saved outcome、凭证完整行顺序与严格整数金额、total、平衡、basis/owner 一致、reversal original、独立 frozen adopted identity/digest/lines 和 complete month membership。必要正文包含 lines 以外的完整 JSON 唯一成员规则；不能因金额最终只消费 lines 就直接换成跳过其他字段的 decoder。封签存在和当前 `c.digest` 匹配不替代独立采用或严格正文语义。

已有 HTTP profile：`account_amounts` 1 次，self 36.982ms / inclusive 330.673ms；`verify_selected_content` 全页 4 次，inclusive 100.902ms；`result_lines` 2010 次，但 `_lines` 1006 次。`result_lines` 的局部 `expected_lines` 按 calculation ID 复用，因此调用数 2010 不能说成同正文解码 2010 次。

本轮唯一 bounded native 定位中，brief 实际 `verify_selected_content` 第一批 requested 1006 / missing 1006，随后资金 requested 504 / missing 0，剩余两次为空；`integrity._object` 合计 1006，按同页 component / record ID 无重复。已经证明实际成功内容复用，不能硬造第二套金额结果缓存。

成功金额证明还留下 journal summary、count、verified rows；后续 activity/voucher page、summary 与 verified header page 有实际消费者，使用精确 scoped key 点查。`_Snapshot.accounts`、opening selection 和本月双边金额职责不同，不能只因都读金额就合并证明。Snapshot 初始化与 `_brief_amounts` 分别读取本月小型 monthly_account 是源码可见重复 SQL，但尚无它是热点、需要额外缓存或足以改善门限的证据，本轮不扩大修改。

## report party / contribution 的实际结果

`reports._report` 内 `cached_party_balance`（1216）按 cutoff/effective source 点查成功结果；`report_projection._party_balance_nets`（922）按 cutoff/source 点查，`stored_month` 按精确 period 点查。这些缓存没有为了查一个键遍历整个已缓存集合。

`_party_balance_nets_uncached`（939）选择可信 checkpoint，再对其后的真实月份消费 frozen party rows 或 open `_authoritative_rows` / `_party_delta`。保留 source rows、publication/current selection、close reference absence、frozen report roots、checkpoint inputs 与 classification body/seals；不能将不同 cutoff、来源或采用集合视为同一 proof。开放当月 source rows 已在成功且证明 no_close_references 后给报表后续行选择复用。

`_party_delta`（337）只解析 RECLASS 行的交易方，报表主行还消费 CASH/PROFIT 语义等其他来源；两处请求集合不同，不等于两次完整重做。已有 HTTP profile 中 `read_open_contributions` 调用 2 次，但 `_decode` 1004 次，没有同 1004 个贡献正文解码两次的证据。`read_open_contributions` 对 exact calculation ID 的 `stored` 点查，只认证缺失项，整批完成 source binding、parents、root identity 检查后更新。`_verify_anchored_source_bytes` 按 ID 成功复用，只是原文绑定证明，不提升成 full decoded content / input / adoption proof。

`_verify_report_fact_sources` 维护成功 ID 集，`_validated_report_classification_headers` 复用精确 scalar headers 与 validated reference IDs，同时对当前请求完整集合重新检测冲突。这是必要集合完整性语义，不是因为缓存存在就可省略。HTTP profile 的 4 次 `verify_fact_versions` 与 metadata 的 4 次不能仅凭次数认定事实重复解码；本轮没有证明其 exact ID 重叠造成重复正文工作。

## 确实存在的小候选：贡献行点查

`report_open_contribution.selected_open_line`（604）对每个请求行构造 `candidates = [item for item in content['rows'] if version_id/line_no 精确匹配]`。实际调用方只有 `report_projection._party_delta`（490）与 `reports._report`（1458）。该集合遍历与行定位真实存在，不是按名称猜测的缺陷。

HTTP profile：1995 次，self 8.548ms / inclusive 24.344ms。`_resolution_from_content` 1003 次 / inclusive 13.509ms，首次生成实际使用的 relation resolution；其后 `content['_runtime_resolution']` 已复用。这部分转换不能被算成逐行扫描可全部省掉的成本。

没有当前 dd86 的 `content.rows` 大小分布、同 full lookup key 重复次数或索引构造 work 统计。1995 次 lookup / 1004 次 decode 本身不能证明每个贡献有大集合，也不能证明某个键重复；平均约两次 lookup 的小贡献可能因建 dict、多分配而更慢。原 native probe 的报表入口未覆盖该支路，不能把其空统计冒充大小分布。故不新增 `_runtime_rows` 或 snapshot 索引。

未来若有真实规模证据支持集中实施，可在已认证贡献对象内部按 `(version_id,line_no)` 保存匹配集合或重复标记，保留 `usable=False`、不存在返回 None、同键多个项时原 `line_duplicated`、reversal 对调、严格行金额/cashflow 比对及原 resolution 复用。不能用 dict 后项覆盖同键前项，也不能改变 malformed content 的当前拒绝范围。验证需看构造成本、实际集合大小和 complete response equivalence；不增加跨请求业务缓存或新通用框架。这只是未实施候选，不预计节省 24ms，更不宣称解决 438ms 热点。

## 五页及其他调用范围

|范围|实际职责与本轮处理|
|---|---|
|brief 主数据、activity/voucher/open-items 分页与焦点|同 request 内精确金额证明和分页 header/body成功复用；每个 HTTP 请求独立 owned Snapshot。|
|funds 主数据、摘要及 movement/账户按需页|消费资金事件及余额；brief 后504来源missing0已证实，普通funds页独立source范围不被替换。|
|employees、assets 主数据及附属/按需页|共用 QueryReads/选择器，但各有工资、资产 adopted/member source；本轮没有新重复ID或不消费字段证据。|
|reports deferred / complete 与 closed export|当前浏览器 deferred 已使用 owned QueryReads.snapshot；完成准备、closed export另有实际资料/冻结消费者，不据摘要裁掉。|
|context、period preparation、owner preparation|context不消费整月金额；准备路径实际消费资料、完整采用与核对，不能借简报窄证明代表完整完成。|
|CLI / MCP|LocalService路由调用同实现；直接 `Reports.report` 是 unowned Store read，需保留既有独立读取路径，不人为授予 snapshot成功缓存。|
|关账、发布、close review、完整核验|完整 source/dependency/lines/freeze 为实际authority；写事务和独立 full verification不能继承普通page缓存结论。|
|repair、backup、restore|源核验、可重建投影、便携包独立完整校验保留；未执行这些流程，未证明新的重复工作。|
|fixed historical v1|`history_reads_v1.V1Reads`及 report_projection_v1 / content_v1等固定读取与编码仍独立；当前贡献缓存候选不接 v1，不改历史采用依据。|

源码对应：`dashboard.py`、`dashboard_reads.py`、`dashboard_funds.py`、`query_reads.py`、`reports.py`、`report_projection.py`、`report_open_contribution.py`、`query_semantics.py`、`business_queries.py`、`close_review.py`、`integrity.py`、`maintenance.py`、`backup.py`、`history_reads_v1.py`。本次没有跑这些非五页流程，表内为调用职责和保持决定，不声称逐流程实测。

## 唯一 native probe 与未成功覆盖部分

执行器：`.tmp/stage9-owner-money-party-read-group-boundedprobe-20261004.py`；原始结果：`.tmp/stage9-owner-money-party-read-group-boundedprobe-20261004.json`。仅用仓库 `.tmp-kernel-venv/Scripts/python.exe -X utf8`，绑定既有 qualifiedmain48，未创建数据库、服务、登录会话或 preview。加载封存源 production bundle（draft / company0 / catalog0），company连接只读/query_only，并核 repair_revision=0。

前后完整 company、company WAL（存在则核）、catalog、construction input、qualified报告、source manifest、checkpoint hash相同；identity/state/schema_history/security_owner等核验摘要相同。核 company ID/database ID/taxpayer ID与qualification一致，state为 `[1,2065,1164,152,48238,0]`，book/manifest/checkpoint与固定qualification hash一致；已导入 ai_accounting模块路径全部位于封存 src。未把真实data作为样本。

brief已成功给出上述1006/504复用统计。probe误用了 `Reports(engine).report(2019,4)`，该API新建普通 Store read且没有 owned `QueryReads.snapshot`；因此没有覆盖浏览器 `Dashboard.quarterly_report` 所用的 contribution支路，`contribution_decodes.calls=0` / `line_lookup.calls=0`只能表达未覆盖。它不是‘报表无需贡献’、不是重复已消除或平均rows=0；native定位对贡献集合大小与键重复的目标未成功。JSON里 `repeat_key_rows_scanned=0`是空统计的占位，不是测得节省量。没有补跑第二次native；贡献判断只引用已有真实HTTP profile和源码。

本轮未做新SQL trace/EXPLAIN、行数/字节/VM计量、故障注入、性能AB或最终门限验收。明确可交付结论是：没有已证实的大批可删重复；必要1006正文成功复用已证实；贡献逐行集合扫描存在但收益未证实，保持候选未实施。
