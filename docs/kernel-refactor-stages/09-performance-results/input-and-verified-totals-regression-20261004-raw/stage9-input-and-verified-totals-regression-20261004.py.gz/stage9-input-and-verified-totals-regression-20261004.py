import ast
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

root = Path(__file__).resolve().parents[1]
prefix = root / '.tmp/stage9-input-and-verified-totals-regression-20261004'
files = '''test_evidence_reference_boundary.py
test_verified_line_totals_work.py
test_integrity_content.py
test_engine.py
test_entities.py
test_discovery.py
test_display.py
test_materials.py
test_asset_batches.py
test_integrity_exports.py
test_exports.py
test_identity_corrections.py'''.splitlines()
nodes = '''test_maintenance.py::test_source_damage_cannot_be_repaired_or_disguised
test_maintenance.py::test_index_repair_restores_missing_close_marker_without_waiving_frozen_roots
test_runtime_backup.py::test_initial_portable_round_trip_and_rollover_are_verified
test_runtime_backup.py::test_evidence_corruption_is_detected_before_backup_is_published
test_offline_upgrade.py::test_nonempty_v1_frozen_adoption_survives_changed_v2_current_model
test_offline_upgrade.py::test_v1_identity_correction_is_verified_after_current_expense_model_changes
test_offline_upgrade.py::test_v1_frozen_opening_and_cumulative_identity_survive_changed_v2_methods_and_helpers
test_close_review_transport.py::test_review_uses_exact_preview_and_survives_freeze_and_service_restart
test_replay_close_range.py::test_replay_schema_keeps_ordinary_close_password_contract'''.splitlines()
selection = ['tests/kernel/' + item for item in files + nodes]
assert len(selection) == len(set(selection))
for item in selection:
    file, _, name = item.partition('::')
    path = root / file
    assert path.is_file(), file
    if name:
        tree = ast.parse(path.read_text(encoding='utf-8'))
        assert any(isinstance(node, ast.FunctionDef) and node.name == name for node in tree.body), item
paths = {item.split('::')[0] for item in selection}
paths.update(str(item.relative_to(root)).replace('\\', '/')
             for item in (root / 'src/ai_accounting/kernel').rglob('*.py'))
hashes = {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in sorted(paths)}
for suffix in ('.xml', '.json', '.log'):
    assert not prefix.with_suffix(suffix).exists(), suffix
command = [sys.executable, '-X', 'utf8', '-m', 'pytest', '-q', *selection,
           '--junitxml=' + str(prefix.with_suffix('.xml'))]
started = time.time()
print(json.dumps({'status': 'starting', 'files': len(files), 'nodes': len(nodes),
                  'log': str(prefix.with_suffix('.log'))}), flush=True)
with prefix.with_suffix('.log').open('x', encoding='utf-8') as log:
    result = subprocess.run(command, cwd=root, stdout=log, stderr=subprocess.STDOUT)
receipt = {'started_unix': started, 'elapsed_seconds': time.time() - started,
           'exit_code': result.returncode, 'command': command, 'files_before': hashes,
           'files_unchanged': all(hashlib.sha256((root / name).read_bytes()).hexdigest() == value
                                  for name, value in hashes.items())}
prefix.with_suffix('.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: value for key, value in receipt.items() if key not in {'command', 'files_before'}}), flush=True)
sys.exit(result.returncode)
