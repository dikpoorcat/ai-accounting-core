"""Narrow private module ABBA guard diagnostic, not fixed-source/page acceptance."""
from pathlib import Path
import sys,json,time,statistics,hashlib,importlib.util,traceback
from contextlib import contextmanager
w=Path(__file__).resolve().parents[1];stem=w/'.tmp/stage9-r74-open-head-native-ab-repair1';output=Path(str(stem)+'.json');assert not output.exists()
fixed=w/'.tmp/stage9-build-source-owner-r73-release';current=w/'src/ai_accounting/kernel/query_reads.py'
sha=lambda b:hashlib.sha256(b).hexdigest()
expected='305924fa53da1b7696433efa8c2654bbe50baf69114ad87e390c9c0e8b0727ac'
assert sha(current.read_bytes())==expected
sys.path.insert(0,str(fixed/'scripts'))
from stage9_source import configure_source
configure_source(fixed,w)
from ai_accounting.kernel.catalog import Catalog
from ai_accounting.kernel.engine import Engine
from ai_accounting.kernel.resident_reads import ResidentReadPool
from ai_accounting.kernel.types import YearMonth
import ai_accounting.kernel as package
from ai_accounting.kernel import query_reads as before
from ai_accounting.kernel.storage import _active_fact_reads
from stage9_metrics import measure_work
alias='ai_accounting.kernel._stage9_r74_private_query_reads'
spec=importlib.util.spec_from_file_location(alias,current);after=importlib.util.module_from_spec(spec);sys.modules[alias]=after;spec.loader.exec_module(after)
bookpath=w/'.tmp/stage9-owner-main48-r73-verified.json';book=json.loads(bookpath.read_text(encoding='utf8'));assert book['status']=='complete' and book['integrity']['status']=='verified' and not book['integrity']['limitations']
root=Path(book['root']);assert root==w/'.tmp/stage9-owner-main48-r63'
result={'scope':'private_single_query_reads_overlay_first_owned_guard_ABBA_diagnostic_not_acceptance','fixed_source':str(fixed),'after_module':str(current),'after_sha256':expected,'before_sha256':sha(Path(before.__file__).read_bytes()),'private_alias':alias,'book_report_sha256':sha(bookpath.read_bytes()),'root':str(root),'concurrency':'small suites/agents may run, not pure latency acceptance','GC_policy':'unchanged; no freeze/collect/threshold operations','overrides':'sequential sys.modules canonical query_reads and package.query_reads point to selected side inside each snapshot; shared storage ContextVar holds that side QueryReads. Restored at every exit. All other source modules/registry/contracts fixed r73 released1.','native_timer_scope':'guard only, snapshot creation and proof extraction excluded','work_scope':'measure_work wraps snapshot/BEGIN and guard; separate untimed work pass per side/scope; bytecode alias may not be covered by every named function counter','runs':[],'work':{},'status':'running'}
canonical=sys.modules['ai_accounting.kernel.query_reads'];package_old=package.query_reads
@contextmanager
def selected(module):
 sys.modules['ai_accounting.kernel.query_reads']=module;package.query_reads=module
 try:yield
 finally:sys.modules['ai_accounting.kernel.query_reads']=canonical;package.query_reads=package_old
normalize=lambda value:json.loads(json.dumps(value,sort_keys=True,default=lambda x: dict(x) if hasattr(x,'keys') else {'exact_bytes_hex': x.hex()} if isinstance(x,bytes) else (_ for _ in ()).throw(TypeError(type(x).__name__))))
def proof(reads):
 return {'relations':{k:v for k,v in sorted(reads._verified_current_voucher_publications.items())},'publication_records':dict(sorted(reads._verified_publication_ids.items())),'open_scopes':sorted([(str(k),v) for k,v in reads._verified_open_voucher_scopes.items()])}
pool=None;golden={}
try:
 catalog=Catalog(root);pool=ResidentReadPool()
 with catalog.connection(read_only=True) as connection:row=dict(connection.execute('SELECT * FROM company WHERE id=?',(book['company']['id'],)).fetchone());store=catalog._bound_store(row,read_pool=pool)
 engine=Engine(store);period=YearMonth('2019-12').ordinal
 def call(module,scope,timed):
  with selected(module):
   with module.QueryReads.snapshot(engine) as reads:
    assert type(reads) is module.QueryReads and _active_fact_reads.get() is reads and module._active_fact_reads.get() is reads
    assert not reads._verified_current_voucher_publications and not reads._verified_publication_ids and not reads._verified_open_voucher_scopes
    start=time.perf_counter();cpu=time.process_time()
    reads.verify_open_voucher_scope(period,posting_period=period if scope=='month' else None)
    cpu_ms=(time.process_time()-cpu)*1000;wall_ms=(time.perf_counter()-start)*1000
    value=normalize(proof(reads));assert len(value['publication_records'])==1006
    if scope in golden:assert value==golden[scope], 'exact relation/cache mismatch'
    else:golden[scope]=value
    data={'wall_ms':wall_ms,'cpu_ms':cpu_ms,'proof_sha256':sha(json.dumps(value,sort_keys=True,separators=(',',':')).encode()),'relation_count':len(value['relations']),'record_count':len(value['publication_records']),'owned_module':module.__name__}
   assert not reads._snapshot_active and not reads._verified_publication_ids and not reads._verified_current_voucher_publications
   return data
 for scope in ('month','through'):
  for index in range(3):
   for side,module in (('A',before),('B',after)):call(module,scope,False)
  for block in range(3):
   for side,module in (('A',before),('B',after),('B',after),('A',before)):
    item=call(module,scope,True);result['runs'].append(dict(scope=scope,side=side,block=block,**item))
  result['work'][scope]={}
  for side,module in (('A',before),('B',after)):
   work,proof_result=measure_work(engine,lambda module=module,scope=scope:call(module,scope,False));result['work'][scope][side]={'metrics':work,'proof':proof_result}
 result['summary']={scope:{side:{'samples':6,'wall_median_ms':statistics.median(x['wall_ms'] for x in result['runs'] if x['scope']==scope and x['side']==side),'cpu_median_ms':statistics.median(x['cpu_ms'] for x in result['runs'] if x['scope']==scope and x['side']==side),'wall_min_ms':min(x['wall_ms'] for x in result['runs'] if x['scope']==scope and x['side']==side),'wall_max_ms':max(x['wall_ms'] for x in result['runs'] if x['scope']==scope and x['side']==side)} for side in ('A','B')} for scope in ('month','through')}
 assert sha(current.read_bytes())==expected,'after source changed during diagnostic'
 result['exact_proof_equality']=True;result['status']='complete'
except BaseException as e:
 result.update(status='failed',error_type=type(e).__name__,error=str(e),traceback=traceback.format_exc());raise
finally:
 if pool is not None:pool.close()
 with output.open('x',encoding='utf8') as o:json.dump(result,o,ensure_ascii=False,indent=2);o.write('\n')
 print(json.dumps({k:result[k] for k in ('status','summary') if k in result}),flush=True)
