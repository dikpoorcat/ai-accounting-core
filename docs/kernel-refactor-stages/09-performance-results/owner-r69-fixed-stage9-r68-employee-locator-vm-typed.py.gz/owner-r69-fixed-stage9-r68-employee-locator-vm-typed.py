"""Typed-month correction of prior wrong-month SQL probes; no native timing."""
import json
import sqlite3
from pathlib import Path
from types import SimpleNamespace

from ai_accounting.kernel.dashboard_reads import _payroll_identity_subjects, _payroll_roster_sql
from ai_accounting.kernel.types import YearMonth

w = Path(__file__).resolve().parents[1]
profile = json.loads((w / '.tmp/stage9-resident-r68-main48-profile.json').read_text('utf-8'))
book = Path(profile['root']) / '91310000123456789S/company.sqlite'
assert book.is_relative_to(w / '.tmp')
connection = sqlite3.connect(book.as_uri() + '?mode=ro', uri=True)
connection.row_factory = sqlite3.Row
connection.execute('PRAGMA query_only=ON')
period = '2019-12'
month = YearMonth(period).ordinal
assert month == 24227
closes = list(connection.execute('SELECT * FROM period_close WHERE period<=?', (month,)))
assert month not in {row['period'] for row in closes}
# Roots supply parameters only. This adapter does not authenticate business
# results or populate successful production proof caches.
reads = SimpleNamespace(
    authoritative_close_rows=lambda periods, through_period: [r for r in closes if r['period'] in periods],
    close_header=lambda row: SimpleNamespace(root=json.loads(row['manifest'])),
)
snapshot = SimpleNamespace(connection=connection, month=month, period=period, reads=reads, close=None)
subjects = _payroll_identity_subjects(snapshot)
new_sql, params = _payroll_roster_sql(
    snapshot, {'annual_bonus', 'opening_payroll_payable', 'payroll', 'payroll_bounded'}, subjects)
old_sql = max(profile['operations']['employees']['work']['sql'],
              key=lambda item: item.get('sqlite_vm_steps', 0))['statement']
prefix, witness_tail = old_sql.split(' , witnesses AS ', 1)
witness_prefix = prefix + ' , witnesses AS ' + witness_tail.split(', selected_heads AS ', 1)[0]
cases = [(name, prefix + ' SELECT * FROM ' + name, params[:4])
         for name in ('scoped_subjects', 'frozen_locators', 'eligible')]
cases += [('ranked_heads', prefix + ' SELECT * FROM heads WHERE rn=1', params[:4]),
          ('witnesses', witness_prefix + ' SELECT * FROM witnesses WHERE employee_rank=1', params[:4]),
          ('r68_baseline', old_sql, params), ('final_production', new_sql, params)]
out = {'scope': 'read_only_fixed_synthetic_SQL_VM_no_native_timing_no_business_proof',
       'database': str(book), 'period': period, 'ordinal_source': 'YearMonth(period).ordinal',
       'month': month, 'parameters': params, 'correction': {
           'old_probe_month': 24239, 'actual_typed_month': month,
           'invalid_for_same_parameter_claim': [
               'stage9-r67-head-locator-explain.json', 'stage9-r67-head-locator-explain-after.json',
               'stage9-r68-employee-locator-vm.json', 'stage9-r68-employee-locator-vm-dedupe.json'],
           'policy': 'Preserve old experiment logs; obtain ordinals from typed months or captured bindings.'
       }, 'cases': []}
baseline = None
for name, sql, bound in cases:
    list(connection.execute(sql, bound))
    count = [0]
    def progress():
        count[0] += 100
        return 0
    connection.set_progress_handler(progress, 100)
    rows = [tuple(row) for row in connection.execute(sql, bound)]
    connection.set_progress_handler(None, 0)
    if name == 'r68_baseline':
        baseline = rows
    if name == 'final_production':
        assert rows == baseline
        out['all_field_output_equal'] = True
    plan = [list(row) for row in connection.execute('EXPLAIN QUERY PLAN ' + sql, bound)]
    item = {'name': name, 'vm': count[0], 'rows': len(rows), 'sql': sql, 'plan': plan}
    out['cases'].append(item)
    print(json.dumps({'name': name, 'vm': count[0], 'rows': len(rows), 'month': month,
                      'role_plan': [p[3] for p in plan if 'entity_current' in p[3]
                                    or 'entity_reference' in p[3] or 'AUTOMATIC' in p[3]]}), flush=True)
(w / '.tmp/stage9-r68-employee-locator-vm-typed.json').write_text(
    json.dumps(out, ensure_ascii=False, indent=2), 'utf-8')
connection.close()
