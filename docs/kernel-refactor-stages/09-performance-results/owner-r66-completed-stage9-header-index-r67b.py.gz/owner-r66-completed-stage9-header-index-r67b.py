"""Second explicit synthetic-copy experiment: index choice and exact results."""
from pathlib import Path
import ast
import hashlib
import inspect
import json
import sqlite3
import sys
import textwrap
import time
w=Path(__file__).resolve().parents[1]
src=w/'.tmp/stage9-build-source-owner-r66-release'
sys.path.insert(0,str(src/'scripts'))
from stage9_source import configure_source
configure_source(src,w)
from ai_accounting.kernel.query_reads import QueryReads
from ai_accounting.kernel.types import canonical,YearMonth
target=w/'.tmp/stage9-header-index-r67.sqlite'
prior=json.loads((w/'.tmp/stage9-header-index-r67.json').read_text('utf-8'))
assert prior['copy']==str(target) and prior['scope'].startswith('index_experiment')
tree=ast.parse(textwrap.dedent(inspect.getsource(QueryReads.calculation_identity_headers)))
sql=next(n.args[0].value for n in ast.walk(tree) if isinstance(n,ast.Call)
         and isinstance(n.func,ast.Attribute) and n.func.attr=='execute')
with sqlite3.connect(target.as_uri()+'?mode=ro',uri=True) as c:
    ids=[r[0] for r in c.execute("SELECT c.id FROM calculation_current h JOIN calculation c "
        "ON c.id=h.calculation_id JOIN subject s ON s.id=c.subject_id "
        "WHERE s.kind IN ('payroll','bounded_payroll') AND c.period<=?",
        (YearMonth('2019-12').ordinal,))]
params=(canonical(sorted(ids)),)
out={'scope':'index_choice_experiment_not_accepted_database_or_page_benchmark',
     'copy':str(target),'source':str(src),'variants':{}}
for name in ('nonunique_forced','unique_auto','unique_forced'):
    if name=='unique_auto':
        with sqlite3.connect(target) as c:
            c.execute('CREATE UNIQUE INDEX header_unique_experiment ON calculation('
                      'id,subject_id,fact_id,kind,period,digest,program_version)')
    statement=sql if name=='unique_auto' else sql.replace('JOIN calculation c ON',
        'JOIN calculation c INDEXED BY '+('header_transport_experiment' if name=='nonunique_forced'
        else 'header_unique_experiment')+' ON')
    samples=[]
    for attempt in range(5):
        with sqlite3.connect(target.as_uri()+'?mode=ro',uri=True) as c:
            c.row_factory=sqlite3.Row
            c.execute('PRAGMA query_only=ON');c.execute('PRAGMA cache_size=-65536');c.execute('BEGIN')
            start=time.perf_counter();cursor=c.execute(statement,params);begun=time.perf_counter()
            rows=cursor.fetchall();fetched=time.perf_counter()
            names=[r[0] for r in cursor.description]
            values=[dict(zip(names,r,strict=True)) for r in rows];finished=time.perf_counter()
            samples.append({'execute_ms':(begun-start)*1000,'fetch_ms':(fetched-begun)*1000,
                'convert_ms':(finished-fetched)*1000,'rows':len(rows),
                'output_digest':hashlib.sha256(repr(values).encode()).hexdigest()})
            plan=[tuple(r) for r in c.execute('EXPLAIN QUERY PLAN '+statement,params)]
            c.rollback()
    out['variants'][name]={'plan':plan,'samples':samples}
with (w/'.tmp/stage9-header-index-r67b.json').open('x',encoding='utf-8') as handle:
    json.dump(out,handle,ensure_ascii=False,indent=2)
print(json.dumps(out,ensure_ascii=False),flush=True)
