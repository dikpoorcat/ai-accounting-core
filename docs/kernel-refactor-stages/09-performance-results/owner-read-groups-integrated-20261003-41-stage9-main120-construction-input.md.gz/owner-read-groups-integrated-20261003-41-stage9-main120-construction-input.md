# Main120 construction-only qualification input

Prepared only: the helper has not been executed, connected to any database,
qualified the book, previewed a period, or timed a request in this task.

The completed raw-copy report cannot directly feed benchmark_stage9_browser
qualification because it lacks company, months, snapshots, distribution and
construction dimensions. The narrow helper assembles only those pinned inputs.

After root confirms the copy process has completed successfully, run in the
repository PowerShell with no concurrent synthetic-book writer:

```powershell
$stage9Main120CopySha = (Get-FileHash -LiteralPath '.tmp/stage9-main120-candidate-cache-group-20261003/stage9-main120-copy-report.json' -Algorithm SHA256).Hash.ToLowerInvariant()
& '.tmp-kernel-venv/Scripts/python.exe' '.tmp/stage9-main120-construction-input.py' --copy-report-sha256 $stage9Main120CopySha --output '.tmp/stage9-owner-main120-read-groups-construction.json'
```

The output must not exist. The SHA argument binds the explicit completed-copy
report; a partial/failed/check-only copy is rejected. The original r22 fixed
CASE report/checkpoint and full source manifests are checked; copied checkpoint
must equal the original except for its explicit isolated company path. Target
catalog/company actual schema, identity, state epochs and closed preview metadata
are read in query-only transactions and compared with the exact checkpoint.
No source database is connected. Current qualification source is pinned to
46f84508afd54165f23af5a83434b1881002ab45490f4358f0c1755c743748be;
the raw copy source is separately recorded as
19ae7d824077e8e988ffe254120f7d8ee7ed42708c5fdf8fb6eff2ffb3e49941.
Their declared company/catalog and content contracts must actually match, and
the target SQL must pass the current schema checker/current factory contract.

The copy's table-byte attestations are checked for inventory, original-table
equality and new-table emptiness, but business bytes are not rescanned here.
The report explicitly records that limitation. Actual content acceptance belongs
to the independent current registered verifier, not metadata conversion.

The emitted status is unverified, four coverage sections are unverified,
measurements are empty, and there is no verified_open_preview. It retains the
original exact month_stats (including seconds), solely as historical construction
statistics required by checkpoint dimension equality. Those seconds cannot serve
as current request/browser performance. The default page limit is 20.

For the next independent qualification, use the fixed current harness with:

```text
.tmp-kernel-venv/Scripts/python.exe .tmp/stage9-build-source-owner-read-groups-20261003-release/scripts/benchmark_stage9_browser.py --source .tmp/stage9-build-source-owner-read-groups-20261003-release --workspace D:/GitHub/ai-accounting-core --book-report .tmp/stage9-owner-main120-read-groups-construction.json --qualify-output .tmp/stage9-owner-main120-read-groups-verified.json --output .tmp/stage9-owner-main120-read-groups-qualification-layout.json --layout-only --repeats 30 --node <root's existing Node executable> --playwright-module <root's existing Playwright module>
```

Node/Playwright arguments must reuse the actual installed paths from root's
current browser commands; placeholders above are not runnable paths. The
qualification command itself is not executed by this preparation task. It runs
the registered full verifier followed by a resident real open-month preview;
layout-only does not supply browser timing acceptance. Every output is separate
and absent before its run. Qualification failure must remain a failure report;
construction-only input cannot pass normal browser validation without a genuine
new complete qualification report. Later timed browser acceptance remains a
separate run using that report and 30 successful samples.
