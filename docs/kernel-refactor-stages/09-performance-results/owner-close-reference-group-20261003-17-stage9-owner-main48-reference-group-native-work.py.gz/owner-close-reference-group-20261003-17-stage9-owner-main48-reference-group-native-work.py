"""Pinned, read-only instrumented diagnostic; this is never browser acceptance timing."""

from __future__ import annotations

import cProfile
import hashlib
import json
import pstats
import sys
from contextlib import contextmanager
from pathlib import Path

WORKSPACE = Path(__file__).resolve().parents[1]
SOURCE = WORKSPACE / ".tmp/stage9-build-source-owner-reference-group-20261003-release"
MANIFEST = SOURCE / "source-manifest.json"
import argparse

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--months', type=int, choices=(48,), required=True)
parser.add_argument('--book-report', type=Path, required=True)
parser.add_argument('--report-sha256', required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
BOOK_REPORT = args.book_report.resolve(strict=True)
OUTPUT = args.output.resolve()
assert BOOK_REPORT.is_relative_to(WORKSPACE / '.tmp')
assert OUTPUT.is_relative_to(WORKSPACE / '.tmp') and not OUTPUT.exists()
MANIFEST_FILE_SHA256 = '9de4a38ae2f93fc575d5a68898ad3cba334ab4dc5786c67731a6c1eead1d52b5'
SOURCE_SHA256 = '6688df6c46f5416ca03917def0d29a701cb20e8ae45b962c59df4a1290f8da62'
REPORT_SHA256 = '029e0eb04fdf4a51cde2d2f1ce235031a3086f33735eec92d70321d562f54656'
assert args.report_sha256 == REPORT_SHA256, "Only this pinned old-qualified main48 qualification is permitted"
assert BOOK_REPORT == (WORKSPACE / '.tmp/stage9-owner-main48-month-reads-qualified.json').resolve()
assert OUTPUT == (WORKSPACE / '.tmp/stage9-owner-main48-reference-group-native-work.json').resolve()


def file_hash(path):
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def main():
    require(
        Path(sys.prefix).resolve() == (WORKSPACE / ".tmp-kernel-venv").resolve(),
        "Use the repository virtual environment",
    )
    require(not OUTPUT.exists(), "Diagnostic output must not exist")
    require(file_hash(MANIFEST) == MANIFEST_FILE_SHA256, "Pinned manifest bytes changed")
    require(file_hash(BOOK_REPORT) == REPORT_SHA256, "Pinned verified report bytes changed")
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    require(
        manifest["status"] == "complete"
        and manifest["sha256"] == SOURCE_SHA256
        and Path(manifest["target"]).resolve() == SOURCE.resolve(),
        "Wrong source manifest",
    )

    # Bootstrap only from the fixed candidate, before importing any accounting module.
    sys.path.insert(0, str(SOURCE / "scripts"))
    import stage9_source

    stage9_source.require_source_module(stage9_source, SOURCE, "scripts/stage9_source.py")
    stage9_source.configure_source(SOURCE, WORKSPACE)
    import benchmark_stage9_browser
    import snapshot_stage9_source
    import stage9_metrics

    from ai_accounting.kernel import catalog as catalog_module
    from ai_accounting.kernel import dashboard as dashboard_module
    from ai_accounting.kernel import engine as engine_module
    from ai_accounting.kernel import resident_reads, schema_bundle
    from ai_accounting.kernel.types import canonical
    from ai_accounting.kernel.versions import database_format

    for module, relative in (
        (snapshot_stage9_source, "scripts/snapshot_stage9_source.py"),
        (benchmark_stage9_browser, "scripts/benchmark_stage9_browser.py"),
        (stage9_metrics, "tests/kernel/stage9_metrics.py"),
        (catalog_module, "src/ai_accounting/kernel/catalog.py"),
        (dashboard_module, "src/ai_accounting/kernel/dashboard.py"),
        (engine_module, "src/ai_accounting/kernel/engine.py"),
        (resident_reads, "src/ai_accounting/kernel/resident_reads.py"),
        (schema_bundle, "src/ai_accounting/kernel/schema_bundle.py"),
    ):
        stage9_source.require_source_module(module, SOURCE, relative)

    def check_source():
        inventory = snapshot_stage9_source._inventory(SOURCE)
        require(
            inventory == manifest["files"]
            and snapshot_stage9_source._digest(inventory) == SOURCE_SHA256,
            "Fixed source bytes drifted",
        )
        require(
            file_hash(MANIFEST) == MANIFEST_FILE_SHA256 and file_hash(BOOK_REPORT) == REPORT_SHA256,
            "Pinned attestations drifted",
        )

    check_source()
    book = json.loads(BOOK_REPORT.read_text(encoding="utf-8"))
    OLD_SOURCE = WORKSPACE / ".tmp/stage9-build-source-owner-month-reads-20261003-release"
    old_manifest_path = OLD_SOURCE / "source-manifest.json"
    require(file_hash(old_manifest_path) == "845318d7e9857cbae422033a7e8b87a5fb7edd2896f1c5f0617709eabca1c979", "Old qualification source manifest changed")
    old_manifest = json.loads(old_manifest_path.read_text(encoding="utf-8"))
    contract_prefix = "src/ai_accounting/kernel/schema_contracts/"
    current_contracts = {k: v for k, v in manifest["files"].items() if k.startswith(contract_prefix)}
    old_contracts = {k: v for k, v in old_manifest["files"].items() if k.startswith(contract_prefix)}
    require(current_contracts and current_contracts == old_contracts, "Diagnostic requires identical manifest contracts")
    for relative, digest in current_contracts.items():
        require(file_hash(SOURCE / relative) == digest and file_hash(OLD_SOURCE / relative) == digest, "Contract bytes changed")
    benchmark_stage9_browser.require_report_source(book, OLD_SOURCE)
    period = benchmark_stage9_browser.validate_book_report(book, company_name="阶段九合成规模企业")
    require(
        book["requested_months"] == args.months
        and book["employee_count"] == 50
        and book["monthly_business_count"] == 1000
        and book["distribution"] == "mixed_cumulative",
        "Wrong main sample dimensions",
    )
    root = stage9_source.synthetic_path(Path(book["root"]), WORKSPACE)
    company = book["company"]
    checkpoint_path = root / "stage9-builder.json"
    checkpoint_hash = file_hash(checkpoint_path)
    require(checkpoint_hash == book["qualification"].get("checkpoint_sha256"), "Old qualified checkpoint changed")
    checkpoint = json.loads(checkpoint_path.read_text(encoding="utf-8"))
    preview = book["verified_open_preview"]
    require(
        checkpoint["company"] == company
        and checkpoint["snapshots"] == book["snapshots"]
        and checkpoint["epochs"] == preview["state"],
        "Checkpoint no longer matches proof",
    )
    expected_state = preview["state"]
    expected_identity = {
        "company_id": company["id"],
        "database_id": company["database_id"],
        "taxpayer_id": company["taxpayer_id"],
    }
    integrity_contract = book["integrity_contract"]
    del checkpoint, book
    require(
        (root / "catalog.sqlite").is_file() and Path(company["path"]).is_file(),
        "Existing databases are required",
    )

    class ReadOnlyCatalog(catalog_module.Catalog):
        @contextmanager
        def connection(self, *, read_only=False, _cross_thread=False):
            require(read_only, "Diagnostic forbids catalog writes")
            with super().connection(read_only=True, _cross_thread=_cross_thread) as connection:
                yield connection

        def recover_operations(self):
            # Never resume pending publications during a read diagnostic.
            with self.connection(read_only=True) as connection:
                count = connection.execute(
                    "SELECT count(*) FROM company_operation WHERE status!='succeeded'"
                ).fetchone()[0]
            require(
                count == 0, "Catalog has unfinished operations; diagnostic will not recover them"
            )

    bundle = schema_bundle.production_bundle()
    catalog = ReadOnlyCatalog(root, bundle)
    require(
        catalog.database_format()["status"] == "released"
        and catalog.database_format()["version"] == 1,
        "Wrong catalog contract",
    )
    companies = catalog.companies()
    require(
        [row for row in companies if row["id"] == company["id"]] == [company],
        "Catalog company identity changed",
    )
    with catalog.connection(read_only=True) as connection:
        catalog_identity = dict(connection.execute("SELECT * FROM catalog_identity").fetchone())

    pool = resident_reads.ResidentReadPool(maximum=4)
    store = catalog.bind(company["id"], read_pool=pool)
    original_connection = store.connection

    @contextmanager
    def read_only_connection(*, read_only=False):
        require(read_only, "Diagnostic forbids company writes")
        with original_connection(read_only=True) as connection:
            yield connection

    store.connection = read_only_connection
    engine = engine_module.Engine(store)
    dashboard = dashboard_module.Dashboard(
        engine, company_name=company["name"], companies=companies
    )
    year, month = map(int, period.split("-"))
    quarter = (month - 1) // 3 + 1

    def check_state():
        require(file_hash(old_manifest_path) == "845318d7e9857cbae422033a7e8b87a5fb7edd2896f1c5f0617709eabca1c979", "Old source manifest drifted")
        for relative, digest in old_contracts.items():
            require(file_hash(OLD_SOURCE / relative) == digest, "Old qualification contracts drifted")
        with store.connection(read_only=True) as connection:
            connection.execute("BEGIN")
            state = list(connection.execute("SELECT * FROM state WHERE id=1").fetchone())
            identity = dict(
                connection.execute(
                    "SELECT company_id,taxpayer_id,database_id FROM identity WHERE id=1"
                ).fetchone()
            )
            require(
                state == expected_state and identity == expected_identity,
                "Company identity, business state or repair revision changed",
            )
            require(
                database_format(connection, bundle=bundle) == integrity_contract,
                "Company format differs from verified source",
            )
        with catalog.connection(read_only=True) as connection:
            require(
                dict(connection.execute("SELECT * FROM catalog_identity").fetchone())
                == catalog_identity,
                "Catalog identity changed",
            )
        require(catalog.companies() == companies, "Catalog registration changed")
        require(file_hash(checkpoint_path) == checkpoint_hash, "Construction checkpoint changed")
        return {"state": state, "identity": identity, "catalog_identity": catalog_identity}

    operations = {
        "context": dashboard.context,
        "brief": lambda: dashboard.brief(period, limit=20, preparation="deferred"),
        "funds": lambda: dashboard.funds(
            period, limit=20, preparation="deferred", movement_account_selection="first"
        ),
        "employees": lambda: dashboard.employees(period, limit=20, preparation="deferred"),
        "assets": lambda: dashboard.assets(period, limit=20, preparation="deferred"),
        "quarterly_report": lambda: dashboard.quarterly_report(
            year, quarter, preparation="deferred"
        ),
    }
    report = {
        "status": "diagnostic_started",
        "scope": "instrumented_native_read_diagnostic",
        "instrumented": True,
        "browser_acceptance": False,
        "source": str(SOURCE),
        "source_sha256": SOURCE_SHA256,
        "book_qualification_source": str(OLD_SOURCE),
        "current_source_full_verification": False,
        "verified_report": str(BOOK_REPORT),
        "verified_report_sha256": REPORT_SHA256,
        "root": str(root),
        "period": period,
        "quarter": f"{year}-Q{quarter}",
        "default_page_limit": 20,
        "resident_pool_maximum": 4,
        "measurements": {},
        "notes": [
            "Old 1c37 qualification binds synthetic sample only; current source is NOT fully qualified.",
            "No content verifier or preview construction rerun; current normal page validations still execute.",
            "Sequential native calls share only the normal resident SQLite connection pool.",
            "Excludes HTTP/auth transport and volatile service owner-review lookup.",
            "cProfile separately rereads brief/report; it never overlaps measure_work.",
            "Instrumented time and allocation peaks are not page latency or production RSS.",
        ],
    }
    # Exclusive output creation; a failure remains a diagnostic failure record.
    with OUTPUT.open("x", encoding="utf-8") as output:
        try:
            report["before"] = check_state()
            for name, operation in operations.items():
                check_state()
                work, result = stage9_metrics.measure_work(engine, operation)
                require(
                    result.get("read_context", {}).get(
                        "company_id", result.get("current_company", {}).get("company_id")
                    )
                    == company["id"],
                    f"{name}: wrong response company",
                )
                if name not in {"context", "quarterly_report"}:
                    require(
                        result["selected_period"]["key"] == period, f"{name}: wrong response month"
                    )
                    for section, collection in result["data"]["collections"].items():
                        page = collection["page"]
                        require(
                            len(collection["items"])
                            == page["returned_count"]
                            == min(20, page["filtered_count"]),
                            f"{name}/{section}: incomplete default page",
                        )
                work["response_bytes"] = len(canonical(result).encode("utf-8"))
                work["schema_version"] = result["schema_version"]
                del result
                report["measurements"][name] = work
                check_state()
            for name in ("brief", "quarterly_report"):
                profiler = cProfile.Profile()
                result = profiler.runcall(operations[name])
                del result
                stats = pstats.Stats(profiler)
                rows = sorted(stats.stats.items(), key=lambda item: item[1][3], reverse=True)[:50]
                report["measurements"][name]["cprofile"] = {
                    "scope": "separate_instrumented_native_read",
                    "total_calls": stats.total_calls,
                    "total_seconds": stats.total_tt,
                    "top_cumulative": [
                        {
                            "file": filename,
                            "line": line,
                            "function": function,
                            "primitive_calls": values[0],
                            "total_calls": values[1],
                            "self_seconds": values[2],
                            "cumulative_seconds": values[3],
                        }
                        for (filename, line, function), values in rows
                    ],
                }
                check_state()
            report["after"] = check_state()
            check_source()
            report["status"] = "diagnostic_complete"
        except BaseException as error:
            report["status"] = "diagnostic_failed"
            report["error"] = {"type": type(error).__name__, "message": str(error)}
            raise
        finally:
            pool.close()
            json.dump(report, output, ensure_ascii=False, indent=2)
            output.write("\n")
    print(json.dumps({"status": report["status"], "output": str(OUTPUT)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
