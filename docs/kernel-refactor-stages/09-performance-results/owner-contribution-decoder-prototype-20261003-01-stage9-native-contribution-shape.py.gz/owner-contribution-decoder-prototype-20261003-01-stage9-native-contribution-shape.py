"""Prototype only: isolated contribution-shape equivalence and local decode cost."""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import sys
import time
import traceback
from collections import Counter
from pathlib import Path

W = Path(__file__).resolve().parents[1]
SOURCE = W / '.tmp/stage9-build-source-owner-month-reads-20261003-release'
SOURCE_SHA = '1c37c576cb0026b0b39c199b74672a60890c43a7d9e2b944416179fe2bf398e9'
MANIFEST_SHA = '845318d7e9857cbae422033a7e8b87a5fb7edd2896f1c5f0617709eabca1c979'
BOOK = W / '.tmp/stage9-owner-main12-month-reads-qualified.json'


def require(value, reason):
    if not value:
        raise ValueError(reason)


def sha(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def fingerprint(value):
    """Preserve all sequence/container/scalar types; dict order is reported separately."""
    if type(value) is dict:
        return ['dict', [[key, fingerprint(item)] for key, item in sorted(value.items())]]
    if type(value) in (list, tuple):
        return [type(value).__name__, [fingerprint(item) for item in value]]
    if type(value) is float:
        return ['float', value.hex()]
    return [type(value).__name__, str(value) if type(value) is int else value]


def result_digest(value):
    return hashlib.sha256(json.dumps(fingerprint(value), ensure_ascii=False).encode()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--report-sha256', required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--rounds', type=int, default=5, choices=range(1, 11))
    args = parser.parse_args()
    out = args.output.resolve()
    log_path = out.with_suffix('.log')
    require(out.is_relative_to(W / '.tmp') and not out.exists() and not log_path.exists(),
            'Exclusive must-new output/log inside .tmp required')
    require(Path(sys.prefix).resolve() == (W / '.tmp-kernel-venv').resolve(), 'Use repo venv')
    report = {'status': 'started', 'scope': 'local_contribution_structure_prototype',
              'production_modified': False, 'read_only': True, 'page_latency_acceptance': False,
              'source_sha256': SOURCE_SHA, 'script_sha256': sha(Path(__file__)),
              'cases': [], 'local_rounds': {'original': [], 'native': []}}
    out.open('x').close()
    log = log_path.open('x', encoding='utf-8')

    def save():
        out.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

    def note(value):
        print(value, flush=True)
        log.write(value + '\n')
        log.flush()

    try:
        require(sha(SOURCE / 'source-manifest.json') == MANIFEST_SHA, 'Manifest drift')
        require(sha(BOOK) == args.report_sha256, 'Qualification receipt drift')
        manifest = json.loads((SOURCE / 'source-manifest.json').read_text(encoding='utf-8'))
        require(manifest['status'] == 'complete' and manifest['sha256'] == SOURCE_SHA
                and Path(manifest['target']).resolve() == SOURCE, 'Wrong fixed source')
        sys.path.insert(0, str(SOURCE / 'scripts'))
        import stage9_source
        stage9_source.configure_source(SOURCE, W)
        import snapshot_stage9_source
        import benchmark_stage9_browser
        from ai_accounting.kernel import report_open_contribution as contribution
        from ai_accounting.kernel import schema_bundle, storage
        from ai_accounting.kernel.contracts import KernelError
        from ai_accounting.kernel.types import YearMonth
        from ai_accounting.kernel.versions import database_format
        from pydantic_core import SchemaValidator, ValidationError, core_schema
        modules = [(stage9_source, 'scripts/stage9_source.py'),
                   (snapshot_stage9_source, 'scripts/snapshot_stage9_source.py'),
                   (benchmark_stage9_browser, 'scripts/benchmark_stage9_browser.py'),
                   (contribution, 'src/ai_accounting/kernel/report_open_contribution.py'),
                   (schema_bundle, 'src/ai_accounting/kernel/schema_bundle.py'),
                   (storage, 'src/ai_accounting/kernel/storage.py')]
        for module, relative in modules:
            stage9_source.require_source_module(module, SOURCE, relative)
        inventory = snapshot_stage9_source._inventory(SOURCE)
        require(inventory == manifest['files'] and snapshot_stage9_source._digest(inventory) == SOURCE_SHA,
                'Source inventory drift')
        report['module_bindings'] = {m.__name__: {'path': str(m.__file__), 'sha256': sha(Path(m.__file__))}
                                     for m, _ in modules}
        book = json.loads(BOOK.read_text(encoding='utf-8'))
        benchmark_stage9_browser.require_report_source(book, SOURCE)
        period = benchmark_stage9_browser.validate_book_report(book, company_name='阶段九合成规模企业')
        require(book['requested_months'] == 12 and book['monthly_business_count'] == 1000
                and book['employee_count'] == 50 and book['distribution'] == 'mixed_cumulative',
                'Wrong qualified sample')
        root = stage9_source.synthetic_path(Path(book['root']), W)
        require(root == W / '.tmp/stage9-owner-main12-r43', 'Wrong authorized root')
        company = book['company']
        db = Path(company['path']).resolve(strict=True)
        require(db.is_relative_to(root), 'DB outside authorized synthetic root')
        checkpoint_path = root / 'stage9-builder.json'
        checkpoint = json.loads(checkpoint_path.read_text(encoding='utf-8'))
        preview = book['verified_open_preview']
        require(checkpoint['company'] == company and checkpoint['snapshots'] == book['snapshots']
                and checkpoint['epochs'] == preview['state'], 'Checkpoint differs from proof')
        checkpoint_sha = sha(checkpoint_path)
        require(checkpoint_sha == book['qualification']['checkpoint_sha256'], 'Checkpoint SHA drift')
        report.update({'root': str(root), 'period': period, 'qualification_sha256': args.report_sha256,
                       'checkpoint_sha256': checkpoint_sha})
        bundle = schema_bundle.production_bundle()
        store = storage.Store(db, bundle, company['id'], company['database_id'],
                              taxpayer_id=company['taxpayer_id'])
        month = YearMonth(period).ordinal
        with store.connection(read_only=True) as connection:
            connection.execute('BEGIN')
            state = list(connection.execute('SELECT * FROM state WHERE id=1').fetchone())
            identity = tuple(connection.execute(
                'SELECT company_id,taxpayer_id,database_id FROM identity WHERE id=1').fetchone())
            require(state == preview['state'], 'State differs from qualified proof')
            require(identity == (company['id'], company['taxpayer_id'], company['database_id']),
                    'Identity differs from qualified proof')
            require(database_format(connection, bundle=bundle) == book['integrity_contract'], 'Schema drift')
            sql = (
                'SELECT p.id,p.calculation_id,a.calculation_id anchor_calculation_id,'
                'a.content_digest anchor_digest,d.content,d.content_digest body_digest '
                'FROM calculation_publication p '
                'LEFT JOIN report_open_contribution_anchor a ON a.publication_id=p.id '
                'LEFT JOIN report_open_contribution d ON d.publication_id=p.id '
                'WHERE p.posting_period=? AND p.calculation_id IS NOT NULL '
                'AND NOT EXISTS(SELECT 1 FROM calculation_publication n '
                'WHERE n.previous_publication_id=p.id) ORDER BY p.id'
            )
            actual = list(connection.execute(sql, (month,)))
            require(actual, 'No current-month contribution candidates')
            bodies = []
            for row in actual:
                require(row['content'] is not None and row['anchor_digest'] is not None,
                        'Missing actual body/immutable anchor: stop, do not repair')
                checksum = hashlib.sha256(row['content'].encode()).digest()
                require(row['anchor_calculation_id'] == row['calculation_id']
                        and checksum == row['anchor_digest'] == row['body_digest'], 'Anchor/body binding damage')
                bodies.append((row['content'], row['id']))
            require(list(connection.execute('SELECT * FROM state WHERE id=1').fetchone()) == state,
                    'Ending state drift')
            connection.rollback()
        report['selection'] = {'sql': sql, 'period_ordinal': month, 'candidate_count': len(bodies),
                               'raw_content_bytes': sum(len(raw.encode()) for raw, _ in bodies),
                               'raw_body_digest': hashlib.sha256(''.join(raw for raw, _ in bodies).encode()).hexdigest(),
                               'claims': 'Qualified unchanged sample + exact local anchor match; no new financial proof'}
        # Exact old shape, with no added identifier, hex or monetary restrictions.
        string = core_schema.str_schema(strict=True)
        length64 = core_schema.str_schema(strict=True, min_length=64, max_length=64)
        integer = core_schema.int_schema(strict=True)
        any_list = core_schema.list_schema(core_schema.any_schema(), strict=True)
        def array(*items):
            return core_schema.no_info_after_validator_function(
                list, core_schema.tuple_schema(list(items), strict=True))
        def object_shape(fields):
            return core_schema.typed_dict_schema(
                {key: core_schema.typed_dict_field(value, required=True) for key, value in sorted(fields.items())},
                strict=True, extra_behavior='forbid')
        validator = SchemaValidator(object_shape({
            'format': core_schema.literal_schema(['ai-accounting-kernel/2/report-open-contribution/1']),
            'publication_id': core_schema.any_schema(),  # Old code checks equality to caller, not type separately.
            'calculation_id': string, 'result_digest': length64, 'fact_id': string,
            'parents': core_schema.list_schema(string, strict=True),
            'source_bindings': core_schema.list_schema(array(string, length64, string, length64), strict=True),
            'rows': core_schema.list_schema(array(string, integer, string, integer, integer,
                                                 core_schema.nullable_schema(string),
                                                 core_schema.dict_schema(strict=True)), strict=True),
            'resolution': object_shape({key: any_list for key in (
                'issues', 'line_relations', 'own_party_accounts', 'party_candidates_by_account')}),
            'usable': core_schema.bool_schema(strict=True),
        }))
        fallback = Counter()
        def native(raw, publication_id):
            try:
                value = validator.validate_json(raw, strict=True)
                if value['publication_id'] != publication_id or value['parents'] != sorted(set(value['parents'])):
                    raise ValueError('Original post-shape identity/parents check')
                return value
            except (ValidationError, TypeError, ValueError, KeyError):
                fallback['calls'] += 1
                # Reuse the untouched original oracle to preserve duplicate-member last-wins
                # acceptance, arbitrary JSON and original KernelError semantics on failure.
                return contribution._decode(raw, publication_id)
        def outcome(decoder, raw, ident):
            try:
                value = decoder(raw, ident)
                return {'accepted': True, 'typed_container_digest': result_digest(value)}, value
            except KernelError as exc:
                return {'accepted': False, 'code': exc.code, 'message': str(exc),
                        'details': exc.details}, None
        normal = []
        for index, (raw, ident) in enumerate(bodies):
            old, old_value = outcome(contribution._decode, raw, ident)
            before = fallback['calls']
            new, new_value = outcome(native, raw, ident)
            equivalent = old == new
            report['cases'].append({'case': f'actual-{index}', 'raw_sha256': hashlib.sha256(raw.encode()).hexdigest(),
                                    'original': old, 'native': new, 'equivalent': equivalent,
                                    'native_fallback': fallback['calls'] - before,
                                    'dict_order_equal': (
                                        old_value is None and new_value is None
                                        or isinstance(old_value, dict) and isinstance(new_value, dict)
                                        and list(old_value) == list(new_value))})
            if (index + 1) % 100 == 0 or not equivalent:
                save()
            require(equivalent and old['accepted'], 'Actual shape mismatch/rejection')
            normal.append((raw, ident))
        save()
        # Synthetic in-memory format vectors only; no database mutation or new business fixture.
        base = contribution._decode(*bodies[0])
        base['parents'] = []
        base['source_bindings'] = [['', 'x' * 64, '', 'z' * 64]]
        base['rows'] = [['', 0, '', 0, -1, None, {}]]
        base['resolution'] = {key: [] for key in base['resolution']}
        vectors = [('baseline-permissive', copy.deepcopy(base))]
        for field in ('calculation_id', 'fact_id'):
            for value in ('', None, True, 1, 1.0):
                item = copy.deepcopy(base); item[field] = value
                vectors.append((f'{field}-{type(value).__name__}-{value}', item))
        for value in ('x' * 64, '💰' * 64, 'f' * 63, 'f' * 65, None, 64):
            item = copy.deepcopy(base); item['result_digest'] = value
            vectors.append((f'digest-{type(value).__name__}-{len(value) if isinstance(value, str) else value}', item))
        for value in (True, False, None, 1, 0, 'true'):
            item = copy.deepcopy(base); item['usable'] = value
            vectors.append((f'usable-{type(value).__name__}-{value}', item))
        for column in (1, 3, 4):
            for value in (True, False, 1.0, None, -(2 ** 200), 2 ** 200):
                item = copy.deepcopy(base); item['rows'][0][column] = value
                vectors.append((f'row-{column}-{type(value).__name__}-{value}', item))
        for key in base['resolution']:
            item = copy.deepcopy(base)
            item['resolution'][key] = [None, False, 1.25, {'unknown': [True, '']}, [], 2 ** 200]
            vectors.append((f'arbitrary-resolution-{key}', item))
            item = copy.deepcopy(base); item['resolution'][key] = None
            vectors.append((f'invalid-resolution-{key}', item))
        item = copy.deepcopy(base)
        item['rows'][0][6] = {'arbitrary': [None, True, {'deep': [float('nan'), float('inf'), -0.0]}]}
        vectors.append(('arbitrary-row-fields', item))
        for value in (None, [], False, 0):
            item = copy.deepcopy(base); item['rows'][0][6] = value
            vectors.append((f'invalid-row-fields-{value!r}', item))
        for column in range(4):
            for value in (None, False, 1.0):
                item = copy.deepcopy(base); item['source_bindings'][0][column] = value
                vectors.append((f'binding-{column}-{type(value).__name__}', item))
        for key in base:
            item = copy.deepcopy(base); del item[key]
            vectors.append((f'missing-top-{key}', item))
        for parents in (['', 'a'], ['a', 'a'], ['b', 'a'], [None], 'bad'):
            item = copy.deepcopy(base); item['parents'] = parents
            vectors.append((f'parents-{parents!r}', item))
        for field in ('rows', 'source_bindings'):
            for value in (None, {}, [True], [[]]):
                item = copy.deepcopy(base); item[field] = value
                vectors.append((f'{field}-{value!r}', item))
        item = copy.deepcopy(base); item['unexpected'] = None
        vectors.append(('unexpected-top-key', item))
        item = copy.deepcopy(base); item['resolution']['unexpected'] = []
        vectors.append(('unexpected-resolution-key', item))
        raw_vectors = [(name, json.dumps(value, ensure_ascii=False), base['publication_id'])
                       for name, value in vectors]
        valid_raw = json.dumps(base, ensure_ascii=False)
        for field, bad in (('usable', '123'), ('rows', 'null'), ('parents', 'null'),
                           ('source_bindings', 'true'), ('format', '"invalid"')):
            member = json.dumps(field) + ':' + bad + ','
            raw_vectors.append((f'duplicate-{field}-bad-first', '{' + member + valid_raw[1:], base['publication_id']))
            raw_vectors.append((f'duplicate-{field}-bad-last', valid_raw[:-1] + ',' + member[:-1] + '}', base['publication_id']))
        raw_vectors.extend([('malformed-json', '{', base['publication_id']),
                            ('wrong-publication', valid_raw, 'different-publication')])
        raw_vectors.append(('duplicate-resolution-bad-first',
            valid_raw.replace('"resolution": {', '"resolution": {"issues": null,', 1),
            base['publication_id']))
        raw_vectors.append(('duplicate-resolution-bad-last',
            valid_raw.replace('"issues": []', '"issues": [], "issues": null', 1),
            base['publication_id']))
        for name, raw, ident in raw_vectors:
            old, _ = outcome(contribution._decode, raw, ident)
            before = fallback['calls']
            new, _ = outcome(native, raw, ident)
            case = {'case': name, 'synthetic_raw': raw, 'original': old, 'native': new,
                    'native_fallback': fallback['calls'] - before, 'equivalent': old == new}
            report['cases'].append(case)
            save()
            require(case['equivalent'], 'Synthetic shape mismatch: ' + name)
        # Every phase is separate. Raw SQL/checksums, equivalence hashing and saving
        # are outside these local decoder loops; results are discarded each call.
        for label, decoder in [('original', contribution._decode), ('native', native)]:
            for iteration in range(args.rounds):
                before = fallback['calls']
                started = time.perf_counter()
                for raw, ident in normal:
                    decoder(raw, ident)
                elapsed = (time.perf_counter() - started) * 1000
                report['local_rounds'][label].append({'round': iteration + 1,
                    'milliseconds_diagnostic': elapsed, 'decoded': len(normal),
                    'native_fallback': fallback['calls'] - before})
                save()
                note(f'{label} round {iteration + 1}: {len(normal)} bodies; local {elapsed:.3f} ms')
        require(sha(BOOK) == args.report_sha256 and sha(checkpoint_path) == checkpoint_sha,
                'Ending receipt/checkpoint drift')
        require(snapshot_stage9_source._inventory(SOURCE) == manifest['files'], 'Ending source drift')
        with store.connection(read_only=True) as connection:
            require(list(connection.execute('SELECT * FROM state WHERE id=1').fetchone()) == preview['state'],
                    'Ending company state drift')
            require(tuple(connection.execute(
                'SELECT company_id,taxpayer_id,database_id FROM identity WHERE id=1').fetchone()) == identity,
                'Ending identity drift')
            require(database_format(connection, bundle=bundle) == book['integrity_contract'],
                    'Ending schema drift')
        report['status'] = 'diagnostic_complete'
        report['limitations'] = ['Structure only, not source/adoption/financial proof or page timing',
            'Current-month terminal-publication candidates only; no history/current report invocation',
            'Native errors fall back to unchanged original decoder',
            'Container equality includes dict/list/tuple/scalar types; dict insertion order reported separately',
            'Production/public schema/frozen v1/DB/service untouched']
        save()
        note(f'Complete: {len(report["cases"])} equivalence cases; no page claim')
    except BaseException:
        report['status'] = 'failed'
        report['error'] = traceback.format_exc()
        save(); note(report['error'])
        raise
    finally:
        log.close()


if __name__ == '__main__':
    main()
