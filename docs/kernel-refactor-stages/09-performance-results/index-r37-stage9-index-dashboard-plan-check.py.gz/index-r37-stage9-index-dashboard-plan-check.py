import json
import sqlite3
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DATABASES = {
    "old12": ROOT / ".tmp/stage9-release-main-12/91310000123456789S/company.sqlite",
    "new12": ROOT / ".tmp/stage9-reseed-main-12-r36/91310000123456789S/company.sqlite",
    "new48_incomplete": ROOT / ".tmp/stage9-reseed-main-48-r36.staging/91310000123456789S/company.sqlite",
}
QUERIES = {
    "query_reads_1000": (
        "SELECT c.id,f.subject_id,s.kind FROM json_each(?) ids JOIN calculation c ON c.id=ids.value "
        "JOIN fact_revision f ON f.id=c.fact_id JOIN subject s ON s.id=f.subject_id",
        "calculations",
    ),
    "query_reads_1117": (
        "SELECT c.id,f.subject_id,s.kind FROM json_each(?) ids CROSS JOIN calculation c ON c.id=ids.value "
        "JOIN fact_revision f ON f.id=c.fact_id JOIN subject s ON s.id=f.subject_id",
        "calculations",
    ),
    "dashboard_reads_189": (
        "SELECT f.id,r.entity_id FROM json_each(?) ids JOIN fact_revision f ON f.id=ids.value "
        "LEFT JOIN entity_reference_current r ON r.fact_id=f.id AND r.role='employee'",
        "facts",
    ),
    "funds_670": (
        "SELECT f.subject_id,f.revision,s.* FROM json_each(?) ids JOIN fact_bank_statement s "
        "ON s.revision_id=ids.value JOIN fact_revision f ON f.id=s.revision_id ORDER BY f.subject_id",
        "bank_statement",
    ),
    "funds_1000": (
        "SELECT c.id,f.subject_id FROM json_each(?) r "
        "JOIN calculation c INDEXED BY calculation_subject ON c.subject_id=json_extract(r.value,'$.source_id') "
        "AND c.kind=json_extract(r.value,'$.source_kind') "
        "JOIN fact_revision f ON f.id=c.fact_id AND f.subject_id=c.subject_id "
        "JOIN dependency_calculation d INDEXED BY dependency_upstream ON "
        "d.upstream_id=c.id AND d.calculation_id=json_extract(r.value,'$.root')",
        "requests",
    ),
    "dashboard_metadata_315": (
        "SELECT t.employee_id,f.id FROM json_each(?) ids JOIN fact_scope s "
        "ON s.kind='tax_import_identity_v2' AND s.scope_key='tax-identity:'||ids.value "
        "JOIN fact_current a ON a.fact_id=s.fact_id JOIN fact_revision f ON f.id=a.fact_id "
        "JOIN fact_tax_import_identity_v2 t ON t.revision_id=f.id AND t.employee_id=ids.value "
        "ORDER BY f.period,f.revision,f.id",
        "employee_ids",
    ),
    "dashboard_fact_ids_of_kind": (
        "SELECT f.id FROM subject s CROSS JOIN fact_revision f ON f.subject_id=s.id "
        "WHERE s.kind IN (SELECT value FROM json_each(?)) AND f.period=?",
        "kind_period",
    ),
    "dashboard_missing_classification": (
        "WITH missing AS MATERIALIZED (SELECT f.id FROM subject s INDEXED BY subject_kind "
        "CROSS JOIN fact_revision f ON f.subject_id=s.id "
        "LEFT JOIN fact_report_classification c ON c.revision_id=f.id "
        "WHERE s.kind='report_classification' AND c.revision_id IS NULL) "
        "SELECT m.id FROM missing m WHERE EXISTS(SELECT 1 FROM close_reference r INDEXED BY close_reference_lookup "
        "WHERE r.reference_type='fact' AND r.reference_id=m.id "
        "AND r.path='readiness.financial_reports.facts[*]' AND r.close_period<=?)",
        "month",
    ),
    "read_indexes_jobs": (
        "SELECT r.job_id FROM fact_revision f JOIN job_reference r "
        "ON r.reference_type IN ('fact','version') AND r.reference_id=f.id "
        "WHERE f.subject_id IN (SELECT value FROM json_each(?))",
        "subjects",
    ),
    "dashboard_open_period_classification": (
        "WITH RECURSIVE periods(period) AS (SELECT min(period) FROM fact_revision WHERE period<=? UNION ALL "
        "SELECT (SELECT min(period) FROM fact_revision WHERE period>p.period AND period<=?) "
        "FROM periods p WHERE p.period IS NOT NULL), "
        "open_periods AS MATERIALIZED (SELECT period FROM periods p WHERE p.period IS NOT NULL "
        "AND NOT EXISTS(SELECT 1 FROM period_close c WHERE c.period=p.period)) "
        "SELECT f.id FROM open_periods p CROSS JOIN fact_revision f INDEXED BY fact_period ON f.period=p.period "
        "JOIN fact_current h ON h.fact_id=f.id JOIN subject s ON s.id=f.subject_id "
        "AND s.kind='report_classification'",
        "period_pair",
    ),
    "dashboard_tax_declaration_candidates": (
        "SELECT f.id FROM fact_current c JOIN fact_revision f ON f.id=c.fact_id "
        "JOIN fact_payroll_tax_declaration_actual d ON d.revision_id=f.id "
        "WHERE d.employee_id IN (SELECT value FROM json_each(?)) "
        "AND d.tax_period IN (SELECT value FROM json_each(?))",
        "employee_period",
    ),
}


for name, path in DATABASES.items():
    if not path.exists():
        continue
    connection = sqlite3.connect(path.as_uri() + "?mode=ro", uri=True)
    connection.execute("PRAGMA query_only=ON")
    def ids(table, column="id", limit=4):
        return [row[0] for row in connection.execute(f"SELECT {column} FROM {table} LIMIT {limit}")]
    params = {
        "calculations": (json.dumps(ids("calculation")),),
        "facts": (json.dumps(ids("fact_revision")),),
        "bank_statement": (json.dumps(ids("fact_bank_statement", "revision_id")),),
        "requests": (json.dumps([{"source_id": row[0], "source_kind": row[1], "root": "none"}
                                  for row in connection.execute("SELECT subject_id,kind FROM calculation LIMIT 4")]),),
        "employee_ids": (json.dumps(ids("fact_tax_import_identity_v2", "employee_id")),),
        "kind_period": (json.dumps(["bank_statement"]), 1),
        "month": (99999,),
        "subjects": (json.dumps(ids("fact_revision", "subject_id")),),
        "period_pair": (99999, 99999),
        "employee_period": (json.dumps(ids("fact_payroll_tax_declaration_actual", "employee_id")),
                            json.dumps(ids("fact_payroll_tax_declaration_actual", "tax_period"))),
    }
    print(name)
    for label, (sql, key) in QUERIES.items():
        try:
            plan = [row[3] for row in connection.execute("EXPLAIN QUERY PLAN " + sql, params[key])]
        except sqlite3.Error as exc:
            plan = [f"ERROR {exc}"]
        print(label + ": " + " | ".join(plan))
    connection.close()
