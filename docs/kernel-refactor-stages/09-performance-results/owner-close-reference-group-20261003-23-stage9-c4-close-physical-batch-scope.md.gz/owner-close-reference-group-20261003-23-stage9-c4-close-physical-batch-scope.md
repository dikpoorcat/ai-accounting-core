# C4 同快照关账物理读取批量化

本组生产改动位于 `close_storage.py`、`read_indexes.py`，QueryReads/reports 接线由 root 负责。没有 DDL、冻结合同、页面内容或跨请求缓存变化，不操作真实资料。依据 same-source 12→48 资产 SQL 322→825，其中目录/块各 188 次、subroot 47 次；这些源内容仍必要，不能裁掉历史 member 目录。

`read_accounting_many` / `read_adopted_results_many` 已先建立全组 publication/voucher authority，再逐月读取。只在现有 current reader、owned read transaction、至少两个 header 时，提前批取缺失 accounting subroots，再用原 authenticated subject filter 计算精确命中 buckets，批取目录及块。完整 accounting 使用 authority 的 complete_subjects；adopted-only 使用该月候选 scope。仍由原 `_bucket_rows` 校验目录/块 digest、count、part multiset，再由原 `_read_accounting` 校验 bucket identity、position、adoption 与 voucher authority。新内容只放本组 staging maps，全组成功才更新 snapshot cache。

公共消费者：BusinessQueries 的冻结 accounting 选择及 asset owner identity；FundsRead 历史资金；Journal 历史采用；员工精确 adopted head identity；历史银行身份。五页及 CLI/MCP 经过共同入口，功能与源 proof 不变。current owned 多期 references 的首次物理读取已集中；独立 fullverify/repair/backup/restore 的 complete decode 与完整目录核验保持原职责。单期 reference_leaves 内 subject metadata helper 提取复用，但独立连接没有新跨月批化或外部成功缓存；固定 content-v1 和非 owned 连接保持原逐月读取。

同一物理 helper 供 `read_readiness_checks_many(connection, headers, name)` 使用，按 headers 顺序返回 tuple。仅命中指定 checker（例如 financial_reports），仍使用原 management subroot contract 和单 value position/count/hash 规则；缺少 checker 返回 `{}`，不读取 sibling checker 或 management_snapshot。无公开提前 cache，任一失败整组不返回。QueryReads/reports 接线由 root 负责。

测试覆盖：批量 vs 原路完整值相等；空 scopes/filter negatives/空 buckets；adopted-only vs complete 的不同 authority universe；多个 fields/重复请求/新 snapshot；末月 subroot、directory、block 及 authority 损坏无成功 prefix；原 `_bucket_rows` 故障仍可注入；单头、非 owned、fixed-v1 fallback。工作量比较实际 SQL/VM/rows/returned bytes，routing scalar 与正文 bytes 分别陈述；不把诊断 wall clock 当页面收益。现有内部 helper monkeypatch 涉及 single read 或 one-header many，保留该原路及断言。

本次最后范围复核只读代码，未另启动测试、DB 或 probe，生产源码未改。root 在集中执行组验证，当前结果见末段。尚未验证新组当前真实页面净延迟，历史 member 裁范围和其他已否定方案不实施。

C5 同批收敛：`verified_header` 在 `require_marker=True` 且既有 owned/current guard 下，只复用 active QueryReads `_close_headers` 的精确 period `CloseHeader`；同时匹配 header.period、logical digest 与该 row 原 manifest bytes 的 storage SHA。`verified_headers` 使用相同精确匹配，只批取 missing support，仍不自行发布 header。所有当前 cache 写入来自 marker-required verified_header/verified_headers 或 authoritative_close_rows（也调用 verified_headers），没有 require_marker=False 的生产者。cache miss、不匹配、非 owned、固定 v1、require_marker=False 原检查，各消费者仍执行自己的 family/source 检查。main48 已有 root 原件证明 report 60 次中 47 必要首次、13 次精确成功重复；不裁必要的首次读取。

8cc 当前源码 / 1c37 旧资格 book 的追加诊断明确此前范围遗漏：资产首次 adopted head locator→QueryReads.verify_close_references→read_indexes.verify_storage_leaves→reference_leaves 按 47 月读 accounting family。随后的 adopted many 已命中这些 family/buckets，无法减少首次循环；另一批项目 cost 凭证引用再逐月首次读 vouchers bucket。native 共 3 次 reference verifier、141 次 per-period reference_leaves；原目录/块各 94 次，calculation subject 定位 47 次/47 行，voucher subject 定位 94 次/140 行。返回的源仍必要，不是重复正文。

补齐公共 reference 路径，而不加资产专项 prefetch：current owned 多期整数请求由 read_indexes 收集独立 marker/root/header 证明后，调用 reference_leaves_many；相同 metadata table 的精确缺失 IDs 一次定位、缺失 family 按 accounting/material 一次读取、原物理 helper 读命中 buckets。原 reference_leaf 与 value/related/position assert 均保留。新 helper 使用本组 fresh parts，read_indexes 外层再等待所有 leaf identity 比较成功，才发布 parts；新 marker-checked headers 也只在调用方传入 map 与 active QueryReads `_close_headers` 是同一对象时，于全组成功末端发布。唯一生产调用方确实传入该现有 map；后续 authoritative_close_rows 重读精确 period_close 行时，公共 verified_headers 可复用匹配证明，不再二次读 support/identity。任一失败不发布本组 header/parts 前缀，已有成功证明保留。QueryReads 最后才发布精确 reference keys。单期、非 owned、v1、异常 period 形态原路径，完整核验的独立连接也不进入本优化。非 bucket 的 readiness/完整 section 保留原读取，不宣称已经批化。

新增 test_close_reference_physical_batch.py 共 19 个参数化案例：120 月物理背景下请求 12/48 月，对照 accounting 和 mixed accounting/material 的实际 SQL/VM/行/字节/解码；真实三个月合成业务经公共入口首次读取/后续 authoritative header 与 accounting 复用；不同 map 不发布、批头 mixed hit/miss、假 row 与末月 marker 缺失；位置、关联、来源缺失、块损坏失败不前缀缓存；single/unowned/v1/异常 period fallback。本次复核未另跑测试、DB 或 probe。

## 最后全局调用方及保留范围

| 入口/职责 | 实际调用与处理边界 |
| --- | --- |
| 简报、资金、员工、资产、报表默认及按需 | Dashboard._snapshot 创建 owned QueryReads；BusinessQueries 选中冻结 accounting、Journal/资产 metadata/历史银行身份、FundsRead、reports 的选中凭证/事实定位，共同经过 verify_close_references、authoritative_close_rows 与 accounting/readiness many。上层已获得整组 refs 的首次多月物理读取集中；不同 scope 的完整 authority 仍分别核验，不裁金额、对象或采用依据。 |
| 冻结 profile/entity Records 枚举与 prime | dashboard_metadata.Records 调 snapshot.reads.verify_close_references。同公共入口，常见单月/不同 reference keys 仍小集合原读；仅凭逐次 SQL 数不能认定缺陷。 |
| 单月管理 membership/枚举 | FrozenManagementIds 直接 read_indexes.verify_close_references，限定 snapshot.month；不增加批接口。该 caller 不传 parts/header map；若 active snapshot 已有精确 header，可由公共 C5 消费，单月 management section 校验仍原路。该 caller 净收益未测。 |
| 其他直接 header 消费者 | Display/profiles/历史来源导出、dashboard 历史 trial balance、按需 CloseReview、frozen_material/material_watch、duplicate_freeze、period_balance_freeze、report flow/classification/semantics/projection、settlement freeze、replay_close 直接或通过 close_reader().verified_header。公共 C5 只复用 marker-required 相等 header，各自 family/root/section/source proof 不变。全历史来源导出所需完整 sections 不按默认页裁小；除已有 report/brief overlap 原件外，其实际命中率未逐项测量。 |
| CLI/MCP/HTTP | Service 命令表路由同 Dashboard/Reports/CloseReview/业务及 maintenance。Dashboard/Reports 自建 owned snapshot 可进入优化；外部提供独立连接不能借另一连接证明。未逐个命令实测，不因传输入口另建 cache 或合同。 |
| 正式关账、preview、replay | Periods→verify_close_integrity、原 readiness/checker；replay_close 独立验证。没有 active owned current QueryReads 的独立连接保留完整路径。decode_close(require_marker=False) 用于创建/同步目录，不消费 C5 缓存，也不产生 `_close_headers`；独立 all-account/source/材料/批准检查不裁。 |
| fullverify、repair、backup/restore | Maintenance 独立连接、verify_integrity/verify_read_indexes、schema_bundle.verify_company_with_registry、backup.verify_file 的独立内容 verifier，继续完整源/目录集合与正文核验。维修写事务不进入 owned-read guard，备份恢复不以看板证明替代核验。 |
| 固定 content-v1 | content_history_context.close_reader→close_storage_v1；current guard 同时排除 v1 registry 与历史 reader/publication reader。固定合同、重复成员解读及原完整历史采用规则未改。 |

非 bucket 的 readiness reference 与完整 section 仍由原 reference_leaf 分支读取，不宣称已批化；financial_reports 多月 checker 是另一入口，已用专用 readiness many。前者没有实际多月热点证据，当前不造专项机制。直接无 parts 的 reference_leaf、完整 decode_close 与单期 reference_leaves 仍做其必要单项验证；current owned 多期 refs 不再逐月执行旧物理读取。

## 缓存生产者及失败复审

全局 `_close_headers` 赋值来源：close_header 的 marker-required verified_header；accounting/adopted-many 全组成功；readiness-many 全组成功；authoritative_close_rows 全组 header 成功；本轮 read_indexes 全组 reference 成功。没有 require_marker=False 的生产者。新 header 成功不代表 close_reference multiset 全检查，`_closes` 仍由原完整目录核验产生，后续 authority 比较不省。guard 要求同 active QueryReads、精确连接、活跃 owned 事务、current close/publication reader 与 non-v1 registry；_reset 清空 maps。新 helper 只 get 精确请求 period/ID，不遍历所有历史 cache。

reference many 的物理 staging 与 outer leaf 比较 staging 是两层，失败不发布本组 header/parts/reference keys。accounting-many 的 positions/parts、readiness-many 的 sections/headers 同样全组成功提交。已完成独立 header proof 后，单项 section 失败可保留该原 header 证明，这是原小集合职责，不宣称 section 成功。未发现本轮新增越界缓存生产者或实际可达的半批成功发布。

## 当前验证状态

本组代码与拒绝语义已按当前6688候选收敛，尚未完成性能／正式交付验收。primary六模块初组75passed／2failed／7warnings／82.87s，失败是新测试错误码预期；8cc原路径实证related为read_index_integrity_failed／reference_leaf_mismatch，invalid_period为read_index_integrity_failed／source_digest_or_marker_mismatch。只修两项测试精确错误码，保留cache失败断言；两个node复验2passed／5.96s，未重跑完整77项。

6688正式factory独立组111passed／2warnings／193.73s／exit0，source inventory before==after，覆盖消费者、固定v1、production verifier、repair及backup／restore相关用例。此组范围不能扩为所有独立命令动态命中或最终包验收，不与初组或旧consumer通过数相加。

native12／48已完成，source6688，current_source_full_verification=false；旧066／029资格只绑定样本。48相对8cc资产SQL636→268，VM841600→840000、rows12565不变、bytes8165375→8164623；季报SQL276→270、rows24902→24896、bytes10688840→10688456，必要load／decode／proof和响应bytes保留。12相对1c37含整组C4／C5，不能单独归因reference。仪器墙钟不是500ms验收。

尚未验证：当前6688 fresh注册资格／浏览器gate尚在运行、未取得纯计时结论；main12／48／120净时延、所有直接公共消费者动态命中、独立／压力／evidence及最终package仍待验。primary仍draft／0，未切库或正式冻结。正常unused候选为0的阴性观察不扩为unsafe／fallback全部排除。
