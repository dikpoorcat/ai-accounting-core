"""An identical-SQL draft fixture preserves raw rows, without qualifying content."""

from __future__ import annotations

import sqlite3
import sys
from contextlib import closing
from dataclasses import replace
from pathlib import Path

import pytest
import test_reports
from test_reports import book as book  # noqa: F401

from ai_accounting.kernel.schema_bundle import production_bundle
from ai_accounting.kernel.storage import Store
from ai_accounting.kernel.versions import verify_schema

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "scripts"))
import prepare_stage9_draft_book as draft

copy = draft.copy


def released_bundle():
    current = production_bundle()
    return replace(
        current,
        status="released",
        current_versions={"company": 1, "catalog": 1},
        contracts={
            kind: {1: {**current.current(kind), "version": 1, "status": "released"}}
            for kind in ("company", "catalog")
        },
        development_contracts={},
        draft_transitions={},
    )


@pytest.fixture
def pair(tmp_path):
    released, current = released_bundle(), production_bundle()
    assert current.current("company")["sha256"] == draft.COMPANY
    assert current.current("catalog")["sha256"] == draft.CATALOG
    source_store = Store.create(
        tmp_path / "source.sqlite", released, "company", "91310000123456789S", "database"
    )
    target_store = Store.create(
        tmp_path / "target.sqlite", current, "company", "91310000123456789S", "database"
    )
    with closing(sqlite3.connect(source_store.path)) as source:
        source.execute(
            "INSERT INTO evidence(rowid,digest,content,media_type,name) VALUES(?,?,?,?,?)",
            (83, b"d" * 32, b"raw\x00bytes\xff", "text/plain", "原样"),
        )
        source.commit()
    with closing(draft.readonly(source_store.path)) as source:
        with closing(sqlite3.connect(target_store.path)) as target:
            target.execute("PRAGMA foreign_keys=ON")
            yield source, target, copy._objects(source), copy._objects(target), released, current


def test_actual_draft_copy_retains_all_tables_and_fresh_factory_metadata(pair):
    source, target, old, new, released, current = pair
    verify_schema(source, bundle=released)
    before_source = copy._digests(source)
    generated = {name: copy._digests(target)[name] for name in copy.GENERATED}
    copy._copy_rows(source, target, old, new, draft_fixture=True)
    copied, source_digests, target_digests = copy._attest_copy(
        source, target, old, new, draft_fixture=True
    )
    verify_schema(target, bundle=current)
    assert old == new
    assert source_digests == before_source
    assert set(source_digests) == set(target_digests) == set(copy._tables(source))
    assert all(
        source_digests[name] == target_digests[name]
        for name in source_digests
        if name not in {"schema_meta", "schema_history"}
    )
    assert generated == {name: target_digests[name] for name in copy.GENERATED}
    assert copied["evidence"]["rows"] == 1
    assert [tuple(row) for row in source.execute("SELECT rowid,* FROM evidence")] == list(
        target.execute("SELECT rowid,* FROM evidence")
    )
    assert target.execute("SELECT rowid FROM evidence").fetchone() == (83,)
    assert target.execute("PRAGMA foreign_keys").fetchone() == (1,)
    assert source_digests["schema_meta"] != target_digests["schema_meta"]
    assert source_digests["schema_history"] != target_digests["schema_history"]
    with pytest.raises(sqlite3.OperationalError, match="readonly"):
        source.execute("DELETE FROM evidence")
    with pytest.raises(sqlite3.IntegrityError, match="immutable"):
        target.execute("UPDATE evidence SET name='changed'")


@pytest.mark.parametrize("side", ["source", "target"])
@pytest.mark.parametrize("damage", ["ancestry", "metadata"])
def test_draft_copy_rejects_nonempty_ancestry_or_wrong_installation(pair, side, damage):
    source, target, old, new, _, _ = pair
    path = Path(source.execute("PRAGMA database_list").fetchone()[2])
    if side == "source":
        source.rollback()
        connection = sqlite3.connect(path)
    else:
        connection = target
    try:
        if damage == "ancestry":
            connection.execute(
                "INSERT INTO schema_draft_history VALUES(1,?,?,?,?)",
                (b"a" * 32, b"b" * 32, b"c" * 32, "now"),
            )
        else:
            connection.execute("PRAGMA user_version=7")
        connection.commit()
    finally:
        if side == "source":
            connection.close()
            source.execute("BEGIN")
    before = copy._digests(target)
    with pytest.raises(ValueError, match="format or empty ancestry"):
        copy._copy_rows(source, target, old, new, draft_fixture=True)
    assert copy._digests(target) == before


def test_draft_copy_rejects_approximate_saved_sql_and_never_uses_delta(pair):
    source, target, old, new, _, _ = pair
    before = copy._digests(target)
    approximate = dict(old)
    approximate[("index", "subject_id_kind_cover")] += " "
    with pytest.raises(ValueError, match="Actual saved SQL"):
        copy._copy_rows(source, target, approximate, new, draft_fixture=True)
    with pytest.raises(ValueError, match="identical complete SQL"):
        copy._copy_rows(source, target, old, new, draft_fixture=True, pre_cover=True)
    with pytest.raises(ValueError, match="DDL inventory"):
        copy._copy_rows(source, target, old, new)
    assert copy._digests(target) == before


def test_draft_late_copy_failure_rolls_back_every_table_and_guard(pair):
    source, target, old, new, _, _ = pair
    before = copy._digests(target)
    visited = []

    def fail(phase, **values):
        visited.append(values["table"])
        if values["table"] == "voucher_version":
            raise RuntimeError("late draft fixture failure")

    with pytest.raises(RuntimeError, match="late draft fixture"):
        copy._copy_rows(source, target, old, new, draft_fixture=True, progress=fail)
    assert "evidence" in visited
    assert copy._digests(target) == before
    assert copy._objects(target) == new
    assert target.execute("PRAGMA foreign_keys").fetchone() == (1,)
    assert not target.in_transaction


def test_draft_attestation_rejects_changed_raw_blob(pair):
    source, target, old, new, _, _ = pair
    copy._copy_rows(source, target, old, new, draft_fixture=True)
    # Use the actual factory trigger name, preserving its exact saved SQL.
    guards = [(key[1], sql) for key, sql in new.items()
              if key[0] == "trigger" and "BEFORE UPDATE ON evidence" in sql]
    assert len(guards) == 1
    name, sql = guards[0]
    target.execute(f'DROP TRIGGER "{name}"')
    target.execute("UPDATE evidence SET content=?", (b"changed\x00",))
    target.execute(sql)
    target.commit()
    with pytest.raises(ValueError, match="exact source rowid/bytes: evidence"):
        copy._attest_copy(source, target, old, new, draft_fixture=True)
    assert copy._objects(target) == new


def test_readonly_wal_snapshot_is_stable_but_data_version_is_not_live_guard(tmp_path):
    path = tmp_path / "wal.sqlite"
    with closing(sqlite3.connect(path)) as writer:
        assert writer.execute("PRAGMA journal_mode=WAL").fetchone() == ("wal",)
        writer.execute("CREATE TABLE value(number INTEGER)")
        writer.execute("INSERT INTO value VALUES(1)")
        writer.commit()
        with closing(draft.readonly(path)) as reader:
            assert reader.execute("SELECT number FROM value").fetchone()[0] == 1
            version = reader.execute("PRAGMA data_version").fetchone()[0]
            writer.execute("UPDATE value SET number=2")
            writer.commit()
            assert reader.execute("SELECT number FROM value").fetchone()[0] == 1
            assert reader.execute("PRAGMA data_version").fetchone()[0] == version
            with pytest.raises(ValueError, match="Live source database changed"):
                draft.require_unchanged_sources((reader, version))
            assert not reader.in_transaction
            assert reader.execute("PRAGMA data_version").fetchone()[0] != version
            assert reader.execute("SELECT number FROM value").fetchone()[0] == 2


@pytest.mark.parametrize("commit", [False, True])
def test_final_source_check_releases_all_snapshots_and_distinguishes_rollback(tmp_path, commit):
    readers, writers, versions = [], [], []
    try:
        for number in (1, 2):
            path = tmp_path / f"source-{number}.sqlite"
            writer = sqlite3.connect(path)
            writers.append(writer)
            writer.execute("PRAGMA journal_mode=WAL")
            writer.execute("CREATE TABLE value(number INTEGER)")
            writer.execute("INSERT INTO value VALUES(1)")
            writer.commit()
            reader = draft.readonly(path)
            readers.append(reader)
            reader.execute("SELECT * FROM value").fetchall()
            versions.append(reader.execute("PRAGMA data_version").fetchone()[0])
        writers[1].execute("UPDATE value SET number=2")
        if commit:
            writers[1].commit()
            with pytest.raises(ValueError, match="Live source database changed"):
                draft.require_unchanged_sources(*zip(readers, versions, strict=True))
        else:
            writers[1].rollback()
            draft.require_unchanged_sources(*zip(readers, versions, strict=True))
        assert all(not reader.in_transaction for reader in readers)
    finally:
        for connection in (*readers, *writers):
            connection.close()


def test_nonempty_frozen_company_copy_preserves_raw_business_and_history(
    tmp_path, monkeypatch, request
):
    released = released_bundle()
    monkeypatch.setattr(test_reports, "production_bundle", lambda: released)
    engine, save, publish, close = request.getfixturevalue("book")
    test_reports.profile(save, publish)
    save("cash_funding", "capital", {
        "period": "2026-01", "actual_date": "2026-01-03", "owner_id": "owner",
        "funding_kind": "capital", "amount_fen": 50000, "cash_account_id": "cash",
    })
    publish("capital")
    close("2026-01")
    current = production_bundle()
    target_store = Store.create(
        tmp_path / "draft-frozen.sqlite", current, "co", "911100000000000001", "db"
    )
    with closing(draft.readonly(engine.store.path)) as source:
        with closing(sqlite3.connect(target_store.path)) as target:
            old, new = copy._objects(source), copy._objects(target)
            before = copy._digests(source)
            assert before["period_close"]["rows"] == 1
            assert before["calculation_publication"]["rows"] >= 1
            assert before["voucher_line"]["rows"] == 2
            assert before["fact_revision"]["rows"] >= 2
            copy._copy_rows(source, target, old, new, draft_fixture=True)
            _, source_digests, target_digests = copy._attest_copy(
                source, target, old, new, draft_fixture=True
            )
            assert source_digests == before
            for table in before.keys() - {"schema_meta", "schema_history"}:
                assert before[table] == target_digests[table], table
            assert [tuple(row) for row in source.execute("SELECT rowid,* FROM period_close")] == (
                list(target.execute("SELECT rowid,* FROM period_close"))
            )
            verify_schema(target, bundle=current)
