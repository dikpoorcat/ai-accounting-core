"""Synthetic owner-read work diagnostics; never a browser timing acceptance.

Run only after the coordinating task freezes its candidate and authorizes it.
No production file or existing company is modified. All companies live in a
fresh TemporaryDirectory. The two comparison adapters live only in this process
and retain ordinary source/adoption verification. They are diagnostic prototypes,
not response contracts or proof that an implementation is safe to ship.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
import tempfile
import traceback
from collections import Counter
from contextlib import ExitStack, contextmanager
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "src"), str(ROOT / "tests" / "kernel")]

from entity_fixture import seed_entities  # noqa: E402
from stage9_metrics import measure_work  # noqa: E402
from test_asset_batches import asset_engine, month  # noqa: E402
from test_payroll_corrections import Company  # noqa: E402

from ai_accounting.kernel import asset_batches as batches_module  # noqa: E402
from ai_accounting.kernel import dashboard as dashboard_module  # noqa: E402
from ai_accounting.kernel import settlement_freeze as freeze  # noqa: E402
from ai_accounting.kernel import settlement_projection as settlement  # noqa: E402
from ai_accounting.kernel.asset_batch_models import OWNER_KINDS  # noqa: E402
from ai_accounting.kernel.asset_batches import AssetBatches  # noqa: E402
from ai_accounting.kernel.dashboard import Dashboard, _Snapshot  # noqa: E402
from ai_accounting.kernel.dashboard_metadata import Records  # noqa: E402
from ai_accounting.kernel.domains.cash import CashFunding, CashPayment  # noqa: E402
from ai_accounting.kernel.domains.transactions import Allocation, Expense  # noqa: E402
from ai_accounting.kernel.entities import Entities  # noqa: E402
from ai_accounting.kernel.types import YearMonth, canonical  # noqa: E402


def source_manifest():
    paths = sorted((ROOT / "src" / "ai_accounting" / "kernel").rglob("*.py"))
    paths.extend(ROOT / "tests" / "kernel" / name for name in (
        "stage9_metrics.py", "entity_fixture.py", "test_asset_batches.py",
        "test_payroll_corrections.py", "payroll_plan_fixture.py",
    ))
    return {
        str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in paths
    }


def value_digest(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def counters(connection):
    # measure_work's proxy owns the counters; no SQL is issued for this snapshot.
    return Counter(getattr(connection, "counts", {}))


class Observe:
    def __init__(self):
        self.phase = "entry"
        self.calls = Counter()
        self.events = []

    @contextmanager
    def phase_work(self, label, connection, **metadata):
        prior, before = self.phase, counters(connection)
        self.phase = label
        try:
            yield
        finally:
            self.events.append({
                "phase": label, **metadata,
                "counters": dict(counters(connection) - before),
            })
            self.phase = prior

    @contextmanager
    def installed(self):
        original_settlement = settlement.settlement_dashboard_open
        original_prime = dashboard_module._brief_prime_activity
        original_voucher = _Snapshot.owner_voucher
        original_records = Records.prime
        original_members = batches_module._checked_members_many

        def scoped_settlement(connection, period, **options):
            label = "current_page" if options.get("current") else "historical_page"
            with self.phase_work(
                label, connection, page_keys=len(options.get("page_keys") or ()),
                summary_only=options.get("summary_only", False),
            ):
                result = original_settlement(connection, period, **options)
            self.events.append({
                "phase": label + "_result", "categories": len(result["categories"]),
                "total_count": result["page"]["total_count"],
                "returned_count": len(result["obligations"]),
            })
            return result

        def prime(snap, rows):
            with self.phase_work("brief_prime", snap.connection, vouchers=len(rows)):
                return original_prime(snap, rows)

        def voucher(snap, row):
            with self.phase_work("owner_voucher", snap.connection, kind=row["basis"]["kind"]):
                result = original_voucher(snap, row)
            self.events.append({
                "phase": "owner_voucher_result", "kind": result["kind"],
                "members": len(result["asset_members"]), "lines": len(result["lines"]),
            })
            return result

        def records(mapping, identifiers):
            identifiers = set(identifiers)
            missing = identifiers - mapping.cache.keys() - mapping.missing
            label = f"metadata:{self.phase}:{mapping.record_type}:{mapping.kind}"
            self.calls[label + ":calls"] += 1
            self.calls[label + ":requested"] += len(identifiers)
            self.calls[label + ":missing"] += len(missing)
            return original_records(mapping, identifiers)

        def members(connection, owner_ids, *, require_seals):
            owner_ids = tuple(owner_ids)
            label = f"members:{self.phase}"
            self.calls[label + ":calls"] += 1
            self.calls[label + ":owners"] += len(owner_ids)
            with self.phase_work(label, connection, owners=len(owner_ids)):
                return original_members(connection, owner_ids, require_seals=require_seals)

        with ExitStack() as stack:
            stack.enter_context(patch.object(settlement, "settlement_dashboard_open", scoped_settlement))
            stack.enter_context(patch.object(dashboard_module, "_brief_prime_activity", prime))
            stack.enter_context(patch.object(_Snapshot, "owner_voucher", voucher))
            stack.enter_context(patch.object(Records, "prime", records))
            stack.enter_context(patch.object(batches_module, "_checked_members_many", members))
            yield


def current_rows_only(connection, period, **options):
    """Diagnostic: preserve scope proof and page hydration, omit global measures.

    This adapter is deliberately confined to brief's current/page_keys call. Its
    statistics describe the selected keys only and must never become a public
    full-summary response. The brief discards all those statistics. Compare only
    the actual owner's response, not the retained core helper's diagnostic shape.
    """
    page_keys = options["page_keys"]
    limit, reads = options["limit"], options["reads"]
    scope = freeze._scope(connection, period, current=True, reads=reads)
    if scope is not None:
        through = scope.through
        states = []
        if page_keys:
            entries = freeze._page_entries(
                connection, scope, include_settled=True, page_keys=page_keys,
                after=None, limit=limit, reads=reads,
            )
            selected = sorted(page_keys & entries.keys())[:limit]
            base = freeze._read_states(
                connection, scope.base_period,
                {key: entries[key][0] for key in selected if key not in scope.overrides},
                reads=reads,
            )
            for key in selected:
                state = dict(scope.overrides[key] if key in scope.overrides else base[key])
                state["period_paid"], state["period_other"] = scope.period_amounts.get(key, (0, 0))
                states.append(state)
        freeze._verified_page_sources(connection, scope.base_period, states)
        rows = [settlement._obligation_view(state) for state in states]
    else:
        # Mandatory current verification still covers every applicable period,
        # including a later publication omitted by a damaged projection.
        cutoff, through, source_keys, parameters = settlement._summary_scope(
            connection, period, subject_ids=None, current=True, reads=reads,
        )
        source_keys += " HAVING obligation_key IN (SELECT value FROM json_each(?))"
        selected = connection.execute(
            settlement._summary_relation(source_keys)
            + "SELECT * FROM obligations ORDER BY obligation_key LIMIT ?",
            [*parameters, canonical(sorted(page_keys)), through, cutoff, cutoff, limit],
        )
        rows = [settlement._obligation_view(row) for row in selected]
    label = str(YearMonth.from_ordinal(through))
    unknown = any(row["remaining_fen"] is None for row in rows)
    return {
        "cutoff_period": label, "current_cutoff_period": label,
        "status": "partially_established" if unknown else "established",
        "complete": not unknown, "issues": [], "categories": {}, "obligations": rows,
        "page": {
            "total_count": len(rows), "filtered_count": len(rows),
            "returned_count": len(rows), "has_more": False, "next_cursor": None,
        },
    }


@contextmanager
def current_rows_adapter():
    original = settlement.settlement_dashboard_open

    def read(connection, period, **options):
        if (options.get("current") and options.get("page_keys") is not None
                and not options.get("summary_only")):
            return current_rows_only(connection, period, **options)
        return original(connection, period, **options)

    with patch.object(settlement, "settlement_dashboard_open", read):
        yield


@contextmanager
def member_metadata_adapter():
    original = dashboard_module._brief_prime_activity

    def prime(snap, rows):
        original(snap, rows)
        owners = set()
        for row in rows:
            if row["basis"]["kind"] not in OWNER_KINDS:
                continue
            ident = row["voucher_calculation_id"]
            if row["reverses_id"]:
                ident = snap.connection.execute(
                    "SELECT calculation_id FROM voucher_version WHERE id=?",
                    (row["reverses_id"],),
                ).fetchone()[0]
            owners.add(ident)
        if owners:
            # Ordinary immutable membership verification is still executed.
            memberships = snap.reads.asset_members_many(owners)
            members = [member for values in memberships.values() for member in values]
            metadata = snap.reads.metadata({m["member_calculation_id"] for m in members})
            snap.reads.facts({value["fact_id"] for value in metadata.values()})
            snap.metadata.prime_profiles("asset", {member["asset_id"] for member in members})

    with patch.object(dashboard_module, "_brief_prime_activity", prime):
        yield


def measure(engine, period, adapter=None):
    observation = Observe()
    with ExitStack() as stack:
        if adapter is not None:
            stack.enter_context(adapter())
        # Observe the comparison adapter too, including its moved prime work.
        stack.enter_context(observation.installed())
        work, response = measure_work(engine, lambda: Dashboard(engine).brief(period, limit=20))
    return {
        "work": work, "phase_events": observation.events,
        "scoped_calls": dict(observation.calls),
    }, response


def visible_data(response):
    data = dict(response["data"])
    data.pop("generated_at", None)
    # These are cursor snapshot tokens, not owner amounts or line identities.
    data["collections"] = {
        key: {"items": value["items"], "page": {
            name: item for name, item in value["page"].items() if name != "next_cursor"
        }} for key, value in data["collections"].items()
    }
    return data


def expense(company, subject, period="2026-01", revision=0, amount=10000):
    company.save(Expense(
        period=YearMonth(period), counterparty_id="supplier-" + subject,
        amount_fen=amount, expense_class="administration", creditor_kind="supplier",
    ), subject, revision=revision)


def add_profile_history(engine, ids, revisions, prefix, *, initialize_name=False):
    identities = tuple(ids)
    entities = Entities(engine)
    for ident in identities:
        with engine.store.connection(read_only=True) as connection:
            latest = connection.execute(
                "SELECT revision,content FROM entity_profile_revision WHERE entity_id=? "
                "ORDER BY revision DESC LIMIT 1", (ident,),
            ).fetchone()
        revision, data = latest["revision"], json.loads(latest["content"])
        if initialize_name:
            data["display_name"] = ident
        else:
            assert data["display_name"] == ident, "history must preserve the established name"
        for number in range(revisions):
            entities.update_entity_profile(
                ident, data, source="synthetic stable-name history",
                expected_revision=revision + number,
                request_id=f"{prefix}-{ident}-{number}",
            )


def settlements_case(path, *, closed, noise, revisions, progress=None):
    company = Company(path / "company.sqlite")
    for number in range(25):
        expense(company, f"target-{number:04d}")
    company.save(CashFunding(
        period=YearMonth("2026-01"), actual_date="2026-01-01", owner_id="owner",
        cash_account_id="cash", funding_kind="capital", amount_fen=1000000,
    ), "funding")
    company.publish("funding", *(f"target-{number:04d}" for number in range(25)))
    if closed:
        company.close("2026-01")
    selected_subject = Dashboard(company.engine).brief("2026-01", limit=20)[
        "data"
    ]["collections"]["open_items"]["items"][0]["subject_id"]
    company.save(CashPayment(
        period=YearMonth("2026-02"), actual_date="2026-02-15", direction="outflow",
        cash_account_id="cash", counterparty_id="supplier-" + selected_subject, amount_fen=10000,
        allocations=(Allocation(
            source_kind="expense", source_id=selected_subject, obligation="primary",
            amount_fen=10000,
        ),),
    ), "later-payment")
    company.publish("later-payment")
    results = []
    expected = None
    for label in ("base", "unrelated_later_objects", "unrelated_history_revisions"):
        if label == "unrelated_later_objects":
            for number in range(noise):
                expense(company, f"noise-{number:04d}", "2026-02")
            if noise:
                company.publish(*(f"noise-{number:04d}" for number in range(noise)))
        elif label == "unrelated_history_revisions" and noise:
            # Unrelated open-month versions change the necessary current proof
            # workload. They never alter any selected January obligation.
            for number in range(revisions):
                expense(company, "noise-0000", "2026-02", revision=number + 1,
                        amount=10001 + number)
                company.publish("noise-0000")
        baseline, response = measure(company.engine, "2026-01")
        narrower, comparison = measure(company.engine, "2026-01", current_rows_adapter)
        actual = visible_data(response)
        assert actual == visible_data(comparison), "current row-only adapter changed owner output"
        if expected is None:
            expected = actual
        assert actual == expected, "unrelated later sources changed selected January output"
        current_items = actual["collections"]["open_items"]["items"]
        assert len(current_items) == 20
        assert any(item["current_status"] == "settled" for item in current_items)
        results.append({
            "growth": label, "selected_rows": len(current_items),
            "visible_digest": value_digest(actual), "baseline": baseline,
            "diagnostic_current_rows_only": narrower,
        })
        if progress is not None:
            progress(results[-1])
    return {"frozen_base": closed, "cases": results}


def asset_case(path, *, count, noise, revisions, progress=None):
    # Reuse the existing real fixture and its typed activation/consumption API.
    engine, evidence = asset_engine.__wrapped__(path)
    ids = ["fixed-a", "intangible-b"]
    extra = [f"member-{number:04d}" for number in range(max(0, count - 2))]
    seed_entities(engine, [(ident, "asset", None) for ident in extra])
    for ident in extra:
        engine.save_fact("asset", ident, {
            "period": "2026-01", "asset_id": ident, "asset_type": "fixed",
            "acquisition_date": "2026-01-02", "supplier_id": "supplier",
            "cost_fen": 12000, "acquisition_basis": "direct_purchase",
        }, evidence=(evidence,), expected_revision=0, request_id="save-" + ident)
    if extra:
        preview = engine.preview(extra)
        engine.confirm(extra, preview_digest=preview["digest"], epochs=preview["epochs"],
                       request_id="acquire-extra")
    ids.extend(extra)
    add_profile_history(engine, ids, 1, "initial-name", initialize_name=True)
    members = [{
        "subject_id": "activate-" + ident, "expected_revision": 0, "data": {
            "period": "2026-01", "asset_id": ident, "in_use_date": "2026-01-03",
            "useful_life_months": 3, "residual_fen": 0,
            "benefit_area": "administration", "rounding_policy": "floor_final_remainder",
        },
    } for ident in ids]
    batches = AssetBatches(engine)
    options = {
        "subject_id": "activation-batch", "period": "2026-01", "members": members,
        "evidence": (evidence,), "expected_revision": 0,
    }
    preview = batches.prepare_activation_batch(**options)
    batches.confirm_activation_batch(
        **options, preview_digest=preview["digest"], epochs=preview["epochs"],
        request_id="activate-all",
    )
    # February consumption requires the real, continuously adopted January
    # predecessor. The fixture follows that rule instead of omitting a month.
    month(engine, evidence, "2026-01", "consume-january")
    month(engine, evidence, "2026-02", "consume-base")
    results, expected = [], None
    for label in ("base", "unrelated_objects", "profile_history_revisions"):
        if label == "unrelated_objects":
            unused = [f"unused-asset-{number:04d}" for number in range(noise)]
            seed_entities(engine, [(ident, "asset", None) for ident in unused])
            add_profile_history(engine, unused, 1, "unused-name", initialize_name=True)
        elif label == "profile_history_revisions":
            add_profile_history(engine, ids, revisions, "same-visible-name")
        baseline, response = measure(engine, "2026-02")
        batched, comparison = measure(engine, "2026-02", member_metadata_adapter)
        actual = visible_data(response)
        assert actual == visible_data(comparison), "metadata batching changed owner output"
        if expected is None:
            expected = actual
        assert actual == expected, "unrelated objects or stable-name history changed owner output"
        vouchers = actual["collections"]["vouchers"]["items"]
        owners = [row for row in vouchers if row["kind"] in OWNER_KINDS]
        assert len(owners) == 1 and len(owners[0]["asset_members"]) == count
        results.append({
            "growth": label, "members": count, "visible_digest": value_digest(actual),
            "baseline": baseline, "diagnostic_batch_member_metadata": batched,
        })
        if progress is not None:
            progress(results[-1])
    return {"cases": results}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--noise", type=int, default=40)
    parser.add_argument("--revisions", type=int, default=4)
    parser.add_argument("--members", type=int, default=30)
    parser.add_argument(
        "--group", choices=("all", "settlements", "unfrozen", "frozen", "assets"),
        default="all",
    )
    args = parser.parse_args()
    if not 0 <= args.noise <= 500 or not 0 <= args.revisions <= 30 or not 2 <= args.members <= 500:
        parser.error("noise 0..500, revisions 0..30, members 2..500")
    if args.output.exists():
        parser.error("output already exists; select a new diagnostic result path")
    before = source_manifest()
    groups = {
        "all": ("unfrozen", "frozen", "assets"),
        "settlements": ("unfrozen", "frozen"),
        "unfrozen": ("unfrozen",), "frozen": ("frozen",), "assets": ("assets",),
    }[args.group]
    args.output.parent.mkdir(parents=True, exist_ok=True)
    # Exclusive creation rejects an existing report even if another process
    # creates it after the preliminary check. All later writes use this owned
    # handle, so a later group failure retains earlier measured work.
    with args.output.open("x+", encoding="utf-8") as target:
        report = {
            "kind": "synthetic_instrumented_work_not_browser_acceptance",
            "status": "running", "selected_groups": groups, "completed_groups": [],
            "groups": {}, "errors": [], "source_sha256": before,
            "parameters": {"noise": args.noise, "revisions": args.revisions,
                           "members": args.members},
            "boundaries": [
                "Fresh synthetic databases only; existing service and real data are untouched.",
                "Complete current publication/projection scope checks remain in both adapters.",
                "Frozen member identity, digest, line attribution and source proof remain.",
                "The row-only adapter omits unconsumed current global aggregates only.",
                "Batching adapter moves normal member/metadata verification; no proof bypass.",
                "Work is instrumented; diagnostic time is not owner page latency.",
                "No independent verify/repair/backup/fixed-v1 result is claimed.",
            ],
        }

        def checkpoint():
            target.seek(0)
            json.dump(report, target, ensure_ascii=False, indent=2)
            target.write("\n")
            target.truncate()
            target.flush()

        checkpoint()
        active_group = None
        try:
            with tempfile.TemporaryDirectory(
                prefix="stage9-owner-final-read-", dir=ROOT / ".tmp",
            ) as name:
                temporary = Path(name)
                for group in groups:
                    active_group = group
                    path = temporary / group
                    path.mkdir()
                    report["groups"][group] = {"status": "running", "cases": []}
                    checkpoint()

                    def progress(case, *, selected_group=group):
                        report["groups"][selected_group]["cases"].append(case)
                        checkpoint()

                    result = (
                        asset_case(
                            path, count=args.members, noise=args.noise,
                            revisions=args.revisions, progress=progress,
                        ) if group == "assets" else settlements_case(
                            path, closed=group == "frozen", noise=args.noise,
                            revisions=args.revisions, progress=progress,
                        )
                    )
                    report["groups"][group] = {"status": "completed", **result}
                    report["completed_groups"].append(group)
                    checkpoint()
            after = source_manifest()
            report["source_unchanged"] = before == after
            if before != after:
                report["source_sha256_after"] = after
                raise RuntimeError("source changed during diagnostics; not a fixed candidate")
            report["status"] = "diagnostic_completed"
            checkpoint()
        except BaseException as error:
            report["status"] = "failed"
            if active_group is not None and active_group not in report["completed_groups"]:
                report["groups"][active_group]["status"] = "failed"
            report["source_unchanged"] = before == source_manifest()
            report["errors"].append({
                "group": active_group, "type": type(error).__name__,
                "message": str(error), "traceback": traceback.format_exc(),
            })
            checkpoint()
            raise
    print(json.dumps({"output": str(args.output), "status": "diagnostic_completed"}))


if __name__ == "__main__":
    main()
