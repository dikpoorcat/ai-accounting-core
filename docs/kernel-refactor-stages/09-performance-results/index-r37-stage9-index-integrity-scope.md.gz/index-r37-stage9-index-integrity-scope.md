# Stage 9 index #1: integrity and storage caller matrix

Scope: read-only comparison of the released synthetic company database at
`.tmp/stage9-release-main-12/91310000123456789S/company.sqlite` with the
reseeded synthetic database at
`.tmp/stage9-reseed-main-12-r36/91310000123456789S/company.sqlite`.
The old 48-month database gave the same plan shapes as old 12. The reseeded
48-month staging database intermittently returned `database is locked` and is
not used as proof for the rows below. Queries used `EXPLAIN QUERY PLAN` on
read-only connections and an absent ID; no source or database was modified.

| Caller / SQL shape | Purpose and reach | Old 12 → reseed 12 plan | Assessment |
| --- | --- | --- | --- |
| `integrity.py:113,148` `_rows(fact_revision,id,IDs)` | Exact facts from `_check_sources`; `verify_sources` for bounded changes and `verify_integrity` for full verification | `SCAN ids → SEARCH fact_revision(id)` in both | Bounded branch remains ID-driven. The `identifiers=None` full scan is the intended whole-source verifier. |
| `integrity.py:155` `json_each(subject IDs) JOIN subject(id)` | Resolve kinds of already selected facts | `SCAN ids → SEARCH subject(id)` in both | Bounded. |
| `integrity.py:185,193,222` fact seal, evidence, and child rows by fact IDs | Verify exact selected facts and their evidence/child ordering | Fact-evidence sample: `SCAN ids → SEARCH fact_evidence(fact_id)` in both | No new `subject.kind → fact_revision` driver. |
| `storage.py:325,352` `fact_revision(id=?) JOIN subject(id)` | Single fact and raw fact reads | `SEARCH fact_revision(id) → SEARCH subject(id)` in both | Bounded. |
| `storage.py:371,444` `json_each(fact IDs) JOIN fact_revision(id) JOIN subject(id)` | Current batch fact data/versions; also used by integrity raw fact fallback | `SCAN ids → SEARCH fact_revision(id) → SEARCH subject(id)` in both; new plan uses `fact_id_subject_cover` for the kind-only query | Bounded. |
| `content_v1.py:230,280` same exact-ID pattern | Released-v1 fact data/versions through `Store.fact_data_many` and `Store.facts` | `SCAN ids → SEARCH fact_revision(id) → SEARCH subject(id)` in both; new plan may use `fact_id_subject_cover` | Bounded historical path. |
| `content_v1_semantics.py:299` `fact_revision.id IN (SELECT value FROM json_each(?))` | Resolve source fact/subject identities | `LIST json_each → SEARCH fact_revision(id)` in both | Bounded. |
| `close_review_integrity_v1.py:552,624,720,780,848,877,888` exact fact ID and selected calculation ID proofs | Historical close receipt checks; the nested voucher-to-calculation-to-fact lookup also starts from selected voucher IDs | Fact `IN`: `LIST json_each → SEARCH fact_revision(id)`; calculation join: `LIST json_each → SEARCH calculation(id) → SEARCH fact_revision(id)` in both | Bounded fixed-v1 proof. The current `close_review.py` mirrors these SQL shapes. |
| `close_storage.py:983-987` `json_each(missing IDs) JOIN fact_revision(id)` | Reject missing saved close references | `SCAN ids → SEARCH fact_revision(id)` in both | Bounded. |
| `publication.py:60,78,195,201` and `publication_v1.py:26,54,66,72` | Published chain, head, calculation and current identity checks by selected subject/calculation IDs | Representative chain: `LIST json_each → SEARCH publication(subject_id)`; heads: `SCAN ids → SEARCH publication(subject_id)` in both | No newly indexed `subject`/`fact_revision` join. |
| `projections.py:166,185,239` | Affected-subject contribution and prior-period lookups for projection verification/repair | `SCAN ids → SEARCH calculation(subject_id)` or `calculation_current(subject_id)` in both | Bounded affected-subject branch. Full reconstruction remains deliberate. |
| `storage.py:637-639` fact source resolution, `q.key='*'` | Explicit all-current-facts wildcard of a kind | Request-first `CROSS JOIN` with `subject.kind` lookup | Broad by contract, not an exact-ID regression. The exact `#fact_id` branch at `:633-636` is request-first. |

The affected frozen material proof is in `close_storage_v1.py:174-186` and is
owned by the close-storage workstream. Its `_v1_frozen_versions` calls are
reached through `_material_summaries` when verifying saved close storage.
Existing `.tmp/stage9-r36-reseed-query-plans.json` proves four old-to-new
plan reversals: old `json_each IDs → fact_revision(id)` versus new
`subject_kind(kind) → fact_revision(subject_id) → ... → json_each IDs`.
Backup and restore invoke the registered company verifier through
`backup._verify_connection`, and offline upgrades verify both source and
target through that function; these paths therefore inherit the affected
close-storage check. The current and historical fact-loading paths above
remain independently ID-driven.

No SQL change is justified in this owned scope. Final verification should
include the close-storage fix and use a completed reseeded 48-month database,
because the staging file was locked during part of this diagnostic pass.
