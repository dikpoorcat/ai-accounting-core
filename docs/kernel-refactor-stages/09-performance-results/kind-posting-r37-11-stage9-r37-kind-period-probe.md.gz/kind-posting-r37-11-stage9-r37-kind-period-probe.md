# r37 `selected_kinds` 当月凭证范围探针

本次只在固定源码 `.tmp/stage9-build-source-r37-release` 与新索引 12／48 月合成库上读取。脚本为 `.tmp/stage9-r37-kind-period-probe.py`，原始参数、完整 SQL、完整 `EXPLAIN QUERY PLAN` 与逐条结果在同名 JSON。每库只调用一次真实 `Dashboard.employees(..., limit=100, preparation="deferred")` 取得 `_PrivateConnection.execute` 的 statement／params，随后在只读事务里单独执行捕获的五条 `selected_kinds` SQL。未跑六页、回归、纯计时或任何改写 SQL 原型。VM 用每一步 progress handler 计数，故比 r37 原工作量文件的百步取整更精确；这仍是插桩诊断，不是页面耗时。

## 结果

真实员工入口每档均执行 3 次 `basis_ids` 和 2 次 `payroll_metrics`；其中 `annual_bonus/payroll/payroll_bounded` 集合各有一条非空调用，另两组 `labor/labor_accrual`、`labor_project_cost` 返回 0。非空两条保持同样的目标月输出：

| 原 SQL，真实参数中的目标凭证入账月 | 12 月库：全部同类 `sc→original` 候选／目标月候选／最终返回／VM | 48 月库：同序 |
| --- | --- | --- |
| `SELECT DISTINCT basis_calculation_id ...`，`2016-12`／`2019-12` | 600／50／50 行 3,300 B／11,467 | 2,400／50／50 行 3,300 B／33,066 |
| 工资度量 `SELECT j.*,json_object(...) ...`，同月 | 600／50／50 行 99,660 B／17,624 | 2,400／50／50 行 99,660 B／39,223 |

两条原 SQL 的计划在两档同型：`SCAN selected_kinds` → `SEARCH sc USING COVERING INDEX calculation_kind_period (kind=?)` → `SEARCH original USING INDEX voucher_calculation (calculation_id=?)` → `SEARCH v USING INDEX ... (id=?)`，最后分别以临时 B-tree 做 DISTINCT／ORDER BY。`sc` 的索引条件只含 `kind`，不是目标月份；确有 600→2,400 个同类候选经过前段，最终凭证入账月只要 50 个。原 SQL VM 增长与这个候选扩大相符，故 r37 增长文档中的计划疑点得到确认。**没有实测任何替代 SQL 的正确性、VM 或净时延，不能称修复方案已确定。**

探针也单独计了 `sc.period`：这两份普通工资合成样本中，其与 `original.period` 恰好全部相同。但 `calculation.period` 是计算所属／来源月，`voucher_version.period` 是凭证入账月；这次样本的相等**不能**成为用 `sc.period` 提前过滤的依据。若后续做方案，只能围绕目标 `voucher_version.period` 保持原精确语义，并覆盖跨月发布、修订、闭期冲正与缺损拒绝。

## `selected_voucher_sql` 调用边界

| 路径 | 当前驱动及期间含义 | 必须保持的边界 |
| --- | --- | --- |
| `dashboard_reads.Journal` → `Dashboard` 简报／员工／资金等 | `kinds` 单独给定才走此次 `selected_kinds`；指定 `accounts` 时先找精确 `voucher_ids`，`subjects` 优先于 `kinds`。`month` 有值时传 `posting_period`，并在外层再次检查 `j.period`；无月时只有限定 `v.period<=cutoff` 的范围读取。 | 不能把本月条件套到全年／截至月 journal；`after_number`、账户筛选和分页沿用既有外层语义。开放月 `no_close_references` 要先证明该月没有相关关账引用。 |
| `BusinessQueries._selected_accounting` | 先从明确 `kinds` 解析主体，再以 `subject_ids` 选择，不走 kind 驱动；可传 `posting_period`，也可跨历史到 cutoff；固定采用清单时传 `authoritative_vouchers`。 | 主体分支把原凭证与其冲正凭证一起纳入候选；之后仍核对冻结采用、当前发布、来源引用及入账月份。不能只按计算所属月裁去跨月凭证。 |
| `report_projection._authoritative_rows` | 按一个确切 `posting_period` 读该月凭证，`open/closed` 分开；先证明开放月关账引用缺席才用相应快路。 | 全月报表行与凭证行、发布来源独立核对，不属于本次 kind 查询的同一计划。 |
| `reports._report_vouchers` | 公开报表按调用方传入 `voucher_ids` 的精确集合，或在历史回退中只给 cutoff；`source=closed` 追加 `selection_source='close_manifest'`。 | 精确 ID 候选、无界历史回退、闭月与开放来源均有不同职责；不得把本月 kind 样本的过滤推广到这些分支。 |
| 固定 v1 | `report_projection_v1.selected_voucher_sql` 是独立历史函数；`position_v1`、`report_projection_v1` 调用它。 | 历史内容比较及非空 v1 读取必须继续按已发布规则，不能借 current 的新筛选替代。 |

选择器本身按 `voucher_ids` → `subject_ids` → `kinds` → 无预选的优先级构造候选，之后依据 `reverses_id` 选择原计算、依据冻结或当前发布选择 basis，并检查 `voucher_current`／`period_close`。本探针只确认 kind＋精确凭证入账月组合存在过宽的前段候选；不对其他组合下结论。

下一步如由主任务决定继续，仅需设计并在**私有对照**中验证对 `voucher_version.period` 的局部约束，再比较原 SQL 的结果／拒绝、VM 与真实主路径净影响。当前阶段没有产品改动建议或性能验收结果。
