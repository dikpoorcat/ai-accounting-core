"""Uninstrumented native read diagnosis. Never an actual browser acceptance result."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[1]

NON_BUSINESS_PATHS = {('generated_at',), ('data', 'generated_at'), ('checked_at',), ('read_context', 'read_version')}

def comparable(value, path=()):
    if isinstance(value, dict):
        return {key: comparable(item, path + (key,)) for key, item in value.items()
                if path + (key,) not in NON_BUSINESS_PATHS}
    if isinstance(value, list):
        return [comparable(item, path + (index,)) for index, item in enumerate(value)]
    return value

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    source, output = args.source.resolve(), args.output.resolve()
    assert source.parent == ROOT / '.tmp' and source.name.startswith('stage9-build-source-')
    assert output.parent == ROOT / '.tmp' and output.name.startswith('stage9-')
    assert not output.exists()
    assert Path(sys.prefix).resolve() == ROOT / '.tmp-kernel-venv'
    sys.path[:0] = [str(source / 'src')]
    os.environ['STAGE9_WORKSPACE_ROOT'] = str(ROOT)
    from ai_accounting.kernel.daemon import _prepare_static_runtime
    from ai_accounting.kernel.dashboard import Dashboard
    from ai_accounting.kernel.service import LocalService
    result = {'status': 'native_diagnostic', 'source': str(source),
              'response_comparison_excludes': sorted('.'.join(path) for path in NON_BUSINESS_PATHS),
              'exclusion_reason': 'Generation/check timestamps and build-bound read token; no business fields excluded.',
              'samples': {}}
    for months in (12, 48):
        root = ROOT / ('.tmp/stage9-reseed-main-12-r36' if months == 12
                       else '.tmp/stage9-reseed-main-48-r36.staging')
        app = LocalService(root, enable_read_pool=True, enable_parallel_brief=True,
                           _static_runtime=_prepare_static_runtime())
        try:
            companies = app.catalog.companies()
            assert len(companies) == 1 and companies[0]['name'] == '阶段九合成规模企业'
            engine = app.engine(companies[0]['id'], dashboard_read=True)
            page = Dashboard(engine)
            period = '2016-12' if months == 12 else '2019-12'
            operations = {
                'context': page.context,
                'brief': lambda: app._dashboard_brief(page, engine, {'period': period, 'limit': 100, 'preparation': 'complete'}),
                'funds': lambda: page.funds(period, limit=100, preparation='deferred'),
                'employees': lambda: page.employees(period, limit=100, preparation='deferred'),
                'assets': lambda: page.assets(period, limit=100, preparation='deferred'),
                'reports': lambda: page.quarterly_report(int(period[:4]), 4, preparation='deferred'),
            }
            sample = {name: {'milliseconds': [], 'parent_cpu_ms': [], 'response_sha256': []} for name in operations}
            result['samples'][str(months)] = sample
            for index in range(7):
                for name, operation in operations.items():
                    cpu, started = time.process_time(), time.perf_counter()
                    response = operation()
                    elapsed = (time.perf_counter() - started) * 1000
                    cpu_ms = (time.process_time() - cpu) * 1000
                    if index >= 2:
                        record = sample[name]
                        record['milliseconds'].append(elapsed)
                        record['parent_cpu_ms'].append(cpu_ms)
                        wire = json.dumps(comparable(response), sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode()
                        record['response_sha256'].append(hashlib.sha256(wire).hexdigest())
                output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
            print(months, 'complete', flush=True)
        finally:
            app.close()
    result['status'] = 'complete_native_diagnostic'
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')

if __name__ == '__main__':
    main()
