from pathlib import Path
import hashlib
import json
import statistics

root = Path(__file__).resolve().parents[1]
names = ('r37-A', 'r38-A', 'r38-B', 'r37-B')
reports = {}
input_digests = {}
for name in names:
    path = root / f'.tmp/stage9-native-close-batch-{name}.json'
    raw = path.read_bytes()
    reports[name] = json.loads(raw)
    input_digests[name] = hashlib.sha256(raw).hexdigest()
    assert reports[name]['status'] == 'complete_native_diagnostic'
rows = []
for months in ('12', '48'):
    for page in ('context', 'brief', 'funds', 'employees', 'assets', 'reports'):
        by_run = {name: reports[name]['samples'][months][page] for name in names}
        checksums = {digest for run in by_run.values() for digest in run['response_sha256']}
        old = [value for name in ('r37-A', 'r37-B') for value in by_run[name]['milliseconds']]
        new = [value for name in ('r38-A', 'r38-B') for value in by_run[name]['milliseconds']]
        assert len(old) == len(new) == 10 and len(checksums) == 1, (months, page)
        old_med, new_med = statistics.median(old), statistics.median(new)
        rows.append({'months': int(months), 'page': page, 'samples_per_revision': 10,
                     'business_responses_equal': True,
                     'before_median_ms': old_med, 'after_median_ms': new_med,
                     'median_delta_ms': new_med - old_med,
                     'median_delta_percent': (new_med / old_med - 1) * 100,
                     'before_max_ms': max(old), 'after_max_ms': max(new),
                     'run_medians_ms': {name: statistics.median(run['milliseconds'])
                                        for name, run in by_run.items()}})
result = {'status': 'complete_native_diagnostic_not_browser_acceptance',
          'order': names, 'input_sha256': input_digests,
          'method': 'Two warmups, five samples per operation per run; ABBA; all raw samples retained.',
          'readiness': 'brief complete with real worker pool, other pages deferred like browser',
          'response_comparison_excludes': reports[names[0]]['response_comparison_excludes'],
          'rows': rows}
output = root / '.tmp/stage9-native-close-batch-summary-r38.json'
assert not output.exists()
output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
for row in rows:
    print(f"{row['months']} {row['page']}: {row['before_median_ms']:.1f} -> "
          f"{row['after_median_ms']:.1f} ms ({row['median_delta_percent']:+.1f}%)")
