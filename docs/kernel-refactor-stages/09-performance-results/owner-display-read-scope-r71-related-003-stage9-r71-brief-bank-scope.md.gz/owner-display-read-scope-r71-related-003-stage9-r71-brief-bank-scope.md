# r71 简报资金摘要范围

生产调用 `funds(..., summary_only=True)` 仅来自 `dashboard.brief` 的 `_funds`；
资金页调用保留普通分支。其他同名 summary_only 属于工资、资产、应收付或资料读取，
不在本项范围。CLI/MCP/core/关账/fullverify/repair/backup 不直接消费本资金摘要。

目前摘要仍初始化 FundsRead，执行 account_summary 后无条件执行 bank_summary。
后者装载当月 statement/reconciliation 分类，构造匹配及覆盖状态、银行原行聚合；
这些信息将由根节点从简报风险删除。普通资金页仍需要它们。

account_summary 独立执行 balance_totals/balance_movements、当前及冻结资金事件证明、
全部必要状态/零账户身份、独立期初和不确定期初证明，再处理退休账户归属。
因此窄返回必须位于它成功完成之后，不能跳过 FundsRead 初始化或减小来源 scope。
资金金额包含 account_rows 与 omitted_account_rows；未知 closing_fen 保持 None。

拟修改仅 dashboard_funds.py：summary_only 在 account_summary 后返回
total_fen/bank_fen/cash_fen/payment_platform_fen/inflow_fen/outflow_fen/
net_change_fen/internal_transfer_fen 八字段。跳过 bank_summary、产品摘要、展示计数、
银行覆盖与对账风险、空 collections 等未消费输出；普通分支保持全部合同。
无新模型、SQL合同、版本、缓存或 source/classification/历史分派变化。

新 tests/kernel/test_owner_funds_summary_scope.py 使用真实合成 bank/platform/opening
事实与 measure_work，对照原 account_summary+bank_summary 完整工作与窄摘要，
记录 SQL VM/返回行/字节/解码正反数据，并比较普通资金页八金额及显式业务预期。
覆盖多未匹配原行、内部转款及资金渠道、未知期初、资金来源损坏拒绝、核心匹配门禁。
只运行这一个新增组，保存实际 stdout/log/XML；不运行验收计时或大套。

已有 test_funds_bounded_reads.py 的两参数 statement 测试断言内部摘要含
collections/bank_statement/unmatched_totals，需要根更新到新八字段合同。
该文件不属本 agent ownership，已通知根；其普通资金页与 FundsRead.bank_summary
断言仍有意义，不应删除。历史账户及其他 summary_only 测试只读取金额或
断言无 investments，仍与窄合同相容。

实际完成：早返回仅八字段；普通分支未变。root 已更新上述既有摘要断言，
普通资金页与 bank_summary 的未匹配断言全部保留。

定向命令：

```powershell
& ./.tmp-kernel-venv/Scripts/python.exe -X utf8 -m pytest tests/kernel/test_owner_funds_summary_scope.py -q -ra --junitxml=.tmp/stage9-r71-owner-funds-summary.xml
```

实际一次 `9 passed, 2 warnings in 16.31s`，完整 stdout 保存
`.tmp/stage9-r71-owner-funds-summary.log`。两个 warning 为 record_property 与
xunit2 的兼容提示；XML 内实际仍保存了两个工作量属性，已读取核对。
指定 source/test 两文件 ruff check 通过，回执仅 tool stdout，不补造 ruff log。

| 实际银行原行 | 旧/窄 VM | 旧/窄 SQL | 旧/窄返回行 | 旧/窄返回字节 |
|---:|---:|---:|---:|---:|
| 9 | 9100 / 7800 | 71 / 65 | 127 / 124 | 18133 / 17926 |
| 209 | 41300 / 17200 | 71 / 65 | 127 / 124 | 36933 / 36726 |

银行原行相关 SQL 3→2；窄路径仍有两项必要来源读取，不能声称完全不读银行资料。
全部计算结果加载/解码仍为7次、1377/1381字节，两条路径严格相等。
大原行组实际 VM 减少，返回字节只减少207，主要收益来自不再聚合未消费对账明细，
没有弱化 source/header/body 身份证明，也不是仅SQL次数减少的判断。

八金额等价普通资金页；bank/cash/platform合法转款显式金额为
total1700、bank900、cash200、platform600、internal100。资金 outcome重复键、
fact seal、publication、零账户独立state损坏，两次重新读取均拒绝；
真实期初来源核验后的下游不确定选择仍传播None。银行原行999与实际资金1000
保持各自职责，普通对账显示仍pending，核心匹配仍拒绝bank_match_difference。
未知期初用已有严格source结果后的下游uncertainty替身，明确不是实际损坏或
工作量测试；历史/v1完整矩阵未在本轮新跑，由root统一受影响组收口。

本项没有运行native/browser/500ms验收、建大库、迁移或操作真实资料。
停止编辑与测试，交root统一验证。
