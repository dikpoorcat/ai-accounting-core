"""Temporary selector prototype; never a product change or page timing result.

Use only pinned synthetic books or fresh synthetic fixtures. The transformed
helper is the existing complete membership identity checker, not a JSON decoder.
All its member/owner identity, dependency, position and complete digest checks
remain. Only frozen activation identities consumed by _asset_card_sources use
it; monetary and latest-event paths keep their ordinary complete reads.
"""

from __future__ import annotations

import argparse
import hashlib
import inspect
import json
import sys
import traceback
from contextlib import contextmanager, nullcontext
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp/stage9-build-source-owner-final-ui-20261003-release"
SOURCE_SHA = "8672404dd3fcb198f80d3583782b98590b8c8358e2c2e354fa3822b71fefa36b"
sys.path.insert(0, str(SOURCE / "scripts"))
import stage9_source  # noqa: E402

stage9_source.configure_source(SOURCE, ROOT)
sys.path.insert(0, str(SOURCE / "tests/kernel"))

from stage9_metrics import measure_work  # noqa: E402

from ai_accounting.kernel import business_queries, dashboard, schema_bundle  # noqa: E402
from ai_accounting.kernel.catalog import Catalog  # noqa: E402
from ai_accounting.kernel.contracts import KernelError  # noqa: E402
from ai_accounting.kernel.engine import Engine  # noqa: E402
from ai_accounting.kernel.resident_reads import ResidentReadPool  # noqa: E402
from ai_accounting.kernel.types import canonical  # noqa: E402

ORIGINAL_EVENTS = dashboard._Snapshot.asset_member_events
ORIGINAL_HEADS = business_queries.BusinessQueries._selected_asset_member_heads
ORIGINAL_MEMBERS = business_queries.BusinessQueries._selected_asset_members
ORIGINAL_CARD_SOURCES = dashboard._asset_card_sources
ORIGINAL_ASSETS = dashboard._assets
ORIGINAL_OWNER_SELECTION = business_queries.BusinessQueries._asset_owner_metadata_selection
PROTOTYPE_PREFIX = "prototype_frozen_activation_identity"
COUNTS = {}


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def sha(path):
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def value_sha(value):
    return hashlib.sha256(canonical(value).encode("utf-8")).hexdigest()


def count(name, number=1):
    COUNTS[name] = COUNTS.get(name, 0) + number


def make_identity_checker():
    """Retain the existing checker verbatim except three explicit scope edits.

    Existing original source is pinned by the source manifest. The returned
    function still authenticates every member of every selected owner before
    returning any identity. It never filters the member SQL by asset_id.
    """
    import textwrap

    source = textwrap.dedent(inspect.getsource(ORIGINAL_HEADS))
    replacements = (
        (
            "def _selected_asset_member_heads(self, connection, period, *, asset_ids):",
            "def prototype_activation_checker(self, connection, period, *, asset_ids=None, _selection=None):",
        ),
        ("    if not asset_ids:\n", "    if asset_ids is not None and not asset_ids:\n"),
        (
            "    selection = self._asset_owner_metadata_selection(connection, period)\n",
            "    selection = _selection if _selection is not None else self._asset_owner_metadata_selection(connection, period)\n"
            "    if selection is None:\n"
            "        return None\n"
            "    events, owners, membership, decoded = selection\n"
            "    events = tuple(event for event in events\n"
            "                   if owners[event['calculation_id']]['kind'] == 'asset_activation_batch')\n"
            "    events = tuple(event for event in events if event['calculation_id'] in membership)\n"
            "    selection = (events, owners, membership, decoded)\n",
        ),
        (
            "            if member[\"asset_id\"] not in asset_ids:\n",
            "            if asset_ids is not None and member[\"asset_id\"] not in asset_ids:\n",
        ),
        (
            '                    "calculation_id": member["member_calculation_id"],\n',
            '                    "calculation_id": member["member_calculation_id"],\n'
            '                    "subject_id": member["member_subject_id"],\n'
            '                    "fact_id": member["member_fact_id"],\n'
            '                    "result_digest": member["result_digest"].hex(),\n',
        ),
    )
    for old, new in replacements:
        require(source.count(old) == 1, "Pinned selector edit anchor changed")
        source = source.replace(old, new, 1)
    namespace = dict(vars(business_queries))
    exec(compile(source, str(Path(__file__).resolve()) + ":identity_checker", "exec"), namespace)
    return namespace["prototype_activation_checker"], source


IDENTITY_CHECKER, CHECKER_SOURCE = make_identity_checker()


def make_open_member_reader():
    import textwrap

    source = textwrap.dedent(inspect.getsource(ORIGINAL_MEMBERS))
    start = source.index("    events = self._selected_asset_owner_events(")
    end = source.index('    kinds = {"asset_activation", "asset_consumption"}', start)
    source = source[:start] + "    events = _events\n" + source[end:]
    source = source.replace("def _selected_asset_members(", "def prototype_open_members(", 1)
    source = source.replace("asset_ids=None, current_heads=False", "asset_ids=None, current_heads=False, _events=()", 1)
    namespace = dict(vars(business_queries))
    exec(compile(source, str(Path(__file__).resolve()) + ":open_members", "exec"), namespace)
    return namespace["prototype_open_members"], source


OPEN_MEMBERS, OPEN_MEMBERS_SOURCE = make_open_member_reader()


def identity_calculation(snap, event):
    if not event.get("prototype_frozen_identity"):
        return snap.calculation(event["calculation_id"])
    # The independently rooted complete directory checker supplied all these
    # exact source identities. No outcome/content/money proof is inserted.
    # CalculationView's existing lazy outcome access still performs full reads.
    return dashboard.CalculationView(snap, {
        "id": event["calculation_id"], "subject_id": event["subject_id"],
        "fact_id": event["fact_id"], "kind": event["kind"],
        "period": event["calculation_period"], "posting_period": None,
        "result_digest": event["result_digest"],
    })


def make_card_sources():
    import textwrap

    source = textwrap.dedent(inspect.getsource(ORIGINAL_CARD_SOURCES))
    old = 'selected[subject] = snap.calculation(event["calculation_id"])'
    require(source.count(old) == 1, "Card identity consumer changed")
    source = source.replace(old, "selected[subject] = identity_calculation(snap, event)")
    namespace = dict(vars(dashboard)) | {"identity_calculation": identity_calculation}
    exec(compile(source, str(Path(__file__).resolve()) + ":card_sources", "exec"), namespace)
    return namespace["_asset_card_sources"], source


CARD_SOURCES, CARD_SOURCES_SOURCE = make_card_sources()


def activation_events(snap, *, kinds=None, subjects=None, asset_ids=None):
    if (not getattr(snap, "_prototype_activation_identity", False)
            or kinds != {"asset_activation"} or subjects is not None or asset_ids is not None):
        return ORIGINAL_EVENTS(snap, kinds=kinds, subjects=subjects, asset_ids=asset_ids)
    reads = snap.reads
    key = (PROTOTYPE_PREFIX, snap.period)
    if reads._snapshot_active and key in reads._report_snapshot_cache:
        count("successful_identity_cache_hits")
        return reads._report_snapshot_cache[key]
    count("identity_attempts")
    selection = snap.queries._asset_owner_metadata_selection(snap.connection, snap.period)
    if selection is None:
        count("ordinary_full_fallbacks")
        return ORIGINAL_EVENTS(snap, kinds=kinds, subjects=subjects, asset_ids=asset_ids)
    events, owners, membership, _ = selection
    result = IDENTITY_CHECKER(snap.queries, snap.connection, snap.period, _selection=selection)
    count("frozen_activation_events", len(result))
    for event in result:
        event["prototype_frozen_identity"] = True
    open_events = [dict(event, selection_source="prototype_exact_owner_selection")
                   for event in events if event["calculation_id"] not in membership
                   and owners[event["calculation_id"]]["kind"] == "asset_activation_batch"]
    if open_events:
        count("ordinary_full_open_owners", len({event["calculation_id"] for event in open_events}))
        result.extend(OPEN_MEMBERS(snap.queries, snap.connection, snap.period,
                                  kinds=kinds, _events=open_events))
    result.sort(key=lambda item: (item["adoption_period"], item["voucher_number"] or 0,
                                 item["owner_calculation_id"], item["asset_id"]))
    # This is identity evidence only. Do not insert into _asset_members,
    # _verified_source_contents or any money/Outcome proof cache.
    if reads._snapshot_active:
        reads._report_snapshot_cache[(PROTOTYPE_PREFIX + "_owners", snap.period)] = selection
        reads._report_snapshot_cache[key] = result
    return result


def selected_owners(queries, connection, period):
    reads = queries._reads(connection)
    key = (PROTOTYPE_PREFIX + "_owners", period)
    if reads._snapshot_active and key in reads._report_snapshot_cache:
        count("successful_owner_selection_cache_hits")
        return reads._report_snapshot_cache[key]
    return ORIGINAL_OWNER_SELECTION(queries, connection, period)


def scoped_assets(snap, **options):
    sections = options.get("sections")
    prior = getattr(snap, "_prototype_activation_identity", False)
    snap._prototype_activation_identity = (not options.get("summary_only", False)
                                          and (sections is None or "assets" in sections))
    try:
        return ORIGINAL_ASSETS(snap, **options)
    finally:
        snap._prototype_activation_identity = prior


def scoped_card_sources(snap):
    if getattr(snap, "_prototype_activation_identity", False):
        return CARD_SOURCES(snap)
    return ORIGINAL_CARD_SOURCES(snap)


@contextmanager
def prototype():
    with patch.object(dashboard._Snapshot, "asset_member_events", activation_events), \
            patch.object(dashboard, "_assets", scoped_assets), \
            patch.object(dashboard, "_asset_card_sources", scoped_card_sources), \
            patch.object(business_queries.BusinessQueries, "_asset_owner_metadata_selection", selected_owners):
        yield


class ReadOnlyCatalog(Catalog):
    @contextmanager
    def connection(self, *, read_only=False, _cross_thread=False):
        require(read_only, "No catalog writes in fixed-book diagnostic")
        with super().connection(read_only=True, _cross_thread=_cross_thread) as connection:
            yield connection

    def recover_operations(self):
        with self.connection(read_only=True) as connection:
            require(connection.execute(
                "SELECT count(*) FROM company_operation WHERE status!='succeeded'"
            ).fetchone()[0] == 0, "Do not recover pending operations")


@contextmanager
def fixed_book(months):
    import benchmark_stage9_browser

    path = ROOT / f".tmp/stage9-owner-main{months}-final-ui-verified.json"
    report = json.loads(path.read_text("utf-8"))
    benchmark_stage9_browser.require_report_source(report, SOURCE)
    period = benchmark_stage9_browser.validate_book_report(report, company_name="阶段九合成规模企业")
    require(report["requested_months"] == months, "Wrong synthetic sample")
    root = stage9_source.synthetic_path(Path(report["root"]), ROOT)
    checkpoint = root / "stage9-builder.json"
    initial_checkpoint = sha(checkpoint)
    company = report["company"]
    catalog = ReadOnlyCatalog(root, schema_bundle.production_bundle())
    companies = catalog.companies()
    require(company in companies, "Company binding differs")
    pool = ResidentReadPool(maximum=4)
    store = catalog.bind(company["id"], read_pool=pool)
    original_connection = store.connection

    @contextmanager
    def only_read(*, read_only=False):
        require(read_only, "No existing company writes")
        with original_connection(read_only=True) as connection:
            yield connection

    store.connection = only_read
    engine = Engine(store)

    def state():
        with store.connection(read_only=True) as connection:
            return {
                "state": list(connection.execute("SELECT * FROM state WHERE id=1").fetchone()),
                "identity": dict(connection.execute("SELECT * FROM identity WHERE id=1").fetchone()),
                "checkpoint_sha256": sha(checkpoint),
                "company_registration": catalog.companies(),
            }

    before = state()
    require(initial_checkpoint == before["checkpoint_sha256"], "Checkpoint changed")
    try:
        yield engine, dashboard.Dashboard(engine, company_name=company["name"], companies=companies), period, before, state
    finally:
        require(state() == before, "Read diagnostic changed sample")
        pool.close()


def measured_pair(engine, operation):
    baseline_work, baseline = measure_work(engine, operation)
    COUNTS.clear()
    with prototype():
        proposed_work, proposed = measure_work(engine, operation)
    require(proposed == baseline, "Prototype changed complete response")
    return {
        "full_response_equal": True,
        "response_sha256": value_sha(baseline),
        "baseline": baseline_work,
        "prototype": proposed_work,
        "prototype_calls": dict(COUNTS),
    }, baseline


def native_cases(months, add_case, *, route=None):
    with fixed_book(months) as (engine, view, period, before, state):
        common = {"preparation": "deferred"}
        if route == "projects_section":
            pair, _ = measured_pair(engine, lambda: view.assets(period, section="projects", **common))
            add_case({"sample": months, "route": route, **pair})
            return
        pair, first = measured_pair(engine, lambda: view.assets(period, **common))
        add_case({"sample": months, "route": "default_assets", **pair})
        pair, all_rows = measured_pair(engine, lambda: view.assets(period, limit=500, **common))
        add_case({"sample": months, "route": "complete_assets", **pair})
        items = all_rows["data"]["collections"]["assets"]["items"]
        for label, options in (
            ("active_filter", {"asset_filter": "active"}),
            ("fixed_filter", {"asset_filter": "fixed"}),
            ("precise_last_card", {"asset_id": items[-1]["asset_id"]}),
            ("projects_section", {"section": "projects"}),
        ):
            pair, _ = measured_pair(engine, lambda options=options: view.assets(period, **common, **options))
            add_case({"sample": months, "route": label, **pair})
        small = view.assets(period, limit=5, **common)
        cursor = small["data"]["collections"]["assets"]["page"]["next_cursor"]
        require(cursor is not None, "Sample needs a second page")
        pair, _ = measured_pair(engine, lambda: view.assets(
            period, section="assets", limit=5, cursor=cursor,
            expected_version=small["snapshot_version"], **common,
        ))
        add_case({"sample": months, "route": "second_page", **pair})
        require(state() == before, "Sample changed during routes")


def fixture_cases(add_case, fixture_root):
    from test_asset_batch_reads import prepare_batch_assets
    from test_asset_batches import month
    from test_integrity_content import damage
    from test_payroll_corrections import Company
    from ai_accounting.kernel.asset_batches import AssetBatches
    from ai_accounting.kernel.content_history_context import historical_content
    from ai_accounting.kernel.entities import Entities

    require(not fixture_root.exists(), "Retain existing synthetic fixture directory")
    fixture_root.mkdir(parents=True)
    company = Company(fixture_root / "base.sqlite")
    engine = company.engine
    view = dashboard.Dashboard(engine)

    def emit(label, operation):
        pair, response = measured_pair(engine, operation)
        add_case({"sample": "synthetic", "route": label, **pair})
        return response

    def page(period, **options):
        return lambda: view.assets(period, preparation="deferred", **options)

    emit("empty_assets_no_period", page(None))
    prepare_batch_assets(company)
    with engine.store.connection(read_only=True) as connection:
        evidence = engine.store.current_fact(connection, "computer").evidence[0]
    emit("open_activation_full", page("2026-02"))
    month(engine, evidence, "2026-02", "consume-zero")
    month(engine, evidence, "2026-03", "consume-march")
    emit("two_open_months", page("2026-03"))
    company.close("2026-02")
    emit("closed_activation_open_consumption", page("2026-03"))
    company.close("2026-03")
    emit("closed_inherited_activation", page("2026-03"))
    month(engine, evidence, "2026-04", "consume-april")
    emit("unrelated_consumption_owner_growth", page("2026-04"))
    emit("precise_other_member", page("2026-04", asset_id="chair"))

    before_profile = emit("profile_before_revisions", page("2026-04"))
    entities = Entities(engine)
    with engine.store.connection(read_only=True) as connection:
        profiles = [dict(row) for row in connection.execute(
            "SELECT p.* FROM entity_profile_revision p WHERE p.entity_id IN ('computer','chair') "
            "AND p.revision=(SELECT max(q.revision) FROM entity_profile_revision q WHERE q.entity_id=p.entity_id)"
        )]
    for record in profiles:
        for offset in range(3):
            entities.update_entity_profile(
                record["entity_id"], json.loads(record["content"]),
                source="synthetic exact same visible profile",
                expected_revision=record["revision"] + offset,
                request_id=f"unchanged-{record['entity_id']}-{offset}",
            )
    after_profile = emit("profile_after_revisions", page("2026-04"))
    before_items = before_profile["data"]["collections"]["assets"]["items"]
    after_items = after_profile["data"]["collections"]["assets"]["items"]
    # Profile version/source provenance deliberately changes; business amounts
    # and the actual visible name must remain unchanged.
    for left, right in zip(before_items, after_items, strict=True):
        for field in ("asset_id", "name", "cost_fen", "book_value_fen", "status"):
            require(left[field] == right[field], "Unrelated exact profile revision changed visible state")

    # Native business_status is the shared public business-read path used by
    # CLI/MCP. Transport/auth handlers are deliberately not exercised here.
    emit("shared_business_status", lambda: business_queries.BusinessQueries(engine).business_status(
        "computer", "2026-04", as_of="2026-04-30"
    ))

    def unowned():
        with engine.store.connection(read_only=True) as connection:
            connection.execute("BEGIN")
            return business_queries.BusinessQueries(engine)._selected_asset_member_heads(
                connection, "2026-04", asset_ids={"computer", "chair"}
            )

    emit("unowned_original_full", unowned)

    def fixed_v1():
        with historical_content(1), view._snapshot("2026-04") as snap:
            return snap.queries._selected_asset_member_heads(
                snap.connection, snap.period, asset_ids={"computer", "chair"}
            )

    emit("fixed_v1_original_full", fixed_v1)

    # A real closed correction is represented by its precise negative/positive
    # adoption events; the open successor must retain ordinary full batch reads.
    correction_company = Company(fixture_root / "correction.sqlite")
    prepare_batch_assets(correction_company)
    correction_engine = correction_company.engine
    correction_view = dashboard.Dashboard(correction_engine)
    correction_company.close("2026-02")
    with correction_engine.store.connection(read_only=True) as connection:
        correction_evidence = correction_engine.store.current_fact(connection, "computer").evidence[0]
        members = [{"subject_id": subject, "expected_revision": 1,
                    "data": correction_engine.store.current_fact(connection, subject).fact.model_dump(mode="json")
                    | {"benefit_area": "sales"}}
                   for subject in ("activate-computer", "activate-chair")]
    options = dict(subject_id="activation-batch", period="2026-02", members=members,
                   evidence=(correction_evidence,), expected_revision=1, posting_period="2026-03")
    batches = AssetBatches(correction_engine)
    preview = batches.prepare_activation_batch(**options)
    batches.confirm_activation_batch(**options, preview_digest=preview["digest"],
                                     epochs=preview["epochs"], request_id="closed-correction")
    month(correction_engine, correction_evidence, "2026-03", "consume-corrected")
    for label, period in (("closed_activation_correction", "2026-03"),
                          ("historical_frozen_after_correction", "2026-02")):
        pair, _ = measured_pair(correction_engine, lambda period=period: correction_view.assets(
            period, preparation="deferred"
        ))
        add_case({"sample": "synthetic", "route": label, **pair})

    # Verify activation failure before publishing any prototype member/owner
    # selection cache. Delete a member outside the requested precise card.
    with engine.store.connection(read_only=True) as connection:
        activation_owner = connection.execute(
            "SELECT c.id FROM calculation c JOIN calculation_publication p ON p.calculation_id=c.id "
            "WHERE c.kind='asset_activation_batch' AND p.posting_period=? ORDER BY p.sequence LIMIT 1",
            (business_queries.YearMonth("2026-02").ordinal,),
        ).fetchone()[0]
    damage(engine, "asset_batch_member",
           "DELETE FROM asset_batch_member WHERE owner_calculation_id=? AND asset_id='chair'",
           (activation_owner,), foreign_keys=False)

    def failed_proof():
        with view._snapshot("2026-02") as snap:
            snap._prototype_activation_identity = True
            failures = []
            for _ in range(2):
                try:
                    activation_events(snap, kinds={"asset_activation"})
                except KernelError as error:
                    failures.append(error.code)
                else:
                    raise AssertionError("Damaged complete activation membership accepted")
                require(not any(isinstance(key, tuple) and str(key[0]).startswith(PROTOTYPE_PREFIX)
                                for key in snap.reads._report_snapshot_cache),
                        "Failed activation published prototype cache")
                require(not snap.reads._asset_members, "Failed activation claimed full members")
            return {"failure_codes": failures, "success_cache_absent": True}

    COUNTS.clear()
    with prototype():
        work, failed = measure_work(engine, failed_proof)
    add_case({"sample": "synthetic", "route": "other_member_missing_failures_not_cached",
              "prototype": work, "prototype_calls": dict(COUNTS), **failed})
    for enabled in (False, True):
        with prototype() if enabled else nullcontext():
            try:
                page("2026-02", asset_id="computer")()
            except KernelError:
                pass
            else:
                raise AssertionError("Precise requested card hid corrupt other batch member")
    add_case({"sample": "synthetic", "route": "precise_page_rejects_other_member_corruption",
              "both_paths_reject": True})


def money_failure_case(add_case, fixture_root):
    from test_asset_batch_reads import prepare_batch_assets
    from test_asset_batches import month
    from test_integrity_content import damage
    from test_payroll_corrections import Company

    require(not fixture_root.exists(), "Retain prior synthetic money fixture")
    fixture_root.mkdir(parents=True)
    company = Company(fixture_root / "money.sqlite")
    prepare_batch_assets(company)
    engine = company.engine
    view = dashboard.Dashboard(engine)
    with engine.store.connection(read_only=True) as connection:
        evidence = engine.store.current_fact(connection, "computer").evidence[0]
    company.close("2026-02")
    month(engine, evidence, "2026-03", "consume-positive")
    company.close("2026-03")
    with engine.store.connection(read_only=True) as connection:
        member = dict(connection.execute(
            "SELECT m.*,c.outcome FROM asset_batch_member m JOIN calculation o "
            "ON o.id=m.owner_calculation_id JOIN calculation c ON c.id=m.member_calculation_id "
            "WHERE o.kind='asset_consumption_month' AND m.asset_id='chair'"
        ).fetchone())
    damage(engine, "calculation", "UPDATE calculation SET outcome=? WHERE id=?",
           ('{"values":{},' + member["outcome"][1:], member["member_calculation_id"]))

    def checked_failure():
        try:
            view.assets("2026-03", asset_id="chair", preparation="deferred")
        except KernelError as error:
            return {"failure_code": error.code}
        raise AssertionError("Latest selected amount lost full outcome check")

    pair, _ = measured_pair(engine, checked_failure)
    add_case({"sample": "synthetic", "route": "latest_member_duplicate_outcome_rejected", **pair})
    with view._snapshot("2026-03") as snap:
        # Identity-only reads legitimately prove just the directory. They must
        # not insert a complete member or content proof for unread raw bytes.
        snap.queries._selected_asset_member_heads(
            snap.connection, snap.period, asset_ids={"chair"}
        )
        require(member["owner_calculation_id"] not in snap.reads._asset_members,
                "Identity checker claimed complete member bodies")
        for _ in range(2):
            try:
                snap.reads.asset_members_many((member["owner_calculation_id"],))
            except KernelError:
                pass
            else:
                raise AssertionError("Corrupt selected full member accepted")
            require(member["owner_calculation_id"] not in snap.reads._asset_members,
                    "Failed full member batch cached")
    add_case({"sample": "synthetic", "route": "money_failure_not_cached", "both_paths_reject": True})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--group", choices=("native12", "native48", "fixtures", "money_failure"), required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--route", choices=("projects_section",))
    options = parser.parse_args()
    require(Path(sys.prefix).resolve() == (ROOT / ".tmp-kernel-venv").resolve(), "Use repository venv")
    require(not options.output.exists(), "Existing report must be retained")
    import snapshot_stage9_source

    manifest = json.loads((SOURCE / "source-manifest.json").read_text("utf-8"))
    require(manifest["sha256"] == SOURCE_SHA, "Wrong fixed source")
    require(snapshot_stage9_source._inventory(SOURCE) == manifest["files"], "Fixed source drift")
    report = {
        "status": "running", "prototype_only": True, "browser_acceptance": False,
        "source": str(SOURCE), "source_sha256": SOURCE_SHA, "group": options.group,
        "helper_source": CHECKER_SOURCE, "open_member_source": OPEN_MEMBERS_SOURCE,
        "card_sources_source": CARD_SOURCES_SOURCE, "cases": [], "errors": [],
        "boundaries": [
            "Only _Snapshot's unfiltered activation identity consumer is substituted.",
            "Complete member SQL and digest checks precede filtering and success cache publication.",
            "No membership/money/content success proof is manufactured.",
            "Open/unowned/fixed-v1 fall back; monetary/latest-event/CLI/MCP helpers are unchanged.",
            "Instrumented wall time is not net page speedup; concurrent main120 copy is allowed.",
        ],
    }
    with options.output.open("x+", encoding="utf-8") as output:
        def checkpoint():
            output.seek(0)
            json.dump(report, output, ensure_ascii=False, indent=2)
            output.write("\n")
            output.truncate()
            output.flush()

        def add_case(case):
            report["cases"].append(case)
            checkpoint()
            print(json.dumps({"case": case.get("route"), "sample": case.get("sample"),
                              "passed": case.get("full_response_equal")}), flush=True)

        checkpoint()
        try:
            if options.group == "money_failure":
                money_failure_case(add_case, options.output.with_suffix(".fixtures"))
            elif options.group == "fixtures":
                fixture_cases(add_case, options.output.with_suffix(".fixtures"))
            else:
                native_cases(int(options.group.removeprefix("native")), add_case, route=options.route)
            require(snapshot_stage9_source._inventory(SOURCE) == manifest["files"], "Source changed")
            report["status"] = "complete"
        except BaseException as error:
            report["status"] = "failed"
            report["errors"].append({"type": type(error).__name__, "message": str(error),
                                     "traceback": traceback.format_exc()})
            checkpoint()
            raise
        checkpoint()


if __name__ == "__main__":
    main()
