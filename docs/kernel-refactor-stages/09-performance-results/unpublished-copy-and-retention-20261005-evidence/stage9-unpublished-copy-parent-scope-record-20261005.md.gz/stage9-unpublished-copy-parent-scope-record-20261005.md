此文件记录 root 在本次归档任务消息中提供的边界，不是独立重跑、数据库复验或原始测试输出。

root 报告：初次 runtime-WAL 目标复制留下整库 WAL 和部分 main，耗尽 D 盘；该首次 copy 仅有已保留的进度 log，归档者未找到完整异常回执，不能补造 traceback。v2 实际公司 main 14359863296 bytes、WAL 0，但未完成业务核验。ce54 包第一次在构建前因四个测试 cache 被源 inventory 守卫拒绝，没有执行包自检；package-receipt 原件直接记录 failed、两次 extra 文件断言和 default_validation_invocations=0，未列四个 cache 的名称。

本次新 a5d4 17 模块统一组及新包正在执行；ce54 main120 迁移/内容核验也未完成。未完成输出不封存，本报告不提前宣称成功。
