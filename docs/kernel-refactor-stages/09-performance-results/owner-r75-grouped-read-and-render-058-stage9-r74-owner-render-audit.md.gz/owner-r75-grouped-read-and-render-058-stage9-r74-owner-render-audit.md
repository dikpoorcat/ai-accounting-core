# r74 同选择刷新挂载审计

审计及小诊断使用 GPT-6.1 Sol 中等推理。仅调整五个 Vue View 和既有 dashboard-context-v2 测试；没有修改后端、接口、生成合同、代理配置或用户约定，没有提交。遵守 FRONTEND.md；本任务明确暂缓完整构建和大回归。

## 原因与实际证据

Brief、Funds、Employees、Assets、Reports 的 refresh 都先调用 invalidateRequests 清空主数据，随后 loadData/loadFunds/loadPeriod/loadAssets/preview 再清空。主模板因空数据进入 spinner 分支，整个业务投影卸载。公司、期间、资金账户、员工/资产筛选及业务定位改变时的取消、清空和 generation 校验属于必要边界，应继续保留。

固定 r73 release 与当前已验证 main12 合成根的真实授权 HTTP 浏览器诊断证明五页旧概览节点在 loading 时全部断开，完成后全部为不同节点。基线 JSON：stage9-r74-owner-render-baseline-attempt3.json。每页仅刷新一次，不创建关账 preview；月度核对正常显示未准备，未伪造准备状态。全部 HTTP 200，无浏览器错误，会话撤销、server/app 关闭。

基线 responseEnd 至新可见 DOM 加 twoRAF 为 brief 52.8、funds 57.2、employees 49.1、assets 49.4、reports 40.3ms。这些是不同页面的一次诊断，包含调度、解析、渲染及观察开销，不能当成重建的独占耗时或可获得的收益。

## 集中改动

同选择 refresh 用 keepContent 保留主投影和 Funds 的旧 snapshotVersion，同时立即 loading；只有带 contextGate 的同公司同期间刷新读取允许保留。新上下文与新主响应都通过后才提交。普通读取与既有同步 scope watcher 继续清空。错误、无数据以及失效期间清空，旧金额不会重新显示。

业务内容使用独立 v-if 容器，loading 时 v-show 设置 display:none，spinner 独立显示；导航同时隐藏。Brief/Funds/Employees/Assets 的新包装默认 display:contents，保留原有布局间隔；Reports 利用已有 report-dashboard 容器。收到新响应后，Vue 同次更新先替换内容再恢复显示；员工、资产和资金在下一次 DOM 更新后保持原有业务定位/滚动行为。

CloseReviewPanel 继续消费新 prefetch：其旧内部结果被既有 watcher 清空，失败不重试，generation 隔离旧结果。BusinessStatusDetails 继续以公司、业务、期间、snapshotVersion 的同步选择 watcher 清空明细。没有改写两个共享组件，没有外部业务缓存，没有减少首屏集合、汇总或正文。

## 验证

现有 dashboard-context-v2、dashboard-render-v2、brief-close-review-prefetch 三组定向测试：28项通过。新增覆盖同选择保留、上下文与主响应双门控、错误清空、公司切换、晚到响应及上下文移除期间；既有预取失败/公司切换/过期预取测试通过。

current Vue 源码使用生成合同合成样例，真实 Edge/Vue DOM 定向诊断：stage9-r74-owner-render-fixtures-final.json。五页全部通过挂载、display:none、错误及公司切换检查，无浏览器错误。每次 refresh 主请求1个，Brief review预取1个。

| 页面 | 同选择刷新复用概览根 | 主内容原子节点保留 | loading 整容器 display |
| --- | --- | --- | --- |
| Brief | 是 | 120/122 | none |
| Funds | 是 | 117/117 | none |
| Employees | 是 | 31/31 | none |
| Assets | 是 | 66/66 | none |
| Reports | 是 | 50/50 | none |

Brief 的两个未保留节点来自新月度核对预取触发的内部结果/状态更新，属于必要失效处理。五页错误及公司切换时原概览节点均断开且不可见。

## 验证边界

当前证据证明减少整棵业务 DOM 的卸载重建，并证明旧内容不可见、不可被可见 DOM 计时条件使用。尚未建立毫秒级净收益或500ms达标结论；基线真实 release 与修复后小合同样例不同，不可直接相减。

没有执行完整 FE build、后端大回归、30次 browser acceptance，也没有形成新的 release 候选。后续应由主任务统一构建、冻结 source 并在真实同规模刷新链中验证。诊断失败文件均保留；早期 harness 的票据导航/原生安全控制器配置和临时 API 路由误截源码模块已纠正，不作为产品失败。所有诊断进程已结束。
