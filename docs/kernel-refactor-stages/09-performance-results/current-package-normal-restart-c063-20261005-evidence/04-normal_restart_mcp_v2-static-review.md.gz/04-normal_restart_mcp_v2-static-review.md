# c063 同根正常停服接续窄 runner：静态准备

未执行 MCP、数据库、服务或构建；AST 检查通过。v1 原件保留，SHA `697d9b950863608f51124ebbeb75da09d95f48743063413ceecf7551412dc706`。v2 SHA `2fdb99d7962605ded6278be18fb9a5842aa11d84a220a91fb801cf8d90146223`。

v2 的每次 `read_phase` 完整退出 stdio / ClientSession 上下文后记录对应 `mcp_stdio_contexts_closed_normally`。最终只说明两次 daemon `Popen.wait` 实际退出 0 和两次 MCP SDK 上下文正常关闭，不扩大为 Windows 整个子进程树、SDK Job 异常关闭或强杀证明。

每次 daemon 的 stdout / stderr 合并进入同 delivery 下独占 `normal-restart-mcp-v2-before_restart-daemon.log` 或 `normal-restart-mcp-v2-after_restart-daemon.log`；失败保留原诊断。原始私有 receipt/log 公开前须脱敏身份、本机路径、PID 和凭据，不直接复制到源码。

静态核对当前包源码：

- `package/app/ai_accounting/kernel/cli.py` 的 `daemon` 直接进入当前 `daemon.run`，`stop` 进入 `stop_service`；runner 不调用 `start_service`，不会通过自动启动路径停止旧服务。
- `package/app/ai_accounting/kernel/daemon.py:421` 的 `run` 获取该根 `instance_lock`，无法获取则返回；runner 只接受 metadata.pid 为自己 Popen.pid 且 build 精确相同的健康 host。
- 同文件 `:127` 的 `_metadata_for_root` 验证实际目录合同与身份；`:256` 的 `stop_service` 核对 metadata/health 后请求正常 shutdown。清理前再次检查 PID，拒绝停止非自身 host。
- `package/app/ai_accounting/kernel/security/service.py` 仅对已存在的合成 owner 做 login/logout；不重新 provision、修改凭据或宣称真人 GUI 验收。
- `package/app/ai_accounting/kernel/engine.py` 的 `request_result` 核对 request 与唯一 audit；runner 使用现存 close 请求，未找到则失败，不生成业务请求 ID。

实际执行由 root 在纯计时和按需验证之后串行安排：

```powershell
& '.tmp/stage9-development-delivery-summary-lifecycle-c063-20261005/package/runtime/python.exe' -I -B -X utf8 '.tmp/stage9-development-delivery-summary-lifecycle-c063-20261005/normal_restart_mcp_v2.py' --execute
```

receipt 为 `normal-restart-mcp-v2-receipt.json`；`hosts[].actual_exit_code` 来自真实 `Popen.wait`。root 另记录实际 UnifiedExec terminal exit/session/chunk，静态准备不生成此类回执。
