# c063 正常同根接续 v3：认证字段守卫修正

v2 实际 terminal exit1、10 MCP 读取及两 daemon 退出0原件保留，不改标签、不覆盖 receipt/log/helper。失败根因依据为 v2 final owner 整行摘要断言和当前包 `security/service.py:325` 的正常成功登录 UPDATE；v2 没保存 before 行，不能声称已证实该次仅改变 last_authenticated_at。

v3 SHA `fe7a664dfca8497aa6542066067c0335989b277116836f8a71aa391faf62cf2f`，仅静态 AST 检查通过。已对明确既有合成 `source-restored/data/catalog.sqlite` 做有限只读列核查：security_owner 一行，password_failures=0、password_blocked_until=NULL、last_authenticated_at 为 int；未输出登录名、密码或恢复资料。

新 owner_guard 保存所有列名与全部身份/凭据列摘要，只排除合法登录修改的 `password_failures`、`password_blocked_until`、`last_authenticated_at`。每次认证后及最终分别检查前两项0/NULL、时间为整数且不倒退，其他 id、login_name/login_key、status、password_hash、credential_version、recovery 状态、created_at、password_changed_at 等每列严格不变。before/phase/after 只留小认证状态与受保护摘要，不保存秘密值。全部公司 SQL/行、冻结/历史/audit/request 守卫原样保留。

同类静态排查：

- 三主 helper 的 owner_count 守卫是人数不变，不是整行摘要；不与认证时间更新冲突。
- 旧19 MCP桥仅在新合成root provision/login，没有宣称既有 owner 整行不变；其证明是业务身份、冻结与完整核验。
- normal v1/v2 是本次过严摘要位置，历史失败不改写；仅新 v3 修正。
- c063 resource-v1 绑定旧 service-v3 的 owner_stable，原定义明确只排除 last_authenticated_at，仍纳入 password_failures/password_blocked_until。已知当前认证状态0/NULL时正常成功登录不改变两项；若未来已有认证失败状态，则该守卫也可能误判。本次不改其冻结 helper/source，供 root 在资源验证前审查适用范围。

未执行 v3。拟 root 审阅后仅补一次相同10次读取：包 runtime `-I -B -X utf8 normal_restart_mcp_v3.py --execute`。新输出独占 `normal-restart-mcp-v3-receipt.json` 和两 phase daemon.log，保留 v2 actual failure。正常停服接续不证明 forced kill、inflight interruption、Windows 全子树或真人认证窗口。
