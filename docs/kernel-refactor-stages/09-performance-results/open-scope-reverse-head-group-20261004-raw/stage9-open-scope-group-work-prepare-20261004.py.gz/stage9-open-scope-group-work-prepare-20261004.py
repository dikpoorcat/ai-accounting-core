"""Seal a one-variable source pair and one actual-work diagnostic helper."""
import hashlib
import json
from pathlib import Path
import sys

W = Path(__file__).resolve().parents[1]
assert Path(sys.prefix).resolve() == W / '.tmp-kernel-venv'
sys.path.insert(0, str(W / 'scripts'))
from snapshot_stage9_source import snapshot_source, _inventory, _digest

candidate = W / '.tmp/stage9-build-source-open-scope-group-candidate-20261004'
before = W / '.tmp/stage9-build-source-open-scope-group-before-20261004'
manifest = snapshot_source(W, candidate, workspace=W)
before_manifest = snapshot_source(candidate, before, workspace=W)
old = W / '.tmp/stage9-journal-contribution-candidate-source-20261004/query_reads.py.before'
original = old.read_bytes()
name = 'src/ai_accounting/kernel/query_reads.py'
original_sha = hashlib.sha256(original).hexdigest()
assert original_sha == '72999dd7080c526a038a2efce017b653e0dd06e16871f8dc4b20d3d1b3e2a9da'
checkpoint = json.loads((W / '.tmp/stage9-input-and-verified-totals-regression-20261004.json').read_text(encoding='utf-8'))
assert checkpoint['files_unchanged'] and checkpoint['files_before'][name] == original_sha
(before / name).write_bytes(original)
before_files = _inventory(before)
changed = [key for key in before_files if before_files[key] != manifest['files'][key]]
assert changed == [name], changed
before_manifest.update(source='explicit retained pre-group source bytes',
    files=before_files, sha256=_digest(before_files),
    reconstruction={'exact_candidate_snapshot': str(candidate), 'only_replaced_file': name,
                    'original_bytes': str(old), 'original_sha256': original_sha,
                    'checkpoint': 'successful 316 affected regression pre-group source'})
(before / 'source-manifest.json').write_text(json.dumps(before_manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
assert _inventory(W) == manifest['files']
helper = W / '.tmp/stage9-open-scope-group-work-20261004.py'
assert not helper.exists()
text = (W / '.tmp/stage9-journal-contribution-work-20261004.py').read_text(encoding='utf-8')
text = text.replace("output.name.startswith('stage9-journal-contribution-work-')", "output.name.startswith('stage9-open-scope-group-work-')")
text = text.replace('    def response_hash(result):', '    def response_hash(result, *, business=False):')
text = text.replace("        return hashlib.sha256(canonical(result).encode()).hexdigest()", "        if business and isinstance(result.get('read_context'), dict):\n            result['read_context'] = dict(result['read_context'])\n            if 'read_version' in result['read_context']:\n                result['read_context']['read_version'] = '<source-bound deferred read token>'\n        return hashlib.sha256(canonical(result).encode()).hexdigest()")
text = text.replace("'operations_per_page': 1, 'warmup_operations': 0, 'observations': [],", "'operations_per_page': 1, 'warmup_operations': 0, 'observations': [],\n        'business_comparison_normalization': ['top-level generated_at/checked_at clocks', 'data.generated_at clock', 'exact top-level read_context.read_version source-bound token'],\n        'all_other_versions_ids_cursors_amounts_and_states_preserved': True,")
text = text.replace("'complete_response_sha256': response_hash(response)}", "'complete_response_sha256': response_hash(response),\n                                           'business_response_sha256': response_hash(response, business=True),\n                                           'actual_read_context': response.get('read_context')}")
helper.write_text(text, encoding='utf-8')
print(json.dumps({'candidate':manifest['sha256'], 'before':before_manifest['sha256'],
                  'changed':changed, 'files':manifest['file_count'], 'helper':str(helper)}, ensure_ascii=False))
