# Stage 9 owned open-scope reverse head relation group

2026-10-04. Scope: query_reads.py plus a new directed test file. No database,
service, frontend, schema, v1 source or release changes. No timing claim.

## Audit before implementation

The current owned open scope SELECT already returns p.*, calculation_current,
calculation/fact identity, physical voucher_current/version and version subject.
Its terminal NOT EXISTS predicate proves no successor. Source checks authenticate
current calculation and fact identities; forward checks authenticate publication
record digests and version/calculation/voucher/period relationships. Nevertheless
the normal reverse checker rereads calculation_current and p.* + has_successor
for those exact same calculation IDs. These are actual duplicate reads.

Version subject must explicitly equal publication subject before reusing a normal
pair. Review retains a different original owner and must use the full reverse
checker. Correction reversals have independent identities and retain their ID
header read and full reverse checker. Zero/cleared results still inspect their
saved outcome; withdrawal still authenticates its own record. The opposite
missing-source query remains independent and precedes the owned batch.

Dashboard five owner pages, context/main and detail consumers share owned
QueryReads snapshots only where their current call reaches Journal._sql or
Reports.report. Journal.account_amounts consumes returned publication mappings;
report_projection's open selected headers also call the reverse checker.
BusinessQueries performs direct forward checks and retains its existing route.
CLI/MCP benefit only through these actual owned query entry points.
Integrity._check_sources uses explicit subject_ids, hence no owned scope carrier;
close/full verification, maintenance repair, backup schema verification and
restore use independent connections. Historical content v1 bypasses current open
scope and keeps independent fixed readers. No new authority is introduced there.

Cached consumers require the independent reverse publication mapping shape:
publication CONTENT_FIELDS plus id and has_successor. Scope-only current/fact/
version columns must not leak into those mappings. A normalized dict with
has_successor=0 preserves the existing contract, grounded in actual terminal SQL.

Read .tmp/stage9-header-scope-review.md and the open-contribution authority audit.
Their distinction between record, relationship, outcome and adoption proofs
applies here. The just-withdrawn contribution candidate is not resumed; no saved
input/content/adoption cache is changed. No assumption is made about the prior
79 ms or any speed gain. Only real work counters will be compared by root once
this source is fixed.

Implementation plan: stage exact normal version/pair receipts privately after
all normal checks, run review/reversal complete reverse batch, then publish
normal receipts. Failed normal or independent checks leave new normal receipts
unpublished; existing successful receipts remain. Publication record rollback
stays bounded to this forward input, while the independent reverse checker
already publishes its own records and relations only after its entire loop.

## Implementation saved

Normal staging now requires the same private carrier and snapshot again,
explicitly compares version subject/current calculation/physical version/
voucher/period/nonreversal, checks authenticated record identity, and rejects
cached signature disagreement before any independent reverse check. Only after
the independent review/reversal group succeeds are new normal receipts committed.
Normal receipts preserve the independent mapping fields exactly. Earlier
successful receipts remain available on failure. No result/input/adoption proof
is inferred or written. Source is fixed and root has been notified that its one
work comparison can now run. No standalone probe or timing was run here.

Directed test group is running once: new relation tests, existing physical-head
tests, open-publication snapshot work tests and v1 voucher-head tests. Ruff passed
for the two modified code files.

## Directed validation completed

The single group completed: 91 passed in 67.51 s. This is test duration, not a
performance claim. The new small normal fixture proves exact returned mapping
equality to the independent path, no duplicate calculation_current/p.* reverse
SQL, preserved opposite missing-source SQL, and fewer actual returned rows,
returned value bytes and VM steps. No result-body reads were introduced.

Legal review/replacement/clear/withdraw and correction reversal cases match the
independent mapping; review/reversal still issue the original reverse SQL. Real
current/publication/subject faults reject twice without new scope/relation/record
proof. A deliberately failing independent reverse stage leaves normal receipts
unpublished while preserving an earlier successful January scope/record/pair;
removing the fault permits a fresh complete result. Existing signature conflict
is rejected before the independent checker can publish. Existing physical/head,
snapshot/token/frozen and fixed-v1 tests also passed. No standalone measurement,
browser, full regression, package, service or real data operation ran here.
