# 第 9 阶段开放范围普通凭证反向头复用独立审查

审查日期：2026-10-04。范围：只读核对已固定的 `query_reads.py`、新 `test_open_scope_relation_proof_reuse.py`、直接消费者及既有测试源码；只写本审查记录。不执行测试、基准，不访问真实数据库或服务。实施组报告 91 项定向测试及 Ruff 通过，本审查没有独立运行或复验该报告。

## 最终独立静态审查结论

无阻断发现。已固定实现的 `_stage_open_scope_normal_relations` 只从 owned whole-prefix / exact-posting-month 开放范围实际行载体生成普通非 `review_no_impact`、非冲正、owner=head 同 calculation ID 的待登记 version signature 与单元素 publication pair。现有 SQL 与完整 source/forward/correction 检查提供省去第二次 `calculation_current` 及 `p.*` 查询的必要依据。

实现满足初审的三个必要条件：receipt 为 `id + CONTENT_FIELDS + has_successor=0`，保留公开返回字段形状；所有普通 pending 在独立 review/reversal 整批成功后才登记；已有 signature 冲突在独立反向读取前失败。外部公开接口没有新增成功布尔值或载体参数；helper 唯一生产调用仍位于现有私有 scope-head 分支，载体唯一生产构造点位于实际 source SQL、逐行 source 核验及 opposite orphan guard 成功后。

最终源码核对没有发现失败后额外 record proof 漏出：独立 `_verify_current_voucher_publication_rows` 的 digest 结果先保存在局部集合，所有当前关系及 digest 成功后才更新记录和关系缓存。普通 signature、receipt 组装均在该独立调用前完成；独立调用返回后仅有 ordinary pending 的 dict update，随后 scope 成功登记，没有新增可失败的业务检查。之前成功记录不在 `pending_records` 中，之前成功关系不被撤销或覆盖。

## 现有前提及对应原检查

| 原反向检查 | actual scope 已有依据 | 必须保留的边界 |
| --- | --- | --- |
| 原始及当前发布存在 | `p.*` 实际返回；`calculation_exists`、`fact_exists` 非空 | 未命中发布不能靠候选缺失视作成功；反向 orphan SQL 必须保留 |
| `heads[subject] == original calculation` | `calculation_current a ON a.subject_id=p.subject_id`，逐行要求 `current_id == calculation_id` | 只适用于普通 owner=head 同 ID；review 仍须完整原始及当前发布查询 |
| publication subject 与物理版本 subject 相同 | 发布 `subject_id == calculation_subject`；版本 `version_calculation == expected_calculations[id]`，非 review 时后者为发布 calculation；`vc` 与 `c` 指向同一实际 calculation | 不能仅依靠 voucher_id 相同；保留 source/fact subject、kind、period 校验 |
| posting month 与版本 month 相同 | forward 要求 `version_period == posting_period` | 用库内整数 ordinal，不能依据用户月份标签推导 |
| current head 无 successor | source SQL 的 `NOT EXISTS(later.previous_publication_id=p.id)` | 生成 receipt 的 `has_successor=0` 只能来自该 actual SQL 谓词 |
| 原始/current voucher_id 相同 | forward 比较实际发布与所选头，要求 `version_voucher == voucher_id` | 冲正独立验证有不同 voucher 关系；不能扩展普通 proof 到 reversal |
| 发布 digest 成功 | owned forward batch 的 `reads.verify_publication_records(publications)` | digest 是整组关系成功前的暂存；失败仅撤销本组新记录证明，保留之前独立成功 |
| version 确实存在且 current | scope `voucher_current h` 与 `voucher_version v` 实际 LEFT JOIN，forward 要求 `version_exists` 且版本归属/期间/计算一致 | 删除版本、缺 current、错误版本或错误 calculation 均不得缓存成功 |
| 开放区间 | `p.posting_period > max(period_close)` 且 `<= through_period`；可另加 exact posting month | 不能给 closed/frozen adoption 发成功证明 |

来源选择失败时不发布缓存。`withdrawn` 独立核 digest 且要求 calculation、voucher、current 全空，不进入普通头证明；保留编号但清零的发布会读完整 outcome 证明 `lines=[]`，没有 version 则不登记普通 current-version proof。独立 correction head 检查必须继续运行：不存在的 reversal 不能从不存在本身推导为合法。

## 缓存形状、签名与整组提交

`_verified_current_voucher_publications[version_id]` 现有合同是 `(signature, {calculation_id: publication_row})`；signature 为 `(id, voucher_id, calculation_id, reverses_id, period, subject_id)`。普通 owner=head 的 pair 恰含一个 calculation；review/reversal 继续由原读取生成实际 pair。

原独立读取返回的 publication 字段为 `id`、`publication.CONTENT_FIELDS` 加 `has_successor`。scope SQL 的原 `sqlite3.Row` 还含 current/source/fact/version 辅助列，不能直接原样写进 receipt。应只复制正式 publication 字段并附 SQL 末端谓词证明的 `has_successor=0`。dict 可满足现有 `row[key]` 与 `dict(row)` 消费方式，但不得删字段、漏 `has_successor` 或增加 scope 辅助字段。既有 `test_open_scope_physical_heads` 明确比较独立路径 receipts，`test_open_publication_snapshot_work` 明确比较公开返回并要求 `has_successor`。

实施后的 helper 先逐个将普通 signature 与已有该 version 的 signature 比较；不同则报完整性错误，不以新 forward 成功覆盖。所有普通 pending proof 的核验和 receipt 组装先完成，再运行独立 review/reversal 批次，最后提交普通 pending；独立批次也保持自身整组成功后才提交。这样既不留下失败组的普通成功，也不会在独立组已登记后才发生普通 signature mismatch。实现没有复制整个缓存用于回滚；record checkpoint 仍限于本组新 ID，既往独立成功保留。

## 快照、版本及 selector 边界

`_OpenVoucherScopeHeads.require` 现已约束 QueryReads/connection/token 身份、active owned current selector、实际 `sqlite3.Row`、数量及逐行对象身份。`_owns_current_selector_snapshot` 同时检查当前 active owner、read transaction、非 registry content v1，以及 current `publication` 和 `close_storage` reader。`QueryReads.snapshot` 私有只读事务的 authorizer 拒绝 transaction/savepoint 改动；退出 `_reset` 换 token 并清缓存。既有 `test_t7_snapshot_reuse` 检查 COMMIT/ROLLBACK/BEGIN/SAVEPOINT 拒绝。

`verify_open_voucher_scope(subject_ids=...)` 现明确不属于 owned carrier 路径；不能因处于 QueryReads snapshot 就给 subject 子集发 whole-scope proof。固定 v1 publication reader早退 current open-source boundary，普通/unowned forward API 也没有 `scope_heads` 参数；保持独立查询。

`_selected_current_voucher_publications` 的 no-close-reference probe 与 actual current predicate证明是另一层权限。open receipt不证明 frozen adoption，也不能替代 `verify_selected_voucher_adoptions`、frozen manifest、close reference 和 source outcome/lines 核验。`selected_voucher_sql` 仍保留被冻结引用的版本及 current/frozen选择规则；其正常与异常 frozen路径不可从 ordinary open关系缓存推导。

## 实际调用图及同类排查

1. `dashboard_reads._Journal._sql` 先执行 `reads.verify_open_voucher_scope`，再做 exact month 的 close/reference absence probe 和 selector。`account_amounts` 在实际 selector rows 后调用 `verify_selected_voucher_adoptions`，然后尝试 `_selected_current_voucher_publications`；filtered consumer 调公开 ID API。两条路径均可自然使用已经完整成功的同 version cache，无需另给 selector publication 正文载体。
2. `report_projection._authoritative_rows(scope='open')` 先执行 open scope，再实际探测 frozen references 并选择 rows；无 frozen references且owned时调用 `_selected_current_voucher_publications`，其余调用公开 ID API。该实际 open callgraph支撑此次复用；closed scope有独立 frozen规则，不纳入。
3. `reports` open读取先调用 `reads.verify_open_voucher_scope(end.ordinal)`；外部普通连接创建的 QueryReads 没有 owned snapshot，仍走原独立逻辑。`integrity` 使用显式 `subject_ids` 的 current-subject审查，也仍走独立路径。
4. `_selected_current_voucher_publications` 与公开 ID API 中剩余的计算头/publication读取不能仅据代码类似删除：selector proof本身只证明当前物理头和无 frozen references，不保证已经跑过完整 owned open scope；公开 ID API也服务 standalone、missing ID、closed/noncurrent、review/reversal。此次优化应仅改变 scope actualrows到普通 reverse proof的交接。

既有测试源码覆盖：physical/source损坏不留证明、review与correction reversal独立来源、withdrawn/future、missing publication重复失败、固定/unowned、cache部分命中、完整返回字段、早先success保留、signature冲突、snapshot退出和savepoint拒绝。新测试源码比较 owned/独立完整 receipts，并检查 normal scope 不重读 `calculation_current/p.*`、保留 opposite orphan查询、合法复核/替换/清零/撤去及 correction三种情形、当前头/发布/subject损坏重复失败、普通与失败review混合时此前success保留并在解除故障后成功、已有 signature conflict先于独立检查。subject subset仍由现有 `owned = subject_ids is None ...` 分流，固定 v1/non-owned边界未改变；新增 helper不接受公开selector行或 caller flag。

## 性能界限

可以从调用图确认消除了普通 owner=head 的重复物理读取候选。不能由此声明实际请求达到 500 ms，不能继承旧工作量/延迟数值，也不能把减少 Python调用次数当作实际 SQL/rows/bytes/VM改进。
