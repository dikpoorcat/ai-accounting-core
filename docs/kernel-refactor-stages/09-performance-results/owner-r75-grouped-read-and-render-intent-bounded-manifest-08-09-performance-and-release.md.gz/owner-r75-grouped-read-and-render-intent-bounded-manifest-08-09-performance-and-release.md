# 第 9 阶段：性能收口与首个正式版交付

## 当前状态

实施中，基线 `835fe4a`。2026-09-30 的中途提交未推送，不代表阶段验收。老板五页精简已经接通，当前集中处理同一快照内的重复读取。r71 已补齐普通读取、完整核验和维修的冲正缺失护栏；其主48月原生诊断仍有报表超500ms，不代表整页通过。r72受影响组为283通过、4失败，原件保留；r73修复批次边界后，17文件289项全部通过，执行源码前后一致。主48月原生六项读取成功，但还没有本候选的整页500ms结论；主12、主48与独立12当前注册完整核验四coverage verified、limitations=[]，真实开放月预览完成。主12真实浏览器五页150次成功响应中简报5／30次≥500ms，其他四页0，性能失败；主48纯浏览器已完成150success／79超线，简报30、资金4、员工0、资产17、报表28，性能失败。升级历史六文件50项已通过，仅隔离合同回归、不是最终包。正式合同冻结、最终运行包和实际 AI／MCP 验收仍未完成。

仓库目录／公司合同为 `ai-accounting-kernel/2`、`draft / 0`，备份格式 2；关账私有存储 3，查重与分类私有格式 2，公开关账内容 4。公司 SQL 指纹为 `c9f9f7051bca67f1241ee5c89676fb9476bc819dc8f92c1a0c0bd1e940f459cb`，目录为 `b484d315272bb64de3856b458f04d2d4881da05db7552250864260916c69a4ee`。正式 `company/v1.json`、`catalog/v1.json`、`content-v1.json` 三文件尚不存在；各轮 released/1 只属于隔离合成源码候选。

| 当前证据 | 实际结果与限制 |
| --- | --- |
| r63 主 12 月 | 注册完整核验及开放月预览通过；五页各 30 次纯浏览器刷新全部成功且小于 500ms。只覆盖该固定候选与主 12 月样本。 |
| r63 主 48 月／独立 12 月 | 两种样本完整核验通过；主 48 月 150 次刷新全部成功，但 **92／150 次 ≥500ms，性能失败**。独立 12 月未取得纯浏览器验收。 |
| r66 固定组 | **320 passed，655.63 秒**，源码前后清单一致；主 48 月 native 简报、员工、报表仍超过 500ms。本候选注册完整核验 not_run，无新浏览器验收。 |
| r67 固定组 | **132 passed／2 failed，171.58 秒**；错误分类修正后最小四项通过。后续主体缺失组 **37 passed／2 failed**，窄修后仅四个分类用例通过，不改写原组结果。 |
| r67 主 48 月诊断 | 员工／资产定位扫描退化到约五秒；报表分类头聚合 VM 增加且没有收益，已撤回。native、插桩和 profile 均不作整页验收。 |
| r68 固定候选 | 三组收敛后固定，主 48 月 native 简报、资金、员工及报表仍超时；银行角色定位返回仅 96 行，却执行约 13.88M VM。原件保留，不作整页验收。 |
| r69 固定候选 | 源码清单 `600fc82ccf6437c28c81c03ff56d04ddb0abaf07446782535ffb0dc29baa8af8`。主 48 月 native：简报 532–603ms，资金 226–232ms，员工 542–593ms，资产 340–363ms，报表 479–513ms。**仍未达标**，员工减少扫描后未取得延迟收益。未跑本候选注册完整核验或浏览器验收。 |
| r69 页缓存对照／r70 实施 | 同源正反对照证实 64 MiB 的 SQLite 页预算导致必要页重复驱逐。256 MiB 时六项原生读取最大约 405ms，业务输出相同；已改为每连接 256 MiB、全局最多四连接，并验证预算异常拒绝。**这仍不是浏览器达标**。员工候选范围修正及统一测量见下一行。 |
| r70 固定候选 | 主12、主48及独立12月当前注册完整核验四项 verified、limitations=[]，真实当前开放月预览通过。主48五页150次纯浏览器刷新完成，**37／150次≥500ms，性能失败**；资金与员工本轮无超线，简报／资产／报表仍有超线。原生改善和完整结果分别见[r70固定诊断](09-performance-results/owner-required-groups-r70.md)、[内容与边界](09-performance-results/owner-r70-content-and-boundaries.md)、[主48浏览器失败组](09-performance-results/owner-main48-browser-r70.md)。 |
| r71 缺失护栏与固定诊断 | 完整源55项通过；普通读取205项首轮200通过、5个错误原因断言失败，分类修正后79项通过，均保存原回执。主48原生报表432–529ms；没有本候选注册完整核验或整页验收。 |
| r72 重复读取组 | **283通过、4失败，442.29秒**，执行源码清单前后一致。失败及根因按[发布证明重用](09-performance-results/owner-publication-proof-reuse-r72.md)与[资产同类读取](09-performance-results/owner-asset-repeated-reads-r72.md)记录；不能把其中通过项写成整组通过。 |
| r73 集中修复与诊断 | **289项全部通过，431.82秒**，源码清单`6a9086e066bd09df5834781fe49da6d4fb7e3333ba6b5569241193a33925f75a`前后一致。主48月原生：简报414–456ms、资金278–284ms、员工211–214ms、资产378–418ms、报表422–446ms；上下文10–14ms。固定候选SHA`420ceb395fc5aec17ddaedf8914c7fc8de640da9f08cb35aded8a3a99a4eb7f4`，主12／主48／独立12当前注册完整核验与真实开放月预览通过；主12浏览器简报5／30超线、其他四页0，整体性能失败，主48纯浏览器150success中79超线，性能失败；升级历史六文件50通过，仅隔离合同组，未取得新整页验收。原件见[r73清单](09-performance-results/owner-open-publication-related-r73-manifest.json)。 主48失败及HTTP／历史准备集中见[请求与准备记录](09-performance-results/owner-http-request-and-readiness-r73.md)。当前内容及浏览器原件见[新清单](09-performance-results/owner-r73-main48-content-main12-browser-manifest.json)。 |

当前依据分别见 [r63 主 12 月清单](09-performance-results/owner-candidate-pure-r63-manifest.json)、[r63 主 48 月与独立 12 月清单](09-performance-results/owner-main48-independent12-r63-manifest.json)、[r66 集中记录](09-performance-results/owner-required-groups-r66.md)、[r67 同类问题记录](09-performance-results/owner-required-groups-r67.md)、[r69 固定诊断](09-performance-results/owner-required-groups-r69.md)、[物理页预算正反对照](09-performance-results/owner-sqlite-page-budget-r70.md)、[r70 成组修正与固定诊断](09-performance-results/owner-required-groups-r70.md)。逐轮日志、失败、慢样本和源码摘要留在专属结果及 manifest，不在主文档重复维护。

本阶段只操作明确的新建合成公司、临时根及隔离候选，不修改真实公司、负责人身份、资料、原件、现有库、备份或服务。业务规则、信任链、整月批准和逐月关账不放宽。**审查第 24 项保留负面实验结果，不重试已回退方案**；定期备份、跨公司配对和真实换库延后。

## 验收口径

主样本为单公司 50 人、每月 1,000 笔业务，分别覆盖 12、48、120 个月；另保留独立业务与累计依赖分布，以及 200 人、每月 5,000 笔压力样本。工资累计、普通收付、跨月清偿、备用金、资产、税务、修订、闭期更正、正常资料处置和明确报表依据均须保留。管理事实、资料事实、修订和自动派生结果另计，不充当业务笔数。

样本须有开放月、冻结月及有效关账预览。构造完成、raw-copy、逐表日志或结构元数据更新均不等于内容 verified；浏览器计时前由独立进程运行注册完整核验，覆盖 sources、historical_adoption、projections、read_indexes，记录实际限制。生产业务门禁不能使用生成器的延后核验选项。

| 度量 | 固定口径 |
| --- | --- |
| 五页热态 | 本机正式前端构建及隔离常驻服务；每页预热后记录 30 次，从点击刷新到上下文、主数字、默认 **20 条**明细及全部可见附属内容渲染完成。全部成功样本须 **<500ms**，保存中位、p95、最大及逐次样本。 |
| 默认业务范围 | 保留全量汇总、老板待办与有效同版月度核对摘要。完整准备、来源证明及技术诊断不进入老板默认读取；AI 会计核心入口、关账和完整核验保留对应职责。 |
| 单列范围 | 冷启动、首次打开、切公司、业务详情、事件及文件任务分别记录；未测或 unavailable 不显示通过。 |
| 隔离与失败 | 纯计时不与建库、回归、完整核验或插桩并行；HTTP／dispatch 插桩须显式启用并标诊断。错误响应不算完成，慢样本和首次失败不删除。 |
| 身份与环境 | 保存固定源码清单、构造／核验来源、合同、静态产物及摘要。当前环境为 Windows、Ryzen 7 3700X、Node 24.19.0、仓库 Python 3.12.13／SQLite 3.53.1；最终报告以实际环境为准。 |
| 工作量 | 分别记录 SQL、SQLite VM、返回行和值字节、事实／结果解码、采用证明及内存。返回字节不等于磁盘读取，Python 分配峰值不等于 RSS，服务树峰值必须同时间采样。 |

小样本、原生调用、并行诊断与局部最快结果仅用于定位。旧默认 100 条及完整准备的报告保留原口径，不能冒充新看板验收。浏览器默认只用 `src/ai_accounting/static/dashboard` 正式构建，缺失即失败；`frontend/dist` 只供显式诊断。

一次问题发现触发一次同类排查；一组相关修改收敛后固定源码成组验证。部分复跑不改写首轮整组，重叠套件不相加；没有新改动、失败或风险的已验证组不机械重跑。

## 按问题类型的成组修改与证据

### 1．老板输出退出，业务汇总和定位保留

现有经营简报、资金、员工、资产、财务报表五页共用公司与期间上下文。技术证明、凭证、来源、JSON、准备对象及其专用请求退出老板页；完整准备与核心 CLI／MCP 读取保留。旧完整准备专用三进程、分派、快照属性和无消费者参数已退出，完整准备仍执行单快照业务检查。

全量汇总与 20 条分页分开，业务直跳使用精确对象定位，不拉全页找对象。资金、投资、工资清偿、资产付款／处置／终止均绑定明确业务；整批付款不伪造成单卡分摊。当前金额和关账时金额分别表达，未知金额不补零。员工全量清偿状态传播保留未加载第 21 人的影响。

共享响应由后端模型生成 schema、TypedDict、TS 和 Ajv；保留 URL 公司／月份／业务／筛选／快照关联、切公司取消与过期响应拒绝。金额仍是整数分，前端用 BigInt；不猜金额字段，不以断言替代校验。月度核对与原生批准绑定同一 `preview_digest`，已关账结论不被后续内容回写。

老板受影响组 r45 为 373 通过；前端 135 项、40 份后端真实合成响应、生成检查、类型检查及正式构建通过。之后退出专用进程的首轮为 73 通过／1 fixture 失败，最小复验 34 通过；这些均非最终包验收，不累加为当前固定全组。

[r63 布局记录](09-performance-results/owner-mobile-r63.md)覆盖四宽度 52 个几何状态，375px 的 12 张截图逐张查看；320px 未逐张人工审阅。最终包布局、展开详情和完整移动端验收仍按实际范围收口。

### 2．查询输入精确，实际仍扫描历史全集

期间、路径、分类和对象来源先从既有索引精确定位，再核真实候选与必要正文；不新增猜测阈值，不因候选为空而省略权威范围核验。早期稀疏半连接 VM 1.319M→1.565M 的负面结果保留；后续精确索引查询才减少扫描，密集集合 VM 略增亦保留。

简报活动分类和投资事件曾按 kind 扫描再匹配精确计算 ID，改为 ID 驱动定位后过滤类型。主 12 月同一 404 个来源 ID，VM 94,413,000→103,000；主样本投资为空，新查询增加约 24k VM，不能概括为全部范围收益。有关工资、资产及无关历史增长的实际范围见 [r64 排查](09-performance-results/owner-history-growth-audit-r64.md)和[实现记录](09-performance-results/owner-history-growth-implementation-r64.md)。

r67 员工名单将证明职责分为每人精确采用见证、本月与开放段完整工资、独立清偿汇总及显式历史；无冻结基线和固定 v1 保持完整路径。但主 48 月实际员工 4,946.68–5,154.36ms、51,375,900 VM，资产 4,163.14–4,757.51ms、36,766,300 VM，定位扫描已退化。

当前员工／资产改由精确来源驱动公共头定位，保留成员拥有者、撤去和缺源语义；报表改为精确寻址实际开放月物理凭证。r68 新增银行角色定位返回仅 96 行却执行 13,884,500 VM，是此前同类排查漏掉实际索引驱动。r69 核对对应消费者后，银行改为按事实主键定位，同行同参数 VM 降至 5,200；员工去掉同计算、同入账期的重复正常／冻结候选，正确月份参数下 VM 1,889,700→1,370,800，但统一 native 仍慢。继续查员工实际候选、排序及汇总读取，不能把减少扫描写为性能完成。

| 后续处理组 | 已取得的局部证据 |
| --- | --- |
| 员工／资产 | 原 50 项组为 48 passed／2 新 fixture 错误分类断言失败；只补跑 3 项，3 passed、10.83 秒。统一预热后增加无关噪声，candidate VM 1,000→1,000，exact refs VM 200→200；这是工作量证据，不是主 48 月页面计时。 |
| 银行 | 身份见证组 48 passed；终端守卫后续组 3 passed／1 fixture UNIQUE 失败，修后只补跑 2 项，2 passed、13.81 秒。范围及边界见 [银行身份见证](09-performance-results/owner-bank-identity-witness-scope.md)。 |
| 报表 | 先有 23 passed；后续组 83 passed／2 fixture 失败，修后只补跑 5 项通过。物理凭证定位 VM 443,200→1,700，分类头聚合已撤回，完整头读取保留 187,600 VM。 |

这些回执不改称原 50／52／85 项整组全过，也不累加。r69 新组三类回执分开保留：银行 11 通过／1 fixture 失败、增长 fixture 修正后单例通过；员工 40 通过；报表初轮 17 通过／1 fixture 失败，修后 20、关联窄组 23、最终别名组 15 各自通过。员工旧手算月份 24239 的 probe 撤回“同参数”资格，仅 typed 24227 的证据有效。原件与限制见 [r69 固定诊断](09-performance-results/owner-required-groups-r69.md)，r68 原失败见 [r68 固定诊断](09-performance-results/owner-required-groups-r68.md)。

历史范围与定位证据另见 [r25 精确来源](09-performance-results/grouped-reference-seeks-r25.md)、[r24 读取增长](09-performance-results/grouped-read-growth-r24.md)、[r62 身份读取](09-performance-results/owner-identity-only-read-audit-r62.md)、[r63 身份规则](09-performance-results/owner-identity-read-r63.md)。

### 3．输出只需身份或汇总，却读取完整历史状态

默认页面只消费必要经营内容。简报分出本月经营金额读取，不再为已退出输出调用完整 position；完整资产负债、恒等式和往来重分类仍由实际消费它们的报表及核心入口核验。简报 complete 只代表返回金额范围，不代替待收待付未知状态。

r71展示读取按必要金额与卡片字段职责收敛：简报完整账户证明后仅返回八金额，普通资金页及核心银行门禁保留；资产全量金额／枚举／筛选保留，展示metadata移到分页后。银行84包含新增9，资产旧103、完整源55、普通页205原200通过／5分类失败及修复后79分别保留原代码与回执范围、不相加。后续真实合成probe证实完整源／维修前置和普通页在冲正pointer＋version＋直属lines同时缺失时漏检；current／固定v1完整源与普通读取各自护栏已在上述相关组及r73统一289项实际验证，原失败不覆盖，不再记维修前置仍待核对。当前r73主12／主48／独立12完整内容核验及真实预览完成；主12实际browser5／150超线性能失败，主48browser150success／79超线性能失败；六文件升级历史50通过为隔离合同回归，非最终包。原生诊断与内容通过均不等于browser500ms通过。详见[展示读取r71](09-performance-results/owner-display-read-scope-r71.md)、[发布复用当前记录](09-performance-results/owner-publication-proof-reuse-r72.md)及[当前内容与升级历史清单](09-performance-results/owner-r73-content-upgrade-history-manifest.json)。

工资和银行身份与结果正文分别处理：身份必须有真实精确来源、独立摘要和冻结采用绑定；不把 identity proof 升级为完整 fact／outcome proof。清偿义务本身、状态传播及当前 JSON 核验不能因历史装载成本而退出。

r66 严格头部、metadata、publication、seal 与 current 对应在消费内核验一次；raw outcome 状态与正文一次读取，身份消费者不加载未用状态。r67 银行完整选择携带已严格解码的精确结果，仍与独立冻结摘要及来源身份比较；146 项关联窄组通过，但没有测时间净收益。当前默认银行身份正见证及终端守卫已有局部回执，尚待固定候选统一验证，不能推定所有历史身份已被排除。

实际消费与 profile 见 [r66 集中记录](09-performance-results/owner-required-groups-r66.md)、[r67 必要读取](09-performance-results/owner-required-groups-r67.md)、[r63 常驻工作量](09-performance-results/owner-resident-work-r63.md)。

### 4．已核原文再次读取、解码或重复证明

复用只限同一拥有的只读事务、连接、规则和精确成功 ID。失败整批不发布半批成功；非托管／写事务、新请求、跨进程、跨快照、独立完整核验、关账、修复及固定 v1 保持其对应路径。**不采用跨请求业务缓存，不关闭或调整垃圾回收。**

r72 沿五页和公共读取发现同一开放范围被重复核验、同一当前凭证的原发布／复核发布被反复查询，以及资产完整拥有者目录被重复枚举。当前修复只复用同一快照内成功的精确关系和完整范围，不扩大为正文或冻结采用证明；资产仍核完整成员目录，不因默认20条而省略必要范围。原287项回归发现批次摘要提前发布：r73失败时仅撤回本批新摘要记录，保留此前独立成功；物理凭证反向检查同时核对实际主体和入账月，避免损坏发布移出查询月份后漏到下游才拒绝。相关289项全部通过，主48月资金返回行18674→13626、资产20512→15312，正文读取多数不变，员工多1行和8字节、报表SQL多3次的限制均记录。未测成本的期间缓存全集扫描与两处关账缓存合并仍是候选，不写成已排除；实际调用范围及源码在集中记录维护。固定r73首次公共开放批次内部物理头重复读取已证实；r74修复对应57项及独立新增负例1项通过各自范围，私有单模块ABBA真实少2009行／约463KB／39kVM，但month约8.4ms、through约1.1ms且波动，未证明稳定整页收益；同owned快照后续仅brief2／assets4小重叠，不是大根因。HTTP同进程配对差额约39.64ms，另约190ms浏览器差额未归因，RSS仅线索。五页刷新DOM卸载重建已确认；前端恢复修正后153项与release build通过，原148／2失败及40／28局部范围保留不相加，r74 DOM final只属恢复前源码，最终优化收益未验证。旧preview观察器自己持有13,911记录，bounded观察未复现全面变慢；RSS／tracked含尚未回收的QueryReads与typed对象，不能证明缓存导致时延。专用活动intent相关39项通过，早期4不叠加；完整preview／冻结合同及最终manifest事务复验保留，净持有与页面收益未验。新r75 snapshot尚未创建，等待统一候选和纯浏览器。原件与具体必要读取边界见[公共HTTP与渲染记录](09-performance-results/owner-http-request-and-readiness-r73.md)及[根因诊断manifest](09-performance-results/owner-r74-root-cause-audit-manifest.json)及[本波归并manifest](09-performance-results/owner-r75-grouped-read-and-render-manifest.json)及[bounded／intent第二批manifest](09-performance-results/owner-r75-grouped-read-and-render-intent-bounded-manifest.json)。主12r73仍5／150超线、主48仍79／150超线；正式draft／0，整页性能与最终交付仍未收口。

r66 raw fact 的已核原文直接交类型化消费，保持 bytes、独立摘要及模型约束；完整核验和 repair 各自在本次操作内构造 recorded expected，再执行各自 current 检查。r67 老板待办复用真实 fact 原文；未发布详情两路径同为 6,931 字节，没有证据证明重复，试改已撤回。

完整 publication 期间检查仍枚举全部实际 ID／期间／序号，仅对已成功 ID 省正文复查，未核头与第二批正文严格比较。1,005 已核／23 未核样本中，返回字节 425,069→220,342、VM 43,800→34,200；增加 5,000 个无关已核 ID 后实际请求参数及工作量不变，没有遍历整个成功缓存。只证明合成工作量减少，未证明主 48／120 月净收益。

材料成功证明也只在同连接受控快照携带；完整简报材料 worker 与父请求是不同事务，不能合并证明。银行准备与材料 worker 合包仅约 6.5ms 诊断收益，且可能改变错误优先级，未采用。见 [r33 双向材料证明](09-performance-results/r33-material-proof-two-way.md)、[银行合包负面结果](09-performance-results/bank-material-worker-negative-r33.md)。

### 5．可变候选目录被当作“没有业务”的证明

原始事实、正式发布、凭证与不可变关账内容是权威来源；可修目录只索引实际引用，不推导完成或采用。派生封签须绑定独立关账根，不能证明自身正确。普通连接不全库扫描或自动回填；修复实际改变结果才原子推进读取修复版本，不新增业务 lane。

关账私有根、目录、块及认证过滤器保留完整逻辑内容与摘要。阴性过滤只能排除确定不存在的键；可能命中仍核原目录、块及来源。清偿、期间余额、资料反向依赖、强信号和报表分类目录均按自身来源建立，完整核验独立重建；缺格式、摘要、必要采用或安全依据即拒绝，不以旧完成标记跳过。

r67 排查发现：删除 publication／calculation 或主体行后，从它们筛候选可能掩盖真实零金额工资、零净值资产和报表历史。当前指针 LEFT JOIN 保留坏来源；银行核截止月全部真实关账，资产核各成员独立拥有者和采用，真实撤去单独核验。空候选也检查权威范围，实际凭证或关账不能被候选删除抹去。

固定组原 **132／2**、主体缺失组原 **37／2**及两次最小四项分类复验分别保留；没有把局部错误码修正改称整组全过。完整 accounting、adopted-only 与缓存作用域职责分开，末尾失败不得留下新成功前缀。完整失败及命令见 [r67 记录](09-performance-results/owner-required-groups-r67.md)。

### 6．完整核验、升级和备份缺少保留证明

只验证升级后结构／内容自洽不能证明升级前历史保全。公司离线升级和备份恢复共用 38 张权威源表稳定列的流式摘要，覆盖身份、原件描述、事实、计算、凭证、发布、关账、request／audit、任务全部字段、管理与实体历史、清单和处置、未消费批准及目录安全历史；绑定正文仍按原版本解码，不用当前计算覆盖冻结历史。

源锁内复核、目标事务内比较，失败回滚。已有非空 v1→v2、篡改、重试、正常新增列与保留组 140 项通过；这是隔离合同和故障注入，不等于正式发行包。固定 v1 独立解码仍须在最终 released 工厂与包中验证，不能由文件存在或当前 helper 推定历史隔离。

Windows ZIP 轮转保存已验证候选与绑定摘要的私有恢复记录，失败不删除目标。r24 第二次轮转 WinError 5 原失败保留，仅隔离恢复通过；r25 另一次查明 Code.exe 占用候选 ZIP，不能倒推 r24 原因。仓库外合成备份组 79 项通过，未放宽生产权限或重试；最终包仍待验。见 [r24 原回执](09-performance-results/backup-rollover-r24.json)、[r25 锁现场](09-performance-results/backup-lock-r25.md)。

运行包的已有输出保护也覆盖验证报告：原实现只拒绝已有软件目录、ZIP及重定位目录，遗漏独立verification JSON。现将四个目标一起预检，报告用独占创建写入；11项文件清单及四目标保留检查通过，Ruff通过。该工具修正不代表最终包已构建或自检通过。

完整核验内存也单列：跨月共用 QueryReads 原型仅少约 0.34% VM，Python 峰值 75→217MB，已撤回；历史大库核验峰值不能当常驻泄漏结论。见 [负面原件](09-performance-results/report-shared-reads-negative.json)、[独立 120 月核验与观察器故障](09-performance-results/stage9-independent120-r30-results.md)。

### 7．局部优化无收益，或验收环境互相干扰

r67 报表分类根指定的 4,932 个来源全部必要。SQL 头聚合虽少返回行，VM 却从 187,600 增至 409,700，物化试验为 424,600／439,500，完整读取未提速；已恢复完整头读取及严格集合比较。原试验 35 通过／1 失败与后补 20 项保留，不改称原整组全过。

开放报表拆逐行表的交替诊断无净收益且增加结构／存储，已撤回；共用全月凭证选择少 VM 却增返回字节，未采用；改变查重 envelope、增量桶、JSON 解析器、提前准备检查与 Ajv 首错退出等私有试验也不作为默认提速。审查第 24 项不重新试验。

负面原件见 [开放报表逐行试验](09-performance-results/open-report-line-negative.json)、[全月选择](09-performance-results/journal-shared-selection-negative.json)、[查重增量桶](09-performance-results/duplicate-incremental-negative-r17.jsonl)。垃圾回收、必要内容核验及跨事务隔离保持原规则。

源码变动中运行的组、并行测量、观察器失败／恢复、fixture 错误、编码警告、浏览器门禁拒绝及首次超时均按原件解释。只保存工具 stdout 的回执不补造完整 log／JUnit；manifest 保存原文及 gzip 摘要，不把逐字节副本算第二次核验。

公共 HTTP 额外成本按一组记录，模拟 TCP 负面对照、主48三次浏览器插桩及主12／主48真实阶段边界见[集中决策记录](09-performance-results/owner-http-extra-cost-r70.md)。这些诊断不替代原主48浏览器30次失败结论；静态请求并行与单次校验不等于耗时验证。

### 8．历史证据的有效范围

| 索引 | 保留的结果与边界 |
| --- | --- |
| [r23 全后端](09-performance-results/regression-r23.json) | 固定 217 文件，2,485 通过／2 平台跳过；属于历史源码，不覆盖后续读取修改。 |
| [r26 读取组](09-performance-results/read-group-r26.json) | 46 文件 503 通过；主 12／48 月完整核验通过，纯浏览器仍未达标。 |
| [r29 浏览器及报表任务](09-performance-results/grouped-r29-browser-and-report-jobs.md)、[r32 浏览器](09-performance-results/grouped-r32-browser-results.md) | 旧 100 条口径，两档均未达标；失败、逐次慢样本及任务范围保留。 |
| [r50 必要读取清单](09-performance-results/owner-required-r50-manifest.json)、[r54 清单](09-performance-results/owner-required-r54-manifest.json) | 老板精简后的早期失败、消费者及快照证明定向回执；不合并为当前固定验收。 |
| [r59](09-performance-results/owner-candidate-pure-r59-manifest.json)、[r60](09-performance-results/owner-candidate-pure-r60-manifest.json)、[r61](09-performance-results/owner-candidate-pure-r61-manifest.json)、[r62](09-performance-results/owner-candidate-pure-r62-manifest.json) | 各自候选、核验及纯计时原件；r62 主 12 月简报仍有 1／30 慢样本，整体 over_target。 |
| [r63 主 12 月](09-performance-results/owner-candidate-pure-r63-manifest.json) | 12,000 业务，30,225 事实、12,413 结果、12,309 凭证、11 关账、85 证据；完整核验约 90.24 秒，四项 coverage verified、limitations=[]。 |
| [r63 主 48 月／独立 12 月](09-performance-results/owner-main48-independent12-r63-manifest.json) | 主 48 月 48,000 业务，完整核验约 1,007.54 秒；独立 12 月约 84.06 秒，四项 coverage verified、limitations=[]。复制证明不构成真实库迁移授权。 |
| [r64 固定组](09-performance-results/owner-r64-unified-manifest.json)、[r65 诊断](09-performance-results/owner-r65-diagnostic-manifest.json)、[r66 统一与诊断](09-performance-results/owner-r66-unified-and-diagnostics-manifest.json) | 后续增长修正与 native profile；不能沿用 r63 浏览器通过覆盖新源码。 |
| [主 120 月构造](09-performance-results/stage9-main120-built-manifest.json) | 120,000 业务、119 关账，built_not_verified；此前核验等待已取消，不能写成主 120 月完整核验通过。 |
| [独立 120 月](09-performance-results/stage9-independent120-r30-results.md) | 旧固定 r30 完整核验与开放预览通过，含观察器失败及同 PID 恢复；非最终正式源码验收。 |

r63 主 12 月五页最大依次 496.2／277.2／316.8／237.3／477.2ms；主 48 月 ≥500ms 次数依次 30／0／30／2／30。全部 150 个逐次样本保留。两次仅一家 eligible company，切公司 unavailable；startup_ms 属前置准备，不冒充独占冷启动。早期压力、边界、240MiB／约1.5GiB 原件和两次开发包结果均是历史诊断，最终范围仍须下节实际验收。

## 剩余交付

执行入口、源码边界、现有测试性质和待执行命令统一见 [正式交付剩余收口](09-performance-results/release-remaining-gates.md)，本节保留交付要求，避免重复逐条命令与 fixture 历史。

| 交付 | 必须实际完成的范围 |
| --- | --- |
| 当前必要读取 | 三组修正先完成相关验证，再固定下一候选统一回归、合同／正式构建与主样本工作量；复核无关历史增长、缺源／损坏、撤去、未知及原子失败。 |
| 规模与整页 | 最终读取器对应主／独立 12、48、120 月及压力必要完整核验；取得规定五页纯浏览器、冷态、切公司及按需路径证据。内容核验通过不替代性能通过。 |
| 首个正式 v1 | 性能与结构收敛后审阅候选，切 released/1，一次独占创建 catalog／company／content 三合同，保存正文与 SHA、production bundle、源码及静态产物身份；已发布合同不可回写。 |
| 正式历史与拒绝 | 最终正式源码验证非空 v1 历史解码、新建／重开／备份恢复；实际 CLI／daemon 拒绝 draft、旧谱系、未知／同版本漂移及混版，失败不改库或身份。复制源码负测不冒充正式包。 |
| offline upgrade | 最终包真实 CLI 同版重复执行、daemon 服务锁拒绝、服务仍存活／目录不变；隔离 v1→v2 故障与重试、公司逐库提交和目录最后迁移、历史摘要成本单列。没有正式 v2 合同／步骤时不宣称正式跨版产品；不是跨库原子，也不自动备份。 |
| 原件规模 | 最终固定正式源码分别完成 240MiB 和 1536MiB mixed 原件的 verify／backup／restore／restored_verify、摘要、ZIP 与同时间服务树峰值、前台影响。资源不足记未执行，不降档或使用真实资料；HTTP 前台不能替代浏览器验收。 |
| 独立正式包 | 全新输出，不用 skip-validation；保存 ZIP／manifest／源码清单摘要和自检报告。隔离安装、重定位、启动、页面、CLI／stdio MCP、恢复及 released 专用升级自检实际通过，包与源码 build 身份一致。 |
| 实际 AI／MCP | 符合当前用户模型要求的实际 AI 经最终包及隔离合成 host，验证切公司、工资／月结、丢响应查询、更正、办理、备份恢复与停止边界，保存原始工具回执；原生批准只消费准确当前预览。host、握手、helper 或 mock 不算实际 AI 复验。 |
| 46 项与编号外事项 | 按 [覆盖记录](09-performance-results/stage9-audit-coverage-r28.md)逐项更新实际完成、保留、排除和延后状态，同步架构、路线图、操作说明、环境与合同／包摘要；不降低原范围。 |

正式版不自动接收开发库；隔离合同、rebase 与恢复验证均不授权真实库转换、替换或重录。恢复只写不存在目标，显式原位升级另有来源与事务规则。子智能体按用户要求和任务复杂度选模型／推理强度并先说明，历史 GPT-6 Sol 记录不构成后续固定模型要求。

## 阶段结束条件

先收敛相关修改，固定源码并完成受影响验证和正式构建，再取得必要注册完整核验与独占浏览器证据。所有规定五页成功样本低于 500ms，冷态、切公司和按需范围有实际记录；不通过退出必要内容或隐藏未知状态达标。

随后冻结三份正式 v1 合同，完成正式历史、拒绝、备份恢复、两档原件、离线升级、最终独立包及实际 AI／MCP 验收。冻结或构包后若源码、静态产物或运行条件变化，补对应受影响验证；旧候选、负面试验和局部补跑不能替代最终证据。

最后逐项收口 46 项及编号外事项，核对文档本地链接、合同／包身份与真实回执。保留失败、排除、负面和延后结论，不以历史测试总数、中途提交或待执行命令声明完成。按用户已明确指令，验收完成后将同一事项的代码、测试、生成产物和文档一起提交 Git 并停止，不自动推送。当前仍未达到阶段结束条件。
