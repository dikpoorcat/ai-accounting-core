# r77 正式 v1 / 离线 upgrade 只读收口审计

范围：当前仓库代码、README/AGENTS、既有测试源码和 r73 原始回执。模型沿用 GPT-6.1 Sol / high。本轮只读生产，未运行测试、服务、包构建、迁移、备份或大库操作；仅新建本审计及同名 JSON。不把静态测试源码当本次运行结果。

结论：本轮未证实需要立即修改生产的缺陷。正式 v1 尚未冻结、正式最终包尚未验收；这些是交付待办，不能写成实现失败或已交付。当前 `schema_bundle.py:18–19` 为 draft/0，实际合同目录只有 draft 和明确的 development 来源；README 第13、27行准确说明此状态。

## 公共调用、实现和决定

| 边界 | 已实现位置与实际语义 | 证据和处理决定 |
| --- | --- | --- |
| 正式 CLI upgrade | `cli.py:71` 在进入 ServiceClient/MCP/daemon 分支之前导入 `offline_upgrade.upgrade_root`；不创建 Catalog、不启动后台、不恢复未完成 operation。使用包内 `production_bundle()`，没有外部合同/版本/SQL参数。 | 保留。测试 CLI 用 synthetic bundle monkeypatch；真正包内命令另有入口，尚待最终包运行。 |
| draft 拒绝 | `offline_upgrade._inspect_root:131` 拒绝非 released bundle；`versions.verify_schema:200` 核 family/kind/status/version/实际SQL/安装历史。正式工厂选 released 时不接收 draft 数据库。 | 保留。当前开发启动允许当前 draft，不等于正式版接受 draft；不要删除开发入口。 |
| released 选择与内容登记 | `schema_bundle.production_bundle:189` 仅由固定 STATUS/VERSION 和包内合同构造；released 强制 `v1_registry()`，为所有历史 released company 版本要求注册 verifier（174）。`contract_files.py:6` 排除 draft，携带声明的 released history 与 content-v1。 | 首版目前无 v2 合同/迁移，不伪造正式 v2。未来必须显式合同与步骤；孤立测试 synthetic v2 不能当生产支持。 |
| schema candidate/freeze | `scripts/export_kernel_schema_contracts.py:15/42/70` candidate 输出完整精确内容但不写；freeze 要求 released/1、提前构造三份候选、exclusive x 创建，任何已有目标拒绝；失败只清理本次创建的文件。write 仅限 draft/0。 | 保留。schema-export tests 覆盖已有文件、partial write、content generation失败、重试拒绝。正式 freeze 尚未实际执行。 |
| 全根预查 | `offline_upgrade._inspect_root:131` 只读事务查目录，核 integrity/FK/operation/path/reparse/身份；对全部登记公司按安装版注册 verifier 完整 verify_file，预查唯一迁移路径。未完成包括 failed/pending 等非 succeeded operation 均拒绝。 | 保留。未完成创建/恢复必须先由原安装版处理，不在升级入口隐式恢复。 |
| 服务锁与锁内重核 | `upgrade_root:210` 预查后拿 `.resident.lock`，未取锁报 service_active；锁内再次全根预查。`daemon.instance_lock:84` 使用同一文件；`run:421` 锁内 check_root_current 后才 LocalService。 | 保留。完整预查发生在锁前是必要先验，不会写业务；活服务拒绝可能先付出预查成本，非正确性缺陷。 |
| 混版启动 | `daemon.ensure_service:194` 和 `run:437` 调 `check_root_current`，released 查全部登记公司结构与身份，require_current=True，不做全量业务扫描。目录-current/任一公司-old 或超前版均拒绝；不自动upgrade。 | 保留。`test_released_cli_startup_rejection` 用真实复制 released-v1 源码的 CLI call/daemon 负例，覆盖 draft目录/公司、旧体系、同版漂移、混版；本轮未运行此文件。 |
| 公司先、目录后与 partial retry | `upgrade_root:210` 单公司事务提交，已current公司在再次完整核验后 verified_skip；全部公司成功才升级目录，目录失败保留已升级公司，下次重验后跳过。 | r73 tests 明确第一公司完成/第二公司中断、目录中断和重复执行。不是全根原子事务，也未声称这样保证。 |
| 单库源竞态 | `versions._execute_steps:300` 无事务前验源，BEGIN IMMEDIATE 后再验源；逐步 `_assert_step_contract`、data validator、FK check，最终 target verifier 后 commit。`offline_upgrade` source callback 比较身份/计数/原列 stream历史摘要。 | 源结构竞争和事务内源失败已有专属 tests；不在 r73 六文件50项内。本轮静态读到实际第二连接竞争实现，没有新运行。 |
| 历史保留 | `offline_upgrade._company_history_state:56` 要 verified 且 limitations为空，比较 identity/evidence/latestclose/counts/`backup._retained_history_digest`；目录 stream摘要覆盖公司登记、operation/settings和负责人/session/recovery/audit等原列，目标事务末尾比较。 | r73覆盖同计数历史替换、证据名、request/audit/job receipt/status、开放entity/material/未消费approval、目录安全等原行、target新列不影响旧列摘要。保留。 |
| FK 关闭和失败恢复 | `versions._execute_steps:330–359` 仅步骤声明 requires_fk_off 才在事务前OFF并readback；成功/失败 finally ON并readback，恢复失败关闭连接；BaseException rollback。 | 专属 tests 包含真实表替换、所有stage失败回滚、execute/readback恢复失败、已有外部事务不触碰。未纳入旧50，不能借其通过数替代。 |
| 当前/固定内容模型 | `content_v1._V1StoredFact:34` 独立 BaseModel carrier，模型从保存JSON Schema/字段类别重建；_V1YearMonth/_V1ActualDate独立；`v1_registry:459` 对 descriptor和各fixed规则源码摘要核验，`verify_v1_company:559` 进入 historical_content(1)。 | 非空历史测试真实 facts/calculations/vouchers/closes、期初/累计工资/纠错，替换未来current字段、scopes/reads/JSON/存储/QueryReads仍核验。不是复用当前Fact模型。 |
| 公共完整性/backup/恢复 | `backup._verify_connection:149` 根据实际安装版本选注册 verifier，缺 verifier拒绝；offline source/target 调同入口；full integrity historical dispatcher 使用fixed publication/journal/close/report规则。 | 正常公司内容失败须rollback；备份恢复 isolated released1→2 也核 retained-history。没有给普通元数据 proof提升全文权限。 |
| 包命令和正式验证 | `package_local_kernel.py:306` 写 finance-local.cmd/ps1，调用包内隔离Python和CLI；复制 exact合同、声明模块/依赖；manifest/runtime build核对与inventory；默认解压再用包内解释器运行 `verify_local_package.py`。 | 保留开发 skip flag。docs/local-kernel-packaging 第15行明确不能把 skip 中间包交付；最终实际调用必须不带 skip，validation非null/status passed且formats released/1。 |

## 已运行证据：r73 六文件，不扩大解释

原件：`.tmp/stage9-r73-upgrade-history-related-command.txt`、`.log`、`.xml`、`.json`。实际 **50 passed /109.62s**；XML tests50，failures/errors/skipped均0（XML suite内部time109.360）。JSON before/after source SHA均 `6a9086e066bd09df5834781fe49da6d4fb7e3333ba6b5569241193a33925f75a`、source_unchanged=true、returncode0。

| 文件 | 实际passed |
| --- | ---: |
| test_offline_upgrade.py | 9 |
| test_offline_upgrade_history_preservation.py | 15 |
| test_stage9_backup_upgrade_history.py | 7 |
| test_v1_stored_json_isolation.py | 4 |
| test_history_reads_v1_warm_cache.py | 1 |
| test_versions_recovery.py | 14 |

限制：这些是隔离合成合同、正常真实 engine/source verifier 以及 fault/monkeypatch 测试。CLI多数为当前进程 `cli.main()`，synthetic v2 仅fixture内加载，生产工厂没有登记fake v2；不证明当前最终源码与r73相同，也不证明最终正式ZIP/隔离Windows launcher/native窗口已通过。versions_recovery 主要是创建恢复/结构及command validation，不能拿它冒充升级源竞态/FK关闭测试。

## 未验证点与下一组最小验证

1. **最终fixed-v1内容与新最终合同的匹配待验。** r73后 fixed publication、position临时视图生命周期等源码已有变化；在最终freeze之前生成新 candidate 后应核 exact descriptor/rules，冻结后运行 `--check` 和实际 factory。不能沿用旧candidate的 content SHA。建议只重验已变化的非空historical消费：`test_nonempty_v1_frozen_adoption_survives_changed_v2_current_model`、`test_v1_identity_correction_is_verified_after_current_expense_model_changes`、`test_v1_frozen_opening_and_cumulative_identity_survive_changed_v2_methods_and_helpers`，加 `test_v1_stored_json_isolation.py`。旧50其余未变范围不自动重跑；根节点根据最终diff决定。
2. **工具/正式选版与真实copied-CLI未包含于旧50。** 一组建议：`test_schema_contract_export.py test_package_contract_selection.py test_released_cli_startup_rejection.py test_stage9_package_file_inventory.py test_stage9_package_upgrade_smoke.py`。具体通过数以未来XML为准，本轮不执行。前两/库存/upgrade-smoke有mock或纯fixture；released-CLI是真子进程复制源码但仍用仓库解释器，不等于包解释器。
3. **竞态/FK恢复已存在测试，现无新失败证据。** 如最终versions/executor未变，不要求机械重跑；若改动这层，最小增量为 `test_migration_steps.py -k 'source_revalidated_after_lock or competing_schema_change or failed_fk_restoration or existing_transaction'`，再视改动加真实table replacement/rollback。
4. **最终实际运行包尚待验，是交付门禁而非新增代码缺陷。** 性能收敛且批准正式选择/freeze后，运行 `scripts/export_kernel_schema_contracts.py --check`；再 `scripts/package-local-kernel.ps1 -OutputDirectory <全新absent交付目录>`（无 SkipValidation）。保存source/manifest/archive SHA、真实命令/stdout/verification；验证 validation.status=passed、database_formats两类released/1、packaged_offline_upgrade非null。禁止把已存在r73 isolated报告或当前draft包冒充这个结果。

实际包验收入口 `verify_local_package.py:82/2022/2221` 已包含活真实daemon的finance-local.cmd upgrade拒绝、同PID/目录数据不变，以及停止resident后同版upgrade两次verified_skip。这是正式首版应有的实际可运行验收；首版没有真实previous released库，不需要为了包测试登记fake正式v2。未来真实前向迁移须有自己的包内步骤和目标内容proof。

## 负面判断和证据限制

- skip-validation存在不构成缺陷；包脚本默认不skip，验证失败raise/nonzero，不输出成功 validation报告。失败前可能留下软件目录/ZIP，必须作为失败中间物保留，不得交付；无需擅自清理或删除flag。
- 当前draft工厂及schema candidate可构造合成released合同不构成生产released声明。正式仓库冻结仍待性能收敛及根节点授权。
- 没有证据表明固定v1实际调用当前领域模型来解释旧事实；保存descriptor+fixedmodules与真实非空future-model tests给出反证。shared完整integrity调度仍需随未来改动复查，不宣称所有未来改动自动安全。
- 本轮未发现可执行新修复类别，建议保留既有实现，把上述最终组合入口列入交付收口；没有新测试通过数或当前package验收结论。
