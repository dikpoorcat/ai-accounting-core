# 月份发现组：10处静态决定

primary修复、sealed d198不动。只前三处接 posting_period_reads.posting_periods（五表可信名单，现有前导索引递归min，无DDL/缓存）；保留独立三表孤立月份与后续真实核验。其余均为职责必要、本组不改/尚未测性能，不能称已排除优化。

|位置（当前primary行）|caller路径与决定|
|---|---|
|period_balances._totals:354，发现SQL原375/现377|Dashboard._brief_amounts→balance_totals/balance_movements→_totals：normal tail接helper，之后verify_balance_periods和frozen余额原样。|
|settlement_freeze._tail_rows:878，原SQL910|settlement_freeze._scope→_tail_rows：normal current/historical tail接helper，late review/min/max与verify_settlement_periods原样。五页结算消费。|
|settlement_projection._summary_scope:554，原SQL594|settlement_position_rows/settlement_summary/settlement_followup_summary→_summary_scope：normal scope接helper，current无上限、historical through及三表coverage原样。|
|period_balances.sync_period_balances:226，SQL231/243|Engine发布/撤回同步→sync_period_balances：bounded subject/write，保持原两条来源枚举。|
|period_balances.verify_selected_balances:287，SQL307|QueryReads.verify_balance_scope/verify_balance_periods及发布投影检查→verify_selected_balances：explicitperiod/full-integrity混合职责，保持。|
|settlement_projection._publication_periods:290，SQL291|sync_settlement_publications/compare_settlement_projection→_publication_periods：explicitperiod或full integrity/write，保持。|
|Engine._check_publication_projections:1316，SQL1325/1335|Engine发布prepared→_check_publication_projections：bounded subject/explicitperiod write检查，保持。|
|BusinessQueries._selected_accounting:406，SQL489|selected accounting states/vouchers→_selected_accounting：subjects非空时json_each IDs→calculation.subject_id→publication，限定cutoff的精确采用月份，保持，不换全表locator。|
|report_projection.compare_report_projection:1131，SQL1140|完整报表投影compare/repair→compare_report_projection：full integrity及可选through，保持；report_projection_v1固定历史完全不改。|
|Worklist._candidate_months:56，SQL76|Worklist.query→_select_month→_candidate_months：工作清单完整候选/身份发现，保持。Dashboard._periods:1668异构事实/材料门槛不改。|

定向原件：stage9-posting-period-discovery-directed-first.log 8passed/18.42s（新4+原caller4）；随后新增装载护栏仅复验1case，loaded-guard.log 1passed/4.17s，两轮不加总。12/48/120月×1000重复行：seek VM2340/8820/21780，原UNION368639/1486475/3722147；加载月份行60/240/600，重复1→1000不增。此为定位工作量，非500ms净收益。

建议root完整组（准确存在）：tests/kernel/test_posting_period_reads.py、test_period_balance_freeze.py、test_period_balance_index_scope.py、test_settlement_freeze.py、test_settlement_period_scopes.py、test_settlement_late_reviews.py、test_settlement_candidate_selection.py、test_unresolved_settlement_reads.py。实际root已完成8文件51passed/113.04s，以rootlog/XML为准，不由此文重跑或加总。fixed-v1必要范围另由root按最终source边界选择。
