# 报表锚定来源读取组只读审查（2026-10-03）

结论：现有 fa5c profile 和源码不足以支持一个可直接实施、预计改善当前 main48 报表瓶颈的安全优化项。不能把 `_verify_anchored_source_bytes` 的 119.354 ms self time 解释成可删除的 Python 哈希成本，也没有同一次快照重复读取 1004 份贡献或 1005 份核算来源的证据。本审查不修改实现、合同、测试、正式数据、服务、身份或资料根；只生成本文件。未运行测试、数据库调用、profile、构建、浏览器或 qualification。

## 证据与适用范围

- 固定诊断文件：`.tmp/stage9-owner-four-read-groups-work-fa5c-20261003.json`。其源码标识为 `fa5c7074031755dd8dcf7682198d735c6e6070f704d8c4699a34b5229e489877`，源码目录为 `.tmp/stage9-build-source-owner-four-read-groups-fixed-20261003`。这是诊断工作量/profile，不能当作浏览器延迟验收或潜在收益。
- 只比较审查相关的八份 current / sealed 文件原始字节，全部相同：`query_reads.py`、`report_open_contribution.py`、`reports.py`、`report_projection.py`、`stored_json.py`、`storage.py`、`integrity.py`、`dashboard.py`。没有用“看起来同代码”代替比较，也没有重新认定整个包资格。
- 主任务给定的 current main48 浏览器结果为报表 median 576 / p95 675 / max 694 ms，30 次失败。此结果说明尚未达标，但本审查没有重新计时。主任务已证明月度报表引用 4932 项均唯一，411 个分类 ID 无重复；这里不重新查询数据库。
- 诊断报表工作量：255 SQL、948100 VM steps、24869 返回行、10684375 返回值字节；1007 核算结果行 / 991627 字节进入 Python，只解码 3 个核算结果；1004 份贡献解码 / 3059132 输入字节。

## 报表实际调用链与两次读取的边界

`Dashboard.quarterly_report`（`dashboard.py:2309`）在 `QueryReads.snapshot`（`query_reads.py:847`）中调用 `Reports._report`（`reports.py:1063`）。其 open 计划也计算准备问题和余额需要的实际报表信息，不能只按界面金额行数量删减来源。

报表的第一份贡献集合来自财务位置往来分组：`_party_balance_nets_uncached`（`report_projection.py:939`）→ `_authoritative_rows`（169）→ `_party_delta`（337、482）→ `read_open_contributions`（`report_open_contribution.py:501`）。第二份集合来自利润/现金流等完整行：`Reports._report`（`reports.py:1447`）→ 同一贡献读取器。`selected_open_line`（`report_open_contribution.py:608`）再将贡献中的凭证 ID、行号、科目、借贷金额和现金流标记与已权威选中的实际行匹配。

两次调用复用同一 `reads._report_snapshot_cache['report_open_contributions']`；读取器只查询缺失 calculation IDs。其下 `_verify_anchored_source_bytes` 也只处理尚未核验的绑定。已有 profile 的贡献解码 1004 次、贡献 SQL 两次合计 1004 行，锚定来源 SQL 两次合计 1005 行，来源 SHA 调用 1005 次，支持分组分批且去重后的工作量，不能据两次函数调用推断重复处理整组。绑定在同一批内还先按 calculation ID 合并，并拒绝同 ID 不同绑定。

`QueryReads.snapshot` 拥有私有只读事务，拒绝消费者提交/重开事务；退出时 `_reset`（`query_reads.py:794`、870）清空全部 proof、原文、贡献和查询缓存。不能跨请求保存证明或核验结果。

## 原文、封签与绑定各自证明什么

`prepare_open_contribution`（`report_open_contribution.py:138`）仅保存根 calculation 和直接 resolver 实际加载的 calculation；已加载直接来源必须属于精确父集合。`source_bindings` 每项为 calculation ID、核算结果 digest、fact ID、fact digest。它不是“全部历史祖先”；不能凭源很多就视为无关全量展开。

`read_open_contributions` 的必需检查依次包括：

1. 贡献体 SHA 同时等于不可变 anchor digest 和派生 body digest；anchor calculation ID 与查询 calculation 一致；贡献 calculation ID、来源集合格式及自身来源存在。
2. `_AnchoredSourceProof` 只能由该模块在既定连接、`reads` 和活跃事务下签发（`_require_source_proof`，`report_open_contribution.py:60`）；普通传入 ID/摘要不能冒充证明。
3. `_verify_anchored_source_bytes`（`query_reads.py:1878`）读取精确 pending calculation IDs 的头信息，核对四项绑定、calculation/fact 封签及 subject/kind/period 身份一致性。封签存在不能代替内容核验。
4. `_verify_selected_fact_bodies`（`query_reads.py:1715`）核对事实物理行期间和子项顺序，并核验原始事实内容；已有原文哈希及支持的标量 SQL 编码是等值快路径，不匹配或不可支持时仍读取原始完整值。fixed-v1 不使用当前标量快路径。
5. 原始 `calculation.outcome` 字节 SHA 必须等于被独立 anchor 绑定的 digest；等值非 canonical JSON 保留精确原文解码后的 digest fallback。贡献已含报表语义，不等于仍保存的原始 outcome 当前未受损。
6. 查询根 calculation 的 `dependency_calculation`，要求精确 parents 和贡献绑定集合一致；根 digest/fact ID 再与贡献头一致。精确依赖、来源内容与凭证行各有独立职责。

因此贡献自身 checksum、calculation/fact seal、当前头 digest、闭期采用依据以及来源原文核验不能互相替代。仅返回摘要或仅检查 seal 会漏掉原始 outcome/fact 内容损坏；减少 source_bindings 需证明实际 resolver 不再消费该来源，目前没有这样的证据。

## SQL 工作量与 profile 的正确解释

锚定头查询为 `FROM json_each(pending IDs) CROSS JOIN calculation ON primary key`，再按 fact ID / subject ID 连接；`CASE WHEN c.id IN (json_each(body_ids)) THEN c.outcome` 控制是否携带 body。当前 profile：两次 SQL、58300 VM steps、1005 行、1237060 返回字节、47.003 ms 仪表 SQLite 时间。贡献查询：两次 SQL、24100 VM steps、1004 行、3322180 字节、29.593 ms 仪表 SQLite 时间。

现有记录没有 query plan、ID 参数逐项记录或每次 cursor stepping 分解，无法证明 `CASE IN`、ID 排序或 JSON IDs 造成超范围扫描；也不能把 119.354 ms self time 全部归为 Python 循环。`execute` 只开始游标，迭代行发生在函数自己的 comprehensions / 循环中，SQLite stepping 和行转换可能被计入 self；并发调度和 profiler 开销也在该 wall profile 内。

该函数直接调用的 SHA 创建约 1.999 ms、digest 约 1.374 ms、UTF-8 encode 约 0.724 ms，合计约 4.097 ms。事实核验 inclusive 约 21.172 ms。self/inclusive 差值不是可直接兑现的收益，不能承诺删哈希即可收回 119 ms。

约 0.99 MB outcome 原文对报表语义而言已有贡献替代，但它当前用于校验源仍与不可变绑定一致；这属于必需信任链输入，不是已证明可删除的业务 payload。当前没有可复用的 SQL SHA UDF；`stored_json.verify_sql_outcomes` 仍读取并解码完整 outcome，以拒绝重复 JSON 字段，不能用它伪称已经具备无原文传输的安全替代。

唯一发现的代码层面可避免传输条件是：`body_ids` 仅排除 `_verified_source_contents`，未排除 `_raw_calculation_outcomes`；后面的原文哈希循环却优先取已有 raw cache。因此若同一快照先加载 raw outcome，再走 anchor 路径，会多传一次 outcome。`verify_selected_content`（`query_reads.py:1635`）已经有 raw reuse 分批读取，说明局部可复用方法存在。但当前固定工作量只有 1007 outcome 行与 1005 anchor 行，没有这些缓存集合的交集证据；不能把这个条件性代码改动推荐为当前 main48 的有效优化组，也不能由它估计收益。

## 同类入口的不同读取职责

| 入口 | 当前链路/消费 | 不能共享或省略的职责 |
| --- | --- | --- |
| brief | `Journal.account_amounts`（`dashboard_reads.py:1289`）先验证整月采用与凭证行，再 `verify_selected_content`（1367）解码实际结果；`Snapshot.activity_classification`（`dashboard.py:1157`）复用已核内容，对付款实际来源另走 `verify_published_source_bindings`（`report_open_contribution.py:416`） | 金额行的 owner / adopted result 与付款分类来源是不同集合；profile 1009 outcome 行/1008 decodes，anchor 495 行只传少量头，贡献完整解码为 0，已经复用该月内容 |
| funds | `Funds._verify_event_sources`（`dashboard_funds.py:314`）核对冻结采用/owner，再 `verify_selected_content`（363）；已核 current 月事件可以复用 journal rows | 事件实际消费结果与闭期采用独立；现有 funds 542 outcome 行/542 decodes、3 次 accounting slices，没有 anchor contribution decode，不能由报表优化假定同收益 |
| employees | `_workforce_cost_from_rows`（`dashboard.py:3287`、3443）及员工金额汇总（3903）使用选中工资/付款实际结果 | profile 101 outcome 行/101 decodes；工资批次值本身被消费，不是未使用报表贡献；没有 anchor contribution decode |
| assets | `_asset_*` 付款摘要（`dashboard.py:4105`）、`_assets`（4185、4280）和 exact batch owner/read selection | profile 197 outcome 行/197 decodes、94 accounting slice reads / 141 adoption rows；冻结 owner discovery 与资产业务结果不是报表同组重复 |
| 全量 integrity | `_verify_integrity_snapshot`（`integrity.py:1249`）→ `_check_sources`（272）→ `compare_open_contributions`（`report_open_contribution.py:632`） | 全部真实源、依赖、事实、证据和 publication/voucher 被独立验证；重建全部贡献并比较 immutable anchors，已有 verified_source/records 复用，不能借派生贡献证明自己 |
| close | `verify_close_integrity`（`integrity.py:1581`）→ 累计当前结果/凭证 + 历史 manifest direct IDs + 完整源证明 | 冻结历史和本次采用需独立核验；不能拿页面窄 scope 的成功证明替代完整 close |
| repair | `Maintenance._repair`（`maintenance.py:27`）先全量 source authority 验证（派生目标可损坏），再修复派生表、再完整验证目标 | 修改结果才推进 repair revision；不能在 repair 前信任待修贡献，也不能用页面 proof 跨写入复用 |
| backup | `_verify_connection`（`backup.py:149`）按 company version 选择 installed verifier；snapshot / portable candidate 都经它 | 数据格式、身份、完整内容与包验证独立；不改成页面窄读取 |
| fixed-v1 | `content_history_context` 将编码、close、publication、report projection、contribution 等路由到 `*_v1`；`storage._scalar_fact_hashes` 明确排除 v1 | 历史解释独立不可变；当前实现改动不能自动扩散到 v1 或用今日模型覆盖历史 |

## 本轮建议

保留现有信任链和读取范围；不实施“去掉 outcome 原文”“只看 seal/头摘要”“合并两次调用即删证明”“跨请求缓存”或未经实际命中证据支持的 raw reuse 性能修复。固定 profile 没有证明一个共同的、当前已发生的冗余根因，不能为了单组方案把不同入口的职责硬合并。

若后续主任务继续做诊断，最小需要新增证据是同一合成报表快照内两次 anchor 调用的 pending IDs / raw-cache overlap 数量，以及 SQL 游标 stepping 与 Python materialization 的分界；可记录计数/集合摘要而不保存业务原文。该说明是缺失证据边界，不是本审查运行请求，也不建议重跑整个资格矩阵。现有证据只能定位成本，不能给出可信收益或宣称当前报表已经通过。
