# Shared read guard source audit — 2026-10-03

只读源码和既有 fa5c 诊断 JSON 审计；没有打开数据库、执行测试、构建、计时或修改生产源码。当前源码已包含 resident warm borrow 去除中间主文件 ACL/path 重检的修复，fa5c profile 则记录修复前的函数名和路径。本文不把历史 instrumented/profile 时长当成浏览器验收或可节省时长。

## HTTP 与主库借用路径

`http.py:359–390` 的 `/api/dashboard/*` → `LocalService.dispatch` (`service.py:489`) → `security.authorize` → `_dispatch`。context 在 `service.py:456` 打开只读目录连接列公司，再 `_bound_store(...read_pool=...)`，`Dashboard.context()` 使用公司只读连接。其他五页通过 `service.py:693` 的 `engine(...dashboard_read=True)` → `catalog.bind` (`catalog.py:466`) 读取公司目录 → `_bound_store` → Dashboard 读取。池启用时 `_bound_store` 不另开公司验证连接，首个实际 borrow 才验证。

公司读取 `Store.connection` (`storage.py:307`) → `ResidentReadPool.borrow` (`resident_reads.py:100`)：本次借用前 `_signature` 验 local path、实际 ACL、文件设备/节点身份；warm 继续 `_validate_reused_read_connection_at_private_path`；验证 sidecars、无遗留事务、SQLite dbconfigs/attached limit/五个 PRAGMA、开启事务后 `store.validate_connection`；检查 cache_size；借用后再次 `_signature`。归还时清除 authorizer/trace/progress callback，回滚遗留事务。前后实际文件/ACL检查、sidecar边界和完整 schema fingerprint 都必须保留。

`Store.validate_connection` (`storage.py:292`) → `verify_schema` → `_verify_schema` (`versions.py:211`)：元数据、版本/状态、sqlite_schema 原始 SQL 全量对象、canonical SHA256、历史、唯一完整身份；之后 Store 再比较实际公司/数据库/税号绑定。两次 identity SQL 的检查目的不同（唯一完整身份与绑定匹配），可以考虑未来在内部复用同一快照的身份行，但不能只保留 `WHERE id=1` 而丢唯一性检查。

## 实际数量和已有成本证据

既有 `.tmp/stage9-owner-four-read-groups-work-fa5c-20261003.json` observations 中 context、brief、funds、funds_first、employees、assets、quarterly_report 每次均恰好 **1 次 verify_schema、1 次 objects、1 次 fingerprint**。没有证据支持“公司完整结构指纹重复多次”。这些内部 Dashboard 诊断不含整条 HTTP auth/catalog 开销，也不是重叠 context/main 浏览器刷新验收。

既有 profile（不是本轮新计时）brief 的 `_verify_schema` 累计约 7.05ms、objects 3.55ms、fingerprint 2.71ms、旧 warm guard 13.03ms、borrow 17.82ms；quarterly_report 相应为 8.86/5.11/2.91/13.28/17.84ms。累计值有包含关系，不可求和；带 callback/调度，不能当可获得收益。该证据不足以将共享结构核验认定为五页主要瓶颈。

## auth/catalog 是否重复

`SecurityService.authorize` (`security/service.py:437`) 使用 `_transaction` (`:158`)：`connect(...validator=_check_catalog)` 在开放后自己的 BEGIN 验证并回滚；随后获得 authorization gate，BEGIN IMMEDIATE，再 `_check_catalog` 校验并查询当前 session/owner，更新 last_seen/idle expiry 后提交。第二次目录验证在写事务里，第一/第二之间存在竞态边界；不能直接删除其中一次，也不能 cookie缓存或跨请求缓存认证结果。

随后 catalog.bind/context 重新打开只读目录并完整验证，再读 company。这是授权写事务结束后的新目录读取快照，不能把前一个事务的核验视为本快照证明。context 与 main 浏览器请求重叠，各自 auth/catalog/main 的工作不能按串行总和描述。

warm guard 的五个 PRAGMA、dbconfig 和 attached limit 检查针对可变连接状态；没有源码证据可以将它们改为仅首次检查。`objects` 使用 dict/zip，`fingerprint` 已用标准 json C encoder 与 hashlib；没有发现应立即替换的昂贵纯 Python schema字节循环。`storage._scalar_fact_hashes` (`:220`) 已使用 SQLite JSON 和 hashlib 精确相等快路，失败/未知codec仍返回原解码检查，content_version=1 明确禁用；本审计没有证据支持再放宽。

## 一个确实重复且可局部去除的候选

`versions._verify_schema:235` 已执行 `SELECT version,fingerprint FROM schema_history ORDER BY version` 并 fetchall。随后 company 分支调用 `verify_draft_history` (`:239`)，draft 分支又在 `:58` 同一事务执行完全相同 SQL/fetchall。draft company 外层随后将自己的 history置空（released版本链不适用于draft），因此第一次 fetch结果除了与第二次重复没有用途。

可选实现：在 `_verify_schema` 中直接让 draft/company 路径由 `verify_draft_history` 获取/校验一次 history；catalog/released仍由外层查询。另一种实现是内部传递已读行给私有draft校验辅助函数，保持公开 `verify_draft_history` 独立调用仍实际读取；仓库独立调用仅有该函数自身和 `tests/kernel/test_draft_schema_history.py:112`。都必须保留唯一version0记录、原始合同来源、完整连续draft链、retained_digest、重复目标拒绝和当前合同终点。

这是**一个小型SQL重复**，不是整套fingerprint重复，也没有本轮可量化收益证据。若实施，验证应明确观察每次draft公司核验该SQL从2次变1次，并覆盖缺失/额外历史、未知原合同、断链/循环/未知迁移、身份/SQL篡改拒绝；不应扩大为跨请求缓存或弱化结构校验。

## 全局影响面清单

- CLI (`cli.py:132`) / MCP (`mcp.py:51`) 经 service.dispatch；非池Store读取仍经 `runtime.connect` + Store.validate_connection，共用versions。当前内部私有continuation只由resident pool调用；公共 `validate_reused_read_connection` 仍自带path/ACL。
- close (`periods.py` / `integrity.verify_close_integrity:1581`) 在公司连接与关账事务执行领域冻结完整核验；本候选仅影响通用draft历史相同SQL，不改冻结采用依据。
- full integrity (`maintenance.py:12`、`integrity.py:1229`) 在Store连接后核验业务/目录；不可以共享schema优化替代业务完整性。
- repair (`maintenance.py:41–106`, `read_indexes.py:897–954`) 前后核验和DDL/结果变更边界均应保留，特别是维修后显式verify_schema；本次无删减建议。
- backup/restore (`backup.py` :357/:611/:682/:718/:963/:1284/:1288) 对不同candidate/阶段显式verify_schema；不是同一快照重复，应保持便携包/源/目标验证。offline upgrade/development upgrade也共享versions且有前后事务/合同边界。
- retained v1 模块不直接定义/调用verify_schema或新resident guard；其冻结字节与内容规则仍通过现有连接由独立v1模块检查，scalar fast path明确跳过content_version1。本候选不改变v1领域语义或合同。

结论：保留当前borrow全边界；仅确认同一draft公司schema验证内重复读取schema_history这一小候选。共享层现有证据不足以解释主页面TTFB占总时长的大部分，需要继续在领域读取/核验源码和既有profile中寻找主要工作；本审计至此完成，停止IO。
