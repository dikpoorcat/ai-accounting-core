# 继承备份任务只读接续预检

2026-10-03；固定e0e包，目标 .tmp/stage9-final-draft-agent-current-runtime-published-20261003。按root本轮明确授权，只读该组已知合成任务表/ZIP和固定包执行代码；没有执行worker/run_jobs/retry_job、Engine、完整性能测试、重启或修改源库/ZIP。没有读取负责人/会话/私有表。记录依据为自己的生产jobs回执 bfe7c8138f8d4aa98f475f19677ff3eb.json，以及 query_only/mode=ro、仅SELECT jobs/identity的 inherited-job-preflight-read.json。

结论：目前唯一未终结任务为 portable_backup 9d68ff6bdc7545c5a363bb1223844f38，running/attempts1；ALL jobs共4行，另两backup及Q3 report_export均succeeded，付款导出和报表执行候选为空。该任务固定I/O payload只有 directory=D:/GitHub/ai-accounting-core/.tmp/stage9-draft-independent-ai-current-runtime-published-source-backup-20261003、rollover=false。输入数据库由生产绑定目标company/database决定，目标7830bf7b192946b8b22f96bf27746c51 / 684f6b25490542cd84c6ec86186f0d01；不是原source live库。

输出既有ZIP实际220640 bytes，SHA256 a91cf879434863593dd9dc3c41e38a047e62bf75ef55b01f82a4dd5fd7cfc321。实际ZIP manifest.request_id=该job9d68...，identity三字段与目标完全一致，draft/0/fingerprint与目标及原verified回执相同，内部company.sqlite字节SHA与manifest一致。原backup业务request key ind-ai-A-latest-external-published-manual-backup-20261003的自身回执0a31c1f9d0b14163a0d67c6487a5621d.json返回同job；manifest使用job ID而非业务request key，这是生产run_backup_jobs的实际规则。源任务成功/四项verified由原fa22d2b109554a4297081168d7f056be.json证明，不移作目标任务成功。

固定包实际路径：service.py:830的run_jobs分别执行backup、payment_export、report_export，limit=1是每队列最多1个，非全局或精确job过滤；不能一般性声称只会执行给定job。当前完整任务表证明另外两队列没有未终结候选；若执行前出现新任务，本结论失效。backup.py:1296选择portable_backup pending/running/failed且attempts<3，按attempts/id排序；目前只有9d68...可选，认领会把attempts1改2。其后create_portable(target live database, 固定原目录, request_id=jobID)，最后只更新目标该job的status/error/result；不新建公司或更改业务事实。

幂等分支：backup.py:1094先完整verify既有ZIP（路径/成员大小/manifest/内库hash/身份/结构/内容），1097要求manifest请求ID相同且当前输入库database_format相同；1103随后verify_file对当前target live数据库完整结构/业务源/历史采用/投影/读索引进行核验。通过后直接return existing + idempotent_replay=true，不进入新snapshot捕获、ZIP写入、rollover或文件替换。它不要求当前target所有表逐字节等于ZIP（认领本身就更新目标job），也不会让ZIP假含目标新receipt；新receipt仅保存于目标jobs。已有ZIP验证使用当前e0e固定bundle；允许的draft来源fallback在489行说明，仅对声明过的同体系来源合同核验，不能伪改manifest/build。本预检没有再执行完整verify，不能预先保证实际执行一定succeeded；最终必须读真实精确job/产物核验回执。

当前原输出目录没有rollover marker或rollover-previous文件，publication lock文件已存在；因此_recover_rollover无恢复动作，rollover=false保留既有ZIP。可证明这条成功幂等分支不写源公司数据库、ZIP内容或替换ZIP，不触其它原host；它仍会持有目标worker锁及原输出目录publication锁，产生验证用临时目录并清理。权限代码permissions.py:180、security/windows.py:308/274会调用Windows SetSecurityInfo收紧既有ZIP和锁文件的owner/DACL，因此不能把它描述为“任何源文件/文件系统元数据零写入”。严格要求连ACL/锁副作用都没有时，现有公开run_jobs不能满足，不能安全承诺。若root允许对这组既有合成备份的正常权限/锁检查，且继续保持无其它任务写入，可限定执行一次公开 run_jobs(company_id=甲,limit=1)，仅接续该唯一任务、随后jobs精确读取和ZIP字节SHA保护核对；不得启动JobRunner、不retry、不改目录、不执行其它target。

本预检不构成执行授权，也不计为继承任务恢复通过。由root决定是否按上述精确范围实际MCP执行。源/目标保留，未提交Git。