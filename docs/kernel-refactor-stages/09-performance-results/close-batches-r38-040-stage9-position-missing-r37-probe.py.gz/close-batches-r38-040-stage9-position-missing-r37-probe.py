"""Bounded read-only comparison of current position missing-typed selectors."""

import json
import sqlite3
from pathlib import Path


ROOT = Path(__file__).resolve().parent
BOOKS = {
    "main12_r36": ROOT / "stage9-reseed-main-12-r36/91310000123456789S/company.sqlite",
    "main48_r36_staging": ROOT / "stage9-reseed-main-48-r36.staging/91310000123456789S/company.sqlite",
}
LIMIT = 2_000_000
QUANTUM = 1000

QUERIES = {
    "original": (
        "WITH missing AS MATERIALIZED ("
        "SELECT f.id FROM subject s INDEXED BY subject_kind "
        "CROSS JOIN fact_revision f ON f.subject_id=s.id "
        "LEFT JOIN fact_report_classification c ON c.revision_id=f.id "
        "WHERE s.kind='report_classification' AND c.revision_id IS NULL) "
        "SELECT m.id FROM missing m WHERE EXISTS("
        "SELECT 1 FROM close_reference r INDEXED BY close_reference_lookup "
        "WHERE r.reference_type='fact' AND r.reference_id=m.id "
        "AND r.path='readiness.financial_reports.facts[*]' AND r.close_period<=?)"
    ),
    "flat_missing": (
        "SELECT f.id FROM subject s INDEXED BY subject_kind "
        "CROSS JOIN fact_revision f ON f.subject_id=s.id "
        "LEFT JOIN fact_report_classification c ON c.revision_id=f.id "
        "WHERE s.kind='report_classification' AND c.revision_id IS NULL "
        "AND EXISTS(SELECT 1 FROM close_reference r INDEXED BY close_reference_lookup "
        "WHERE r.reference_type='fact' AND r.reference_id=f.id "
        "AND r.path='readiness.financial_reports.facts[*]' AND r.close_period<=?)"
    ),
    "fact_first": (
        "SELECT f.id FROM subject s INDEXED BY subject_kind "
        "CROSS JOIN fact_revision f ON f.subject_id=s.id "
        "WHERE s.kind='report_classification' "
        "AND EXISTS(SELECT 1 FROM close_reference r INDEXED BY close_reference_lookup "
        "WHERE r.reference_type='fact' AND r.reference_id=f.id "
        "AND r.path='readiness.financial_reports.facts[*]' AND r.close_period<=?) "
        "AND NOT EXISTS(SELECT 1 FROM fact_report_classification c WHERE c.revision_id=f.id)"
    ),
    "reference_first": (
        "SELECT DISTINCT r.reference_id FROM close_reference r "
        "CROSS JOIN fact_revision f ON f.id=r.reference_id "
        "CROSS JOIN subject s ON s.id=f.subject_id "
        "LEFT JOIN fact_report_classification c ON c.revision_id=f.id "
        "WHERE r.close_period<=? AND r.path='readiness.financial_reports.facts[*]' "
        "AND r.reference_type='fact' AND s.kind='report_classification' "
        "AND c.revision_id IS NULL"
    ),
}


def run(db: Path):
    uri = db.resolve().as_uri() + "?mode=ro"
    conn = sqlite3.connect(uri, uri=True)
    try:
        conn.execute("PRAGMA query_only=ON")
        conn.execute("PRAGMA busy_timeout=1000")
        close_period = conn.execute("SELECT max(period) FROM period_close").fetchone()[0]
        month = close_period + 1
        indexes = [list(row) for row in conn.execute(
            "SELECT name,sql FROM sqlite_master WHERE type='index' "
            "AND tbl_name='close_reference' ORDER BY name"
        )]
        checks = {}
        for name, sql in QUERIES.items():
            plan = [list(row) for row in conn.execute("EXPLAIN QUERY PLAN " + sql, (month,))]
            steps = 0

            def progress():
                nonlocal steps
                steps += QUANTUM
                return int(steps >= LIMIT)

            conn.set_progress_handler(progress, QUANTUM)
            try:
                rows = sorted(row[0] for row in conn.execute(sql, (month,)))
                status = "complete"
            except sqlite3.OperationalError as exc:
                rows = None
                status = "interrupted" if "interrupted" in str(exc).lower() else str(exc)
            finally:
                conn.set_progress_handler(None, 0)
            checks[name] = {"sql": sql, "plan": plan, "vm_rounded_up": steps,
                            "status": status, "rows": rows}
        return {"db": str(db), "month_ordinal": month, "close_reference_indexes": indexes,
                "checks": checks}
    finally:
        conn.close()


if __name__ == "__main__":
    result = {name: run(db) for name, db in BOOKS.items()}
    target = ROOT / "stage9-position-missing-r37-probe.json"
    target.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(target)
    for book, item in result.items():
        print(book, item["month_ordinal"], [
            (name, value["status"], value["vm_rounded_up"],
             None if value["rows"] is None else len(value["rows"]))
            for name, value in item["checks"].items()
        ])
