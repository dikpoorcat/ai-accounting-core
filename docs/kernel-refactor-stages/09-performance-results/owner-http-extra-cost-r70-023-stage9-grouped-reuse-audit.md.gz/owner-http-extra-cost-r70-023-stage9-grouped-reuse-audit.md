# 第 9 阶段同次读取与核验复用：成组实施清单（2026-09-27）

此清单供下一轮集中实施，不是性能验收结果。本轮只读源码、已保存采样和旧工作量报告；没有新跑逐点实验、测试或改生产代码。基准范围是固定 r21 读取器与主规模 12／48 月合成库，120 月增长只作待验证外推。`stage9-release-main-48-verified-r21.json` 目前记录 `status=measuring`，不能冒充最终完整测量报告。r21/main48 的全进程 `measure_work` 插桩使并行简报回退，未形成有效工作量；原生请求三 worker 的 `attempt.finish` 曾正常完成。`.tmp/stage9-r21-main48-worker-work-isolated.py` 尚未运行，停止继续逐点补测。

实施边界：任何复用都限于同一 SQLite 只读事务或同一次完整核验里已经成功认证的精确身份、来源摘要、期间和范围；失败不缓存。默认 100 条明细、完整准备与关账核对、独立备份和修复验证保留。三 worker 的 `QueryReads` 证明不能传给父进程或别的 worker；整组读仍须通过首尾提交与数据库身份门禁。正式 v1 使用自己的冻结规则，不因当前源码更新而改写历史。可重建目录缺行不能作为“无来源”的证明。审查第 24 项的逐行报表投影已撤回，不重试。

## 已采用，集中回归时须保留

| 范围与调用者 | 已有决定及证据 | 防退化检查 |
| --- | --- | --- |
| 五页入口 `service.dashboard_context`、`Dashboard.context` 和各页 `Dashboard._snapshot` | 每个 HTTP／CLI／MCP 命令重新取得独立快照与 `read_context`；同一请求里的 `QueryReads` 缓存成功来源，不建立跨请求业务缓存。context 的季度覆盖使用本次 `reads`。 | 公司／期间切换、修复版本改变、写入夹在请求之间时响应或游标失效；不把独立请求的返回当核验事实。 |
| 简报 `Dashboard.brief` 默认 100 明细、`BriefParallelPool`、`Periods.collect_current_readiness` | 父进程一次装载本页结果、依赖与资料展示；三 worker 负责资料、查重、报表＋位置，父清偿行集只作为同组内部计算值，经 commit guard 一起接受。`month_journal.prime_summary` 共用笔数、分组和借贷合计。已有 r16 主 12 月串／并完整响应（除生成时间）等价证据 `.tmp/stage9-r16-main12-parallel-work-diagnostic.json`。 | 完整响应逐字段（只排除时间戳）、默认 100 条、issue 顺序、worker 故障／超时／缺包／写入／关闭回收、父异常与大 Pipe；分别记父和各进程 CPU、SQL VM、返回字节、解码及同时 RSS。 |
| 资料 `read_completeness_summary`、`_CompletenessInspectionCache`、`material_watch` | 普通页复用认证的冻结资料摘要，只重新检查变化和开放尾部；同次来源解析与 `source_changes_since` 有连接绑定缓存。完整核验仍重建全部覆盖。 | 后补／撤去资料、身份与分组更正、空月、原件损坏、连续变化区间、丢失可修目录行均不能假阴性；完整核验与普通页双路径。 |
| 查重 `DuplicateCandidates.unresolved`、`narrowed_duplicate_candidates` | 认证最近闭月根与过滤器后，按 `journal_highwater` 以来的变化找候选，命中仍核对原事实、位置和核对记录；没有闭月或过滤器不可用时走全量原规则。r16/main12 旧工作量中 materials 解析 7 份原件／1000 项，duplicates 解析 4 份／948 项，说明两进程有部分同月原件重读，但没有证明串行共享可降低整页关键路径。 | 过滤器缺失／损坏、目录缺行、future fact 到期、核对修订、首次登记与 source_change 断档；保留未命中不读正文的工作量断言。 |
| 报表与资产 `QueryReads`、开放贡献、`report_flow`、`settlement_projection`、`_selected_asset_members` | 同事务复用来源、直接采用与成员认证；开放报表仍使用不可变贡献正文，当前／v1 的凭证与分类候选已缩小。清偿只对可能自有贡献的计算装载祖先，身份及来源集合照核。资产成员先批量验证 owner，再一次取精确成员 metadata（本轮 49 项相关测试与 Ruff 通过）；固定 r19/main48 SQL 965→918，但预热 ABBA 的整段 CPU／wall 未稳定改善，不能记作过线收益。 | 直接采用、缺头、重复、历史冲正、空成员、错误关系、旧 v1 内容和同事务损坏拒绝。以实际 CPU／VM／字节与完整响应计，不以 SQL 次数单独定成功。 |
| 完整核验 `integrity._verify_close_integrity_snapshot`、`_check_closes` | 首轮 `decode_close` 得到 `decoded_closes`，交给 `_check_closes(predecoded_closes=...)`，这两个阶段**已避免**把同一闭月正文重新解一次；`_check_closes` 继续独立核对来源、采用、余额、目录。v1 owner/position 已在认证后的同连接 lease 中使用 `_verified_close_prefix`。 | 当前／v1：损坏、缺月、错连接、事务重开、历史期间、最终全块集合；重复解码数按期间记录，不能把传入列表当作未认证的跳检令牌。 |
| 备份、恢复、维修 | `create_portable` 的源快照与候选 ZIP 独立复验保持；此前评估同字节承接收益不明显，未改。`verify_portable`、恢复迁移后和 `rebuild_projections` 都继续从权威来源完整核验。 | ZIP 成员／大小／摘要／身份／格式、恢复后结构、损坏块及目录、回滚与多轮轮转；不能把同次候选结果持久化成“已核验”标记。 |

## 确认的剩余成本与下一组处理决定

1. **长历史关账预览先处理一次解码的真实成本，再判断二次遍历。** `Periods.preview_close → _manifest → verify_close_integrity → _verify_close_integrity_snapshot` 在最新 main48 预览采样 `.tmp/stage9-main48-r21b-preview-profile.txt` 的首分钟仍处首轮 `decode_close`；499 样本约 129 落 `_frozen_versions` SQL，约 100 落 JSON／字段桶。此时**还未**进入 `_check_closes`，故不能把该采样归咎于 owner review 重复。先在成组性能工作中统计每个 close 的字段桶查询、字节和 `decode_close` 次数，合批同一次解码内部的重复定位；不得跳过任何字段、根、封签或来源校验，也不得照搬审查 24 的 `close_rows` 两段式负面方案。只有首轮证明完成后，才检查 `close_review.verify_owner_review_integrity → build_owner_review` 的当前版是否再读相同已认证前缀；其接口没有 v1 的 `_verified_closes` 参数，属于**静态可疑、尚未动态证实**。若成立，仅由 `_check_closes` 在同连接成功证明后的 lease 传精确前缀，保留每期 owner 语义重建与独立首次验证；先验证完整输出／损坏拒绝和阶段 CPU，再实施。
2. **资料与查重跨 worker 读取相同当月变化和原件，但先不合并 worker。** r16/main12 插桩里两者都返回一条约 624 KB 的 `source_change` 区间；materials 7 次、duplicates 4 次原件解析。两条各在自己的事务中证明不同问题，且目前并行运行。把资料结果传到查重会增加等待依赖与跨进程证明边界，尚无净关键路径证据，**不实施**。后续只在真实整组计量里确认重复原件交集、各 worker 完成时点和 CPU；若要共享，只能把同一事务的共同原件认证与两个规则一起设计并证明 critical path 下降，不能借可修目录缺行推断空。
3. **默认简报与报表的本月报表来源仍是容量热点，重复程度未证实。** r16/main12 有效旧插桩：reports worker 约 9.85 MB 返回、1,004 份开放贡献解码；r19/main48 的 `_long_term_assets` cProfile 约 194 ms，其中四次 `calculations_of_kind` 约 183 ms、资产成员 88 ms。资产四类选择合并的私有 r19/main48 对照仅热态约 253→245 ms，但 VM 839.9k→874.3k、返回 2.896→2.937 MB，**不采用**；资产成员 metadata 合批则已采用但不宣称整页收益。接下来按父／report worker 对精确来源 ID 分组计数：同一 `QueryReads` 命中是否还重复 SQL、不同投影是否重复正文 JSON 解析，以及只有检查需要的字段与展示字段各是多少；直接依据仍保留完整 source/root/seal 检查。若仅节省几毫秒或增加返回正文，停止，不为 500 ms 指标添加新表或缓存层。
4. **context／默认明细／准备／关账核对的跨请求重叠有合同边界。** `Dashboard.context` 取公司、期间和季度完成；页面随后默认 100 明细、`period_preparation` 与 close-review 按自己的请求读一致快照。它们可能重读同月 header，却不共享事务或 `read_version`，当前**不得**把结果跨 HTTP 请求缓存成证明。仅检查同一个请求内 context 的季度覆盖、`Dashboard.brief` 默认页及 `Periods.collect_current_readiness` 是否两次走同范围 `QueryReads`；已有 `snap.preparation` 为 cached property，worker material/duplicate/report 在 `collect_current_readiness` 只取一次结果。按需详情必须仍验证精确选中对象、分页版本与来源，不能因首页已看过而跳读。
5. **缓存查找和集合遍历作为一组核对，不先建新索引层。** `QueryReads` 的 `_asset_members`、`metadata`、`fact_versions` 与关闭期块缓存均按精确 ID／期间命中；已见的资产成员逐 owner `metadata` 调用已合批。`Dashboard.asset_member_events` 在已有全量事件缓存时会为新的过滤集合重新遍历缓存列表，这是静态可见的潜在重复；默认简报是否重复请求多个不同集合、48／120 月真实扫描行数**未验证**。先记录每请求 key 数、全量事件长度和过滤次数；只有确认同快照多次大集合扫描，才考虑一次性建立精确按 kind／subject／asset 的临时索引，事务退出丢弃，仍按原 owner 证明产生事件。`Calculations.selected` 四类资产合并已做负面 AB，不能以“减少缓存键数”重新包装该方案。

## 覆盖面与尚未动态核验项

| 入口 | 同组审查焦点 | 目前结论／下一步 |
| --- | --- | --- |
| 五页 context、主数字、默认明细、准备与核对摘要 | `Dashboard.context`、`brief`、`funds`、`employees`、`assets`、`reports`、`period_preparation`；分页 100 | 简报并行与同次 `QueryReads` 已采用；其余各页的**同请求**重复来源 ID／字节尚无 r21/main48 完整分组，列为待核验。不得用 20 条或 deferred 替代默认体验。 |
| 按需详情、文件任务 | 资产／员工／资金／报表详情，close-review `read_collection`，文件生成 | 精确身份、分页、版本、原件证明必须保留；尚未做长历史同次重复工作量矩阵，按是否与首页同一事务分别登记。 |
| CLI、MCP、HTTP | `LocalService.dispatch` 共用校验与 `_dispatch` 业务读取；HTTP 另有响应合同转换 | 不为适配器另造缓存。尚未分别计合同转换与业务读取；若入口长尾不同，先量服务 native 与 HTTP JSON 而非删核验。 |
| 正式关账、预览、完整核验 | `Periods._manifest/close`、`integrity._verify_close_integrity_snapshot/_check_closes`、owner review、各冻结构造 | main48 预览采样证实首次历史解码本身很重；当前 owner 是否二次读取、各冻结构造重复权威装载尚需阶段计数。不能用待核验根自身作真值。 |
| 修复、备份／恢复、v1 | `Engine.rebuild_projections`、`verify_portable/create_portable`、Catalog 恢复、`content_history_context` 分流、`position_v1` | 完整独立复验保留；v1 prefix 已用同连接认证边界。当前版 owner 若优化须与 v1 不同规则各自回归；旧正式包、恢复目标与结构损坏分别覆盖。 |

v1 对照清单：`content_history_context` 按记录版本选择 `close_review_integrity_v1`、`position_v1`、`duplicate_freeze_v1`、`material_watch_v1`、`report_projection_v1`、`report_flow_v1/report_flow_rules_v1`、`report_open_contribution_v1`。当前版同名模块的复用优化不能自动套进这些固定规则；只在同一 v1 调用中减少已经成功认证的精确对象重复读取，并用非空正式 v1 包验证结果、损坏拒绝和离线升级／备份恢复。独立修复仍以全部已存集合和权威来源比较，不接受“页面已读过”的状态。

## 成组实施与验收顺序

1. 先统一一个**只读**的请求／核验阶段记录：以真实 `period`、入口、调用者、事务标识和来源 ID 摘要分组，记 wall／process CPU、SQL VM、返回行和值字节、事实／结果／贡献解码、原件解析、闭月字段块及峰值同时 RSS。插桩另跑，严禁混入 30 次纯浏览器计时；worker 插桩必须确认 `attempt.finish=true` 和完整响应等价，fallback 结果丢弃。
2. 按已证实的重复位置成组修：先降低单次闭月解码内部重复，再审 current owner 已认证前缀；随后检查同事务资料／查重与报表本月正文是否有无增量成本的复用。每个合并只传已认证且带完整身份／摘要／范围的值，失败不进入缓存。未出现实际 CPU／关键路径下降的候选撤回。
3. 一个回归组覆盖五页完整响应、默认 100 条、期间／公司切换、闭期更正、旧 v1、损坏／缺目录／错事务、关账预览与正式关账、完整核验、修复、备份和恢复。工作量断言用增长数据集确认无重复解码或按历史平方增长，且保护来源与校验数量；最后在暂停其他负载后跑 12／48／120 月各页 30 次真实浏览器整页，错误和慢样本全部保留。

保留负面依据：`docs/kernel-refactor-stages/09-performance-and-release.md`“未采用的优化”、`.tmp/stage9-r19-bucket-reuse-ab-summary.json`、`.tmp/stage9-r19-report-flow-open-selector-ab.json`、`.tmp/stage9-asset-selector-r19-diagnostic.json`、`.tmp/stage9-asset-member-metadata-production-abba.json`、`.tmp/stage9-r19-brief-gc-profile.json`。其中增量查重桶 48 月只省完整核验约 3–4%，跨月共用 `QueryReads` 令内存显著增加，第四 party worker 与逐行报表投影增加总工作量，均不进入本组成组重试。

## r21 主 48 月五页成组读取画像与窄改职责

后续成组插桩结果在 `.tmp/stage9-grouped-main48-r21-all-pages.json`。固定 r21 源、已登记完整核验的 main48、2019-12、默认 100 明细、完整准备；逐页单进程调用并按 SQLite VM、返回行和值字节计数。插桩本身显著增加 CPU，并与 120 月构建并行，以下 wall **只用于归属诊断，不是正式页面延迟或净收益**。此前纯浏览器 r21/main48 五页 median/max（ms）依次为简报 1038/1258、资金 467/795、员工 536/717、资产 1177/1575、报表 977/1236，全部未满足 500ms 上限。

| 同请求入口 | SQL 调用／VM／返回行／值字节 | 本次确认的主要重复或过宽选择；下一组决定 |
| --- | --- | --- |
| context | 339／0.093M／523／0.90MB | 47 个闭月各取 financial_reports readiness 小块用于季度覆盖，属精确已闭月检查；未证重复大正文。 |
| brief | 1994／7.84M／115172／29.23MB | `period_readiness` 一次；共同历史报表来源查询返 19,318 行／2.67MB，分类候选返 15,208 行／0.49MB。父、worker 隔事务各自认证不能相互注入证明，先缩各自精确消费范围。 |
| funds | 1157／5.82M／111848／27.83MB | 同样一次 `period_readiness`；共同历史来源选取占返回量，资金自身 `voucher_line_account` 两次共返 1008 行。核对用途后缩候选，保留资金业务验证。 |
| employees | 832／5.88M／129145／27.35MB | 同样一次 `period_readiness`；工资本身期间限制查询返 2400 行／0.35MB、1.13M VM，区别于五页共因。 |
| assets | 2412／24.76M／115315／32.46MB | 同样一次 `period_readiness`，但两个 `close_reference` 查询共约 19.6M VM、仅返 234 行：`QueryReads.verify_selected_voucher_adoptions` 和 `BusinessQueries._selected_accounting`/资产凭证调用。先以真实计划验证 `json_each` 与 `close_reference_lookup` 的驱动顺序；若只是把每个闭月引用全表反复扫描，固定候选驱动和索引后保持所有原返回行及 `verify_close_references`，不删任何后来引用或缺失判定。 |
| reports | 1090／11.15M／237948／39.61MB | `Dashboard.quarterly_report` 明确为季度三个月各调用一次 `_period_readiness`；它们的期末分别为 10/11/12 月，**不是完全相同的三个请求**。其中重复历史前缀与分类 ID 大集合，但各月报表准备事实、来源可不同。当前 `Reports._report` 已有同快照 `closes`、`closed_report_fact_sources`、`party_balance` 等精确 cutoff 缓存；由 read_impl 负责进一步缩 `_closed_report_fact_sources` 及真正消费的分类候选。我只在调用层核对是否有同月全检查重复，不取消任一月份的准备检查。 |

每个非 context 页面都有同形 19,318 行历史事实／凭证来源 SELECT、15,208 行分类候选 SELECT，还有一个仅返回 4–10 行却约 237k–696k VM 的 `fact_revision + subject` kind/period 查询；SQL 全文和单次指标在原始 JSON。本组将按调用者精确区分来源认证（必须）与非命中类型/期间扫描（可缩），不凭少量返回行推断无源。`period_readiness` 插桩每页约 2.8–3.9s，报表三次合计约 5.9s；嵌套计时会重叠，不与总时长相加。资产成员 metadata 合批已生效，本次仍有四次 `asset_member_events` 滤取；观察到资产页事件过滤 217ms／48 个输出、简报 99ms／48 个输出，需先确认过滤缓存扫描长度和是否同条件重复，再决定一次性临时索引，不改证明源。

晚分页窄范围：`Dashboard._external_collection` 先全取本期 `external_obligation` subject ID 再 `page_keys`，只有页内正文才读；`BusinessQueries.business_collection(source_history)` 先全取符合 scope 的 `(subject_id,revision,id)` 键再页内 `reads.facts`。两处可在 SQL 中分别做 COUNT 和有界稳定键集、LIMIT+1，游标 ID 必须在原完整筛选集合中精确存在，否则保持拒绝；页集合版本与总数仍依据全集合。需要无关对象、修订增长下的 VM／Python 实际装载量及结果等价回归。`events` 的采用/冲正全量证明不可直接 LIMIT；`file_jobs` 虽静态看到 summary、metadata、页内读取重合，但只有证明同请求成功构造重复才加事务内复用，当前不改。

上述候选的损坏保护：close_reference 缺行、重复或错误 path／position、不同 close_period 与同 voucher 后来引用，精确 ID 缺失、关闭／开放混合、闭期更正；报表三个月分别缺 profile／分类／结转；分页 after 不存在、跨类型游标、全集合版本写入变化。以原返回集合逐行对照及 12／48 增长 VM 防退化，失败路径不得把缓存写成成功。

资产 close_reference 计划已具体证实：`QueryReads.verify_selected_voucher_adoptions` 原 `json_each JOIN close_reference` 被 SQLite 排成先按 `reference_type` 扫所有引用、再遍历候选 ID；固定 r21/main48 只读原 DB 47 ID 的旧／新 SQL 均返完全相同 47 行，但 VM 9,305,100→1,000，插桩 wall 343.6→0.6ms；100 ID 为 19,318,800→2,100 VM，原始输出 `.tmp/stage9-close-reference-plan-r21-main48.txt` 由 `.tmp/stage9-close-reference-plan.py` 产生。新查询只固定 ID 为外循环，仍以 `close_period<=cutoff` 取所有后续引用并调用完整 `verify_close_references`。按 ID＋期＋path 的另一个查询旧计划已经先遍历候选并用 `(close_period,path)` 主键搜索，强迫 `close_reference_lookup` 反而全扫，因此保持原样。此项独立 SQL 改动已在当前源码；索引计划、真实闭月引用和删引用拒绝的定向测试，以及资产批读组均已通过。任何正式净页时延须另在无并行负载纯测，不能用这份插桩数据宣称过线。

晚分页两处已落当前源码并保留原完整 scope 的 COUNT、精确 after 是否在 scope 内、稳定键排序、LIMIT+1、全集合 total/filtered count 和既有页内事实/业务来源认证。固定 r21/main48 的 2019-12 `source_history` 私有只读原始记录 `.tmp/stage9-pagination-work-r21-main48.json`：旧先返回 2,550 个键／180,530 值字节／69,900 VM；新 COUNT＋100 页键仅 102 行／5,086 字节／9,800 VM，前 101 键逐项相等。该库无 external_obligation，故 external_followups 的正式样本收益**未被证实**。新增 `test_collection_keyset_work.py` 用 1,000 个目标修订＋4,000 无关修订、2,000 个目标义务＋4,000 无关对象独立计 VM，实际调用生产分页函数，断言其 VM 少于旧全量选键、只装载／请求页内 2 个身份、完整计数与游标接续不变；2 passed。另 `test_query_reads.py`、`test_dashboard_business_queries.py`、`test_dashboard_bounded_reads.py` 本组 67 passed（含资产 close_reference 和真实来源分页），所改文件 Ruff passed。报告中的旧／新 wall 是并行建库下 SQL 诊断，不能移作前台收益。

## 固定 r23/main48 对 r21/main48 的全页成组复核

同一 `.tmp/stage9-grouped-reuse-meter.py` 在固定 r23 源、同一 main48 公司/期间运行，原始记录 `.tmp/stage9-grouped-main48-r23-all-pages.json`，与 r21 原始记录逐页按 VM／返回行／值字节比较。r23 读取时 `.tmp/stage9-release-main-48-verified-r23.json` 仍为 `measuring`；本段只是并行核验/建库下的**诊断**，完整独立核验与纯浏览器时延须另报告。两次插桩相同但 wall/CPU 受并发扰动，不作胜负证据。

| 入口 | r21→r23 SQL VM | 返回行 | 返回值字节 | 诊断结论 |
| --- | ---: | ---: | ---: | --- |
| context | 0.093M→0.093M | 523→523 | 0.90→0.90MB | 无变化；季度闭月覆盖只取小 readiness 来源。 |
| brief | 7.84M→5.58M | 115,172→85,161 | 29.23→26.88MB | 历史报表分类/来源候选缩小，仍一次完整 `period_readiness`。 |
| funds | 5.82M→4.05M | 111,848→81,835 | 27.83→25.44MB | 同一准备路径收益，资金 movement 本身仍约 0.24M VM。 |
| employees | 5.88M→4.11M | 129,145→99,132 | 27.35→24.97MB | 同一准备路径收益，`dashboard_reads.adopted_head_metadata` 历史 head 窗口仍约 1.13M VM/2400行，属于不同于报表的精确采用选择，尚未证明重复。 |
| assets | 24.76M→13.68M | 115,315→85,302 | 32.46→30.07MB | 大幅下降后仍有独立旧 join 顺序查询；见下。 |
| reports | 11.15M→6.79M | 237,948→178,349 | 39.61→36.28MB | 季度 10/11/12 月三次不同 cutoff 的 `period_readiness` 原合同保留；进一步复用须证每月规则。 |

全量 native 响应原文分别在 `.tmp/stage9-grouped-main48-r21-responses.json`、`...r23-responses.json`，逐字段路径和未改写 SHA 在 `.tmp/stage9-grouped-main48-r21-r23-response-diff.json`。六个响应业务数字、列表、来源 ID、问题与准备字段完全相同；仅 context `generated_at`、brief `data.generated_at`、reports `checked_at` 为本次真实时间不同，五页 `read_context.read_version` 不同。**未删除 read_version 做比较**：其输入包括 `PROGRAM_VERSION`，固定 r21 为 `local-kernel-2:afe992...`、r23 为 `local-kernel-2:f96981...`；同一库的 epochs `(2065,1164,152)`、`read_repair_revision=0`，所以版本差异来自源码 build ID，不是维修写入。每页完整原始 SHA 见差异 JSON，正文同义结论仅针对上述逐字段例外。

仍在大扫描的具体路径和决定：

1. **资产 `dashboard_reads.Journal.hydrate` 仍旧 join 顺序。** r23 资产页 `SELECT r.* FROM json_each(?) ids JOIN close_reference r ON r.reference_id=ids.value WHERE r.reference_type='voucher' AND r.close_period<=?` 仍 9.305M VM、仅 47 行／8KB，约占该页 SQL VM 68%。这不是已改的 `QueryReads.verify_selected_voucher_adoptions`，而是默认凭证行 hydrate 的另一调用；同样先全扫 voucher 引用再匹配候选。属于确认重复大扫描，下一组可共用已证明的候选驱动 SQL 形态，但仍须保留所有截至 cutoff 的引用、每条 `verify_close_references`、缺行与跨闭月损坏拒绝。当前全后端回归期间**不改**。
2. **资产精确期/path 引用约 1.32M VM、234 行。** `BusinessQueries._selected_accounting` 等既有 SQL 是 JSON 候选先驱动、按 `(close_period,path)` 主键查询；强制旧 `close_reference_lookup` 的私有计划反而退化。没有安全证明能删掉错误 type/path 的拒绝，当前不改。
3. **报表分类和呈现剩余筛选由各规则拥有者确认。** brief 中 `dashboard._position` 的缺 typed 行异常探测约 0.49M VM／0 行、开放头约 0.38M VM／411 行；read_impl 正负责来源选择及这一路径，不能把 0 行误作无须损坏检查。reports 中 `Reports.browser_report_details` 对 `plan.report_fact_ids` 分组约 0.38M VM／3 行，属于实际计划来源计数；是否能同快照利用已认证类型须先证精确集合和损坏行为，当前不动。三次不同月准备不以相同 SQL 形态判重复。
4. **事实来源读取仍有必需范围。** 多页 `QueryReads` 本月来源批量核对 12 次合计约 4,932 行／0.78MB／0.19M VM，并非一条 19,318 行全历史盲读取；不把必要 source/root/seal 首验当成优化对象。`asset_member_events` 简报和资产仍各调用 4 次、总返回 48 行；仅有过滤次数，未量得相同键大列表重扫导致的净损，保持未验证，不加缓存。

A 类小 ID 集连接认证目录的全局位置/调用/计划/决定矩阵见 `.tmp/stage9-id-directory-query-audit.md`。其固定 r23/main48 只读计划/目录基数为 `.tmp/stage9-id-directory-plan-r23-main48.json`；包含 `Journal.hydrate` 旧同形 SQL 的遗漏根因、按期/path 的安全边界、job/audit/fullverify/修复/备份与正式 v1 分流。全后端回归期间没有因此修改生产或测试。

该 A 类矩阵已补充两份后续**私有诊断、未落生产**的证据。其一，`Journal.hydrate` 改为调用同 snapshot 的既有 `QueryReads.verify_close_references`，资产页完整响应除真实时间外相同，叶验证 187→140、accounting 读取 94→47；原始 `.tmp/stage9-journal-verified-leaf-ab-r23.json`。其二，`BusinessQueries._selected_accounting` 的 period/path 目录查询可用无 DDL 的 materialized tuple 半连接，固定 r23/main48 单月 47 候选 VM 331.4k→21.9k，跨三月 141 候选 994.3k→118.8k，返回字节及多重集不变，且合成错 type 行仍进入结果；原始 `.tmp/stage9-period-path-semijoin-ab-r23.json`。均在并行核验期间只比较工作量与语义，不代表纯页面时延；待当前全量回归结束后，按同组边界增回归再决定落地。
