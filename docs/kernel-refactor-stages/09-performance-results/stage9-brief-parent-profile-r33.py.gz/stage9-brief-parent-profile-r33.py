"""Production three-worker parent diagnosis against a named synthetic book."""
import cProfile
import json
import pstats
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / '.tmp/stage9-build-source-r33-release'
sys.path.insert(0, str(SOURCE / 'src'))

def main():
    assert Path(sys.prefix).resolve() == (ROOT / '.tmp-kernel-venv').resolve()
    from ai_accounting.kernel.daemon import _prepare_static_runtime
    from ai_accounting.kernel.dashboard import Dashboard
    from ai_accounting.kernel.service import LocalService
    book = json.loads((ROOT / '.tmp/stage9-release-main-48-verified-r32.json').read_text(encoding='utf-8'))
    assert book['status'] == 'complete'
    service = LocalService(book['root'], enable_read_pool=True, enable_parallel_brief=True,
                           _static_runtime=_prepare_static_runtime())
    try:
        engine = service.engine(book['company']['id'], dashboard_read=True)
        data = {'period': '2019-12', 'limit': 100, 'preparation': 'complete'}
        service._dashboard_brief(Dashboard(engine), engine, data)
        profile = cProfile.Profile()
        profile.enable()
        value = service._dashboard_brief(Dashboard(engine), engine, data)
        profile.disable()
        print('source', SOURCE, 'book verified source', book['source'])
        print('parent profile, not pure timing; static contracts unchanged', value.keys())
        stats = pstats.Stats(profile).sort_stats('cumtime')
        stats.print_stats(80)
        stats.print_callees('collect_current_readiness|_asset_card_sources|_long_term_assets|verify_selected_content')
        profile.dump_stats(str(ROOT / '.tmp/stage9-brief-parent-profile-r33.pstats'))
    finally:
        service.close()

if __name__ == '__main__':
    main()
