"""One fixed affected group for shared current proof and asset discovery reuse."""
import json
import os
import subprocess
import sys
from pathlib import Path

workspace = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(workspace / "scripts"))
from snapshot_stage9_source import _digest, _inventory

stem = workspace / ".tmp/stage9-r72-open-publication-related"
paths = {suffix: Path(str(stem) + suffix) for suffix in (".log", ".xml", ".json", "-command.txt")}
if any(path.exists() for path in paths.values()):
    raise FileExistsError("Do not replace earlier results")
tests = [
    "test_open_publication_snapshot_work.py", "test_owner_asset_repeated_reads.py",
    "test_current_adoption_damage.py", "test_publication_record_proof_reuse.py",
    "test_publication_period_reuse.py", "test_required_money_header_reuse.py",
    "test_report_selector_header_reuse.py", "test_journal_source_header_reuse.py",
    "test_open_correction_publication_heads.py", "test_open_correction_source_heads.py",
    "test_publication_v1_voucher_heads.py", "test_owner_asset_metadata_scope.py",
    "test_asset_owner_outcome_reads.py", "test_owner_asset_card_page_scope.py",
    "test_open_voucher_scope_work.py", "test_payroll_corrections.py", "test_report_projection.py",
]
command = [sys.executable, "-X", "utf8", "-m", "pytest", "-q", "-ra",
           *("tests/kernel/" + name for name in tests), "--junitxml=" + str(paths[".xml"])]
before = _inventory(workspace)
with paths["-command.txt"].open("x", encoding="utf-8") as output:
    output.write(subprocess.list2cmdline(command) + "\n")
with paths[".log"].open("xb") as output:
    result = subprocess.run(command, cwd=workspace, stdout=output, stderr=subprocess.STDOUT,
                            env=os.environ | {"PYTHONUNBUFFERED": "1"})
after = _inventory(workspace)
evidence = {"returncode": result.returncode, "files": tests,
            "before_sha256": _digest(before), "after_sha256": _digest(after),
            "source_unchanged": before == after, "before_files": before, "after_files": after}
with paths[".json"].open("x", encoding="utf-8") as output:
    json.dump(evidence, output, ensure_ascii=False, indent=2)
print(json.dumps({key: value for key, value in evidence.items() if not key.endswith("_files")}))
sys.exit(result.returncode if before == after else 2)
