import hashlib
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
prefix=ROOT/'.tmp/stage9-r75-owner-frontend'
old=json.loads(Path(str(prefix)+'-validation.json').read_text(encoding='utf-8'))
new=json.loads(Path(str(prefix)+'-postfix-validation.json').read_text(encoding='utf-8'))
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
changed={p:{'before_recovery_fix':old['after'].get(p),'after_recovery_fix':new['before'].get(p)}
         for p in sorted(set(old['after'])|set(new['before'])) if old['after'].get(p)!=new['before'].get(p)}
result={'complete':new['complete'],'full_test':{'total':153,'passed':153,'failed':0},
        'previous_full_test':{'total':150,'passed':148,'failed':2,'preserved_log':'.tmp/stage9-r75-owner-frontend-test.log'},
        'changed_by_recovery_fix':changed,'validation_source_hashes_unchanged':new['changed_files']==[],
        'targeted_overlap':{'earlier_28_all_in_153':True,'new_recovery_directed_40_all_in_153':True,
                           'current_three_original_files':{'dashboard-context-v2.test.mjs':22,'dashboard-render-v2.test.mjs':5,'brief-close-review-prefetch.test.mjs':4},
                           'do_not_add_counts':True},
        'coverage':{'continuation_paths':{'Brief':['activity','open_items'],'Funds':['book','bank','investment','accounts','investment_products'],
                                        'Employees':['employees','labor_sources','payroll first','payroll continuation'],'Assets':['assets','projects']},
                    'explicit_version_mismatch':['Employees/loadMore','Assets/loadMore'],
                    'detail_changed_parent_refresh':['Brief direct and forwarded activity/open_items','Funds','Employees','Assets'],
                    'Reports':'no continuation/detail version recovery; manual refresh retention unchanged',
                    'guards':'existing company/period/filter generation guards and BusinessStatusDetails scoped emission retained'},
        'dom_provenance':'r74 fixture final precedes recovery fix; source attribution uses pre-fix validation before hashes. Manual retention is unchanged, but no new browser/HTTP acceptance claimed for this post-fix source.',
        'evidence_files':{str(p.relative_to(ROOT)).replace('\\','/'):digest(p) for p in sorted((ROOT/'.tmp').glob('stage9-r75-owner-frontend*.log'))},
        'final_release_outputs':{str(p.relative_to(ROOT)).replace('\\','/'):digest(p) for p in sorted((ROOT/'src/ai_accounting/static/dashboard').rglob('*')) if p.is_file()}}
output=Path(str(prefix)+'-final.json');assert not output.exists()
output.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
report=Path(str(prefix)+'-final.md');assert not report.exists()
report.write_text('''# r75 前端收敛验收

修复后统一执行一次全前端测试和一次正式 build:release：153/153通过，contracts:check、vue-tsc、vite --mode release通过。Node24.19.0，Python仓库venv；未用开发mode。日志、命令及before/after源码hash均独立保存为stage9-r75-owner-frontend-postfix-*。验收期间捕获的五View、测试及生成合同hash无变化。

首次150项有2失败（148通过），原stdout与修复前构建均保留，不回写、不和153加总。一次40项恢复定向检查也全部属于153，早期28项同样全部属于153；原三文件现为22+5+4=31项。

修复保持手动同选择刷新隐藏旧组件。明确dashboard_snapshot_changed、Employees/Assets continuation显式响应版本变化、BusinessStatusDetails向父级发出的changed全部走refreshChanged：先清主投影/旧版本/旧分页，持续loading，然后并行读取context及主结果，二者均通过后才能显示。Brief转发组件activity/open_items也接通失效刷新；Reports没有分页/业务详情恢复入口，手动刷新路径不变。共享详情仍同步清其旧结果并只在本身公司/业务/月份/快照generation有效时emit；未改共享组件/API。

三项新恢复测试按实际入口覆盖13条读取/续页路径（Brief2、Funds5、Employees4、Assets2）：失效立即清空，context先完成仍不提交主金额或宣告成功；旧A-B-A失败不得再发恢复请求；四父changed及两显式version mismatch清空。既有公司/月份晚到main成功、catch/finally隔离、Funds旧恢复通知及详情来源隔离覆盖继续通过。资金手动刷新旧null断言改为保持原对象+loading、新bank-b不可提前提交，未删门控断言。

正式构建生成静态dashboard输出；最终输出hash列于stage9-r75-owner-frontend-final.json。r74 DOM最终及失败/early回执列表已在stage9-r75-owner-frontend-receipts.json记录，r74 final实际使用此次恢复修复之前的Vue源，不能当作后修复browser验收。后修复仅统一前端检查，没有HTTP/preview/真实数据/性能测试；主任务将统一固定新candidate及严格browser验收。

本次仅改Brief/Funds/Employees/Assets恢复区分及相关现有context/funds/details测试；此前Reports的隐藏挂载改动保留。没有修改代理/vite配置/AGENTS，没有提交，没有复制海量archives。所有执行进程已经退出。
''',encoding='utf-8')
print(json.dumps({'complete':result['complete'],'changed_by_fix':list(changed),'output':str(output)},ensure_ascii=False))
