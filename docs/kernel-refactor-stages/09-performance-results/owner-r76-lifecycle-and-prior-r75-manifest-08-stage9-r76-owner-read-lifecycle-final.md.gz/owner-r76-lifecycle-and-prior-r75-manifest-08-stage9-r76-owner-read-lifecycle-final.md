# 生命周期修复最终回执

14项定向全部通过：4项current/v1临时视图成功/异常生命周期，2项owner工资来源与解析，4项固定v1分类选择/损坏规则，4项工资确认展示/core历史绑定。此前10项9通过1失败保存在stage9-r76-owner-read-lifecycle-tests.log，不覆盖、不加总。

旧失败是已退出老板看板的payroll_confirmation技术字段断言。保留来源绑定语义：改从BusinessQueries完整业务读取验证published calculation ID及confirmation_fact_id，并断言Dashboard gross金额不变、技术键不存在。相关同类测试已迁到core/诊断/trace，未发现同范围第二个旧UI确认技术字段正向断言，未回填页面payload。

修改仅close_review.py、close_review_integrity_v1.py、position_v1.py，必要测试test_close_review_lifecycle.py及parse_reuse测试。current/v1财务position临时视图都在完整计算完成/失败后的finally释放；外部_frozen_position给定分支不构造/释放任何调用者对象。五页已有snapshot finally保持；QueryReads/readpool/verified lease退出不变。

静态范围及必要存活边界详见stage9-r76-owner-read-lifecycle-report.md。新固定v1 AST实际source digests列在final.json，和简单文件SHA256分开标明；这不是新candidate正式content合同SHA。两固定v1文件在内容指纹范围，原合同没有改，主任务必须生成新隔离candidate并核实际content新指纹，不沿用旧8abd；原raw manifest仍按原source归属保全。

未调用GC、未改GC策略、无性能/浏览器/全后端验证、无真实业务资源或提交。所有测试进程已退出。构造中失败尚未故障注入，不把可回收cycle或82860 tracked当不可回收泄漏，不报告未经测量的延迟收益。
