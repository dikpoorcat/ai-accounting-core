"""Two bounded employee tests runs, with sealed kernel and explicit test provenance."""
import contextlib
import hashlib
import json
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[1]
mode = sys.argv[1]
if mode == "old":
    source = root / ".tmp/stage9-build-source-owner-cache-group-20261003-release"
    expected = "19ae7d824077e8e988ffe254120f7d8ee7ed42708c5fdf8fb6eff2ffb3e49941"
    tests = source / "tests/kernel"
    prefix = "stage9-employee-line-scope-old-p3-original"
    selected = [str(tests / "test_dashboard_workforce_assets.py") +
                "::test_employee_line_scope_preserves_open_and_closed_responses"]
elif mode == "new":
    source = root / ".tmp/stage9-build-source-owner-read-groups-20261003-release"
    expected = "46f84508afd54165f23af5a83434b1881002ab45490f4358f0c1755c743748be"
    tests = root / "tests/kernel"
    prefix = "stage9-payroll-line-fixture-corrected-final-format"
    selected = [str(tests / "test_payroll_head_line_scope.py")]
else:
    raise ValueError("Explicit old/new mode required")
manifest_path = source / "source-manifest.json"
manifest_bytes = manifest_path.read_bytes()
manifest = json.loads(manifest_bytes)
assert manifest["sha256"] == expected
log = root / ".tmp" / (prefix + ".log")
report = root / ".tmp" / (prefix + ".json")
if log.exists() or report.exists():
    raise ValueError("Evidence outputs must be new")
sys.path.insert(0, str(tests))
sys.path.insert(0, str(source / "src"))
from ai_accounting.kernel import dashboard
assert Path(dashboard.__file__).resolve() == source / "src/ai_accounting/kernel/dashboard.py"
import pytest

tracked = {}

def remember(path):
    path = path.resolve()
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    if path.is_relative_to(source):
        assert actual == manifest["files"][path.relative_to(source).as_posix()]
    tracked[str(path)] = actual

for item in selected:
    remember(Path(item.split("::")[0]))
arguments = [*selected, "-q", "-s", "--junitxml=" + str(root / ".tmp" / (prefix + ".xml"))]
assert not Path(arguments[-1].split("=", 1)[1]).exists()
with log.open("x", encoding="utf-8", newline="\n") as output:
    with contextlib.redirect_stdout(output), contextlib.redirect_stderr(output):
        print(json.dumps({"kernel_source_sha256": expected, "test_root": str(tests),
                          "manifest_file_sha256": hashlib.sha256(manifest_bytes).hexdigest(),
                          "arguments": arguments, "selected_test_sha256": tracked}, ensure_ascii=False))
        exit_code = int(pytest.main(arguments))
for name, module in tuple(sys.modules.items()):
    raw = getattr(module, "__file__", None)
    if not raw:
        continue
    path = Path(raw).resolve()
    if name.startswith("ai_accounting"):
        assert path.is_relative_to(source / "src"), (name, str(path))
        remember(path)
    elif name.startswith("test_") and path.suffix == ".py":
        assert path.is_relative_to(tests), (name, str(path))
        remember(path)
assert manifest_path.read_bytes() == manifest_bytes
for path, fingerprint in tracked.items():
    assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == fingerprint
value = {"status": "passed" if exit_code == 0 else "tests_failed",
         "pytest_exit_code": exit_code, "kernel_source_sha256": expected,
         "manifest_file_sha256": hashlib.sha256(manifest_bytes).hexdigest(),
         "tests_source": "sealed_old_snapshot" if mode == "old" else "current_repository",
         "arguments": arguments, "loaded_module_sha256": tracked,
         "fingerprints_unchanged": True, "full_log": log.relative_to(root).as_posix(),
         "browser_acceptance": False}
with report.open("x", encoding="utf-8", newline="\n") as output:
    json.dump(value, output, ensure_ascii=False, indent=2)
    output.write("\n")
print(json.dumps({"status": value["status"], "exit_code": exit_code,
                  "report": str(report), "log": str(log)}))
raise SystemExit(exit_code)
