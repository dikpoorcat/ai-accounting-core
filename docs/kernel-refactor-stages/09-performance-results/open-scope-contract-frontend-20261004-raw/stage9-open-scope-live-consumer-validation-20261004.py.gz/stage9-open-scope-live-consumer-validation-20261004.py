"""Validate fresh current-backend synthetic HTTP responses in generated consumers."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

workspace=Path(__file__).resolve().parents[1]
prefix=workspace/'.tmp/stage9-open-scope-live-consumer-validation-20261004'
receipt_path=Path(str(prefix)+'.json')
samples=Path(str(prefix)+'-samples.json')
assert Path(sys.prefix).resolve()==workspace/'.tmp-kernel-venv'
assert not samples.exists() and not receipt_path.exists()
manifest=json.loads((workspace/'.tmp/stage9-build-source-open-scope-group-candidate-20261004/source-manifest.json').read_text(encoding='utf-8'))
assert manifest['sha256']=='24b9b8b65723cee8c6982b1f41235dce380e62788db33f100176f92c714571fc'
names=[name for name in manifest['files'] if name.startswith(('src/ai_accounting/kernel/','src/ai_accounting/payroll/','frontend/src/api/generated/'))]
names+=['tests/kernel/response_samples.py','frontend/scripts/check-contract-samples.mjs']
def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()
before={name:sha(workspace/name) for name in names}
for name,value in before.items():
    if name in manifest['files']:
        assert value==manifest['files'][name]
node=Path('D:/Program Files/nodejs/node.exe')
env=dict(os.environ)
env['PATH']=str(node.parent)+os.pathsep+str(workspace/'.tmp-kernel-venv/Scripts')+os.pathsep+env.get('PATH','')
env['PYTHONDONTWRITEBYTECODE']='1'
commands=[('backend-samples',[sys.executable,'-B','-X','utf8','tests/kernel/response_samples.py',str(samples)]),
          ('generated-consumers',[str(node),'frontend/scripts/check-contract-samples.mjs',str(samples)])]
results=[]
for name,command in commands:
    log=Path(str(prefix)+'-'+name+'.log');assert not log.exists()
    started=time.perf_counter()
    with log.open('x',encoding='utf-8') as handle:
        result=subprocess.run(command,cwd=workspace,env=env,stdout=handle,stderr=subprocess.STDOUT)
    results.append({'name':name,'command':command,'exit_code':result.returncode,
                    'elapsed_seconds':time.perf_counter()-started,'log':str(log),'log_sha256':sha(log)})
    if result.returncode:
        break
after={name:sha(workspace/name) for name in names}
data=json.loads(samples.read_text(encoding='utf-8')) if samples.exists() else None
receipt={'status':'passed' if len(results)==2 and all(item['exit_code']==0 for item in results) and before==after else 'failed',
    'source_sha256':manifest['sha256'],'files_before':before,'files_unchanged':before==after,
    'fresh_backend_samples':True,'samples_path':str(samples),
    'sample_sha256':sha(samples) if samples.exists() else None,
    'sample_count':len(data) if data else None,'commands':results,
    'fixture_or_product_files_overwritten':False,'browser_timing':False}
with receipt_path.open('x',encoding='utf-8') as handle:
    json.dump(receipt,handle,ensure_ascii=False,indent=2);handle.write('\n')
print(json.dumps({key:value for key,value in receipt.items() if key not in ('files_before','commands')},ensure_ascii=False))
assert receipt['status']=='passed'
