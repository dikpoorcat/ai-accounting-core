"""Prepare one current frontend group because its prior inputs have changed."""
from pathlib import Path
import hashlib
import json

workspace=Path(__file__).resolve().parents[1]
template=workspace/'.tmp/stage9-reference-group-frontend-validation.py'
target=workspace/'.tmp/stage9-open-scope-current-frontend-validation-20261004.py'
assert not target.exists()
text=template.read_text(encoding='utf-8')
text=text.replace("PREFIX = ROOT / '.tmp/stage9-reference-group-frontend'", "PREFIX = ROOT / '.tmp/stage9-open-scope-current-frontend-20261004'")
text=text.replace(".tmp/stage9-build-source-owner-reference-group-20261003-release/source-manifest.json", ".tmp/stage9-build-source-open-scope-group-candidate-20261004/source-manifest.json")
text=text.replace('9de4a38ae2f93fc575d5a68898ad3cba334ab4dc5786c67731a6c1eead1d52b5',
                  '9d81e82d7e2637637cc052cd42ff80946c6a0274264473d53f1d22a6f48fcef5')
text=text.replace('6688df6c46f5416ca03917def0d29a701cb20e8ae45b962c59df4a1290f8da62',
                  '24b9b8b65723cee8c6982b1f41235dce380e62788db33f100176f92c714571fc')
text=text.replace("re.findall(r'^# (tests|suites|pass|fail|cancelled|skipped|todo) (\\d+)\\s*$', contents, re.MULTILINE)",
                  "re.findall(r'^(?:#|ℹ) (tests|suites|pass|fail|cancelled|skipped|todo) (\\d+)\\s*$', contents, re.MULTILINE)")
compile(text,str(target),'exec')
target.write_text(text,encoding='utf-8',newline='\n')
print(json.dumps({'helper':str(target),'helper_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),
                  'prior_unchanged_scope_not_claimed':True}))
