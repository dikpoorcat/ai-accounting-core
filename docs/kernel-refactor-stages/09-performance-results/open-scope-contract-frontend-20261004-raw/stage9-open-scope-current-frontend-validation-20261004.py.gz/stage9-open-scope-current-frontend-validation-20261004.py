"""One authorized frontend verification group; never regenerate source contracts."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
FRONTEND = ROOT / 'frontend'
NODE = Path('D:/Program Files/nodejs/node.exe')
NPM = NODE.parent / 'node_modules/npm/bin/npm-cli.js'
VENV = ROOT / '.tmp-kernel-venv'
PREFIX = ROOT / '.tmp/stage9-open-scope-current-frontend-20261004'
SUMMARY = Path(str(PREFIX) + '-summary.json')
STAGES = (
    ('contracts', ['run', 'contracts:check']),
    ('samples', ['run', 'contracts:samples', '--', 'tests/fixtures/dashboard-contracts.json']),
    ('tests', ['run', 'test']),
    ('release-build', ['run', 'build:release']),
)
LOGS = {name: Path(str(PREFIX) + '-' + name + '.log') for name, _ in STAGES}
assert Path(sys.prefix).resolve() == VENV
assert not SUMMARY.exists() and all(not path.exists() for path in LOGS.values())


def digest_file(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def inventory():
    result = {}
    for relative in ('frontend/src', 'src/ai_accounting/static/dashboard', 'frontend/dist'):
        directory = ROOT / relative
        assert directory.is_dir(), relative
        files = {}
        for path in sorted(directory.rglob('*')):
            assert not path.is_symlink(), str(path)
            if path.is_file():
                files[path.relative_to(directory).as_posix()] = digest_file(path)
        encoded = json.dumps(files, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()
        result[relative] = {'file_count': len(files), 'sha256': hashlib.sha256(encoded).hexdigest(), 'files': files}
    return result


def difference(before, after):
    result = {}
    for root in before:
        old, new = before[root]['files'], after[root]['files']
        result[root] = {
            'added': sorted(new.keys() - old.keys()),
            'removed': sorted(old.keys() - new.keys()),
            'changed': sorted(key for key in old.keys() & new.keys() if old[key] != new[key]),
            'same': old == new,
        }
    return result


def main():
    env = dict(os.environ)
    env['VIRTUAL_ENV'] = str(VENV)
    env['PYTHON'] = str(VENV / 'Scripts/python.exe')
    env['PYTHON_EXECUTABLE'] = str(VENV / 'Scripts/python.exe')
    env['PATH'] = os.pathsep.join((str(NODE.parent), str(VENV / 'Scripts'), env.get('PATH', '')))
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    env.pop('FINANCE_DATA_ROOT', None)
    version = subprocess.run([str(NODE), '--version'], capture_output=True, text=True, check=True).stdout.strip()
    assert version == 'v24.19.0', version
    sample_path = FRONTEND / 'tests/fixtures/dashboard-contracts.json'
    samples = json.loads(sample_path.read_text('utf-8'))
    sealed_manifest = ROOT / '.tmp/stage9-build-source-open-scope-group-candidate-20261004/source-manifest.json'
    pinned = '9d81e82d7e2637637cc052cd42ff80946c6a0274264473d53f1d22a6f48fcef5'
    assert digest_file(sealed_manifest) == pinned
    report = {
        'status': 'running', 'pid': os.getpid(), 'node': str(NODE), 'node_version': version,
        'python': str(VENV / 'Scripts/python.exe'), 'cwd': str(FRONTEND),
        'source': str(sealed_manifest.parent),
        'source_sha256': '24b9b8b65723cee8c6982b1f41235dce380e62788db33f100176f92c714571fc',
        'sealed_manifest_before_sha256': pinned,
        'sample_path': str(sample_path), 'sample_file_before_sha256': digest_file(sample_path),
        'sample_count': len(samples),
        'sample_counts_by_command': {key: sum(item['command'] == key for item in samples.values())
                                     for key in sorted({item['command'] for item in samples.values()})},
        'python_selection': 'Generator/checker consume existing schema/sample JSON; no Python generation. Node local-api test explicitly uses repo venv python; env PATH/PYTHON/VIRTUAL_ENV pinned.',
        'inventory_before': inventory(), 'stages': {}, 'started_epoch': time.time(),
        'contracts_generated': False, 'controller_run': False,
    }
    try:
        for name, args in STAGES:
            if name == 'release-build':
                report['inventory_before_release_build'] = inventory()
            command = [str(NODE), str(NPM), *args]
            started = time.perf_counter()
            with LOGS[name].open('x', encoding='utf-8') as log:
                log.write(json.dumps({'command': command, 'cwd': str(FRONTEND), 'node_version': version,
                                      'python': env['PYTHON']}, ensure_ascii=False) + '\n')
                log.flush()
                completed = subprocess.run(command, cwd=FRONTEND, env=env,
                                           stdout=log, stderr=subprocess.STDOUT, check=False)
            contents = LOGS[name].read_text('utf-8', errors='replace')
            stage = {'command': command, 'exit_code': completed.returncode,
                     'elapsed_seconds': time.perf_counter() - started,
                     'log': str(LOGS[name]), 'log_sha256': digest_file(LOGS[name])}
            if name == 'tests':
                stage['counts'] = {key: int(value) for key, value in
                                   re.findall(r'^(?:#|ℹ) (tests|suites|pass|fail|cancelled|skipped|todo) (\d+)\s*$', contents, re.MULTILINE)}
            elif name == 'samples':
                stage['validated_samples'] = len(samples) if completed.returncode == 0 else None
            report['stages'][name] = stage
            print(json.dumps({'stage': name, 'exit_code': completed.returncode,
                              'counts': stage.get('counts'), 'validated_samples': stage.get('validated_samples')}, ensure_ascii=False), flush=True)
        report['inventory_after'] = inventory()
        report['overall_inventory_difference'] = difference(report['inventory_before'], report['inventory_after'])
        report['release_build_difference'] = difference(report['inventory_before_release_build'], report['inventory_after'])
        report['source_files_unchanged'] = report['overall_inventory_difference']['frontend/src']['same']
        report['sample_file_after_sha256'] = digest_file(sample_path)
        report['sealed_manifest_after_sha256'] = digest_file(sealed_manifest)
        assert report['sealed_manifest_after_sha256'] == pinned, 'Sealed source manifest changed'
        report['status'] = 'passed' if all(stage['exit_code'] == 0 for stage in report['stages'].values()) else 'failed'
    except BaseException as error:
        report['status'] = 'runner_failed'
        report['error'] = {'type': type(error).__name__, 'message': str(error)}
        raise
    finally:
        report['finished_epoch'] = time.time()
        with SUMMARY.open('x', encoding='utf-8') as output:
            json.dump(report, output, ensure_ascii=False, indent=2)
            output.write('\n')
        print(json.dumps({'status': report['status'], 'summary': str(SUMMARY)}, ensure_ascii=False), flush=True)
    return 0 if report['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
