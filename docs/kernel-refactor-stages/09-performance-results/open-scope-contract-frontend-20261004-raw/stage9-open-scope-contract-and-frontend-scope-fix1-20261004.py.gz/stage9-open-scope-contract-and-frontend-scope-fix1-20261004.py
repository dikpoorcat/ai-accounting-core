"""Check current model exports and unchanged frontend validation scope once."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

workspace = Path(__file__).resolve().parents[1]
prefix = workspace/'.tmp/stage9-open-scope-contract-and-frontend-scope-20261004'
output = Path(str(prefix)+'.json')
assert Path(sys.prefix).resolve() == workspace/'.tmp-kernel-venv'
assert not output.exists()
source = workspace/'.tmp/stage9-build-source-open-scope-group-candidate-20261004'
manifest = json.loads((source/'source-manifest.json').read_text(encoding='utf-8'))
assert manifest['sha256']=='24b9b8b65723cee8c6982b1f41235dce380e62788db33f100176f92c714571fc'
prior_path = workspace/'.tmp/stage9-reference-group-frontend-summary-final.json'
prior = json.loads(prior_path.read_text(encoding='utf-8'))
assert prior['status']=='passed'
previous_source = Path(prior['source'])
previous_manifest = json.loads((previous_source/'source-manifest.json').read_text(encoding='utf-8'))

def sha(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle,'sha256').hexdigest()

scope = {}
for name in ('frontend/src','frontend/tests','frontend/scripts','src/ai_accounting/static/dashboard'):
    paths = {p.relative_to(workspace).as_posix():sha(p) for p in (workspace/name).rglob('*') if p.is_file()}
    previous = {key:value for key,value in previous_manifest['files'].items() if key.startswith(name+'/')}
    current = {key:value for key,value in manifest['files'].items() if key.startswith(name+'/')}
    scope[name] = {'files':paths, 'current_sealed_match':paths==current,
                   'previous_sealed_match':paths==previous,
                   'changed_since_previous':sorted(key for key in paths.keys()|previous.keys() if paths.get(key)!=previous.get(key))}
    if name=='frontend/scripts':
        scope[name]['not_in_source_manifest']=True
        scope[name]['prior_validation_scope_unproven']=True
    else:
        assert scope[name]['current_sealed_match']
for name in ('frontend/package.json','frontend/package-lock.json','frontend/tsconfig.json','frontend/vite.config.ts'):
    assert sha(workspace/name)==manifest['files'][name]
    scope[name]={'current_sha256':sha(workspace/name),
                'previous_sha256':previous_manifest['files'].get(name),
                'unchanged_since_previous':sha(workspace/name)==previous_manifest['files'].get(name)}
commands = [
    ('database-contracts',[sys.executable,'-B','-X','utf8','scripts/export_kernel_schema_contracts.py','--check']),
    ('response-model-export',[sys.executable,'-B','-X','utf8','scripts/export_dashboard_response_schemas.py','--check']),
]
results=[]
for name,command in commands:
    log=Path(str(prefix)+'-'+name+'.log')
    assert not log.exists()
    started=time.perf_counter()
    with log.open('x',encoding='utf-8') as handle:
        result=subprocess.run(command,cwd=workspace,stdout=handle,stderr=subprocess.STDOUT)
    results.append({'name':name,'command':command,'exit_code':result.returncode,
                    'elapsed_seconds':time.perf_counter()-started,'log':str(log),'log_sha256':sha(log)})
frontend_same=all(item.get('previous_sealed_match',item.get('unchanged_since_previous',False)) for key,item in scope.items() if key!='frontend/scripts')
receipt={'status':'passed' if all(item['exit_code']==0 for item in results) else 'failed',
    'source_sha256':manifest['sha256'],'commands':results,'scope':scope,
    'frontend_scope_same_as_prior_passed_validation':frontend_same,
    'prior_frontend_summary':str(prior_path),'prior_frontend_summary_sha256':sha(prior_path),
    'prior_frontend_stages':prior['stages'],
    'frontend_tests_or_build_repeated':False,
    'generation_script_prior_scope_unproven':True,
    'claim':'Scope equality reuses unchanged frontend unit/type/build proof only; not current backend, HTTP or browser performance proof',
    'current_scope_unchanged':all(sha(workspace/name)==value for item in scope.values() for name,value in item.get('files',{}).items()),
}
with output.open('x',encoding='utf-8') as handle:
    json.dump(receipt,handle,ensure_ascii=False,indent=2);handle.write('\n')
print(json.dumps({key:value for key,value in receipt.items() if key not in ('commands','scope','prior_frontend_stages')},ensure_ascii=False))
assert receipt['status']=='passed' and receipt['current_scope_unchanged']
