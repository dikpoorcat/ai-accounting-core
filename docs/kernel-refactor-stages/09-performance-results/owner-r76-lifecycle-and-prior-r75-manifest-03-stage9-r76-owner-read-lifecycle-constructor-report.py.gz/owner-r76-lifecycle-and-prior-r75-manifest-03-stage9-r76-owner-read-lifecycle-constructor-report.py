import hashlib
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
prefix=ROOT/'.tmp/stage9-r76-owner-read-lifecycle-constructor'
paths=['src/ai_accounting/kernel/dashboard.py','src/ai_accounting/kernel/close_review.py',
       'src/ai_accounting/kernel/close_review_integrity_v1.py','src/ai_accounting/kernel/position_v1.py',
       'tests/kernel/test_close_review_lifecycle.py']
result={'complete':True,'targeted':{'total':6,'passed':6,'failed':0},
        'previous_14_preserved':'.tmp/stage9-r76-owner-read-lifecycle-postfix-tests.log',
        'source_sha256':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths},
        'new_changes':['dashboard.py initialization failure release boundary','test_close_review_lifecycle actual source read failure for current/v1'],
        'v1_constructor_unchanged_reason':'all source SQL/decode before last self.journal assignment; reverse journal constructor only assigns inputs and there is no later business operation',
        'fixed_v1_source_digest_unchanged_from_previous_lifecycle_fix':True,
        'limits':['no GC collection/strategy','no browser/timing/full regressions','caller transaction and original SQLite DatabaseError preserved']}
output=Path(str(prefix)+'-final.json');assert not output.exists()
output.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
report=Path(str(prefix)+'-final.md');assert not report.exists()
report.write_text('''# 构造失败生命周期收口

新增修改仅src/ai_accounting/kernel/dashboard.py和tests/kernel/test_close_review_lifecycle.py。_Snapshot构造在ClosedPeriods反向helper建立后仍有close读取、monthly_account SQL、metadata构造等失败点；现在__init__以窄_initialize调用边界捕获BaseException，先复用release，再原异常raise。成功和活动调用不提前清空，调用方事务不回滚/提交。

固定v1 PositionInputsV1实际顺序：verified prefix校验、V1Reads构造、trial/month voucher读取、首个close读取/解码、opening calculation读取，都在journal之前。唯一反向边是末句self.journal=_V1SelectedJournal(self)；该journal构造只赋self.inputs，末句之后没有源读取或业务操作。因此没有需要修复的cycle后业务失败点，不强行改固定历史构造。此前position计算完成/异常finally release保留。

6项生命周期定向全通过（4项已覆盖current/v1完整owner review成功/position异常，加2项构造源读取失败）。新测试实际用SQLite authorizer拒绝monthly_account/period_close读取，不匹配_initialize/release方法名或用mock替代初始化。current拒绝发生时真实ClosedPeriods helper已建立；异常traceback仍持view时__dict__已空且helper弱引用立即消失；丢弃traceback后view立即释放。v1拒绝发生在journal建立前，丢弃traceback后view同样立即释放。都保持原DatabaseError含实际被拒表、caller transaction仍有效，无GC调用。

此前14项通过及原9/10失败回执全部保留，此轮不重跑整组/前端/密码/浏览器/性能。fixedv1 AST指纹相对此前生命周期修复没有再次变化，但新候选仍须按此前两个fixedv1改动重新生成内容指纹，原合同未修改。所有执行进程已退出。sourceSHA及完整定向stdout分别在constructor-final.json和constructor-tests.log。
''',encoding='utf-8')
print(json.dumps({'complete':True,'passed':6,'source_sha256':result['source_sha256']}))
