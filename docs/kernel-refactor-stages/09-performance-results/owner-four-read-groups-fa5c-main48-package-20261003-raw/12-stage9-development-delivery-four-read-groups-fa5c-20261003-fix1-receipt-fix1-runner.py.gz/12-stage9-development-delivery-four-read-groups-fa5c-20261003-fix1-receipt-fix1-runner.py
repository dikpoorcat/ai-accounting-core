import hashlib
import json
from pathlib import Path
import re
import sqlite3
import sys
import zipfile
from datetime import UTC, datetime

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def inventory(root):
    files = {}
    for path in sorted(root.rglob('*')):
        assert not path.is_symlink() and not path.is_junction()
        if path.is_file():
            files[path.relative_to(root).as_posix()] = sha(path)
        else:
            assert path.is_dir()
    return files

source = Path(sys.argv[1]).resolve(strict=True)
package = Path(sys.argv[2]).resolve(strict=True)
receipt_path = package.with_name(package.name + '-receipt-fix1.json')
assert not receipt_path.exists()
assert sys.version_info[:3] == (3, 12, 13) and sqlite3.sqlite_version == '3.53.1'
assert sys.flags.isolated == 1 and sys.flags.dont_write_bytecode == 1
assert not any(n.startswith('ai_accounting') for n in sys.modules)
sys.path[:0] = [str(source / 'src'), str(source / 'scripts')]
from prepare_stage9_main120 import require_manifest
from snapshot_stage9_source import _inventory, _digest
expected_source_sha = 'fa5c7074031755dd8dcf7682198d735c6e6070f704d8c4699a34b5229e489877'
expected_manifest_sha = '00c86f83316ab784c7d0184dce1df8aecefd56af14af30465d694e053c79f370'
require_manifest(source, expected=expected_source_sha)
assert sha(source / 'source-manifest.json') == expected_manifest_sha
source_manifest = json.loads((source / 'source-manifest.json').read_text(encoding='utf-8'))
assert source_manifest['file_count'] == 752
source_before = inventory(source)
expected_names = set(source_manifest['files']) | {'source-manifest.json'}
extras_before = set(source_before) - expected_names
assert not expected_names - set(source_before)
assert all('__pycache__' in Path(name).parts and name.endswith('.pyc') for name in extras_before)
assert _inventory(source) == source_manifest['files']
import ai_accounting
from ai_accounting.kernel import build, schema_bundle
for module, relative in [(ai_accounting, 'src/ai_accounting/__init__.py'), (build, 'src/ai_accounting/kernel/build.py'), (schema_bundle, 'src/ai_accounting/kernel/schema_bundle.py')]:
    assert Path(module.__file__).resolve() == source / relative
bundle = schema_bundle.production_bundle()
assert bundle.status == 'draft' and dict(bundle.current_versions) == {'catalog': 0, 'company': 0} and set(bundle.company_verifiers) == {0}
formats = {kind: bundle.database_format(kind) for kind in ('catalog', 'company')}
source_build_id = build.calculator_build_id()
relocated = package.with_name(package.name + '-relocated')
archive_path = package.with_name(package.name + '.zip')
manifest_path = package / 'manifest.json'
verification_path = package.with_name(package.name + '-verification.json')
wrapper_receipt_path = package.with_name(package.name + '-receipt.json')
process_path = package.with_name(package.name + '-process-exit-evidence.json')
manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
verification = json.loads(verification_path.read_text(encoding='utf-8'))
wrapper = json.loads(wrapper_receipt_path.read_text(encoding='utf-8'))
process_evidence = json.loads(process_path.read_text(encoding='utf-8-sig'))
assert wrapper['status'] == 'failed' and wrapper['error']['type'] == 'AssertionError'
assert "assert verification['cli_calls'] == 160" in wrapper['error']['traceback']
assert wrapper['selected_source_inventory_unchanged'] is True
assert verification['status'] == 'passed'
assert verification['runtime'] == manifest['runtime']
assert manifest['source_build_id'] == manifest['runtime']['build_id'] == source_build_id == wrapper['source_build_id']
assert verification['runtime']['python'] == '3.12.13' and verification['runtime']['sqlite'] == '3.53.1' and verification['runtime']['isolated'] == 1
assert verification['database_formats'] == manifest['runtime']['database_formats'] == formats
assert verification['packaged_offline_upgrade'] is None
assert all(value is True for key, value in verification.items() if isinstance(value, bool))
assert verification['debit_fen'] == verification['credit_fen']
assert process_evidence['remaining_package_python_processes'] == 0
assert process_evidence['package_prefix'] == str(package)
manifest_sha = sha(manifest_path)
assert sha(relocated / 'manifest.json') == manifest_sha
expected_software = set(manifest['files']) | {'manifest.json'}
package_inventory = inventory(package)
assert set(package_inventory) == expected_software
for name, item in manifest['files'].items():
    assert sha(package / name) == sha(relocated / name) == item['sha256']
    assert (package / name).stat().st_size == (relocated / name).stat().st_size == item['bytes']
with zipfile.ZipFile(archive_path) as archive:
    names = archive.namelist()
    assert len(names) == len(set(names)) and set(names) == expected_software
    for name in names:
        assert not Path(name).is_absolute() and '..' not in Path(name).parts
        assert archive.getinfo(name).file_size == (package / name).stat().st_size
    assert hashlib.sha256(archive.read('manifest.json')).hexdigest() == manifest_sha
    archive_entry_count = len(names)
historical = {}
source_modules = {}
for relative in manifest['application_modules']:
    source_name = 'src/ai_accounting/' + relative
    package_name = 'app/ai_accounting/' + relative
    assert source_name in source_manifest['files']
    assert manifest['files'][package_name]['sha256'] == source_manifest['files'][source_name]
    source_modules[source_name] = source_manifest['files'][source_name]
    if relative.startswith('kernel/') and Path(relative).name.endswith('_v1.py'):
        historical[source_name] = {'source_sha256': source_manifest['files'][source_name], 'package_path': package_name, 'package_sha256': manifest['files'][package_name]['sha256']}
all_historical_source = {name for name in source_manifest['files'] if name.startswith('src/ai_accounting/kernel/') and Path(name).name.endswith('_v1.py')}
assert set(historical) == all_historical_source
decoder_names = ['close_contract.py', 'close_storage.py', 'content_history_context.py', 'replay_close.py', 'verified_close_archive.py', 'content_v1.py', 'history_encoding_v1.py', 'history_reads_v1.py', 'close_storage_v1.py']
decoder_hashes = {}
for name in decoder_names:
    relative = 'src/ai_accounting/kernel/' + name
    assert relative in source_modules
    decoder_hashes[relative] = source_modules[relative]
contracts = {name: item['sha256'] for name, item in manifest['files'].items() if name.startswith('app/ai_accounting/kernel/schema_contracts/')}
assert 'app/ai_accounting/kernel/schema_contracts/draft.json' in contracts
assert 'app/ai_accounting/kernel/schema_contracts/content-v1.json' not in contracts
assert not (package / 'app/ai_accounting/kernel/security/legacy.py').exists()
for launcher in ['finance-local.cmd', 'finance-local.ps1']:
    assert 'kernel-draft' in (package / launcher).read_text(encoding='utf-8')
inputs = package.with_name(package.name + '-relocated-validation') / 'inputs'
input_names = sorted(path.name for path in inputs.glob('*.json'))
assert len(input_names) == verification['cli_calls']
verify_code = (source / 'scripts/verify_local_package.py').read_text(encoding='utf-8')
assert 'calls += 1' in verify_code and 'jobs = call("jobs", {"company_id": company_id}, root=root)' in verify_code
source_after = inventory(source)
extras_after = set(source_after) - expected_names
assert not expected_names - set(source_after)
assert all('__pycache__' in Path(name).parts and name.endswith('.pyc') for name in extras_after)
require_manifest(source, expected=expected_source_sha)
assert _inventory(source) == source_manifest['files']
assert {name: source_before[name] for name in expected_names} == {name: source_after[name] for name in expected_names}
receipt = {
    'status': 'passed', 'mode': 'read_only_evidence_audit_after_successful_default_package_selfcheck',
    'no_package_or_cli_or_mcp_or_selfcheck_rerun': True,
    'source': str(source), 'source_sha256': expected_source_sha,
    'source_manifest_sha256': expected_manifest_sha,
    'source_selected_file_count': len(source_manifest['files']),
    'source_selected_inventory_before': source_manifest['files'],
    'source_selected_inventory_after': _inventory(source),
    'source_inventory_before': source_before, 'source_inventory_after': source_after,
    'source_selected_inventory_unchanged': True,
    'source_full_inventory_unchanged_during_audit': source_before == source_after,
    'derived_caches_before': {n: source_before[n] for n in sorted(extras_before)},
    'derived_caches_after': {n: source_after[n] for n in sorted(extras_after)},
    'source_inventory_before_sha256': _digest(source_before),
    'source_inventory_after_sha256': _digest(source_after),
    'actual_source_module_files': {module.__name__: str(Path(module.__file__).resolve()) for module in [ai_accounting, build, schema_bundle]},
    'runner': str(Path(__file__).resolve()), 'runner_sha256': sha(Path(__file__).resolve()),
    'command_argv': [sys.executable, '-I', '-B', '-X', 'utf8', str(Path(__file__).resolve()), str(source), str(package)],
    'actual_build_command_argv': wrapper['command_argv'],
    'actual_build_runpy_argv': wrapper['runpy_argv'],
    'actual_build_runner_sha256': wrapper['runner_sha256'],
    'actual_build_stdout_sha256': sha(package.with_name(package.name + '-build.stdout.log')),
    'actual_build_stderr_sha256': sha(package.with_name(package.name + '-build.stderr.log')),
    'original_wrapper_receipt': str(wrapper_receipt_path),
    'original_wrapper_receipt_sha256': sha(wrapper_receipt_path),
    'original_wrapper_status': wrapper['status'], 'original_wrapper_error': wrapper['error'],
    'original_wrapper_failure_analysis': 'An obsolete exact CLI count assertion failed after successful product selfcheck; no product validation failed.',
    'cli_call_count_actual': verification['cli_calls'], 'cli_request_input_count': len(input_names),
    'cli_count_source_basis': {'script': str(source / 'scripts/verify_local_package.py'), 'sha256': sha(source / 'scripts/verify_local_package.py'), 'counter_initialization_line': 1309, 'counter_increment_lines': [1315, 1371], 'backup_poll_loop_lines': [1407, 1414], 'explanation': 'call and call_rejected increment calls; wait_for_backup invokes jobs repeatedly until the background job succeeds, so total calls depend on completion timing.'},
    'fixed_assumptions_audit': {'source_count_752': 'explicit fixed-source requirement and actual manifest count; retained', 'source_manifest_sha': 'new fa5c manifest hash; retained', 'cli_160': 'old observed count only; rejected as gate; actual159', 'historical_module_33': 'computed exact historical source set equality; observed count recorded', 'build_id_and_fingerprints': 'derived from active fa5c source production bundle and compared with actual package selfcheck', 'source_file_set': 'same generator inventory must equal manifest; only derived __pycache__ pyc extra files allowed', 'package_file_set': 'original software package and ZIP index exact; relocated software files immutable, synthetic default launcher data is expected after selfcheck'},
    'package': str(package), 'relocated': str(relocated), 'archive': str(archive_path),
    'archive_sha256': sha(archive_path), 'archive_bytes': archive_path.stat().st_size,
    'package_manifest_sha256': manifest_sha, 'archive_entry_count': archive_entry_count,
    'software_file_count': len(manifest['files']),
    'every_original_and_relocated_software_file_verified_against_manifest': True,
    'zip_index_and_manifest_verified': True,
    'zip_byte_content_verified_by_default_builder_before_selfcheck': True,
    'verification': str(verification_path), 'verification_sha256': sha(verification_path),
    'verification_result': verification,
    'source_build_id': source_build_id, 'package_source_build_id': manifest['source_build_id'],
    'packaged_actual_calculator_build_id': verification['runtime']['build_id'],
    'database_formats': formats,
    'all_packaged_source_module_hashes': source_modules,
    'historical_v1_module_count': len(historical), 'historical_v1_modules': historical,
    'current_and_historical_decoder_source_hashes': decoder_hashes,
    'packaged_contracts': contracts, 'packaged_offline_upgrade': None,
    'package_services_exit_evidence': process_evidence,
    'package_services_exit_evidence_sha256': sha(process_path),
    'finished_at': datetime.now(UTC).isoformat(),
}
with receipt_path.open('x', encoding='utf-8', newline='\n') as stream:
    json.dump(receipt, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
print(json.dumps({'receipt': str(receipt_path), 'receipt_sha256': sha(receipt_path), 'status': receipt['status'], 'cli_calls': receipt['cli_call_count_actual'], 'historical_v1_modules': len(historical), 'software_files': len(manifest['files']), 'archive_sha256': receipt['archive_sha256'], 'manifest_sha256': manifest_sha, 'verification_sha256': receipt['verification_sha256'], 'source_build_id': source_build_id}, ensure_ascii=False, indent=2))
