import hashlib
import json
import os
from pathlib import Path
import runpy
import sqlite3
import sys
import traceback
from datetime import UTC, datetime

SOURCE_SHA = 'fa5c7074031755dd8dcf7682198d735c6e6070f704d8c4699a34b5229e489877'
MANIFEST_SHA = '00c86f83316ab784c7d0184dce1df8aecefd56af14af30465d694e053c79f370'

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def full_inventory(root):
    result = {}
    for path in sorted(root.rglob('*')):
        assert not path.is_symlink() and not path.is_junction(), str(path)
        if path.is_file():
            result[path.relative_to(root).as_posix()] = sha(path)
        else:
            assert path.is_dir(), str(path)
    return result

def write_new(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')

source = Path(sys.argv[1]).resolve(strict=True)
output = Path(sys.argv[2]).resolve()
runner = Path(__file__).resolve()
receipt_path = output.with_name(output.name + '-receipt.json')
targets = [output, output.with_name(output.name + '.zip'), output.with_name(output.name + '-relocated'), output.with_name(output.name + '-verification.json'), output.with_name(output.name + '-relocated-validation'), receipt_path]
assert not any(p.exists() for p in targets), 'Preserve existing targets'
assert sys.version_info[:3] == (3, 12, 13) and sqlite3.sqlite_version == '3.53.1'
assert sys.flags.isolated == 1 and sys.flags.dont_write_bytecode == 1
assert not any(n.startswith('ai_accounting') for n in sys.modules)
os.environ.pop('FINANCE_DATA_ROOT', None)
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
sys.path[:0] = [str(source / 'src'), str(source / 'scripts')]
from prepare_stage9_main120 import require_manifest
from snapshot_stage9_source import _inventory, _digest
require_manifest(source, expected=SOURCE_SHA)
assert sha(source / 'source-manifest.json') == MANIFEST_SHA
source_manifest = json.loads((source / 'source-manifest.json').read_text(encoding='utf-8'))
assert source_manifest['file_count'] == 752
before = full_inventory(source)
expected_source_files = set(source_manifest['files']) | {'source-manifest.json'}
extra_before = set(before) - expected_source_files
assert not (expected_source_files - set(before))
assert all('__pycache__' in Path(name).parts and name.endswith('.pyc') for name in extra_before)
assert _inventory(source) == source_manifest['files']
import ai_accounting
from ai_accounting.kernel import schema_bundle, build
assert Path(ai_accounting.__file__).resolve() == source / 'src/ai_accounting/__init__.py'
assert Path(schema_bundle.__file__).resolve() == source / 'src/ai_accounting/kernel/schema_bundle.py'
assert Path(build.__file__).resolve() == source / 'src/ai_accounting/kernel/build.py'
bundle = schema_bundle.production_bundle()
assert bundle.status == 'draft' and dict(bundle.current_versions) == {'company': 0, 'catalog': 0} and set(bundle.company_verifiers) == {0}
source_build_id = build.calculator_build_id()
formats = {kind: bundle.database_format(kind) for kind in ('company', 'catalog')}
script = source / 'scripts/package_local_kernel.py'
receipt = {
    'status': 'running', 'started_at': datetime.now(UTC).isoformat(),
    'source': str(source), 'source_sha256': SOURCE_SHA,
    'source_manifest_sha256': MANIFEST_SHA, 'source_file_count': 752,
    'source_inventory_before': before, 'runner': str(runner),
    'runner_sha256': sha(runner), 'interpreter': sys.executable,
    'python': sys.version.split()[0], 'sqlite': sqlite3.sqlite_version,
    'isolated': sys.flags.isolated, 'dont_write_bytecode': sys.flags.dont_write_bytecode,
    'command_argv': [sys.executable, '-I', '-B', '-X', 'utf8', str(runner), str(source), str(output)],
    'runpy_argv': [str(script), '--output', str(output)],
    'package_script_sha256': sha(script),
    'verification_script_sha256': sha(source / 'scripts/verify_local_package.py'),
    'source_build_id': source_build_id, 'source_database_formats': formats,
    'initial_module_files': {name: str(Path(module.__file__).resolve()) for name, module in [('ai_accounting', ai_accounting), ('schema_bundle', schema_bundle), ('build', build)]},
    'default_validation_skipped': False,
}
failure = None
try:
    sys.argv = [str(script), '--output', str(output)]
    runpy.run_path(str(script), run_name='__main__')
    manifest_path = output / 'manifest.json'
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    verification_path = output.with_name(output.name + '-verification.json')
    verification = json.loads(verification_path.read_text(encoding='utf-8'))
    assert verification['status'] == 'passed'
    assert verification['runtime'] == manifest['runtime']
    assert manifest['source_build_id'] == manifest['runtime']['build_id'] == source_build_id == build.calculator_build_id()
    assert manifest['runtime']['database_formats'] == verification['database_formats'] == formats
    assert manifest['runtime']['python'] == '3.12.13' and manifest['runtime']['sqlite'] == '3.53.1' and manifest['runtime']['isolated'] == 1
    assert verification['packaged_offline_upgrade'] is None
    assert verification['cli_calls'] == 160
    required = ('backup_verified_and_restored', 'background_backup_without_manual_run', 'native_approved_close_backup_restored_and_frozen', 'closed_period_correction_uses_posting_period', 'closed_snapshot_unchanged_after_correction', 'corrected_backup_verified_and_restored', 'relative_imports_only', 'http_page_and_authenticated_api', 'dashboard_five_routes_and_legacy_entries', 'dashboard_current_schemas_and_collections', 'relative_cmd_and_powershell_launchers', 'launchers_default_to_packaged_root', 'stdio_mcp_handshake_and_query', 'synthetic_credentials_revoked_and_removed')
    assert all(verification[key] is True for key in required)
    historical = {}
    for relative, digest in source_manifest['files'].items():
        path = Path(relative)
        if relative.startswith('src/ai_accounting/kernel/') and (path.name.endswith('_v1.py') or path.name == 'content_v1.py'):
            package_relative = 'app/ai_accounting/' + path.relative_to('src/ai_accounting').as_posix()
            module_relative = path.relative_to('src/ai_accounting').as_posix()
            assert module_relative in manifest['application_modules']
            assert manifest['files'][package_relative]['sha256'] == digest
            assert sha(output / package_relative) == sha(output.with_name(output.name + '-relocated') / package_relative) == digest
            historical[relative] = {'source_sha256': digest, 'packaged_path': package_relative, 'packaged_sha256': manifest['files'][package_relative]['sha256']}
    assert len(historical) == 33, len(historical)
    contracts = {name: item['sha256'] for name, item in manifest['files'].items() if name.startswith('app/ai_accounting/kernel/schema_contracts/')}
    assert 'app/ai_accounting/kernel/schema_contracts/draft.json' in contracts
    assert 'app/ai_accounting/kernel/schema_contracts/content-v1.json' not in contracts
    assert not (output / 'app/ai_accounting/kernel/security/legacy.py').exists()
    for launcher in ('finance-local.cmd', 'finance-local.ps1'):
        assert 'kernel-draft' in (output / launcher).read_text(encoding='utf-8')
    imported = {}
    for name, module in tuple(sys.modules.items()):
        if name.startswith('ai_accounting') and getattr(module, '__file__', None):
            path = Path(module.__file__).resolve()
            assert path.is_relative_to(source / 'src/ai_accounting'), (name, path)
            imported[name] = str(path)
    receipt.update({
        'status': 'passed', 'package': str(output),
        'archive': str(output.with_name(output.name + '.zip')),
        'archive_sha256': sha(output.with_name(output.name + '.zip')),
        'package_manifest_sha256': sha(manifest_path),
        'verification': str(verification_path), 'verification_sha256': sha(verification_path),
        'package_source_build_id': manifest['source_build_id'],
        'packaged_actual_calculator_build_id': verification['runtime']['build_id'],
        'package_database_formats': formats,
        'verification_result': verification,
        'historical_v1_module_count': len(historical), 'historical_v1_modules': historical,
        'packaged_contracts': contracts, 'actual_source_imports': imported,
        'zip_and_relocated_inventory_verified_by_default_package_builder': True,
        'packaged_offline_upgrade': None,
    })
except BaseException as error:
    failure = error
    receipt.update({'status': 'failed', 'error': {'type': type(error).__name__, 'message': str(error), 'traceback': traceback.format_exc()}})
finally:
    try:
        require_manifest(source, expected=SOURCE_SHA)
        after = full_inventory(source)
        extra_after = set(after) - expected_source_files
        assert not (expected_source_files - set(after))
        assert all('__pycache__' in Path(name).parts and name.endswith('.pyc') for name in extra_after)
        assert _inventory(source) == source_manifest['files']
        assert {n: before[n] for n in expected_source_files} == {n: after[n] for n in expected_source_files}
        receipt.update({'full_source_inventory_unchanged': before == after, 'derived_cache_before': {n: before[n] for n in sorted(extra_before)}, 'derived_cache_after': {n: after[n] for n in sorted(extra_after)}, 'source_selected_inventory_before': source_manifest['files'], 'source_selected_inventory_after': _inventory(source)})
        assert sha(source / 'source-manifest.json') == MANIFEST_SHA
        receipt.update({'source_inventory_after': after, 'selected_source_inventory_unchanged': True, 'source_inventory_before_sha256': _digest(before), 'source_inventory_after_sha256': _digest(after), 'source_manifest_sha256_after': sha(source / 'source-manifest.json')})
    except BaseException as error:
        failure = error
        receipt.update({'status': 'failed', 'source_recheck_error': {'type': type(error).__name__, 'message': str(error), 'traceback': traceback.format_exc()}})
    receipt['finished_at'] = datetime.now(UTC).isoformat()
    write_new(receipt_path, receipt)
if failure is not None:
    raise failure
