import inspect
import sys
import textwrap
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

import pytest
from ai_accounting.kernel import reports

method = textwrap.dedent(inspect.getsource(reports.Reports._report))
original = "reuse_end_totals = bool(closes) and _owns_current_selector_snapshot(reads, connection)"
assert method.count(original) == 1
method = method.replace(original, "reuse_end_totals = False")
namespace = {}
exec(compile(method, "<report-reuse-disabled-baseline>", "exec"), reports.__dict__, namespace)
reports.Reports._report = namespace["_report"]

raise SystemExit(pytest.main([
    "tests/kernel/test_opening_continuation.py::test_midyear_report_supplement_after_close_is_an_explicit_frozen_reference",
    "--junitxml=.tmp/stage9-owner-report-disable-reuse-baseline-20261003.xml",
    "-q",
]))
