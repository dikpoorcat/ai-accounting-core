"""Pure timing control for this owned synthetic main48 run only."""
import ctypes
from ctypes import wintypes
import json, subprocess, time
from pathlib import Path

workspace = Path(__file__).resolve().parents[1]
output = workspace / '.tmp/stage9-owner-current-consumption-AB-control-20261003.json'
assert not output.exists()
kernel = ctypes.WinDLL('kernel32', use_last_error=True)
nt = ctypes.WinDLL('ntdll')
kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
kernel.OpenProcess.restype = wintypes.HANDLE
kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
kernel.WaitForSingleObject.restype = wintypes.DWORD
kernel.CloseHandle.argtypes = [wintypes.HANDLE]
nt.NtSuspendProcess.argtypes = [wintypes.HANDLE]
nt.NtSuspendProcess.restype = ctypes.c_long
nt.NtResumeProcess.argtypes = [wintypes.HANDLE]
nt.NtResumeProcess.restype = ctypes.c_long

class FILETIME(ctypes.Structure):
    _fields_ = [('low', wintypes.DWORD), ('high', wintypes.DWORD)]

kernel.GetProcessTimes.argtypes = [wintypes.HANDLE, *([ctypes.POINTER(FILETIME)] * 4)]

def times(handle):
    values = [FILETIME() for _ in range(4)]
    assert kernel.GetProcessTimes(handle, *[ctypes.byref(v) for v in values])
    return dict(zip(('creation', 'exit', 'kernel', 'user'),
                    [v.high * 2**32 + v.low for v in values]))

def processes():
    command = 'Get-CimInstance Win32_Process | Select-Object ProcessId,ParentProcessId,CommandLine | ConvertTo-Json -Compress'
    result = subprocess.run(['powershell', '-NoProfile', '-Command', command],
                            capture_output=True, text=True, check=True)
    return {p['ProcessId']: p for p in json.loads(result.stdout)}


import hashlib
parents = {
 13520:(54044,'benchmark_stage9_browser.py','stage9-draft-runtime-main120-20261003'),
 29828:(13520,'benchmark_stage9_browser.py','stage9-draft-runtime-main120-20261003'),
 51132:(58128,'stage9_package_agent_harness.py','stage9-final-draft-agent-fix1-20261003'),
 27232:(52292,'stage9_restore_agent_harness.py','stage9-final-draft-agent-restore-20261003'),
 39716:(23008,'stage9_restore_agent_harness.py','stage9-final-draft-agent-current-runtime-20261003'),
 5244:(46856,'stage9_restore_agent_harness.py','stage9-final-draft-agent-current-runtime-published-20261003'),
}
state={'status':'started','scope':'owned_synthetic_only','started_epoch':time.time(),'targets':{}}
handles,paused={},[]
try:
 inventory=processes()
 for pid,(parent,script,marker) in parents.items():
  item=inventory[pid]
  assert item['ParentProcessId']==parent and script in item['CommandLine'] and marker in item['CommandLine']
 children=[pid for pid,item in inventory.items() if item['ParentProcessId'] in (51132,27232,39716,5244)]
 for pid in [*parents,*children]:
  handle=kernel.OpenProcess(0x0800|0x0400|0x00100000,False,pid);assert handle;handles[pid]=handle
  assert kernel.WaitForSingleObject(handle,0)==258
  assert nt.NtSuspendProcess(handle)==0;paused.append(pid)
  state['targets'][str(pid)]={'before':times(handle),'parent':inventory[pid]['ParentProcessId']}
 state['window_started_epoch']=time.time()
 state['branches']=[]
 time.sleep(3)
 for prefix,source_sha in [('stage9-owner-current-consumption-AB-baseline-20261003', 'e0c8cd4d7c03db0743c8e2b3d15c3c0f668e4e0c690b3cb388942fc2b55e0871'), ('stage9-owner-current-consumption-AB-candidate-20261003', '148d6fffc9aacd1857b6837401bd6138eb4ba3ff7193277f97c40229e27d9760')]:
  script=workspace/'.tmp'/f'{prefix}.py'
  gate=workspace/'.tmp'/f'{prefix}.gate.json'
  report=workspace/'.tmp'/f'{prefix}.json'
  log=workspace/'.tmp'/f'{prefix}.log'
  assert not gate.exists() and not report.exists() and not log.exists()
  gate_value={'status':'native_read_cost_probe_authorized','source_sha256':source_sha,'root':str(workspace/'.tmp/stage9-draft-fixture-main48-20261003'),'output':str(report),'qualification_sha256':'e1fde1266e0f359c9ef7358d22a88dd2fc0fc465dc6122386f5641508201ce92','script_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),'owned_cpu_quiet':True,'main120_qualification_paused':True,'synthetic_hosts_paused':4,'scope':'current_consumption_group_six_entries_workload_only','max_window_seconds':240}
  with gate.open('x',encoding='utf-8') as stream:json.dump(gate_value,stream)
  with log.open('x',encoding='utf-8') as stream:
   run=subprocess.run([str(workspace/'.tmp-kernel-venv/Scripts/python.exe'),'-X','utf8',str(script),'--gate',str(gate),'--output',str(report),'--qualification-sha256',gate_value['qualification_sha256']],stdout=stream,stderr=subprocess.STDOUT,timeout=245)
  state['branches'].append({'prefix':prefix,'source_sha256':source_sha,'returncode':run.returncode})
  assert run.returncode==0
 state.update(window_finished_epoch=time.time(),probe_returncode=0)
 for pid in paused:
  record=state['targets'][str(pid)];record['after']=times(handles[pid])
  record['cpu_unchanged']=all(record['before'][k]==record['after'][k] for k in ('kernel','user'));assert record['cpu_unchanged']
 state['status']='probe_finished'
 assert run.returncode==0
except BaseException as error:
 state.update(status='control_failed',error={'type':type(error).__name__,'message':str(error)});raise
finally:
 for pid in reversed(paused):state['targets'][str(pid)]['resume_status']=nt.NtResumeProcess(handles[pid])
 for handle in handles.values():kernel.CloseHandle(handle)
 state['finished_epoch']=time.time()
 with output.open('x',encoding='utf-8') as stream:json.dump(state,stream,indent=2)
 print(json.dumps({'status':state['status'],'output':str(output)}),flush=True)
 assert all(state['targets'][str(pid)]['resume_status']==0 for pid in paused)
