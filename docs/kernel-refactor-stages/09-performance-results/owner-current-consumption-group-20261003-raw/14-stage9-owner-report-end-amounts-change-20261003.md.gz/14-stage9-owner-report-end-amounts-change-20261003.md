# 阶段 9 报表同调用期末金额复用

2026-10-03。修改 `src/ai_accounting/kernel/reports.py` 与 `tests/kernel/test_reports.py`；主代理明确决定职责调整后，更新 `tests/kernel/test_opening_continuation.py` 的既有候选 UI 断言。未操作真实公司库、现有服务、固定样本源、浏览器或正在运行的完整核验。

## 输入相同与职责证明

`reports.py:1200–1209` 的第一次 `_account_totals(end.ordinal, source, (), reads=reads)` 用于未知科目检查，结果现在保存在本次 `_report` 的局部变量。`reports.py:1668` 构造年初、季初、期末三个金额时，只有期末截止期精确相同才可复用。其余两个截止期仍走原路径。

`_account_totals`（909）先查最近冻结边界。有边界时直接调用 `dashboard_reads.posted_account_totals`（1642），其结果完全不消费 `opening_rows` 或 `unknown_opening_period`。后者读取已冻结 trial_balance，并在 open 模式聚合边界后至相同 cutoff 的 monthly_account 与 opening_account。第一次调用成功即取得这份精确数据；第二次本来只重新取得同一边界、同一 trial_balance、同一尾段聚合，不承担独立业务写入或另一个来源范围的完整校验。

复用条件是本次已经查到 `period<=end` 的 close，并且 `_owns_current_selector_snapshot`（query_reads.py:434）确认 reads、connection、活动快照上下文、当前内容读取器一致及事务仍在。在后面的复用点再次确认该所有权。该检查排除 content_version=1，固定 v1 核验保持独立。

没有冻结边界时，opening_rows 与 unknown_opening_period 可以改变金额或使结果为 None，因此保留原来的两次期末读取；非所有者 reads、普通独立连接同样保留。结果仅在当前函数局部变量保存，复用时复制 dict；没有增加专用缓存、跨请求复用或改变输出 shape/version。

scope/header/body/amount 的来源检查未删。当前调用前面的 closed report sources、profiles、opening、完整 contribution 及 party 分类路径均原样运行。冻结 trial_balance 的精确内容在第一次相同路径完成；重复调用没有新的未检查来源输入。必要源损坏回归仍包含在定向测试组。

## 实际验证

- Ruff：`ruff check src/ai_accounting/kernel/reports.py tests/kernel/test_reports.py` 通过。
- 一次定向组：80 passed、1 failed，192.12 秒。包括 reports、report_projection、report_flow、report_open_contribution、new_company_reports、两项 opening continuation，以及 classification/contribution 的固定 v1 用例。日志与 JUnit：`stage9-owner-report-end-amounts-regression-20261003.log/.xml`。
- 新增 4 个合成库工作量用例：open full、open issues_only、closed full 均验证所有者与非所有者完整 plan（含 digest）相等，实际期末冻结金额 SQL 由 2 次减为 1 次；无冻结边界仍为 2 次。三个截止期之外的数据与完整 plan 均未缩减。
- 首轮失败项 `test_midyear_report_supplement_after_close_is_an_explicit_frozen_reference`：损坏 carry-forward 后 preview_export 正确拒绝，Dashboard quarterly_report 未抛。进程内仅令 `reuse_end_totals=False` 单独重跑，同一断言仍失败（8.19 秒），证明本次金额复用不是原因。隔离脚本、原始日志与 JUnit：`stage9-owner-report-disable-reuse-baseline-20261003.py/.log/.xml`，均保留原件。
- 追溯旧断言：原异常来自已删 browser_report_details 对未采用的 carry options 列表的认证；原默认计划没有自动采用补录。主代理明确决定该弃用 UI 的读取职责退出，保留真实源消费者。本测试现保留显式 preview_export(carry_id) 损坏拒绝，新增 Maintenance.verify_integrity 对该坏源的拒绝；正常补录和损坏补录下的默认页面都 closed+blocked、无 selector、禁止导出，业务状态和全部展示金额相同。独立重跑这 1 例通过（6.52 秒），`stage9-owner-report-carry-consumption-regression-20261003.log/.xml`；80 项首轮成功用例未重复执行。没有改 Dashboard 或输出 shape。

## 未验证范围

本次没有新性能测量、profile、浏览器资格或完整大样本核验，不声称达到 500 ms 或给出毫秒收益。必要实际工作量减少已由合成库 SQL trace 证明；正在运行的全组资格由主代理统一收敛。定向组最终为首轮 80 项通过加职责调整后的原失败项独立通过，并非重新跑了一轮全 81 项。
