# 资金零账户精确正向见证读取边界

2026-10-03；本组延续简报金额窄路径，只修改 dashboard_funds.py 与本组测试，不修改通用 selected_accounting / fixed v1 / 冻结合同 / DDL。无提交、封源、浏览器时延、pure native 测量；不暂停或操作 main120 / independent120 资料。

## 问题与采用范围

原 `_bank_identity_witness_subjects` 返回 subject 集合。即使每个银行已有确切正向见证，通用 selector 在没有 posting_period 时仍认证全部历史关账对这些 subject 的 absence，读取并核验不被当前账户目录消费的 family 节点。

`_bank_identity_witness_heads` 现在返回完整定位身份（id / subject_id / fact_id / kind / source period / posting period），并把 bank_opening 加入定位、源身份、封签、发布和开放 terminal guard。保留每个实际 bank_opening；每个注册银行选最早正向身份见证，statement 优先；全体 open、目标 source month、目标 posting month 都保留。来源只做候选定位，不能代替内容证明。

原 guard 仍要求自有活动 snapshot、事务、当前 close/publication readers、非 fixed v1、无 identity correction、无 withdrawn、subject 无多 posting tranche、完整注册 bank 正向覆盖、完整 fact role 路径。真实 opening_package / opening_bank / opening_cash 任一 subject 存在直接回完整选择，保留未知期初与未建立 state 的原语义。空/不完整 guard 返回完整选择，不解释为零账户。

`_bank_identity_states` 按实际 posting period 分组调用原完整 selector，明确 posting_period，并核对每组返回的 calculation IDs / fact IDs / kind / source month / posting month 及唯一性；缺失、转向、额外或重复状态均拒绝。未建立选择回完整路径。不是自行重做独立 adopted proof，也未减少精确完整 accounting node 证明。

历史 statement/reconciliation 身份继续既有 frozen_bank_account_identities 合同：完整 frozen outcome bytes、独立 adoption、实际 fact scalar / seal / 注册身份。它不宣称完整历史 fact/body 核验。bank_opening、开放及目标来源仍经原完整 _verify_event_sources。金额余额根、open tail、current money proof 与资金明细 source 内容检查保留。

## 首轮定向证据

`.tmp/stage9-bank-exact-witness-targeted-first.xml`：23 passed，排除独立 600 draft-role fixture 用例。覆盖 zero/inactive 账户、draft/missing/wrong-role/unowned/disabled/fixed-v1 回退、未选源 publication/calculation/fact-seal/scalar/type 损坏、被消费 outcome mutation、未请求旧正文与完整 checker 区别、all open/month 状态、missing/redirected terminal、真实 identity correction、duplicate/wrong role path、精确 posting node、bank opening 自身 missing/redirected terminal。

两实际关闭月的 public funds + brief 完全相同，账户数仍为 2，含零及 inactive 账户。当月实际消费仍保留；仅读到早期正向见证的 state 则为 4，完整基线为 10。直接构造器用例确认完整 accounting slice 只有实际 2026-09 节点，无 2026-10 absence 节点。

| public funds + brief 工作量 | 完整基线 | 精确见证 |
| --- | ---: | ---: |
| returned rows | 169 | 142 |
| returned value bytes | 50,304 | 44,098 |
| outcome JSON decodes | 12 | 6 |
| stdlib JSON loads | 45 | 26 |
| accounting slice reads | 5 | 3 |
| SQL calls | 146 | 155 |
| observed VM callback steps | 10,300 | 16,300 |

小样本新增银行起点候选 guard 的 SQL / VM 大于完整基线，不能把节点范围减少直接说成整体加速或 500 ms 验收。观察器 elapsed 不用于时延结论。

## 范围增长夹具

原拟两银行只保留首两个月 state 并真实关账 120 个无业务月；首次在 2026-11 被 banking.required_work 合法拒绝，因为已建立账户即使无资金变动也必须当月 statement 与 reconciliation。失败保留于 `.tmp/stage9-bank-exact-witness-node-growth-first.xml`，未跳过 readiness。

修正夹具依法逐月发布两账户各自空 statement + reconciliation，bank material 实际确认后再关账，无新资金发生。每月 inventory 在该月 freeze 前记录；每个读取点断言当时最新 close 为目标月份上一月，未来 inventory 不参与已冻结来源。12 / 48 / 120 个实际 freeze 节点对应 50 / 194 / 482 个 typed bank state；这只是两账户的节点范围工作回归，不是主 12 / 48 / 120 业务规模或空页性能验收。

`.tmp/stage9-bank-exact-witness-node-growth-repair.xml` 的唯一单例 PASS。以下只测 FundsRead 构造器的 state selector，不包含完整 page account_summary；选中四个状态的 subject / fact / digest 均与完整基线逐项一致。public page 金额、零及 inactive 账户、当月来源等价由上面的 23 例单独证明。

| freeze 月数 / typed states | 完整→精确 returned rows | 完整→精确 returned bytes | 完整→精确 outcome decodes | 完整→精确 accounting slices | 完整→精确 VM callback steps |
| --- | ---: | ---: | ---: | ---: | ---: |
| 12 / 50 | 464→251 | 133,768→86,157 | 50→4 | 12→1 | 15,200→44,100 |
| 48 / 194 | 1,796→863 | 527,367→316,513 | 194→4 | 48→1 | 60,900→167,700 |
| 120 / 482 | 4,458→2,087 | 1,314,416→777,323 | 482→4 | 120→1 | 151,900→414,800 |

各点完整→精确 SQL calls 为 24→33；stdlib loads 为 172→25、676→61、1,682→133；outcome payload 输入为 10,123→691、39,607→691、98,575→691 字节。精确完整 accounting period 始终仅首月 24308（2026-09），完整基线覆盖当时全部 12 / 48 / 120 个冻结月。没有后来 inventory 参与这些测点的历史节点认证。

role lookup 每点均一条 SQL，其返回行 / 字节 / VM：50 / 10,616 / 3,200；194 / 41,216 / 12,400；482 / 102,416 / 30,800。EXPLAIN 从 json_each 请求 ID 开始，calculation / fact_revision / 三种 scalar 表均按主键 seek，entity_reference_recorded 使用 fact_id 前缀主键 seek。没有 role-wide scan；这里按实际候选 ID 数增长，不宣称 O(1) 或全部 metadata 读取不随历史增长。

当前精确 guard 与强制完整 fallback 比较的总 SQL / VM 更高。范围、返回量和 decode 改善不等于总体工作或时延改善；本结果也不是旧 e0e 与新代码的 AB。root 应在正式比较中判断 guard 开销是否值得，不能据此给 500 ms 验收。准备及测试总 1,541.69 秒只反映真实逐月造夹具和带 observer 测试成本，不用于 page latency。

生产算法在首次 23 case 通过后未再修改。后续只修增长夹具，未另跑前端、构建或重跑银行 23 case。最终受影响同组回归与新旧正式来源 AB 由 root 统一安排。
