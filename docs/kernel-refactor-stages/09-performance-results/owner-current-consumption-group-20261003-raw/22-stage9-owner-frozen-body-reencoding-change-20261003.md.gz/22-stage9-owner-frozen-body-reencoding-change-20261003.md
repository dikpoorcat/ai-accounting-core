# 阶段 9 冻结原文重复重编码窄组回执

2026-10-03。先阅读 `stage9-owner-frozen-decode-authority-scope-20261003.md`、AGENTS.md、FRONTEND.md，按主代理已确认的独立父根及内部 writer 边界实施。仅修改当前 `report_flow.py`、`period_balance_freeze.py` 及它们的两个定向测试文件；未改 fixed-v1、Dashboard、bank/response、固定源、真实库或现有服务，未构建、测速或提交。

## 精确生产 diff

1. `report_flow.read_report_flow:343` 删除解码后的 `canonical(content) != stored["content"]` 及对应错误；增加两行注释说明正常 writer 的原文已由独立 private parent root 精确绑定。保留 `_root(period, close.digest, source_root, semantic_root, stored.content) == bound`、存储 root/close 身份、json.loads、所有 classification 来源/typed voucher/period/digest 对照、None fallback 及仅成功缓存。
2. `period_balance_freeze._verified_root:397` 只删除 `or canonical(root) != row["payload"]`。保留原文 SHA == 独立 derived_root、close digest、高水位、完整 root 字段集合、contract/period/types、bucket directory 与读取的完整桶行金额/identity/count/digest/index。

write/prepare、`_require_prepared_consistency` 的规范编码与完整 shape/amount/row/bucket 检查、compare/repair 从原始来源重建逻辑内容及父根对照均原样。report_flow `_root` 内对包含原文字符串的根封装仍须规范编码；省去的是解码 body 再编码，不是所有 JSON 编码。

## 实际工作量与业务回归

新增测试在真正业务发布、正常关账完成后，以底层 `json.JSONEncoder.encode` 返回的实际 UTF-8 编码长度记录整个解码 body 的重编码字节；通过真实 stored body 字段集合识别对象，不匹配实现行号。再执行原先的解码/规范编码比较，验证输出与原文相同并记录其实际字节。首次 JUnit properties 回执：

| 合成夹具及工作 | 原解码 body 重编码 | 修改后普通读取 |
| --- | ---: | ---: |
| 报表 2026 年 1–3 月正常 flow，各 body 一次 | 2,083 B | 0 B |
| 期间余额根，完整/指定 key/不存在 key 三种读取 | 861 B（287 B × 3） | 0 B |

报表 owner snapshot 连续成功读取完整数据相同；关账前与 closed 后三表金额相同。期间余额完整/指定读取均保留 ending/activity=10000，缺 key 返回空，不省被命中桶证明。

三组 flow 篡改（原文空白、格式、利润金额）与三组 balance root 篡改（空白、格式、bucket checksum）均在独立父根处拒绝；格式/金额/checksum 用例还重算可变本行 digest，不能借自带摘要绕过父根。首次失败不缓存。完整 verify 拒绝坏派生内容，repair 重新按源构造精确原文，随后普通读取和完整 verify 成功。原有余额同桶金额篡改用例亦通过，金额不藏在 root 中时仍验证完整桶。

非法 PreparedBalanceFreeze 的空白编码、unknown 字段、金额错误类型和原有 rows/directory 金额不一致仍在持久化前拒绝；本次未把 report_flow.persist 的既有父根绑定检查扩展为任意外部 prepared shape validator。

## 实际测试回执

- 首次仅运行 `test_report_flow.py` 与 `test_period_balance_freeze.py` 一次：28 passed、6 failed，74.49 秒。原始 `stage9-owner-frozen-body-reencoding-regression-20261003.log/.xml` 保留，以上字节回执来自其已成功用例。
- 六失败是新增测试在 QueryReads.snapshot 中错误调用完整核验；页面 authorizer 禁止 `verified_source_lease` 所需 SAVEPOINT，异常为 sqlite3.DatabaseError:not authorized，尚未进入内容检查。测试改用完整核验原有独立只读 BEGIN 入口；不改任何生产 authorizer 或核验职责。
- 只复跑这两个新增失败函数的六个参数：6 passed，17.09 秒。回执 `stage9-owner-frozen-body-reencoding-failure-regression-20261003.log/.xml`。28 项首轮成功例未重复，不宣称再次完整运行 34 项。
- 四修改文件 Ruff 通过。

## 未验证范围

本次只有合成公司功能与实际重编码字节工作量，无毫秒收益、profile、浏览器、50 人/1000 笔/120 月资格、真实备份/恢复或独立 fixed-v1 回归，不宣称满足 500 ms。fixed-v1 文件与读路由未改；完整核验/修复通过用例来自当前合成库，不能替代主代理正在收敛的固定整组资格。
