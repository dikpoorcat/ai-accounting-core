"""Pinned native read diagnostic. No implementation alternatives or proof shortcuts."""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from contextlib import contextmanager
import functools
import hashlib
import json
from pathlib import Path
import sys
import threading
import time

WORKSPACE = Path(__file__).resolve().parents[1]
SOURCE = WORKSPACE / '.tmp/stage9-build-source-draft-runtime-query-group-20261003'
SOURCE_SHA = 'e0c8cd4d7c03db0743c8e2b3d15c3c0f668e4e0c690b3cb388942fc2b55e0871'
QUALIFIED = WORKSPACE / '.tmp/stage9-draft-runtime-main48-20261003-qualified.json'
BOOK = WORKSPACE / '.tmp/stage9-owner-main48-draft-period-group-construction-input.json'
BOOK_SHA = 'a73ded22688073e7aecb7a79d56a6e31d9d6be202e1083738b091d42d3671d93'
ROOT = WORKSPACE / '.tmp/stage9-draft-fixture-main48-20261003'


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


class Observer:
    """Call wrappers only. Thread/snapshot scope is explicit; no shared proof cache."""
    def __init__(self, modules):
        self.modules = modules
        self.undo = []
        self.stack = []
        self.events = []
        self.aggregates = defaultdict(Counter)
        self.snapshots = {}
        self.current = None
        self.active = False
        self.page = None
        self.traversed = Counter()
        self.unique_blocks = set()
        self.line_contents = Counter()
        self.line_sizes = Counter()
        self.lookup_sizes = Counter()
        self.proof_bodies = {}
        self.fact_events = []

    def snapshot(self):
        reads = self.modules['storage']._active_fact_reads.get()
        if reads is None or not reads._snapshot_active or not reads.connection.in_transaction:
            return None
        # Retain tokens so CPython cannot reuse an object's id between pages.
        token = reads._snapshot_token
        if token not in self.snapshots:
            self.snapshots[token] = len(self.snapshots) + 1
        return self.snapshots[token]

    def patch(self, owner, name, custom=None, compact=False):
        original = getattr(owner, name)
        label = f'{owner.__name__}.{name}'
        @functools.wraps(original)
        def wrapped(*args, **kwargs):
            if not self.active:
                return original(*args, **kwargs)
            event = {'name': label, 'snapshot': self.snapshot(),
                     'thread': threading.get_ident(), 'page': self.page,
                     'children_ns': 0, 'details': {}}
            parent = self.stack[-1] if self.stack else None
            started = time.perf_counter_ns()
            self.stack.append(event)
            try:
                result = custom(original, event, args, kwargs) if custom else original(*args, **kwargs)
                event['succeeded'] = True
                return result
            except BaseException as error:
                event['succeeded'] = False
                event['error_type'] = type(error).__name__
                raise
            finally:
                elapsed = time.perf_counter_ns() - started
                require(self.stack.pop() is event, 'Observer stack mismatch')
                event['inclusive_ns'] = elapsed
                event['observed_self_ns'] = elapsed - event.pop('children_ns')
                if parent is not None:
                    parent['children_ns'] += elapsed
                totals = self.aggregates[label]
                totals['calls'] += 1
                totals['inclusive_ns'] += elapsed
                totals['observed_self_ns'] += event['observed_self_ns']
                totals['failed'] += not event['succeeded']
                for key, value in event['details'].items():
                    if type(value) is int:
                        totals[key] += value
                if not compact or not event['succeeded']:
                    self.events.append(event)
        setattr(owner, name, wrapped)
        self.undo.append((owner, name, original))

    @staticmethod
    def bindings(rows, *, selected=False):
        if selected:
            return {(r['fact_id'], r['fact_kind'], r['fact_period'], r['fact_digest'].hex())
                    for r in rows}
        return {(ident, r['kind'], r['period'], r['digest'].hex())
                for ident, r in rows.items()}

    def fact_check(self, original, event, args, kwargs):
        result = original(*args, **kwargs)
        event['details']['facts'] = len(result[0])
        rows = self.bindings(result[0])
        # This function has proved body/order/seals, but its evidence is still
        # provisional until its parent verify_sources has completed successfully.
        for frame in reversed(self.stack[:-1]):
            if frame['name'].endswith('.verify_sources'):
                self.proof_bodies[id(frame)] = rows
                break
        self.fact_events.append({'snapshot': event['snapshot'], 'proof': 'body_order_seal',
                                 'bindings': sorted(rows), 'page': self.page})
        return result

    def verify_sources(self, original, event, args, kwargs):
        try:
            result = original(*args, **kwargs)
            rows = self.proof_bodies.get(id(event), set())
            self.fact_events.append({'snapshot': event['snapshot'],
                                     'proof': 'complete_fact_and_evidence_success',
                                     'bindings': sorted(rows), 'page': self.page})
            return result
        finally:
            self.proof_bodies.pop(id(event), None)

    def selected_bodies(self, original, event, args, kwargs):
        # Production immediately tuples these headers too. No iterator is read
        # twice, and no facts/headers are fetched by the observer.
        headers = tuple(args[1])
        rows = self.bindings(headers, selected=True)
        result = original(args[0], headers, *args[2:], **kwargs)
        event['details']['facts'] = len(rows)
        self.fact_events.append({'snapshot': event['snapshot'], 'proof': 'selected_body_success',
                                 'bindings': sorted(rows), 'page': self.page})
        return result

    def selected_line(self, original, event, args, kwargs):
        content = args[0]
        # Original list comprehension visits every row, including duplicate hits.
        event['details']['candidate_visits'] = len(content['rows'])
        event['details']['candidate_list_builds'] = 1
        self.line_sizes[len(content['rows'])] += 1
        key = (event['snapshot'], content['publication_id'])
        self.line_contents[key] += 1
        event['details']['row_index_builds'] = 0
        return original(*args, **kwargs)

    def lookup(self, original, event, args, kwargs):
        supplied = kwargs.get('load_block')
        def observed_load(header):
            # Exactly the one production load is performed; never a second read.
            items = supplied(header) if supplied is not None else self.modules['settlement_freeze']._read_block(args[0], args[1], header)
            event['details']['key_list_items'] = len(items)
            event['details']['key_list_builds'] = 1
            self.lookup_sizes[len(items)] += 1
            self.unique_blocks.add((event['snapshot'], args[1], tuple(header)))
            return items
        altered = {**kwargs, 'load_block': observed_load}
        return original(*args, **altered)

    def cache_scope(self, original, event, args, kwargs):
        reads = args[0]
        ids = args[1]
        # Do not normalize or pre-consume opaque iterators.
        if isinstance(ids, (set, frozenset, list, tuple)):
            requested = set(ids)
            event['details']['requested_ids'] = len(requested)
            name = event['name'].rsplit('.', 1)[-1]
            cache_name = {'verify_selected_content': '_verified_source_contents',
                          'verify_fact_versions': '_fact_versions',
                          'metadata': '_metadata', 'asset_members_many': '_asset_members'}.get(name)
            if cache_name:
                event['details']['existing_cache_ids'] = len(requested & getattr(reads, cache_name).keys())
        return original(*args, **kwargs)

    def decoded_facts(self, original, event, args, kwargs):
        result = original(*args, **kwargs)
        event['details']['returned_fact_ids'] = len(result)
        reads = self.modules['storage']._active_fact_reads.get()
        if reads is not None:
            event['details']['snapshot_raw_fact_bytes'] = sum(len(reads._raw_fact_data.get(i, b'')) for i in result)
        return result

    def install(self):
        m = self.modules
        self.patch(m['integrity'], '_check_facts', self.fact_check)
        self.patch(m['integrity'], 'verify_sources', self.verify_sources)
        self.patch(m['query_reads'].QueryReads, '_verify_selected_fact_bodies', self.selected_bodies)
        self.patch(m['report_open_contribution'], 'selected_open_line', self.selected_line, compact=True)
        self.patch(m['settlement_freeze'], '_lookup', self.lookup, compact=True)
        # Hash/raw routines are imported by the live functions at call time.
        for name in ('_snapshot_fact_hashes', '_scalar_fact_hashes', '_snapshot_fact_raws'):
            self.patch(m['storage'], name, self.decoded_facts)
        for name in ('_snapshot_fact_hashes', '_snapshot_fact_raws'):
            self.patch(m['integrity'], name, self.decoded_facts)
        self.patch(m['storage'].Store, 'fact_data_many', self.decoded_facts)
        for name in ('verify_selected_content', 'verify_fact_versions', 'metadata', 'asset_members_many'):
            self.patch(m['query_reads'].QueryReads, name, self.cache_scope)
        for name in ('_verify_anchored_source_bytes', 'calculations', 'raw_calculations'):
            self.patch(m['query_reads'].QueryReads, name)
        for name in ('_brief_amounts', '_funds', '_open_items', '_assets', '_asset_card_sources', '_employees'):
            self.patch(m['dashboard'], name)
        self.patch(m['dashboard_owner'], 'owner_tasks')
        for name in ('_scope', '_tail_rows', '_read_root', '_read_block', '_read_states', 'frozen_subject_summary'):
            self.patch(m['settlement_freeze'], name)
        self.patch(m['close_storage'], '_decode_family')
        self.patch(m['report_flow'], 'read_report_flow')
        self.patch(m['report_open_contribution'], 'read_open_contributions')
        self.patch(m['report_open_contribution'], '_decode', compact=True)
        self.patch(m['reports'].Reports, '_report')
        self.patch(m['report_projection'], '_party_balance_nets')
        self.patch(m['business_queries'].BusinessQueries, '_asset_member_identity_events')

    def restore(self):
        self.active = False
        for owner, name, original in reversed(self.undo):
            setattr(owner, name, original)
        self.undo.clear()

    def summary(self):
        def sizes(counter):
            count = sum(counter.values())
            offset = 0
            p95 = None
            for value, repeats in sorted(counter.items()):
                offset += repeats
                if p95 is None and offset >= (count * 95 + 99) // 100:
                    p95 = value
            return {'calls': count, 'total_candidate_visits': sum(k*v for k, v in counter.items()),
                    'max_rows': max(counter, default=0), 'p95_rows': p95,
                    'histogram': dict(sorted(counter.items()))}
        scoped = defaultdict(lambda: defaultdict(set))
        intersections = []
        for item in self.fact_events:
            key = item['snapshot'], item['page']
            bindings = set(map(tuple, item['bindings']))
            for prior_type, previous in scoped[key].items():
                common = previous & bindings
                if common:
                    intersections.append({'snapshot': key[0], 'page': key[1],
                                          'prior_proof': prior_type, 'current_proof': item['proof'],
                                          'bindings': sorted(common), 'count': len(common)})
            scoped[key][item['proof']].update(bindings)
        return {'aggregates': dict(self.aggregates), 'boundary_events': self.events,
                'fact_proof_events': self.fact_events, 'fact_proof_intersections': intersections,
                'lookup_unique_blocks': len(self.unique_blocks),
                'lookup_block_sizes': sizes(self.lookup_sizes),
                'contribution_lookup_sizes': sizes(self.line_sizes),
                'contribution_lookup_unique_contents': len(self.line_contents),
                'contribution_lookup_calls_per_content': [
                    {'snapshot': s, 'publication_id': p, 'calls': count}
                    for (s, p), count in sorted(self.line_contents.items())],
                'elapsed_caveat': 'Observed wrapper elapsed includes instrument overhead; nested inclusive intervals are not additive. No cProfile.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--gate', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--qualification-sha256', required=True)
    args = parser.parse_args()
    require(Path(sys.prefix).resolve() == (WORKSPACE / '.tmp-kernel-venv').resolve(), 'Use repository venv')
    output = args.output.resolve()
    gate_path = args.gate.resolve(strict=True)
    require(output.parent == WORKSPACE / '.tmp' and output.name.startswith('stage9-owner-current-consumption-AB-') and not output.exists(), 'Require new isolated output')
    require(gate_path.parent == WORKSPACE / '.tmp', 'Require isolated root gate')
    qualification_hash = sha(QUALIFIED)
    require(qualification_hash == args.qualification_sha256 and sha(BOOK) == BOOK_SHA, 'Pinned qualification/construction drift')
    manifest_path = SOURCE / 'source-manifest.json'
    manifest_hash = sha(manifest_path)
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    qualified = json.loads(QUALIFIED.read_text(encoding='utf-8'))
    company, period = qualified['company'], qualified['verified_open_preview']['period']
    require(manifest['status'] == 'complete' and manifest['sha256'] == SOURCE_SHA and Path(manifest['target']).resolve() == SOURCE, 'Wrong source')
    require(Path(qualified['root']).resolve() == ROOT and qualified['requested_months'] == 48, 'Wrong sample')
    gate_hash = sha(gate_path)
    expected_gate = {'status': 'native_read_cost_probe_authorized', 'source_sha256': SOURCE_SHA,
                     'root': str(ROOT), 'output': str(output), 'qualification_sha256': qualification_hash,
                     'script_sha256': sha(__file__), 'owned_cpu_quiet': True,
                     'main120_qualification_paused': True, 'synthetic_hosts_paused': 4,
                     'scope': 'current_consumption_group_six_entries_workload_only', 'max_window_seconds': 240}
    require(json.loads(gate_path.read_text(encoding='utf-8')) == expected_gate, 'Root exclusive gate mismatch')
    sys.path.insert(0, str(SOURCE / 'scripts'))
    import stage9_source
    stage9_source.require_source_module(stage9_source, SOURCE, 'scripts/stage9_source.py')
    stage9_source.configure_source(SOURCE, WORKSPACE)
    import snapshot_stage9_source
    import benchmark_stage9_browser
    from ai_accounting.kernel import catalog, dashboard, engine, resident_reads, schema_bundle, storage
    from ai_accounting.kernel import query_reads, integrity, report_open_contribution, settlement_freeze
    from ai_accounting.kernel import dashboard_owner, close_storage, report_flow
    from ai_accounting.kernel import reports, report_projection, business_queries
    from ai_accounting.kernel.versions import database_format
    from ai_accounting.kernel.read_state import repair_revision
    from ai_accounting.kernel.types import canonical
    modules = {m.__name__.rsplit('.', 1)[-1]: m for m in (catalog, dashboard, engine, resident_reads, schema_bundle, storage, query_reads, integrity, report_open_contribution, settlement_freeze, dashboard_owner, close_storage, report_flow, reports, report_projection, business_queries)}
    for name, module in modules.items():
        stage9_source.require_source_module(module, SOURCE, f'src/ai_accounting/kernel/{name}.py')
    stage9_source.require_source_module(snapshot_stage9_source, SOURCE, 'scripts/snapshot_stage9_source.py')
    stage9_source.require_source_module(benchmark_stage9_browser, SOURCE, 'scripts/benchmark_stage9_browser.py')
    benchmark_stage9_browser.require_report_source(qualified, SOURCE)
    require(benchmark_stage9_browser.validate_book_report(qualified, company_name=company['name']) == period, 'Qualification mismatch')
    checkpoint = ROOT / 'stage9-builder.json'
    checkpoint_hash = sha(checkpoint)
    require(checkpoint_hash == qualified['qualification']['checkpoint_sha256'], 'Checkpoint mismatch')
    expected_state = qualified['verified_open_preview']['state']
    expected_identity = {'company_id': company['id'], 'database_id': company['database_id'], 'taxpayer_id': company['taxpayer_id']}

    def check_source():
        inventory = snapshot_stage9_source._inventory(SOURCE)
        require(inventory == manifest['files'] and snapshot_stage9_source._digest(inventory) == SOURCE_SHA, 'Source inventory drift')
        require(sha(manifest_path) == manifest_hash and sha(QUALIFIED) == qualification_hash and sha(BOOK) == BOOK_SHA and sha(checkpoint) == checkpoint_hash and sha(gate_path) == gate_hash, 'Guard drift')
    check_source()

    class ReadOnlyCatalog(catalog.Catalog):
        @contextmanager
        def connection(self, *, read_only=False, _cross_thread=False):
            require(read_only, 'No catalog writes')
            with super().connection(read_only=True, _cross_thread=_cross_thread) as c:
                require(c.execute('PRAGMA query_only').fetchone()[0] == 1, 'Catalog is not query_only')
                yield c
        def recover_operations(self):
            with self.connection(read_only=True) as c:
                require(c.execute("SELECT count(*) FROM company_operation WHERE status!='succeeded'").fetchone()[0] == 0, 'No recovery during diagnostic')

    bundle = schema_bundle.production_bundle()
    require(bundle.status == 'draft' and dict(bundle.current_versions) == {'company': 0, 'catalog': 0}, 'Wrong draft factory')
    cat = ReadOnlyCatalog(ROOT, bundle)
    companies = cat.companies()
    require([r for r in companies if r['id'] == company['id']] == [company], 'Catalog company drift')
    with cat.connection(read_only=True) as c:
        catalog_identity = dict(c.execute('SELECT * FROM catalog_identity').fetchone())
    pool = resident_reads.ResidentReadPool(maximum=1)
    store = cat.bind(company['id'], read_pool=pool)
    normal_connection = store.connection
    @contextmanager
    def readonly(*, read_only=False):
        require(read_only, 'No company writes')
        with normal_connection(read_only=True) as c:
            require(c.execute('PRAGMA query_only').fetchone()[0] == 1, 'Company is not query_only')
            yield c
    store.connection = readonly
    core = engine.Engine(store)
    board = dashboard.Dashboard(core, company_name=company['name'], companies=companies)
    year, month = map(int, period.split('-'))
    operations = {'context': board.context,
                  'brief': lambda: board.brief(period, limit=20),
                  'funds': lambda: board.funds(period, limit=20, preparation='deferred', movement_account_selection='first'),
                  'employees': lambda: board.employees(period, limit=20, preparation='deferred'),
                  'assets': lambda: board.assets(period, limit=20, preparation='deferred'),
                  'quarterly_report': lambda: board.quarterly_report(year, (month-1)//3+1, preparation='deferred')}

    def check_state():
        with store.connection(read_only=True) as c:
            c.execute('BEGIN')
            state = list(c.execute('SELECT * FROM state WHERE id=1').fetchone())
            identity = dict(c.execute('SELECT company_id,database_id,taxpayer_id FROM identity WHERE id=1').fetchone())
            require(state == expected_state and identity == expected_identity, 'Company identity/state drift')
            value = {'state': state, 'identity': identity, 'repair_revision': repair_revision(c), 'format': database_format(c, bundle=bundle)}
            require(value['format'] == qualified['integrity_contract'], 'Company format drift')
        with cat.connection(read_only=True) as c:
            require(dict(c.execute('SELECT * FROM catalog_identity').fetchone()) == catalog_identity, 'Catalog identity drift')
        require(cat.companies() == companies, 'Catalog registrations drift')
        return value

    def response_hash(result):
        # Only natural response clocks are removed; preserve complete business content.
        result = dict(result)
        for field in ('generated_at', 'checked_at'):
            if field in result:
                result[field] = '<response clock>'
        if isinstance(result.get('data'), dict):
            result['data'] = dict(result['data'])
            if 'generated_at' in result['data']:
                result['data']['generated_at'] = '<response clock>'
        return hashlib.sha256(canonical(result).encode()).hexdigest()

    observer = Observer(modules)
    report = {'status': 'diagnostic_started', 'diagnostic_only': True, 'browser_acceptance': False,
              'source': str(SOURCE), 'source_sha256': SOURCE_SHA, 'source_manifest_sha256': manifest_hash,
              'qualification_guard': {'path': str(QUALIFIED), 'sha256': qualification_hash},
              'qualification_reused_or_created': False, 'qualification_is_original_sample_guard_only': True, 'fresh_current_qualification': False, 'construction_input_sha256': BOOK_SHA,
              'checkpoint_sha256': checkpoint_hash, 'script_sha256': sha(__file__), 'gate_sha256': gate_hash,
              'root': str(ROOT), 'period': period, 'default_page_limit': 20, 'observations': [],
              'runtime_path_memo': {'browser': 'Native Dashboard methods only; no HTTP/auth/serialize or active owner_review_request callback measurement. UI/context/deferred/section/default20 retained.',
                                    'csv_cli_mcp': 'No export/CLI/MCP work executed. Same kernel shared helpers; complete integrity, close, repair, backup and fixed-v1 retain independent paths.',
                                    'qualification': 'Current e0e qualification guards sample identity only; diagnostic creates or inherits no performance acceptance.'}}
    with output.open('x', encoding='utf-8') as stream:
        try:
            report['before'] = check_state()
            started = time.perf_counter()
            responses = {name: operation() for name, operation in operations.items()}
            report['warmup_responses'] = responses
            baseline = {name: response_hash(result) for name, result in responses.items()}
            sys.path.insert(0, str(SOURCE / 'tests/kernel'))
            import stage9_metrics
            stage9_source.require_source_module(stage9_metrics, SOURCE, 'tests/kernel/stage9_metrics.py')
            for name, operation in operations.items():
                require(time.perf_counter() - started < 230, 'Native workload window exceeded')
                work, result = stage9_metrics.measure_work(core, operation)
                digest = response_hash(result)
                require(digest == baseline[name], f'{name}: complete response drift')
                report['observations'].append({'page': name, 'repeat': 0, 'actual_work': work,
                                               'complete_response_sha256': digest,
                                               'equal_to_uninstrumented_warmup': True})
                print(json.dumps({'status': 'workload_page_complete', 'page': name}), flush=True)
            report['work'] = {'scope': 'one actual instrumented read per six entries; not latency acceptance'}
            report['after'] = check_state()
            require(report['before'] == report['after'], 'Snapshot state drift')
            check_source()
            report['status'] = 'diagnostic_complete'
        except BaseException as error:
            report.update(status='diagnostic_failed', error_type=type(error).__name__, error=str(error))
            raise
        finally:
            observer.restore()
            report.setdefault('work', observer.summary())
            store.connection = normal_connection
            pool.close()
            json.dump(report, stream, ensure_ascii=False, indent=2)
            stream.write('\n')
    print(json.dumps({'status': report['status'], 'output': str(output), 'diagnostic_only': True}))


if __name__ == '__main__':
    main()
