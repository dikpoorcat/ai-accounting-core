"""Compare complete synthetic responses; only declared asset display removals and clocks differ."""
import copy
import hashlib
import json
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[1]
base = root / '.tmp'
paths = [base / f'stage9-owner-current-consumption-AB-{side}-20261003.json'
         for side in ('baseline', 'candidate')]
reports = [json.loads(p.read_bytes()) for p in paths]
control_path = base / 'stage9-owner-current-consumption-AB-control-20261003.json'
control = json.loads(control_path.read_bytes())
assert control['status'] == 'probe_finished'
assert all(row['cpu_unchanged'] and row['resume_status'] == 0 for row in control['targets'].values())
assert len(control['targets']) == 14
assert all(report['status'] == 'diagnostic_complete' for report in reports)
assert reports[0]['before'] == reports[0]['after'] == reports[1]['before'] == reports[1]['after']
removed = {'latest_charge_period','charge_state_label','source_label',
           'source_party_label','source_parties'}
program_versions={}
for report in reports:
    code="import sys,json;from pathlib import Path;sys.path.insert(0,str(Path(sys.argv[1])/'scripts'));from stage9_source import configure_source;configure_source(Path(sys.argv[1]),Path(sys.argv[2]));from ai_accounting.kernel.engine import PROGRAM_VERSION;print(json.dumps(PROGRAM_VERSION))"
    run=subprocess.run([sys.executable,'-X','utf8','-c',code,report['source'],str(root)],
                       capture_output=True,text=True,check=True)
    program_versions[report['source']]=json.loads(run.stdout)

def normalize(value, report):
    result = copy.deepcopy(value)
    for field in ('generated_at', 'checked_at'):
        if field in result:
            result[field] = '<response clock>'
    if isinstance(result.get('data'), dict) and 'generated_at' in result['data']:
        result['data']['generated_at'] = '<response clock>'
    if 'read_context' in result:
        context=result['read_context']
        state=report['before']['state']
        payload={'protocol':'dashboard-deferred-read-v1',
                 'build':program_versions[report['source']],
                 **{key:context[key] for key in ('company_id','database_id','as_of')},
                 'epochs':dict(zip(('accounting','material','management'),state[1:4],strict=True)),
                 'read_repair_revision':report['before']['repair_revision']}
        expected=hashlib.sha256(json.dumps(payload,ensure_ascii=False,sort_keys=True,
                                           separators=(',',':')).encode()).hexdigest()
        assert context['read_version']==expected
        context['read_version']='<independently checked source-bound request version>'
    return result

def differences(left, right, path=''):
    output=[]
    if type(left) is not type(right):
        return [{'path':path,'kind':'type'}]
    if isinstance(left, dict):
        for key in sorted(left.keys() | right.keys()):
            here=path+'/'+key
            if key not in left or key not in right:
                output.append({'path':here,'kind':'key','key':key,
                               'present_in':'baseline' if key in left else 'candidate'})
            else:
                output.extend(differences(left[key],right[key],here))
    elif isinstance(left,list):
        if len(left) != len(right):
            output.append({'path':path,'kind':'length'})
        else:
            for index,(a,b) in enumerate(zip(left,right)):
                output.extend(differences(a,b,f'{path}/{index}'))
    elif left != right:
        output.append({'path':path,'kind':'value'})
    return output

rows=[]
for before,after in zip(reports[0]['observations'], reports[1]['observations']):
    page=before['page']
    assert page == after['page']
    left=normalize(reports[0]['warmup_responses'][page],reports[0])
    right=normalize(reports[1]['warmup_responses'][page],reports[1])
    changes=differences(left,right)
    if page == 'assets':
        assert left['schema_version'] == 9 and right['schema_version'] == 10
        assert all(change['path']=='/schema_version' or (
            change['kind']=='key' and change['present_in']=='baseline'
            and change['key'] in removed and change['path'].startswith('/data/collections/assets/items/')
        ) for change in changes), changes[:25]
    else:
        assert not changes, (page,changes[:25])
    rows.append({'page':page,'business_content_equal_except_approved_asset_projection':True,
                 'response_changes':changes,
                 'baseline':before['actual_work'], 'candidate':after['actual_work']})
result={'status':'same_synthetic_business_content_verified',
        'acceptance':False,'scope':'same main48 actual six native entries; workload instrumentation, not refresh latency',
        'raw_reports':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},
        'control_sha256':hashlib.sha256(control_path.read_bytes()).hexdigest(),
        'source_program_versions':program_versions,
        'source_bound_read_versions_independently_checked':True,
        'before_after_identity_state_equal':True,'paused_owned_processes':14,
        'all_resumed':True,'pages':rows}
target=base/'stage9-owner-current-consumption-AB-comparison-20261003.json'
with target.open('x',encoding='utf-8') as stream:
    json.dump(result,stream,ensure_ascii=False,indent=2)
print(json.dumps({'status':result['status'],'pages':len(rows),'source':'148d versus e0e','acceptance':False}))
