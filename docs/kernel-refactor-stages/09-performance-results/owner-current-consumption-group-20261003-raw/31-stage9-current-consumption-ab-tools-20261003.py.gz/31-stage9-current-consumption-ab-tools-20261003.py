"""Create two pinned, read-only diagnostic branches and one owned-process control."""
import ast
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
base = root / '.tmp'
old_source = 'stage9-build-source-draft-runtime-query-group-20261003'
new_source = 'stage9-build-source-owner-current-consumption-20261003'
old_sha = 'e0c8cd4d7c03db0743c8e2b3d15c3c0f668e4e0c690b3cb388942fc2b55e0871'
new_sha = '148d6fffc9aacd1857b6837401bd6138eb4ba3ff7193277f97c40229e27d9760'
original = (base / 'stage9-owner-read-cost-probe-four-hosts-20261003.py').read_text('utf-8')
control_original = (base / 'stage9-owner-read-cost-probe-first-control.py').read_text('utf-8')

def replace_once(content, before, after):
    assert content.count(before) == 1, before[:100]
    return content.replace(before, after, 1)

before = '''            baseline = {name: response_hash(operation()) for name, operation in operations.items()}
            observer.install()
            for repeat in range(2):
                for name, operation in operations.items():
                    require(time.perf_counter() - started < 55, 'Native diagnostic window exceeded')
                    observer.active = True
                    observer.page = f'{name}:{repeat}'
                    t0 = time.perf_counter_ns()
                    try:
                        result = operation()
                    finally:
                        elapsed = time.perf_counter_ns() - t0
                        observer.active = False
                    digest = response_hash(result)
                    require(digest == baseline[name], f'{name}: complete response drift')
                    report['observations'].append({'page': name, 'repeat': repeat, 'instrumented_native_ns': elapsed,
                                                   'complete_response_sha256': digest, 'equal_to_uninstrumented_warmup': True})
            observer.restore()
            report['work'] = observer.summary()
'''
after = '''            responses = {name: operation() for name, operation in operations.items()}
            report['warmup_responses'] = responses
            baseline = {name: response_hash(result) for name, result in responses.items()}
            sys.path.insert(0, str(SOURCE / 'tests/kernel'))
            import stage9_metrics
            stage9_source.require_source_module(stage9_metrics, SOURCE, 'tests/kernel/stage9_metrics.py')
            for name, operation in operations.items():
                require(time.perf_counter() - started < 230, 'Native workload window exceeded')
                work, result = stage9_metrics.measure_work(core, operation)
                digest = response_hash(result)
                require(digest == baseline[name], f'{name}: complete response drift')
                report['observations'].append({'page': name, 'repeat': 0, 'actual_work': work,
                                               'complete_response_sha256': digest,
                                               'equal_to_uninstrumented_warmup': True})
                print(json.dumps({'status': 'workload_page_complete', 'page': name}), flush=True)
            report['work'] = {'scope': 'one actual instrumented read per six entries; not latency acceptance'}
'''
rows = []
for label, source, source_sha in (
    ('baseline', old_source, old_sha), ('candidate', new_source, new_sha),
):
    prefix = f'stage9-owner-current-consumption-AB-{label}-20261003'
    content = replace_once(original, before, after)
    content = content.replace("output.name.startswith('stage9-owner-read-cost-probe-')", "output.name.startswith('stage9-owner-current-consumption-AB-')")
    content = content.replace("'max_window_seconds': 60", "'max_window_seconds': 240")
    content = content.replace("'scope': 'two_read_cost_groups_six_entries'", "'scope': 'current_consumption_group_six_entries_workload_only'")
    content = content.replace("'qualification_reused_or_created': False", "'qualification_reused_or_created': False, 'qualification_is_original_sample_guard_only': True, 'fresh_current_qualification': False")
    if label == 'candidate':
        content = replace_once(content, "SOURCE = WORKSPACE / '.tmp/" + old_source + "'", "SOURCE = WORKSPACE / '.tmp/" + new_source + "'")
        content = replace_once(content, "SOURCE_SHA = '" + old_sha + "'", "SOURCE_SHA = '" + new_sha + "'")
        content = replace_once(content, 'benchmark_stage9_browser.require_report_source(qualified, SOURCE)',
                               "benchmark_stage9_browser.require_report_source(qualified, WORKSPACE / '.tmp/" + old_source + "')")
    ast.parse(content)
    path = base / (prefix + '.py')
    with path.open('x', encoding='utf-8') as stream:
        stream.write(content)
    rows.append((prefix, source_sha))

control = control_original.replace('stage9-owner-read-cost-probe-first-control.json', 'stage9-owner-current-consumption-AB-control-20261003.json')
start = control.index(" script=workspace/'.tmp/stage9-owner-read-cost-probe-four-hosts-20261003.py'")
stop = control.index(' for pid in paused:', start)
sequence = " state['window_started_epoch']=time.time()\n state['branches']=[]\n time.sleep(3)\n"
sequence += ' for prefix,source_sha in ' + repr(rows) + ':\n'
sequence += '''  script=workspace/'.tmp'/f'{prefix}.py'
  gate=workspace/'.tmp'/f'{prefix}.gate.json'
  report=workspace/'.tmp'/f'{prefix}.json'
  log=workspace/'.tmp'/f'{prefix}.log'
  assert not gate.exists() and not report.exists() and not log.exists()
  gate_value={'status':'native_read_cost_probe_authorized','source_sha256':source_sha,'root':str(workspace/'.tmp/stage9-draft-fixture-main48-20261003'),'output':str(report),'qualification_sha256':'e1fde1266e0f359c9ef7358d22a88dd2fc0fc465dc6122386f5641508201ce92','script_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),'owned_cpu_quiet':True,'main120_qualification_paused':True,'synthetic_hosts_paused':4,'scope':'current_consumption_group_six_entries_workload_only','max_window_seconds':240}
  with gate.open('x',encoding='utf-8') as stream:json.dump(gate_value,stream)
  with log.open('x',encoding='utf-8') as stream:
   run=subprocess.run([str(workspace/'.tmp-kernel-venv/Scripts/python.exe'),'-X','utf8',str(script),'--gate',str(gate),'--output',str(report),'--qualification-sha256',gate_value['qualification_sha256']],stdout=stream,stderr=subprocess.STDOUT,timeout=245)
  state['branches'].append({'prefix':prefix,'source_sha256':source_sha,'returncode':run.returncode})
  assert run.returncode==0
 state.update(window_finished_epoch=time.time(),probe_returncode=0)
'''
control = control[:start] + sequence + control[stop:]
ast.parse(control)
path = base / 'stage9-owner-current-consumption-AB-control-20261003.py'
with path.open('x', encoding='utf-8') as stream:
    stream.write(control)
receipt = {'scope':'pinned old and new source; same synthetic main48 read-only sample; diagnostics only',
           'original_probe_sha256':hashlib.sha256(original.encode()).hexdigest(),
           'original_control_sha256':hashlib.sha256(control_original.encode()).hexdigest(),
           'created_scripts':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [
               base / (prefix + '.py') for prefix, _ in rows] + [path]}}
with (base / 'stage9-owner-current-consumption-AB-tools-20261003.json').open('x',encoding='utf-8') as stream:
    json.dump(receipt,stream,indent=2)
print(json.dumps(receipt))
