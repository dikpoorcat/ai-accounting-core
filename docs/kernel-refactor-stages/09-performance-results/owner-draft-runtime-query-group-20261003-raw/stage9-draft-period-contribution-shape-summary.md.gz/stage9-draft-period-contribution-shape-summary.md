# 完整贡献 shape 下沉负结果

原件 `stage9-draft-period-contribution-shape-first.json/.log`，工具 `stage9-draft-period-contribution-shape-prototype.py`。一次执行exit0。固定22ef源、主48 draft qualified-r2 SHA2db3e594、checkpoint与业务身份/epochs前后保持，不重新资格/preview、无新库或业务写入。生产、封存源、固定v1独立decoder均未修改。

SchemaValidator编译完整10键对象与resolution4键，required无defaults/extra forbid；source_bindings固定4项、rows固定7项，tuple验证后用builtin list恢复原容器。int strict拒bool，digest只维持64字符；IDs不增加非空或hex规则，publication_id仍仅动态Python相等比较，parents仍按原sortedunique规则。row第7项任意dict、resolution列表的任意元素仍保留，不能给这些未限定内容额外禁止字段。

32份实际保存贡献的完整返回dict/list/金额业务值相等。162个变异/畸形输入对照全部一致，其中37接受、125拒绝；包括missing/extra/null、bool/float/大整数、数组宽度、digest长度、parents排序/重复、resolution任意元素、row任意正文对象、动态publication ID及畸形JSON。拒绝仍是原KernelError code/message/details。该窄probe不宣称所有可能JSON语义已穷尽。

每组32份×100轮，7组交替顺序，使用thread_time_ns、不关闭GC、不改阈值。原函数CPU中位46.875ms，原型78.125ms，ratio1.667；7组原型全部更慢。Windows线程CPU计时呈15.625ms量化，但方向一致。本轮没有walltime净收益或500ms证据。全shape compiled validation与每行tuple→list恢复的成本未获得收益；没有继续拆分做另一个优化原型。

据事先分支，未启动六入口work-only前后对照；也不再追加profile/纯计时。原型运行结束恢复原_decode；负结果工具原件保留，生产实施建议撤回。其他冻结小根、fullverify/repair及owner生成合同仍未改变，不能据本次负结果永久排除其他调用形状。background copy/MCP可能并行，按root授权未暂停；绝对耗时非验收。
