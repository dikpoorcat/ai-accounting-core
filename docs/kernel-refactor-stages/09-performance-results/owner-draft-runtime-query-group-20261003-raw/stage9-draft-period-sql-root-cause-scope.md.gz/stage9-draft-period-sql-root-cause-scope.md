# 当前六入口 SQL 根因范围

仅使用 `stage9-draft-period-main48-work-first.json` 的 prototype（当前22ef三函数）实际工作记录、温态HTTP profile r2原件和封存代码。工作记录当时是construction诊断，不能回写成完整资格或500ms验收。温态profile根frame存在计账异常，调用链只作辅助；不将cumtime相加。原有月份发现、签名复用、header/source缓存组不是本轮新问题，own-line与compiled-shape负结果不重试。

下表SQL标识为statement UTF-8 SHA256前12位，能在原work JSON各页 `prototype.sql` 精确定位。字节是返回给Python的值，不是磁盘读取量；VM按原progress callback记录，有量化误差。

| 入口 | 实际重点SQL / calls | VM | 返回行 / 字节 | 结论 |
|---|---|---:|---:|---|
| context | 52ce8a7c10fc recursive period discovery / 1 | 10,800 | 48 / 384 | 当前按月seek，已处理范围，不是新scan |
| brief | aad15abccf64 full current journal / 1 | 114,800 | 1005 / 454,060 | 整月金额、源定位与默认20分别承担完整/分页职责 |
| brief | b889c1450ee5 exact voucher lines / 1 | 49,900 | 2294 / 224,929 | 完整line-set金额/正文对照，不能截为20 |
| funds | abaa46fbece2 money aggregate / 1 | 245,500 | 2 / 202 | 全月实际收付需要全money效果；低返回不等于错扫 |
| funds | f655b3f86904 first-account page CTE / 1 | 230,400 | 21 / 7084 | 与aggregate重复展开money源，默认first分支最有依据的另一个候选 |
| funds | 7375148fc229 statement summary/page / 1 | 154,500 | 21 / 6886 | 有完整汇总与20+1分页职责，不能只看21行删全源统计 |
| employees | 7557363633cb roster candidate publications / 1 | 130,000 | 50 / 1140 | 独立开放/撤去/缺指针/冻结候选；无错计划证据 |
| employees | 5eb160981f08 entity roster seeds / 1 | 86,200 | 50 / 4640 | period<=范围发现所有人、每人kind最新事实；未做新EXPLAIN |
| assets | b1fd58bb6f3d selected member source headers / 2 | 121,800 | 1175 / 1,321,287 | 完整所选owner成员目录身份，不按20截；两批重叠未证实 |
| assets | 85710ec54978 adopted bank/asset heads / 1 | 61,400 | 96 / 27,121 | 关闭采用与对象定位；未证明无关扫描 |
| report | 35b1aecbf1c4 monthly flow classification refs / 12 | 187,600 | 4932 / 784,188 | EXPLAIN为逐ID主键seek与排序，不是全历史误扫 |
| report | 4d8a27d0832b open report source journal / 1 | 137,900 | 1005 / 410,845 | 完整开放金额/语义来源，不能仅读显示行 |
| report | 68981c716774 subject-scoped missing publication / 4 | 72,900 | 0 / 0 | 已确认空subject集合仍驱动开放尾部，是最小修复候选 |

## 空范围仍扫描开放尾部

`reports._verify_report_fact_sources`（827）→ `QueryReads.verify_fact_versions`（1067）→ `integrity.verify_sources`（1483，calculation_ids默认空tuple）→ `_check_sources`（272）。只把extra_fact_ids加入事实/证据核验，calculations为空，随后（511）仍将明确empty current_subjects传给 `query_reads.verify_open_voucher_scope`（319）。SQL原件4次calculation/seal/publication读取均零行，四次subject反向guard仍72900VM。不是凭代码相似猜测。

已批准的两条只读EXPLAIN原件为 `stage9-draft-period-sql-plan-first.json/.log`，exit0；固定22ef、当前qualified-r2、身份/epochs/checkpoint/source前后不变。只执行EXPLAIN，没有执行这两个工作查询，ID数组使用neutral empty bind，月份/closed boundary按当前样本。报告classification refs的plan是ids虚表→fact_revision.id PK→subject.id PK→typed revision_id PK，加ORDER BY临时树。反向guard plan是 voucher_period范围seek→voucher_current version PK→calculation id PK→subject IN过滤→current/publication PK；不是全历史scan，但空集合在该驱动下仍检查整个开放尾部。

最小候选仅对current reader明确empty subject_ids返回，不创建任何完整范围成功证明。`subject_ids=None`必须保留独立全范围查找；非空范围不据此改plan，fixed-v1保持其独立规则。完整facts/body/seals/evidence、遗漏或坏引用拒绝、失败无半批成功均不删除。函数还被Journal SQL、report projection、reports整范围与integrity用于普通/CLI/MCP/完整核验/写入源检查；其中事实-only空calculation闭包也可能有同触发，未做额外工作测量。unowned与full模式不能因owned cache已有证明就跳过。本轮未改生产、未实测修改收益。

## 默认资金首账户重复关系展开

`Dashboard.funds`→`dashboard_funds.funds`（1729）在select_first_account=true时先`FundsRead.account_summary()`（586），再选完整已证明可见账户集的first，再第二次`read.movements()`→`_sql_summary_page`（58，调用1813）。源字符串有event_queries同快照缓存，但SQL关系仍两次执行。第一次aggregate245500VM，第二次page230400VM；后者明确empty summary SQL，所以不是重复计算公司summary，却仍重新物化journal/events/outcome balances/transfer partition及全局/筛选计数。

完整金额、内部转账判定、count与selected first identity确实必要。可研究把已证明账户排序选择、全摘要和首账户page放到一个关系执行中，或复用同snapshot已核完整money关系，仅限该函数组、不建跨请求业务缓存。first不能从money事件自行猜：零活动opening、退役更正、银行覆盖都影响可见账户集。不得先过滤所选账户而遗漏同一事件的转账另一端。当前数据证明重复物化位置，没有证明安全最小重写或净收益，root决定是否进下一组。

## 大payload与循环查询的必要边界

- brief/funds/assets `3edbd5bc8892` family-subroot分别46/47/47行约1.83/1.87/1.87MB；这是冻结采用family摘要/引用与source证明，已batch不是逐月完整manifest。未证明可只取digest而不验证内容，不重新提出此前C4缓存收益。
- brief `4b4d021bdbbd`495贡献1,557,339B用于publication/source绑定；正文仍被immutable anchor checksum认证。report `c922e8f30f7a`两批合计1004贡献3,322,180B、decode合计1004；金额/party/semantic消费者实际需要内容。bodyhash不等于任意解析JSON证明，旧own-line与shape负原型不再建议。
- settlement `_scope/_tail_rows` 在brief/employees/assets读取current settlement_change 1246行521,477B，另seal聚合1行451,669B，是派生行完整性与业务读取两层。shared root679,077B及目录1458refs219,006B已同snapshot成功缓存；原件一根读取，不能说同页重复整根。归类为必要source与projection核验，未测可替代方案。
- report `read_report_flow`23函数调用仅12次body SQL、12次分类header SQL；已有成功同snapshot月缓存，不是23次重读。12个不同flow body共1,605,370B是采用后的月度金额/party/checkpoint/分类引用证明。各月4932个refs是否存在跨月同ID重叠，原SQL证据未保存绑定值，不能认定可消去；现有PK plan已经有界。
- assets period_balance历史桶：46次行查询、45次seal查询总VM约2000、仅约7KB，是每月覆盖/摘要检查，虽循环但非主要VM。完整性与未出现category也须核验，不凭calls45立即batch；新性能未测。
- report fact-only完整verify中4次sqlite_schema table枚举（988返回名字/17500VM）服务asset-member表存在判断；该支路空calculation闭包实际用不到成员循环。是小的可复用同职责线索，但首组建议只修空subject guard，避免扩大核验改动。资料结构职责及fixed historical schema差异保留。

没有EXPLAIN证据的employees/asset主体查询只能标尚未验证，不能把130kVM/50返回直接叫坏planner。温态employee慢样本也不能据一次cProfile认生产退化。当前最少成组建议为query_reads明确空范围 + 必要业务/负例/无关开放行增长测试；资金first关系合并另列候选待root决定，不连带重写所有页面。已停止DB诊断，不运行整页、fullverify或纯计时。
