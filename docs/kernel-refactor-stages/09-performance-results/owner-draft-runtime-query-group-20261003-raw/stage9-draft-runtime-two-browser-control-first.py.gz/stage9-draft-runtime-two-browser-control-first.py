"""Two sequential pure browser windows on fixed e0e draft fixtures."""
import ctypes
from ctypes import wintypes
import json,subprocess,time
from pathlib import Path
workspace=Path(__file__).resolve().parents[1]
control=workspace/'.tmp/stage9-draft-runtime-two-browser-control-first.json'
assert not control.exists()
targets={
 57784:(55364,'scripts/prepare_stage9_draft_book.py','stage9-draft-fixture-main120-20261003'),
 53324:(46008,'scripts/benchmark_stage9_browser.py','stage9-draft-runtime-main48-20261003'),
 51132:(58128,'stage9_package_agent_harness.py','stage9-final-draft-agent-fix1-20261003'),
 3912:(34300,'stage9_restore_agent_harness.py','stage9-final-draft-agent-restore-20261003'),
}
kernel = ctypes.WinDLL('kernel32', use_last_error=True)
nt = ctypes.WinDLL('ntdll')
kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
kernel.OpenProcess.restype = wintypes.HANDLE
kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
kernel.WaitForSingleObject.restype = wintypes.DWORD
kernel.CloseHandle.argtypes = [wintypes.HANDLE]
nt.NtSuspendProcess.argtypes = [wintypes.HANDLE]
nt.NtSuspendProcess.restype = ctypes.c_long
nt.NtResumeProcess.argtypes = [wintypes.HANDLE]
nt.NtResumeProcess.restype = ctypes.c_long

class FILETIME(ctypes.Structure):
    _fields_ = [('low', wintypes.DWORD), ('high', wintypes.DWORD)]

kernel.GetProcessTimes.argtypes = [wintypes.HANDLE, *([ctypes.POINTER(FILETIME)] * 4)]

def times(handle):
    values = [FILETIME() for _ in range(4)]
    assert kernel.GetProcessTimes(handle, *[ctypes.byref(v) for v in values])
    return dict(zip(('creation', 'exit', 'kernel', 'user'),
                    [v.high * 2**32 + v.low for v in values]))

def description(pid):
    ps = (f"Get-CimInstance Win32_Process -Filter 'ProcessId={pid}' | "
          "Select-Object ProcessId,ParentProcessId,CommandLine | ConvertTo-Json -Compress")
    result = subprocess.run(['powershell', '-NoProfile', '-Command', ps],
                            capture_output=True, text=True, check=True)
    return json.loads(result.stdout) if result.stdout.strip() else None



handles,paused={},[]
state={'status':'control_started','scope':'owned_synthetic_jobs_only','started_epoch':time.time(),'targets':{},'windows':[]}
try:
 for pid,(parent,script,marker) in targets.items():
  item=description(pid)
  if item is None:
   state['targets'][str(pid)]={'already_finished':True};continue
  assert item['ParentProcessId']==parent and script in item['CommandLine'] and marker in item['CommandLine']
  handle=kernel.OpenProcess(0x0800|0x0400|0x00100000,False,pid)
  assert handle;handles[pid]=handle
  if kernel.WaitForSingleObject(handle,0)==258:
   assert nt.NtSuspendProcess(handle)==0;paused.append(pid)
   state['targets'][str(pid)]={'before':times(handle),'paused_epoch':time.time()}
 for pid,parent in ((56548,51132),(34460,51132),(33328,3912),(55560,3912)):
  item=description(pid)
  if item is None:
   state['targets'][str(pid)]={'already_finished':True};continue
  assert item['ParentProcessId']==parent and parent in paused
  handle=kernel.OpenProcess(0x0800|0x0400|0x00100000,False,pid)
  assert handle;handles[pid]=handle
  if kernel.WaitForSingleObject(handle,0)==258:
   assert nt.NtSuspendProcess(handle)==0;paused.append(pid)
   state['targets'][str(pid)]={'before':times(handle),'paused_epoch':time.time(),'test_host_parent':parent}
 # Hold the second browser while the first runs; both completed qualification.
 other=kernel.OpenProcess(0x0800|0x0400|0x00100000,False,49624)
 assert other
 item=description(49624)
 assert item['ParentProcessId']==31096 and 'stage9-draft-runtime-independent12-20261003' in item['CommandLine']
 assert nt.NtSuspendProcess(other)==0
 second_before=times(other)
 for label,pid in (('main12',44736),('independent12',49624)):
  prefix=workspace/f'.tmp/stage9-draft-runtime-{label}-20261003'
  ready=Path(str(prefix)+'-timing.ready.json');start=Path(str(prefix)+'-timing.start.json');report=Path(str(prefix)+'-browser.json')
  assert ready.exists() and not start.exists() and not report.exists()
  signal=json.loads(ready.read_text(encoding='utf-8'))
  assert signal['pid']==pid and Path(signal['output']).resolve()==report.resolve()
  if label=='independent12':
   second_after=times(other)
   assert all(second_before[k]==second_after[k] for k in ('kernel','user'))
   state['other_browser_hold']={'pid':49624,'before':second_before,'after':second_after,'resume_status':nt.NtResumeProcess(other)}
   assert state['other_browser_hold']['resume_status']==0
   second_before=None
  browser=kernel.OpenProcess(0x0400|0x00100000,False,pid);assert browser
  try:
   time.sleep(3)
   with start.open('x',encoding='utf-8') as out:json.dump({'status':'pure_timing_released','owned_synthetic_paused':paused,'epoch':time.time()},out)
   window={'label':label,'pid':pid,'started_epoch':time.time()};state['windows'].append(window)
   print(json.dumps({'status':'pure_browser_started','sample':label,'pid':pid}),flush=True)
   deadline=time.monotonic()+420
   while kernel.WaitForSingleObject(browser,1000)==258:assert time.monotonic()<deadline,'Browser timeout'
   assert report.exists()
   result=json.loads(report.read_text(encoding='utf-8'))
   window.update(finished_epoch=time.time(),result_status=result['status'])
  finally:kernel.CloseHandle(browser)
 for pid in paused:
  target=state['targets'][str(pid)];target['after']=times(handles[pid])
  target['cpu_unchanged']=all(target['before'][k]==target['after'][k] for k in ('kernel','user'))
  assert target['cpu_unchanged']
 state['status']='timing_finished'
except BaseException as error:
 state['status']='control_failed';state['error']={'type':type(error).__name__,'message':str(error)}
 raise
finally:
 if 'second_before' in globals() and second_before is not None:
  state['other_browser_failure_resume_status']=nt.NtResumeProcess(other)
 if 'other' in globals():kernel.CloseHandle(other)
 for pid in reversed(paused):
  state['targets'][str(pid)]['resume_status']=nt.NtResumeProcess(handles[pid]);state['targets'][str(pid)]['resumed_epoch']=time.time()
 for handle in handles.values():kernel.CloseHandle(handle)
 state['finished_epoch']=time.time()
 with control.open('x',encoding='utf-8') as out:json.dump(state,out,indent=2)
 print(json.dumps({'status':state['status'],'control':str(control)}),flush=True)
 assert all(state['targets'][str(pid)]['resume_status']==0 for pid in paused)
