"""Exclusive diagnostic native window; only known synthetic jobs are suspended."""
import ctypes
from ctypes import wintypes
import json,subprocess,time,sys
from pathlib import Path
workspace=Path(__file__).resolve().parents[1]
report=workspace/'.tmp/stage9-draft-runtime-query-main48-native-first.json'
control=workspace/'.tmp/stage9-draft-runtime-native-control-first.json'
gate=workspace/'.tmp/stage9-draft-runtime-query-main48-native-first.gate.json'
assert not report.exists() and not control.exists() and not gate.exists()
targets={
 57784:(55364,'scripts/prepare_stage9_draft_book.py','stage9-draft-fixture-main120-20261003'),
 44736:(53140,'scripts/benchmark_stage9_browser.py','stage9-draft-runtime-main12-20261003'),
 53324:(46008,'scripts/benchmark_stage9_browser.py','stage9-draft-runtime-main48-20261003'),
 49624:(31096,'scripts/benchmark_stage9_browser.py','stage9-draft-runtime-independent12-20261003'),
 51132:(58128,'stage9_package_agent_harness.py','stage9-final-draft-agent-fix1-20261003'),
 3912:(34300,'stage9_restore_agent_harness.py','stage9-final-draft-agent-restore-20261003'),
}
kernel = ctypes.WinDLL('kernel32', use_last_error=True)
nt = ctypes.WinDLL('ntdll')
kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
kernel.OpenProcess.restype = wintypes.HANDLE
kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
kernel.WaitForSingleObject.restype = wintypes.DWORD
kernel.CloseHandle.argtypes = [wintypes.HANDLE]
nt.NtSuspendProcess.argtypes = [wintypes.HANDLE]
nt.NtSuspendProcess.restype = ctypes.c_long
nt.NtResumeProcess.argtypes = [wintypes.HANDLE]
nt.NtResumeProcess.restype = ctypes.c_long

class FILETIME(ctypes.Structure):
    _fields_ = [('low', wintypes.DWORD), ('high', wintypes.DWORD)]

kernel.GetProcessTimes.argtypes = [wintypes.HANDLE, *([ctypes.POINTER(FILETIME)] * 4)]

def times(handle):
    values = [FILETIME() for _ in range(4)]
    assert kernel.GetProcessTimes(handle, *[ctypes.byref(v) for v in values])
    return dict(zip(('creation', 'exit', 'kernel', 'user'),
                    [v.high * 2**32 + v.low for v in values]))

def description(pid):
    ps = (f"Get-CimInstance Win32_Process -Filter 'ProcessId={pid}' | "
          "Select-Object ProcessId,ParentProcessId,CommandLine | ConvertTo-Json -Compress")
    result = subprocess.run(['powershell', '-NoProfile', '-Command', ps],
                            capture_output=True, text=True, check=True)
    return json.loads(result.stdout) if result.stdout.strip() else None


handles,paused={},[]
state={'status':'control_started','scope':'owned_synthetic_jobs_only','started_epoch':time.time(),'targets':{}}
try:
 for pid,(parent,script,marker) in targets.items():
  item=description(pid)
  if item is None:
   state['targets'][str(pid)]={'already_finished':True};continue
  assert item['ParentProcessId']==parent and script in item['CommandLine'] and marker in item['CommandLine'], 'Refuse unrelated process'
  handle=kernel.OpenProcess(0x0800|0x0400|0x00100000,False,pid)
  assert handle;handles[pid]=handle
  if kernel.WaitForSingleObject(handle,0)==258:
   assert nt.NtSuspendProcess(handle)==0
   paused.append(pid)
   state['targets'][str(pid)]={'before':times(handle),'paused_epoch':time.time()}
 # Descendants of the two known test hosts have no real service ancestry.
 for pid,parent in ((56548,51132),(34460,51132),(33328,3912),(55560,3912)):
  item=description(pid)
  if item is None:
   state['targets'][str(pid)]={'already_finished':True};continue
  assert item['ParentProcessId']==parent and parent in paused,'Refuse unrelated descendant'
  handle=kernel.OpenProcess(0x0800|0x0400|0x00100000,False,pid)
  assert handle;handles[pid]=handle
  if kernel.WaitForSingleObject(handle,0)==258:
   assert nt.NtSuspendProcess(handle)==0
   paused.append(pid)
   state['targets'][str(pid)]={'before':times(handle),'paused_epoch':time.time(),'test_host_parent':parent}
 time.sleep(3)
 with gate.open('x',encoding='utf-8') as out:
  json.dump({'status':'native_authorized','source_sha256':'e0c8cd4d7c03db0743c8e2b3d15c3c0f668e4e0c690b3cb388942fc2b55e0871','construction_input_sha256':'a73ded22688073e7aecb7a79d56a6e31d9d6be202e1083738b091d42d3671d93','root':str(workspace/'.tmp/stage9-draft-fixture-main48-20261003'),'output':str(report),'owned_cpu_quiet':True,'function_group':'empty_open_subject_scope'},out)
 command=[sys.executable,'-B','-X','utf8',str(workspace/'.tmp/stage9-draft-runtime-query-main48-before-after.py'),'--months','48','--book-report',str(workspace/'.tmp/stage9-owner-main48-draft-period-group-construction-input.json'),'--report-sha256','a73ded22688073e7aecb7a79d56a6e31d9d6be202e1083738b091d42d3671d93','--qualification-report',str(workspace/'.tmp/stage9-owner-main48-draft-period-group-qualified-r2.json'),'--qualification-sha256','2db3e5945722ba909264d6c8f8e9c25f3703546e26e38bfd79077ffdca9de2ac','--output',str(report),'--native-gate',str(gate)]
 state['diagnostic_started_epoch']=time.time()
 print(json.dumps({'status':'exclusive_native_started','paused':paused}),flush=True)
 with (workspace/'.tmp/stage9-draft-runtime-query-main48-native-first.log').open('xb') as out:
  child=subprocess.Popen(command,cwd=workspace,stdout=out,stderr=subprocess.STDOUT)
  state['diagnostic_pid']=child.pid
  state['diagnostic_exit_code']=child.wait(timeout=360)
 state['diagnostic_finished_epoch']=time.time()
 assert report.is_file(),'Diagnostic exited without final report'
 result=json.loads(report.read_text(encoding='utf-8'))
 state['diagnostic_status']=result['status']
 for pid in paused:
  target=state['targets'][str(pid)];target['after']=times(handles[pid])
  target['cpu_unchanged']=all(target['before'][k]==target['after'][k] for k in ('kernel','user'))
  assert target['cpu_unchanged'],'Paused job consumed CPU during pure native'
 assert state['diagnostic_exit_code']==0 and result['status']=='diagnostic_complete'
 state['status']='timing_finished'
except BaseException as error:
 state['status']='control_failed';state['error']={'type':type(error).__name__,'message':str(error)}
 raise
finally:
 for pid in reversed(paused):
  state['targets'][str(pid)]['resume_status']=nt.NtResumeProcess(handles[pid])
  state['targets'][str(pid)]['resumed_epoch']=time.time()
 for handle in handles.values():kernel.CloseHandle(handle)
 state['finished_epoch']=time.time()
 with control.open('x',encoding='utf-8') as out:json.dump(state,out,indent=2)
 print(json.dumps({'status':state['status'],'control':str(control)}),flush=True)
 assert all(state['targets'][str(pid)]['resume_status']==0 for pid in paused)
