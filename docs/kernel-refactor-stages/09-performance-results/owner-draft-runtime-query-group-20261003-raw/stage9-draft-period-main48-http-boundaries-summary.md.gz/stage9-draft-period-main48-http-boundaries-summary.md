# Draft main48 HTTP 边界诊断

本轮只执行一次五页各一组预热、三组观察；每组 context/main 并发。40 个实际授权 HTTP GET 全部 200，620 条边界事件，进程 session 63394 exit 0。原件为 `stage9-draft-period-main48-http-boundaries-first.json/.log`，工具为同 prefix `.py`。没有重新资格核验、preview、浏览器计时或业务写入。源 22ef、qualified-r2 报告 2db3e594、checkpoint、业务身份和 epochs 前后守卫通过。

每个请求 dispatch、authorize、core command、command/response validation、dump_json、页面方法、pool acquire/held 均一次；安全目录结构验证两次（事务前与 BEGIN IMMEDIATE 后）；主请求 Catalog.bind 一次，context 为零，bound_store 均一次。没有发现重复主 API 或同请求重复页面执行。两次安全验证处于不同事务边界，计数本身不能证明可删除其中一次。

以下均为三个观察样本的毫秒值；嵌套区间不能相加。client 是 request_sent→response_headers，held 是正常页面读取持有连接的范围，包含页面内工作，不是 SQLite 单独耗时。

| 主页面 | client 等待 | Service.dispatch | pool held |
|---|---|---|---|
| brief | 1061.1 / 527.0 / 479.8 | 1060.2 / 525.6 / 479.0 | 1007.6 / 464.4 / 418.8 |
| funds | 338.3 / 371.9 / 381.2 | 338.1 / 371.1 / 380.5 | 298.4 / 310.5 / 324.0 |
| employees | 236.0 / 330.2 / 304.6 | 235.8 / 329.2 / 303.9 | 197.1 / 272.6 / 246.6 |
| assets | 578.1 / 410.7 / 409.3 | 577.0 / 410.5 / 408.0 | 541.7 / 367.3 / 354.3 |
| quarterly_report | 544.3 / 443.4 / 508.0 | 543.6 / 442.6 / 507.1 | 507.8 / 410.2 / 451.4 |

context client 等待约 38.5–67.8ms；authorize 约 8.4–20.7ms，pool acquire 约 12.5–37.6ms，其中 Store 结构/身份验证约 5.3–20.7ms；真正 held 约 1–10ms。这说明 native context 与 HTTP context 的差额包含真实授权及取得/核验连接成本，不能全归网络或固定排队。acquire 同时包含文件/sidecar/PRAGMA/结构检查，不能视作纯队列等待；不同嵌套范围不得相加。

主请求 response validation 约 0.2–1.0ms，dump_json 约 0.1–0.3ms，写出通常小于 1ms。长 brief/assets/report 样本主要仍在页面 held 范围；本次 assets 578ms 不是合同序列化或连接首次取得的主要开销。不过它与原纯浏览器 assets 596.5ms 不是同一次事件，不能据此断定旧慢样本的内部根因。

静态 HTTP/dispatch 路径无固定 50ms sleep。ThreadingHTTPServer 每请求线程；serve_forever 的 poll interval 属服务控制。ResidentReadPool 满额才 Condition.wait，本轮未隔离证明实际排队；授权 gate 串行保护真实会话 last_seen 写入。daemon 的 0.1s sleep 是启动/健康等待。JobRunner 的 5s 周期属于常驻后台任务，本工具与浏览器 harness 都未启动 JobRunner，因此没有验证正式 daemon 后台影响。CLI/MCP 同用 service 的严格校验与授权入口，不能把此次 HTTP 结果当其传输端到端证据。

背景 main120 copy PID 57784 全程未暂停，另一个合成根 MCP 按 root 授权并行。before/after background JSON 保留 CPU 状态；after 观察包含结果分析时间，不可把其 CPU 差额全算作测量期间。绝对 wall time 与比例均有调度干扰；这不是 500ms 验收或净收益证据。没有改生产、阈值、源码封存或旧原件。后续仅在 root 决定后对页面内部具体工作做诊断，不从两次安全校验的表面相似直接修改保护。
