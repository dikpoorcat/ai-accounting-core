"""Archive this fixed group's raw evidence; never declare page acceptance."""
from pathlib import Path
import difflib
import gzip
import hashlib
import json
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]
out = root / 'docs/kernel-refactor-stages/09-performance-results'
group = json.loads((root / '.tmp/stage9-group-r38/result.json').read_text('utf-8'))
proof = json.loads((root / '.tmp/stage9-main48-verification-r38.json').read_text('utf-8'))
window = json.loads((root / '.tmp/stage9-native-close-batch-ab-window-r38.json').read_text('utf-8-sig'))
assert group['status'] == 'passed' and group['source_unchanged']
assert proof['status'] == 'complete' and proof['integrity']['status'] == 'verified'
assert not proof['integrity'].get('limitations')
assert window['status'] == 'finished' and len(window['runs']) == 4
assert all(run['exit_code'] == 0 for run in window['runs'])
old_root = root / '.tmp/stage9-build-source-r37-release'
new_root = root / '.tmp/stage9-build-source-r38-release'
old = json.loads((old_root / 'source-manifest.json').read_text('utf-8'))
new = json.loads((new_root / 'source-manifest.json').read_text('utf-8'))
changes = sorted(key for key in old['files'].keys() | new['files'].keys()
                 if old['files'].get(key) != new['files'].get(key))
assert set(changes) == {
    'src/ai_accounting/kernel/close_storage.py',
    'src/ai_accounting/kernel/query_reads.py',
    'src/ai_accounting/kernel/reports.py',
    'tests/kernel/test_close_management_sections.py',
    'tests/kernel/test_close_storage_batch_io.py',
    'tests/kernel/test_t7_quarter_coverage.py',
}, changes
counts = dict.fromkeys(('tests', 'failures', 'errors', 'skipped'), 0)
for path in (root / '.tmp/stage9-group-r38').glob('*-junit.xml'):
    for suite in ET.parse(path).getroot().iter('testsuite'):
        for key in counts:
            counts[key] += int(suite.attrib.get(key, 0))
assert counts == {'tests': 366, 'failures': 0, 'errors': 0, 'skipped': 0}
paths = list((root / '.tmp/stage9-group-r38').iterdir())
paths += [new_root / 'source-manifest.json',
          root / '.tmp/stage9-release-candidate-work-r38/candidate-provenance.json']
for pattern in (
    'stage9-remaining-profile-r37*', 'stage9-remaining-profile-r38*',
    'stage9-close-batch-*r38*', 'stage9-main48-verification-r38*',
    'stage9-main12-browser-diagnostic-r37*',
    'stage9-position-missing-r37-probe*',
    'stage9-remaining-brief-r37-scope.md', 'stage9-remaining-reports-r37-scope.md',
    'stage9-native-close-batch-*', 'stage9-run-native-close-batch-ab.ps1',
    'stage9-group-r38-tests.txt', 'stage9-group-r38.log', 'stage9-prepare-r38.log',
    'stage9-next-root-cause-after-r38.md',
):
    paths.extend((root / '.tmp').glob(pattern))
paths.append(Path(__file__))
paths = sorted(set(path for path in paths if path.is_file()))
destinations = [(path, out / ('close-batches-r38-' + str(index).zfill(3) + '-' + path.name + '.gz'))
                for index, path in enumerate(paths, 1)]
diff_path = out / 'close-batches-r38-code.diff'
manifest_path = out / 'close-batches-r38-manifest.json'
assert not diff_path.exists() and not manifest_path.exists()
assert all(not target.exists() for _, target in destinations)
records = []
for path, target in destinations:
    raw = path.read_bytes()
    compressed = gzip.compress(raw, mtime=0)
    target.write_bytes(compressed)
    assert gzip.decompress(target.read_bytes()) == raw
    records.append({'source': str(path.relative_to(root)), 'archive': target.name,
                    'raw_bytes': len(raw), 'archive_bytes': len(compressed),
                    'raw_sha256': hashlib.sha256(raw).hexdigest(),
                    'archive_sha256': hashlib.sha256(compressed).hexdigest()})
diff = ''.join(line for name in changes for line in difflib.unified_diff(
    (old_root / name).read_text('utf-8').splitlines(keepends=True) if (old_root / name).exists() else [],
    (new_root / name).read_text('utf-8').splitlines(keepends=True),
    fromfile='r37/' + name, tofile='r38/' + name))
diff_path.write_text(diff, encoding='utf-8')
manifest = {'purpose': 'fixed_group_evidence_not_stage9_acceptance',
            'decision': 'withdrawn_after_no_native_page_latency_gain',
            'source_sha256': new['sha256'], 'previous_source_sha256': old['sha256'],
            'repository_source_sha256': group['repository_source_sha256'],
            'changed_from_r37': changes, 'group': counts,
            'group_seconds': group['elapsed_seconds'], 'source_unchanged': True,
            'contracts_unchanged': True,
            'native_timing_order': [run['name'] for run in window['runs']],
            'full_verification_months': 48,
            'code_diff_sha256': hashlib.sha256(diff_path.read_bytes()).hexdigest(),
            'files': records}
manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'group': counts, 'archives': len(records),
                  'compressed_bytes': sum(row['archive_bytes'] for row in records)}, ensure_ascii=False))
