"""Private read-only comparison of the captured r37 kind+posting-month SQL."""

from __future__ import annotations

from collections import Counter
import json
from pathlib import Path
import sqlite3


ROOT = Path(__file__).resolve().parents[1]
CAPTURE = ROOT / ".tmp/stage9-r37-kind-period-probe.json"
OUTPUT = ROOT / ".tmp/stage9-r37-kind-period-private-ab.json"
OLD = (
    "scoped_vouchers AS (SELECT original.id FROM json_each(?) selected_kinds "
    "CROSS JOIN calculation sc INDEXED BY calculation_kind_period "
    "ON sc.kind=selected_kinds.value CROSS JOIN voucher_version original "
    "INDEXED BY voucher_calculation ON original.calculation_id=sc.id), "
)
NEW = (
    "scoped_vouchers AS (SELECT original.id FROM "
    "(SELECT 1 FROM json_each(?) selected_kinds "
    "CROSS JOIN calculation sc INDEXED BY calculation_kind_period "
    "ON sc.kind=selected_kinds.value LIMIT 1) has_kind "
    "CROSS JOIN voucher_version original INDEXED BY voucher_period "
    "ON original.period=? "
    "CROSS JOIN calculation scoped_calc ON scoped_calc.id=original.calculation_id "
    "AND scoped_calc.kind IN (SELECT value FROM json_each(?))), "
)


def value_wire(value):
    if isinstance(value, bytes):
        return {"bytes_hex": value.hex()}
    return value


def read_work(connection, sql, params):
    steps = 0

    def progress():
        nonlocal steps
        steps += 1
        return 0

    plan = [list(row) for row in connection.execute("EXPLAIN QUERY PLAN " + sql, params)]
    connection.set_progress_handler(progress, 1)
    try:
        rows = [tuple(row) for row in connection.execute(sql, params)]
    finally:
        connection.set_progress_handler(None, 0)
    return rows, steps, plan


def main():
    assert CAPTURE.is_file() and not OUTPUT.exists()
    capture = json.loads(CAPTURE.read_text(encoding="utf-8"))
    result = {"status": "private_read_only_comparison", "source": capture["source"],
              "variant": "kind_exists_guard_then_voucher_posting_period_then_kind_filter",
              "samples": {}}
    for months, sample in capture["samples"].items():
        book = ROOT / sample["book"] / "91310000123456789S/company.sqlite"
        assert book.is_file()
        connection = sqlite3.connect(book.as_uri() + "?mode=ro", uri=True)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA query_only=ON")
        connection.execute("BEGIN")
        try:
            records = []
            for original in sample["queries"]:
                sql = original["statement"]
                assert sql.count(OLD) == 1
                params = original["parameters"]
                kind_index = sql[: sql.index("scoped_vouchers")].count("?")
                target = original["target_posting_period_ordinal"]
                candidate_sql = sql.replace(OLD, NEW)
                candidate_params = params[: kind_index + 1] + [target, params[kind_index]] + params[kind_index + 1 :]
                old_rows, old_steps, old_plan = read_work(connection, sql, params)
                new_rows, new_steps, new_plan = read_work(connection, candidate_sql, candidate_params)
                # Preserve all selected columns, including bytes, for independent
                # review. A multiset check permits unspecified DISTINCT order.
                old_wire = [[value_wire(v) for v in row] for row in old_rows]
                new_wire = [[value_wire(v) for v in row] for row in new_rows]
                old_members = Counter(json.dumps(row, sort_keys=True, ensure_ascii=False) for row in old_wire)
                new_members = Counter(json.dumps(row, sort_keys=True, ensure_ascii=False) for row in new_wire)
                records.append({
                    "family": original["family"],
                    "selected_kinds": original["selected_kinds"],
                    "target_posting_period_ordinal": target,
                    "original_sql": sql,
                    "original_params": params,
                    "candidate_sql": candidate_sql,
                    "candidate_params": candidate_params,
                    "original_vm_steps": old_steps,
                    "candidate_vm_steps": new_steps,
                    "same_order": old_wire == new_wire,
                    "same_row_multiset": old_members == new_members,
                    "original_rows": old_wire,
                    "candidate_rows": new_wire,
                    "original_plan": old_plan,
                    "candidate_plan": new_plan,
                })
            result["samples"][months] = records
        finally:
            connection.rollback()
            connection.close()
    OUTPUT.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    assert all(
        record["same_row_multiset"]
        for records in result["samples"].values()
        for record in records
    )


if __name__ == "__main__":
    main()
