"""Seal a new isolated released candidate; leave repository/runtime draft intact."""
from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
import sys
from pathlib import Path

workspace = Path(__file__).resolve().parents[1]
assert Path(sys.prefix).resolve() == workspace / ".tmp-kernel-venv"
sys.path.insert(0, str(workspace / "scripts"))
from snapshot_stage9_source import _digest, _inventory, snapshot_source

candidate = workspace / ".tmp/stage9-build-candidate-owner-close-proof-groups-20261003"
snapshot = workspace / ".tmp/stage9-build-source-owner-close-proof-groups-20261003-release"
assert not candidate.exists() and not snapshot.exists()
before = _inventory(workspace)
candidate.mkdir()
for relative in before:
    target = candidate / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    with (workspace / relative).open("rb") as source, target.open("xb") as output:
        shutil.copyfileobj(source, output)
assert _inventory(workspace) == before and _inventory(candidate) == before
selector = candidate / "src/ai_accounting/kernel/schema_bundle.py"
content = selector.read_text(encoding="utf-8")
assert content.count('STATUS = "draft"') == content.count('VERSION = 0') == 1
selector.write_text(
    content.replace('STATUS = "draft"', 'STATUS = "released"').replace('VERSION = 0', 'VERSION = 1'),
    encoding="utf-8", newline="\n",
)
runner = (
    "import pathlib,runpy,sys; root=pathlib.Path(sys.argv[1]).resolve(); "
    "sys.path.insert(0,str(root/'src')); "
    "sys.argv=[str(root/'scripts/export_kernel_schema_contracts.py'),*sys.argv[2:]]; "
    "runpy.run_path(sys.argv[0],run_name='__main__')"
)
for option in ("--freeze-v1", "--check"):
    subprocess.run([sys.executable, "-X", "utf8", "-c", runner, str(candidate), option],
                   cwd=workspace, check=True)
result = snapshot_source(candidate, snapshot, workspace=workspace)
assert _inventory(workspace) == before
contracts = {}
for relative in ("company/v1.json", "catalog/v1.json", "content-v1.json"):
    path = snapshot / "src/ai_accounting/kernel/schema_contracts" / relative
    data = json.loads(path.read_text(encoding="utf-8"))
    contracts[relative] = {"sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                           "fingerprint": data["sha256"]}
print(json.dumps({"status": "isolated_candidate_sealed", "repository_status": "draft/0",
                  "original_source_sha256": _digest(before), "candidate": str(candidate),
                  "snapshot": str(snapshot), "snapshot_sha256": result["sha256"],
                  "contracts": contracts}, ensure_ascii=False))
