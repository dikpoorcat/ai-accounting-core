"""Observe the real declared company upgrade in the exclusive synthetic copy."""
import argparse
import hashlib
import importlib.util
import json
import shutil
import sys
import traceback
from contextlib import closing
from datetime import UTC, datetime
from pathlib import Path
from time import perf_counter

W = Path(__file__).resolve().parents[1]
S = W / '.tmp/stage9-build-source-verification-snapshot-converged-20261005'


def sha(path):
    with Path(path).open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


PARAMETERS = W / '.tmp/stage9-followup-distribution-525f-20261005-parameters.json'
PARAMETERS_SHA = '8850904f61d0f35377fced2a8b0e0d6c25a7265dac278908da4b65d675120062'


def parameter_table():
    assert sha(PARAMETERS) == PARAMETERS_SHA
    return json.loads(PARAMETERS.read_text('utf-8'))


def require_book(book, cfg):
    for key in ('distribution', 'requested_months', 'monthly_business_count',
                'business_count', 'registered_object_count', 'employee_count', 'period'):
        assert book.get(key) == cfg[key], key
    assert book['company']['name'] == cfg['company_name']
    for key, expected in (('id', cfg['company_id']), ('database_id', cfg['database_id']),
                          ('taxpayer_id', cfg['taxpayer_id'])):
        assert book['company'][key] == expected
    assert book['source'] == cfg['recorded_construction_source']
    # Construction provenance stays historical; this is not current Q evidence.
    assert book['copy_provenance']['mode'] == 'synthetic_draft_fixture_construction_not_downgrade'
    assert book['copy_provenance']['target_company_format'] == cfg['recorded_company_format']
    assert book['copy_provenance']['target_snapshot_sha256'] == cfg['recorded_construction_source_sha256']


def main():
    assert sys.flags.dont_write_bytecode and sys.flags.utf8_mode
    assert Path(sys.executable).resolve() == W / '.tmp-kernel-venv/Scripts/python.exe'
    table = parameter_table()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--sample', required=True, choices=tuple(table['samples']))
    args = parser.parse_args()
    cfg = table['samples'][args.sample]
    INPUT, OUTPUT, copy_path = map(Path, (cfg['target_input'], cfg['upgrade_receipt'], cfg['copy_receipt']))
    assert not OUTPUT.exists() and not OUTPUT.with_suffix('.exclusive').exists()
    copy = json.loads(copy_path.read_text('utf-8'))
    assert copy['status'] == 'copied_content_unverified'
    assert copy['source_bytes_identity_state_history_and_sessions_unchanged']
    assert copy['source_inventory_unchanged'] and copy['input_sha256'] == sha(INPUT)
    assert copy['parameters_sha256'] == PARAMETERS_SHA
    assert copy['helper_sha256'] == sha(W / '.tmp/stage9-followup-distribution-525f-20261005-copy.py')
    assert copy['sample'] == args.sample and copy['source_sha256'] == table['copy_source']['sha256']
    assert copy['source_builder_name'] == cfg['source_builder_name']
    book = json.loads(INPUT.read_text('utf-8'))
    assert sha(cfg['source_input']) == cfg['source_input_sha256']
    original_book = json.loads(Path(cfg['source_input']).read_text('utf-8'))
    assert book['construction_provenance'] == original_book['copy_provenance']
    require_book(book | {'copy_provenance': book['construction_provenance']}, cfg)
    root = Path(cfg['target_root'])
    assert root.resolve(strict=True).parent == (W / '.tmp').resolve(strict=True)
    assert not root.is_symlink() and root.name == 'stage9-draft-fixture-' + args.sample + '-verification-snapshot-525f-20261005'
    assert Path(book['root']).resolve() == root
    assert book['copy_provenance']['installation_and_history_rewritten'] is False
    assert book['copy_provenance']['only_catalog_company_path_changed'] is True
    assert copy['target_checkpoint_sha256'] == sha(root / cfg['source_builder_name'])
    assert copy['source_builder_sha256'] == cfg['source_builder_sha256']
    assert sha(root / 'stage9-draft-copy-book.json') == sha(INPUT)
    path = Path(book['company']['path']).resolve(strict=True)
    assert path == root / book['company']['taxpayer_id'] / 'company.sqlite'
    assert path.is_relative_to(root) and not path.is_symlink()
    for copied in copy['copies']:
        copied_path = Path(copied['path']).resolve(strict=True)
        assert copied_path.is_relative_to(root)
        assert copied_path.stat().st_size == copied['bytes'] and sha(copied_path) == copied['sha256']
    assert sha(table['source_guard_helper']) == table['source_guard_helper_sha256']
    spec = importlib.util.spec_from_file_location('upgrade_source_guard', W / '.tmp/stage9-directory-test-repair-converged-browser-20261004-runner.py')
    guards = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(guards)
    manifest = json.loads((S / 'source-manifest.json').read_text('utf-8'))
    assert manifest['sha256'] == table['upgrade_source']['sha256']
    assert manifest['file_count'] == table['upgrade_source']['file_count']
    assert str(S) == table['upgrade_source']['path']
    assert sha(S / 'source-manifest.json') == table['upgrade_source']['manifest_sha256']
    guards.S, guards.SOURCE_SHA = S, manifest['sha256']
    guards.MANIFEST_SHA, guards.SOURCE_FILE_COUNT = sha(S / 'source-manifest.json'), manifest['file_count']
    before_source = guards.source_guard()
    guards.configure_source()
    from ai_accounting.kernel import offline_development_upgrade as upgrade
    from ai_accounting.kernel.runtime import connect
    from ai_accounting.kernel.schema_bundle import production_bundle
    from ai_accounting.kernel.versions import verify_schema, objects, fingerprint
    from ai_accounting.kernel.permissions import create_private_file, reject_reparse_path
    from ai_accounting.kernel.runtime import private_file_lock
    import stage9_source
    stage9_source.require_source_module(upgrade, S, 'src/ai_accounting/kernel/offline_development_upgrade.py')
    from ai_accounting.kernel import backup, runtime
    for module, relative in ((backup, 'src/ai_accounting/kernel/backup.py'),
                             (runtime, 'src/ai_accounting/kernel/runtime.py')):
        stage9_source.require_source_module(module, S, relative)
    assert backup.verification_snapshot is runtime.verification_snapshot
    assert upgrade.verification_snapshot is runtime.verification_snapshot
    for checked_path in (root, path, root / 'catalog.sqlite'):
        reject_reparse_path(checked_path)
    bundle = production_bundle()
    assert bundle.current('company')['sha256'] == '52556e8ec6cbbb81ab9ad9a69bb87897401471dba9c693e7b7ebddd2a5b08bf4'
    result = {'status': 'running', 'source_sha256': manifest['sha256'],
              'manifest_sha256': guards.MANIFEST_SHA, 'helper_sha256': sha(__file__),
              'input_sha256': sha(INPUT), 'root': str(root),
              'copy_receipt_sha256': sha(copy_path), 'source_file_count': manifest['file_count'],
              'parameters_sha256': PARAMETERS_SHA, 'sample': args.sample,
              'interpreter': sys.executable,
              'actual_upgrade_module': upgrade.__file__, 'actual_upgrade_module_sha256': sha(upgrade.__file__),
              'free_bytes_before': shutil.disk_usage(W).free,
              'started_at': datetime.now(UTC).isoformat(), 'phases': [],
              'scope': 'real company upgrade executor, isolated synthetic copy; not root upgrade or browser acceptance'}
    original_verify = upgrade._verify_connection
    original_rows = upgrade._all_existing_rows

    def observed(name, callback, *args, **kwargs):
        started = perf_counter()
        print(json.dumps({'phase': name, 'status': 'started', 'time': datetime.now(UTC).isoformat()}), flush=True)
        entry = {'phase': name, 'status': 'started'}
        result['phases'].append(entry)
        try:
            value = callback(*args, **kwargs)
        except BaseException as error:
            entry.update(status='failed', error_type=type(error).__name__, milliseconds=(perf_counter() - started) * 1000)
            raise
        entry.update(status='passed', milliseconds=(perf_counter() - started) * 1000)
        if name.startswith('content_'):
            entry['verification'] = value['verification']
            assert value['verification']['status'] == 'verified' and not value['verification']['limitations']
        else:
            entry['rows_digest'], entry['table_counts'] = value
        print(json.dumps({'phase': name, 'status': 'passed', 'milliseconds': entry['milliseconds']}), flush=True)
        return value

    verify_calls = 0
    def observe_verify(*args, **kwargs):
        nonlocal verify_calls
        verify_calls += 1
        return observed('content_' + str(verify_calls), original_verify, *args, **kwargs)

    rows_calls = 0
    def observe_rows(*args, **kwargs):
        nonlocal rows_calls
        rows_calls += 1
        return observed('all_original_rows_' + str(rows_calls), original_rows, *args, **kwargs)

    def boundary(name):
        print(json.dumps({'boundary': name, 'time': datetime.now(UTC).isoformat()}), flush=True)

    try:
        expected = {'expected_company_id': book['company']['id'],
                    'expected_database_id': book['company']['database_id'],
                    'expected_taxpayer_id': book['company']['taxpayer_id']}
        assert upgrade.INDEX_SOURCE_FINGERPRINT == table['expected_source_company_fingerprint']
        assert bundle.current('company')['sha256'] == table['expected_target_company_fingerprint']
        previous = upgrade.source_bundle(bundle, upgrade.INDEX_SOURCE_FINGERPRINT)
        with closing(connect(path, read_only=True)) as candidate:
            verify_schema(candidate, bundle=previous)
            assert tuple(candidate.execute('SELECT * FROM identity').fetchone()) == (
                1, book['company']['id'], book['company']['taxpayer_id'], book['company']['database_id'])
            before_draft_history = [tuple(row) for row in candidate.execute('SELECT * FROM schema_draft_history ORDER BY sequence')]
        with closing(connect(root / 'catalog.sqlite', read_only=True)) as catalog:
            verify_schema(catalog, bundle=bundle, kind='catalog')
            assert [dict(row) for row in catalog.execute('SELECT * FROM company')] == [book['company']]
        claim_path = OUTPUT.with_suffix('.exclusive')
        create_private_file(claim_path)
        upgrade._verify_connection, upgrade._all_existing_rows = observe_verify, observe_rows
        with private_file_lock(claim_path) as claimed, private_file_lock(root / '.resident.lock') as stopped:
            assert claimed and stopped, 'exclusive synthetic target or resident lock unavailable'
            with closing(connect(path)) as connection:
                before_state = [tuple(row) for row in connection.execute('SELECT * FROM state')]
                before_history = [tuple(row) for row in connection.execute('SELECT * FROM schema_history')]
                result['upgrade'] = upgrade.upgrade_company(
                    connection, bundle, fault=boundary,
                    expected_source_fingerprint=upgrade.INDEX_SOURCE_FINGERPRINT, **expected)
                assert result['upgrade']['status'] == 'upgraded'
                assert len(result['upgrade']['steps']) == 1
                assert verify_calls == 3, 'source/locked-source/target complete verification boundaries missing'
                assert result['upgrade']['steps'][0]['source_fingerprint'] == table['expected_source_company_fingerprint']
                assert result['upgrade']['steps'][0]['target_fingerprint'] == table['expected_target_company_fingerprint']
                after_draft_history = [tuple(row) for row in connection.execute('SELECT * FROM schema_draft_history ORDER BY sequence')]
                assert after_draft_history[:-1] == before_draft_history
                assert len(after_draft_history) == len(before_draft_history) + 1
                assert after_draft_history[-1][0] == max((row[0] for row in before_draft_history), default=0) + 1
                expected_tables = {item['name'] for item in previous.current('company')['objects'] if item['type'] == 'table'}
                row_phases = [entry for entry in result['phases'] if entry['phase'].startswith('all_original_rows_')]
                assert len(row_phases) == 2 and all(set(entry['table_counts']) == expected_tables for entry in row_phases)
                assert row_phases[0]['rows_digest'] == row_phases[1]['rows_digest'] == result['upgrade']['original_rows_digest']
                verify_schema(connection, bundle=bundle)
                assert before_state == [tuple(row) for row in connection.execute('SELECT * FROM state')]
                assert before_history == [tuple(row) for row in connection.execute('SELECT * FROM schema_history')]
                assert connection.execute('PRAGMA foreign_keys').fetchone()[0] == 1
                assert not connection.in_transaction
                assert connection.execute('PRAGMA foreign_key_check').fetchone() is None
                assert tuple(connection.execute('PRAGMA wal_checkpoint(TRUNCATE)').fetchone()) == (0, 0, 0)
                result['target_fingerprint'] = fingerprint(objects(connection)).hex()
                result['transaction_closed'] = True
                result['foreign_keys_enabled'] = True
                result['foreign_key_check_empty'] = True
                result['checkpoint'] = [0, 0, 0]
                result['state_unchanged'] = True
                result['schema_history_unchanged'] = True
                result['draft_history'] = [
                    {key: (value.hex() if isinstance(value, bytes) else value)
                     for key, value in dict(row).items()}
                    for row in connection.execute('SELECT * FROM schema_draft_history')
                ]
        result['target_database_bytes'] = path.stat().st_size
        result['target_database_sha256'] = sha(path)
        result['status'] = 'declared_upgrade_verified'
    except BaseException as error:
        result['status'], result['error_type'] = 'upgrade_failed', type(error).__name__
        result['error_traceback'] = traceback.format_exc()
        raise
    finally:
        upgrade._verify_connection, upgrade._all_existing_rows = original_verify, original_rows
        result['source_inventory_unchanged'] = guards.source_guard() == before_source
        result['finished_at'] = datetime.now(UTC).isoformat()
        with OUTPUT.open('x', encoding='utf-8') as handle:
            json.dump(result, handle, ensure_ascii=False, indent=2)
        assert result['source_inventory_unchanged']


if __name__ == '__main__':
    main()
