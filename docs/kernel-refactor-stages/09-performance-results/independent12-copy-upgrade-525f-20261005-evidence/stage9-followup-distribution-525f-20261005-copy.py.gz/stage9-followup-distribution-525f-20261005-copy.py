"""Normal SQLite snapshot copies of pinned synthetic books, never real data.

Keep the exact old draft installation/history; the declared upgrade must run next.
This copy does not qualify content and does not provide performance acceptance.
"""
import argparse
import hashlib
import sys
import traceback
from contextlib import closing
from datetime import UTC, datetime
import importlib.util
import json
import shutil
from pathlib import Path

W = Path(__file__).resolve().parents[1]
S = W / '.tmp/stage9-build-source-stable-owned-read-converged-20261005'


def sha(path):
    with Path(path).open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()

PARAMETERS = W / '.tmp/stage9-followup-distribution-525f-20261005-parameters.json'
PARAMETERS_SHA = '8850904f61d0f35377fced2a8b0e0d6c25a7265dac278908da4b65d675120062'


def parameter_table():
    assert sha(PARAMETERS) == PARAMETERS_SHA
    return json.loads(PARAMETERS.read_text('utf-8'))


def require_book(book, cfg):
    for key in ('distribution', 'requested_months', 'monthly_business_count',
                'business_count', 'registered_object_count', 'employee_count', 'period'):
        assert book.get(key) == cfg[key], key
    assert book['company']['name'] == cfg['company_name']
    for key, expected in (('id', cfg['company_id']), ('database_id', cfg['database_id']),
                          ('taxpayer_id', cfg['taxpayer_id'])):
        assert book['company'][key] == expected
    assert book['source'] == cfg['recorded_construction_source']
    # Construction provenance stays historical; this is not current Q evidence.
    assert book['copy_provenance']['mode'] == 'synthetic_draft_fixture_construction_not_downgrade'
    assert book['copy_provenance']['target_company_format'] == cfg['recorded_company_format']
    assert book['copy_provenance']['target_snapshot_sha256'] == cfg['recorded_construction_source_sha256']


def main():
    assert sys.flags.dont_write_bytecode and sys.flags.utf8_mode
    assert Path(sys.executable).resolve() == W / '.tmp-kernel-venv/Scripts/python.exe'
    table = parameter_table()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--sample', choices=tuple(table["samples"]), required=True)
    args = parser.parse_args()
    cfg = table['samples'][args.sample]
    assert sha(table['source_guard_helper']) == table['source_guard_helper_sha256']
    spec = importlib.util.spec_from_file_location('clone_source_guards', W / '.tmp/stage9-directory-test-repair-converged-browser-20261004-runner.py')
    guards = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(guards)
    manifest = json.loads((S / 'source-manifest.json').read_text('utf-8'))
    assert manifest['sha256'] == 'ed96dfd296cd96d4279745eb0ac26a9422db450c10d3bb9f8e7def11e2f9d8c8'
    guards.S, guards.SOURCE_SHA = S, manifest['sha256']
    guards.MANIFEST_SHA, guards.SOURCE_FILE_COUNT = guards.sha(S / 'source-manifest.json'), manifest['file_count']
    assert manifest['file_count'] == table['copy_source']['file_count']
    assert str(S) == table['copy_source']['path']
    assert guards.MANIFEST_SHA == table['copy_source']['manifest_sha256']
    source_guard = guards.source_guard()
    guards.configure_source()
    assert guards.INPUT_SHA[args.sample] == cfg['source_input_sha256']
    before, book, old_root = guards.guard(args.sample)
    require_book(book, cfg)
    assert str(old_root) == cfg['source_root']
    assert guards.sha(cfg['source_attestation']) == cfg['source_attestation_sha256']
    assert guards.sha(old_root / cfg['source_builder_name']) == cfg['source_builder_sha256']
    target, output, input_path = map(Path, (cfg['target_root'], cfg['copy_receipt'], cfg['target_input']))
    assert target.parent.resolve(strict=True) == (W / '.tmp').resolve(strict=True)
    assert target.name == 'stage9-draft-fixture-' + args.sample + '-verification-snapshot-525f-20261005'
    assert not target.exists() and not output.exists() and not input_path.exists()
    from ai_accounting.kernel.runtime import connect
    from ai_accounting.kernel.permissions import create_private_file, ensure_private_directory, reject_reparse_path
    from ai_accounting.kernel.schema_bundle import production_bundle
    from ai_accounting.kernel.versions import verify_schema
    bundle = production_bundle()
    assert bundle.current('company')['sha256'] == 'c9f9f7051bca67f1241ee5c89676fb9476bc819dc8f92c1a0c0bd1e940f459cb'
    for source_path in (old_root, Path(book['company']['path']), old_root / 'catalog.sqlite'):
        reject_reparse_path(source_path)
    planned_files = (old_root / 'catalog.sqlite', Path(book['company']['path']))
    planned_bytes = sum(path.stat().st_size + (Path(str(path) + '-wal').stat().st_size
                        if Path(str(path) + '-wal').exists() else 0) for path in planned_files)
    required_free = planned_bytes * 2 + 2 * 2**30
    assert shutil.disk_usage(W).free >= required_free, 'insufficient space for exclusive copy plus conservative WAL headroom'
    result = {'required_free_bytes': required_free, 'free_bytes_before': shutil.disk_usage(W).free, 'status': 'running', 'source_sha256': source_guard['source_sha256'],
              'helper_sha256': guards.sha(__file__), 'parameters_sha256': PARAMETERS_SHA, 'sample': args.sample,
              'source_builder_name': cfg['source_builder_name'], 'source_builder_sha256': cfg['source_builder_sha256'],
              'source_attestation_sha256': cfg['source_attestation_sha256'],
              'started_at': datetime.now(UTC).isoformat(), 'source_before': before,
              'target': str(target), 'target_book_report': str(input_path), 'copies': [], 'copy_mode': 'unpublished destination DELETE before SQLite backup, normal WAL after',
              'limitations': ['readonly source normal WAL snapshots into absent exclusive synthetic files',
                              'same old draft schema/history, not installed target schema or migration',
                              'no content verifier, preview, service/session, or performance acceptance']}
    try:
        target.mkdir(exist_ok=False)
        ensure_private_directory(target)
        new_company = book['company'] | {'path': str(target / book['company']['taxpayer_id'] / 'company.sqlite')}
        for kind, old_path, new_path in (
            ('catalog', old_root / 'catalog.sqlite', target / 'catalog.sqlite'),
            ('company', Path(book['company']['path']), Path(new_company['path'])),
        ):
            ensure_private_directory(new_path.parent)
            create_private_file(new_path)
            with closing(connect(old_path, read_only=True, validator=lambda c, k=kind: verify_schema(c, bundle=bundle, kind=k))) as source:
                source.execute('BEGIN')
                before_version = source.execute('PRAGMA data_version').fetchone()[0]
                with closing(connect(new_path)) as destination:
                    initial_mode = destination.execute('PRAGMA journal_mode=DELETE').fetchone()[0]
                    assert initial_mode == 'delete'
                    def copy_progress(status, remaining, total):
                        if shutil.disk_usage(W).free < 2 * 2**30:
                            raise RuntimeError('copy stopped before exhausting disk headroom')
                    source.backup(destination, pages=4096, progress=copy_progress)
                    actual_main = new_path.stat().st_size
                    sidecar = Path(str(new_path) + '-wal')
                    actual_wal = sidecar.stat().st_size if sidecar.exists() else 0
                    assert actual_wal < max(65536, actual_main // 100), 'copy unexpectedly produced a full-size destination WAL'
                    verify_schema(destination, bundle=bundle, kind=kind)
                    assert [tuple(row) for row in destination.execute('SELECT * FROM schema_history')] == [tuple(row) for row in source.execute('SELECT * FROM schema_history')]
                    if kind == 'catalog':
                        assert not source.execute('SELECT 1 FROM company_operation LIMIT 1').fetchone()
                        assert not source.execute('SELECT 1 FROM company_setting LIMIT 1').fetchone()
                        assert [dict(row) for row in source.execute('SELECT * FROM company')] == [book['company']]
                        assert [dict(row) for row in destination.execute('SELECT * FROM security_owner')] == [dict(row) for row in source.execute('SELECT * FROM security_owner')]
                        assert [tuple(row) for row in destination.execute('SELECT * FROM security_session')] == [tuple(row) for row in source.execute('SELECT * FROM security_session')]
                        destination.execute('BEGIN IMMEDIATE')
                        try:
                            destination.execute('UPDATE company SET path=? WHERE id=?', (new_company['path'], new_company['id']))
                            destination.commit()
                        except BaseException:
                            destination.rollback()
                            raise
                        assert [dict(row) for row in destination.execute('SELECT * FROM company')] == [new_company]
                    else:
                        for table in ('identity', 'state', 'schema_draft_history'):
                            assert [tuple(row) for row in destination.execute('SELECT * FROM '+table)] == [tuple(row) for row in source.execute('SELECT * FROM '+table)]
                        assert destination.execute('PRAGMA foreign_key_check').fetchone() is None
                    assert destination.execute('PRAGMA journal_mode=WAL').fetchone()[0] == 'wal'
                    assert tuple(destination.execute('PRAGMA wal_checkpoint(TRUNCATE)').fetchone()) == (0, 0, 0)
                source.rollback()
                assert source.execute('PRAGMA data_version').fetchone()[0] == before_version
            result['copies'].append({'kind': kind, 'path': str(new_path), 'sha256': guards.sha(new_path), 'bytes': new_path.stat().st_size})
            print(json.dumps({'copied': kind, 'bytes': new_path.stat().st_size}), flush=True)
        checkpoint = json.loads((old_root / cfg['source_builder_name']).read_text('utf-8'))
        checkpoint['company'] = new_company
        with (target / cfg['source_builder_name']).open('x', encoding='utf-8') as handle:
            json.dump(checkpoint, handle, ensure_ascii=False, indent=2)
        copied = book | {'root': str(target), 'company': new_company, 'status': 'copied_content_unverified', 'content_verified': False,
                         'construction_provenance': book['copy_provenance'],
                         'copy_provenance': {'mode': 'same_draft_sqlite_snapshot_copy_pending_declared_upgrade', 'source_root': str(old_root),
                                             'source_manifest_sha256': guards.MANIFEST_SHA, 'helper_sha256': result['helper_sha256'],
                                             'installation_and_history_rewritten': False, 'only_catalog_company_path_changed': True}}
        for path in (input_path, target / 'stage9-draft-copy-book.json'):
            with path.open('x', encoding='utf-8') as handle:
                json.dump(copied, handle, ensure_ascii=False, indent=2)
        assert guards.sha(input_path) == guards.sha(target / 'stage9-draft-copy-book.json')
        result['input_sha256'] = guards.sha(input_path)
        result['target_checkpoint_sha256'] = guards.sha(target / cfg['source_builder_name'])
        result['status'] = 'copied_content_unverified'
    except BaseException as error:
        result['status'], result['error_type'] = 'copy_failed', type(error).__name__
        result['error_traceback'] = traceback.format_exc()
        raise
    finally:
        after, _, _ = guards.guard(args.sample)
        result['source_after'] = after
        result['source_bytes_identity_state_history_and_sessions_unchanged'] = before == after
        result['source_inventory_unchanged'] = guards.source_guard() == source_guard
        result['finished_at'] = datetime.now(UTC).isoformat()
        with output.open('x', encoding='utf-8') as handle:
            json.dump(result, handle, ensure_ascii=False, indent=2)
        assert result['source_bytes_identity_state_history_and_sessions_unchanged'] and result['source_inventory_unchanged']


if __name__ == '__main__':
    main()
