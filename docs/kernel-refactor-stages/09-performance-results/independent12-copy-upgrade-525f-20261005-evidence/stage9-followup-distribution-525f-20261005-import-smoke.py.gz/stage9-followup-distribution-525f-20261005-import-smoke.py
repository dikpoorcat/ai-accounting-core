"""Check actual fixed-source imports without any database connection."""
import ast
import hashlib
import importlib
import json
import sqlite3
import sys
from pathlib import Path

W = Path(__file__).resolve().parents[1]
S = W / '.tmp/stage9-build-source-verification-snapshot-converged-20261005'
OUT = W / '.tmp/stage9-followup-distribution-525f-20261005-import-smoke.json'
DRIVER = W / '.tmp/stage9-followup-distribution-525f-20261005-upgrade-v2.py'

def digest(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()

def forbidden(*args, **kwargs):
    raise AssertionError('Import smoke must not open a database')

assert sys.flags.dont_write_bytecode and sys.flags.utf8_mode
assert Path(sys.prefix).resolve() == W / '.tmp-kernel-venv'
assert not OUT.exists()
sqlite3.connect = forbidden
sys.path.insert(0, str(S / 'scripts'))
import stage9_source
stage9_source.configure_source(S, W)
manifest = json.loads((S / 'source-manifest.json').read_text('utf-8'))
assert manifest['sha256'] == '525f02d6718561bb51b22b559b03b3dc6f2aea968eb9a3a13484a532c0cc1d9f'
text = DRIVER.read_text('utf-8')
compile(text, str(DRIVER), 'exec')
tree = ast.parse(text)
names = set()
for node in ast.walk(tree):
    if not isinstance(node, ast.ImportFrom) or not node.module:
        continue
    if node.module == 'ai_accounting.kernel':
        names.update('ai_accounting.kernel.' + item.name for item in node.names)
    elif node.module.startswith('ai_accounting.kernel.'):
        names.add(node.module)
checked = []
for name in sorted(names):
    module = importlib.import_module(name)
    relative = 'src/' + name.replace('.', '/') + '.py'
    stage9_source.require_source_module(module, S, relative)
    checked.append({'module': name, 'relative': relative, 'sha256': digest(S / relative)})
from ai_accounting.kernel import backup, runtime, offline_development_upgrade
assert backup.verification_snapshot is runtime.verification_snapshot
assert offline_development_upgrade.verification_snapshot is runtime.verification_snapshot
for node in ast.walk(tree):
    if isinstance(node, ast.ImportFrom) and node.module and node.module.startswith('ai_accounting.kernel.'):
        module = importlib.import_module(node.module)
        for item in node.names:
            assert hasattr(module, item.name), (node.module, item.name)
value = {'status': 'actual_imports_passed_no_database', 'source_sha256': manifest['sha256'],
         'source_manifest_sha256': digest(S / 'source-manifest.json'),
         'driver_sha256': digest(DRIVER), 'modules': checked,
         'sqlite_connections_forbidden': True, 'helper_sha256': digest(Path(__file__)),
         'scope': 'actual imports and explicit symbols; no qualification, migration or performance claim'}
with OUT.open('x', encoding='utf-8') as handle:
    json.dump(value, handle, ensure_ascii=False, indent=2)
print(json.dumps(value, ensure_ascii=False))
