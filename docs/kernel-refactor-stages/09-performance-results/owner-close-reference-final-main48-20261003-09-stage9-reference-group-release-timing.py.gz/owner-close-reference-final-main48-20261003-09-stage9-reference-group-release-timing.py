"""Run the prepared controller after this exact live qualifier signals ready."""
import ctypes
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

workspace = Path(__file__).resolve().parents[1]
assert Path(sys.prefix).resolve() == workspace / '.tmp-kernel-venv'
prefix = workspace / '.tmp/stage9-owner-main48-reference-group'
ready = Path(str(prefix) + '-timing-ready.json')
qualified = Path(str(prefix) + '-qualified.json')
report = Path(str(prefix) + '-browser.json')
output = workspace / '.tmp/stage9-reference-group-release-timing.json'
assert not output.exists()
kernel = ctypes.WinDLL('kernel32', use_last_error=True)
kernel.OpenProcess.argtypes = [ctypes.c_ulong, ctypes.c_int, ctypes.c_ulong]
kernel.OpenProcess.restype = ctypes.c_void_p
kernel.WaitForSingleObject.argtypes = [ctypes.c_void_p, ctypes.c_ulong]
kernel.CloseHandle.argtypes = [ctypes.c_void_p]
handle = kernel.OpenProcess(0x00100000, False, 39344)
assert handle, 'Pinned qualifier no longer running'
result = {'status': 'waiting', 'qualifier_pid': 39344, 'ready': str(ready)}
try:
    deadline = time.monotonic() + 7200
    while not ready.exists():
        if kernel.WaitForSingleObject(handle, 0) != 258:
            raise RuntimeError('Qualifier exited before timing ready')
        if time.monotonic() > deadline:
            raise TimeoutError('Qualifier did not become ready')
        time.sleep(0.5)
    signal = json.loads(ready.read_text(encoding='utf-8'))
    assert signal['pid'] == 39344 and Path(signal['output']).resolve() == report
    raw = qualified.read_bytes()
    sha = hashlib.sha256(raw).hexdigest()
    assert json.loads(raw)['status'] == 'complete'
    result['qualification_sha256'] = sha
    completed = subprocess.run([
        sys.executable, '-B', '-X', 'utf8',
        str(workspace / '.tmp/stage9-close-reference-group-timing-control.py'),
        '--source', str(workspace / '.tmp/stage9-build-source-owner-reference-group-20261003-release'),
        '--book-report', str(qualified), '--report-sha256', sha, '--output', str(report),
    ], cwd=workspace, check=False)
    result.update(status='controller_completed', controller_exitcode=completed.returncode)
    assert completed.returncode == 0
finally:
    kernel.CloseHandle(handle)
    with output.open('x', encoding='utf-8') as target:
        json.dump(result, target, ensure_ascii=False, indent=2)
        target.write('\n')
