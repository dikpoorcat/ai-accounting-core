"""One-shot, synthetic r37 quarterly-party work attribution; not page timing.

Run only after the coordinator approves it, with .tmp-kernel-venv Python. This
uses the existing stage9_metrics SQL/VM/byte counters, then assigns the same
work to nested report phases. It neither changes application code nor writes
the company database. Inclusive phase counters must never be added together.
"""

from __future__ import annotations

import hashlib
import json
import os
import sys
import time
from collections import Counter, defaultdict
from contextlib import contextmanager
from functools import wraps
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp/stage9-build-source-r37-release"
BOOK = ROOT / ".tmp/stage9-reseed-main-48-r36.staging"
OUTPUT = ROOT / ".tmp/stage9-r37-party-proof-work.json"
sys.path[:0] = [str(SOURCE / "src"), str(ROOT / "tests/kernel")]
os.environ["STAGE9_WORKSPACE_ROOT"] = str(ROOT)


def _bytes(value):
    from stage9_metrics import _value_bytes

    return _value_bytes(value)


class Observation:
    def __init__(self):
        self.stack = []
        self.events = []
        self.statement_work = defaultdict(Counter)
        self.seen_payloads = set()
        self.seen_contribution_ids = set()
        self.decode_count = 0
        self.decode_bytes = 0
        self.patches = []
        self.next_id = 0

    def patch(self, owner, name, wrapper):
        original = getattr(owner, name)
        setattr(owner, name, wrapper(original))
        self.patches.append((owner, name, original))

    def restore(self):
        for owner, name, original in reversed(self.patches):
            setattr(owner, name, original)

    def add(self, name, value):
        if not self.stack or not value:
            return
        for event in self.stack:
            event["work"][name + "_inclusive"] += value
        self.stack[-1]["work"][name + "_exclusive"] += value

    def sql(self, statement, name, value):
        self.add(name, value)
        if self.stack and value:
            key = (self.stack[-1]["phase"], " ".join(statement.split()))
            self.statement_work[key][name] += value

    @contextmanager
    def phase(self, name, **details):
        self.next_id += 1
        parent = self.stack[-1] if self.stack else None
        event = {
            "id": self.next_id,
            "parent_id": None if parent is None else parent["id"],
            "phase": name,
            "details": details,
            "work": Counter(),
            "child_cpu_ns": 0,
            "child_wall_ns": 0,
        }
        self.stack.append(event)
        wall_started = time.perf_counter_ns()
        cpu_started = time.process_time_ns()
        try:
            yield event
            event["success"] = True
        except BaseException as exc:
            event["success"] = False
            event["error_type"] = type(exc).__name__
            raise
        finally:
            cpu = time.process_time_ns() - cpu_started
            wall = time.perf_counter_ns() - wall_started
            event["cpu_ms_inclusive"] = cpu / 1e6
            event["cpu_ms_exclusive"] = (cpu - event.pop("child_cpu_ns")) / 1e6
            event["wall_ms_inclusive"] = wall / 1e6
            event["wall_ms_exclusive"] = (wall - event.pop("child_wall_ns")) / 1e6
            event["work"] = dict(event["work"])
            assert self.stack.pop() is event
            if parent is not None:
                parent["child_cpu_ns"] += cpu
                parent["child_wall_ns"] += wall
            self.events.append(event)

    def install_sql(self):
        # stage9_metrics owns the progress handler (100-VM-step sampling),
        # counts all SQL and payload bytes, and returns its normal work report.
        # These wrappers only attribute those same counters to active phases.
        from stage9_metrics import _Connection, _Cursor

        def execute_wrapper(original):
            @wraps(original)
            def execute(connection, statement, parameters=()):
                before = connection.counts["sqlite_vm_steps"]
                self.sql(statement, "sql_calls", 1)
                try:
                    cursor = original(connection, statement, parameters)
                    cursor._party_diag_statement = statement
                    return cursor
                finally:
                    self.sql(
                        statement,
                        "sqlite_vm_steps_sampled",
                        connection.counts["sqlite_vm_steps"] - before,
                    )

            return execute

        def read_wrapper(original):
            @wraps(original)
            def read(cursor, operation, *args):
                before = cursor.counter["sqlite_vm_steps"]
                try:
                    return original(cursor, operation, *args)
                finally:
                    self.sql(
                        getattr(cursor, "_party_diag_statement", "<unbound cursor>"),
                        "sqlite_vm_steps_sampled",
                        cursor.counter["sqlite_vm_steps"] - before,
                    )

            return read

        def row_wrapper(original):
            @wraps(original)
            def row(cursor, value):
                result = original(cursor, value)
                if result is None or not self.stack:
                    return result
                statement = getattr(cursor, "_party_diag_statement", "<unbound cursor>")
                self.sql(statement, "returned_rows", 1)
                self.sql(statement, "returned_value_bytes", sum(_bytes(part) for part in result))
                for part in result:
                    if not isinstance(part, (str, bytes, bytearray, memoryview)):
                        continue
                    raw = part.encode("utf-8") if isinstance(part, str) else bytes(part)
                    if len(raw) < 256:
                        continue
                    fingerprint = (len(raw), hashlib.sha256(raw).digest())
                    if fingerprint in self.seen_payloads:
                        self.sql(statement, "repeated_large_value_bytes", len(raw))
                    else:
                        self.seen_payloads.add(fingerprint)
                        self.sql(statement, "first_large_value_bytes", len(raw))
                return result

            return row

        self.patch(_Connection, "execute", execute_wrapper)
        self.patch(_Cursor, "_read", read_wrapper)
        self.patch(_Cursor, "_row", row_wrapper)

    def install_report(self):
        from ai_accounting.kernel import (
            query_reads,
            report_flow,
            report_open_contribution,
            report_projection,
        )

        def party_wrapper(original):
            @wraps(original)
            def party(engine, connection, cutoff, *, source="open", reads=None):
                cache = reads._report_snapshot_cache if reads is not None else {}
                with self.phase(
                    "party_balance_rows", cutoff=cutoff, source=source,
                    cache_hit_before=("party_balance_rows", cutoff, source) in cache,
                ) as event:
                    result = original(engine, connection, cutoff, source=source, reads=reads)
                    event["details"]["returned_rows"] = None if result is None else len(result)
                    return result

            return party

        def delta_wrapper(original):
            @wraps(original)
            def delta(engine, connection, period, source_rows, *, source="open",
                      classification_refs=None, reads=None):
                with self.phase(
                    "party_delta", period=period, source=source,
                    selected_source_rows=len(source_rows),
                    classification_refs=None if classification_refs is None else len(classification_refs),
                ) as event:
                    result = original(
                        engine, connection, period, source_rows, source=source,
                        classification_refs=classification_refs, reads=reads,
                    )
                    event["details"]["usable"] = result[1]
                    return result

            return delta

        def rows_wrapper(original):
            @wraps(original)
            def rows(connection, scope, period, *, with_absence=False):
                with self.phase(
                    "authoritative_rows", scope=scope, period=period,
                    with_absence=with_absence,
                ) as event:
                    result = original(connection, scope, period, with_absence=with_absence)
                    event["details"]["returned_rows"] = len(result[0] if with_absence else result)
                    return result

            return rows

        def contribution_wrapper(original):
            @wraps(original)
            def contribution(engine, connection, calculation_ids, *, reads):
                ids = set(calculation_ids)
                cache = reads._report_snapshot_cache.get("report_open_contributions", {})
                before = self.seen_contribution_ids.copy()
                self.seen_contribution_ids.update(ids)
                with self.phase(
                    "read_open_contributions", requested_count=len(ids),
                    requested_seen_earlier=len(ids & before),
                    requested_new=len(ids - before),
                    cache_hit_before=len(ids & cache.keys()),
                    missing_before=len(ids - cache.keys()),
                ) as event:
                    decode_before = self.decode_count
                    decode_bytes_before = self.decode_bytes
                    result = original(engine, connection, calculation_ids, reads=reads)
                    event["details"]["returned_count"] = len(result)
                    event["details"]["decoded_count"] = self.decode_count - decode_before
                    event["details"]["decoded_input_bytes"] = self.decode_bytes - decode_bytes_before
                    return result

            return contribution

        def decode_wrapper(original):
            @wraps(original)
            def decode(content, publication_id):
                value = original(content, publication_id)
                self.decode_count += 1
                self.decode_bytes += _bytes(content)
                return value

            return decode

        def proof_wrapper(original):
            @wraps(original)
            def proof(reads, sealed_proof):
                with self.phase("verify_anchored_source_bytes") as event:
                    result = original(reads, sealed_proof)
                    event["details"]["verified_binding_count"] = len(result)
                    return result

            return proof

        def relations_wrapper(original):
            @wraps(original)
            def relations(reads, lines_by_source):
                with self.phase(
                    "fallback_report_line_relations", source_count=len(lines_by_source),
                ):
                    return original(reads, lines_by_source)

            return relations

        def flow_wrapper(original):
            @wraps(original)
            def flow(connection, period, *, reads=None):
                cache = reads._report_snapshot_cache if reads is not None else {}
                with self.phase(
                    "read_report_flow", period=period,
                    cache_hit_before=("report_period_flow", period) in cache,
                ) as event:
                    result = original(connection, period, reads=reads)
                    event["details"]["available"] = result is not None
                    return result

            return flow

        self.patch(report_projection, "party_balance_rows", party_wrapper)
        self.patch(report_projection, "_party_delta", delta_wrapper)
        self.patch(report_projection, "_authoritative_rows", rows_wrapper)
        self.patch(report_open_contribution, "read_open_contributions", contribution_wrapper)
        self.patch(report_open_contribution, "_decode", decode_wrapper)
        self.patch(query_reads.QueryReads, "_verify_anchored_source_bytes", proof_wrapper)
        self.patch(query_reads.QueryReads, "report_line_relations_many", relations_wrapper)
        self.patch(report_flow, "read_report_flow", flow_wrapper)


def main():
    assert Path(sys.prefix).resolve() == (ROOT / ".tmp-kernel-venv").resolve()
    assert SOURCE.is_dir() and BOOK.is_dir()
    assert BOOK.resolve().is_relative_to((ROOT / ".tmp").resolve())
    assert not OUTPUT.exists(), "Preserve any prior diagnostic; choose a new output name"

    from ai_accounting.kernel.daemon import _prepare_static_runtime
    from ai_accounting.kernel.dashboard import Dashboard
    from ai_accounting.kernel.service import LocalService
    from stage9_metrics import measure_work

    service = LocalService(
        BOOK, enable_read_pool=True, enable_parallel_brief=True,
        _static_runtime=_prepare_static_runtime(),
    )
    try:
        companies = service.catalog.companies()
        assert len(companies) == 1 and companies[0]["name"] == "阶段九合成规模企业"
        engine = service.engine(companies[0]["id"], dashboard_read=True)
        page = Dashboard(engine)
        observation = Observation()
        observation.install_sql()
        observation.install_report()
        try:
            work, response = measure_work(
                engine,
                lambda: page.quarterly_report(2019, 4, preparation="deferred"),
            )
        finally:
            observation.restore()
        assert response["period"]["year"] == 2019
        assert response["period"]["quarter"] == 4
        assert response["readiness_state"] == "ready", response.get("readiness_state")
        output = {
            "scope": "r37_main48_single_quarterly_report_party_proof_work_diagnostic",
            "source": str(SOURCE), "book": str(BOOK),
            "period": "2019-12", "not_browser_latency": True,
            "counter_note": (
                "SQL VM is sampled per 100 steps; bytes are values delivered to Python, "
                "not physical disk bytes. Phase CPU includes diagnostic overhead. "
                "Inclusive parent/child values overlap and must not be summed. "
                "Large-value first/repeated means byte-identical SQL values >=256 bytes "
                "within this request; it does not waive any integrity check."
            ),
            "whole_request_work": work,
            "phase_events": observation.events,
            "sql_by_exclusive_phase": [
                {"phase": phase, "statement": statement, **counts}
                for (phase, statement), counts in observation.statement_work.items()
            ],
            "unique_requested_contribution_ids": len(observation.seen_contribution_ids),
            "successful_contribution_decodes": observation.decode_count,
            "successful_contribution_decode_input_bytes": observation.decode_bytes,
        }
        OUTPUT.write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")
        print(OUTPUT)
    finally:
        service.close()


if __name__ == "__main__":
    main()
