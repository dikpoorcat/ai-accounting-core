"""Read-only identity-call locator; never a page latency or full-proof claim."""
from __future__ import annotations

import argparse
import hashlib
import inspect
import json
import sys
import traceback
from contextlib import contextmanager
from itertools import combinations
from pathlib import Path
from unittest.mock import patch

W = Path(__file__).resolve().parents[1]
SOURCE = W / '.tmp/stage9-build-source-owner-month-reads-20261003-release'
SOURCE_SHA = '1c37c576cb0026b0b39c199b74672a60890c43a7d9e2b944416179fe2bf398e9'
MANIFEST_SHA = '845318d7e9857cbae422033a7e8b87a5fb7edd2896f1c5f0617709eabca1c979'
BOOK = W / '.tmp/stage9-owner-main12-month-reads-qualified.json'
BOOK_SHA = '066dff5d70b1ae0a37d6f8f615c4242af2c0f6a6269c507f062a4a7bb739fa58'
ROOT = W / '.tmp/stage9-owner-main12-r43'


def require(value, reason):
    if not value:
        raise ValueError(reason)


def sha(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--report-sha256', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    out = args.output.resolve()
    log_path = out.with_suffix('.log')
    require(out.is_relative_to(W / '.tmp') and not out.exists() and not log_path.exists(),
            'Exclusive must-new output/log inside .tmp required')
    require(args.report_sha256 == BOOK_SHA, 'Only the pinned main12 receipt is authorized')
    require(Path(sys.prefix).resolve() == (W / '.tmp-kernel-venv').resolve(), 'Use repo venv')
    report = {'status': 'started', 'scope': 'default_assets_member_identity_overlap',
              'production_modified': False, 'read_only': True, 'page_latency_acceptance': False,
              'source_sha256': SOURCE_SHA, 'script_sha256': sha(Path(__file__)),
              'qualification_sha256': BOOK_SHA, 'calls': [], 'pairwise': []}
    out.open('x').close()
    log = log_path.open('x', encoding='utf-8')
    pool = None

    def save():
        out.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

    def note(text):
        print(text, flush=True)
        log.write(text + '\n')
        log.flush()

    try:
        manifest_path = SOURCE / 'source-manifest.json'
        require(sha(manifest_path) == MANIFEST_SHA and sha(BOOK) == BOOK_SHA, 'Attestation drift')
        manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
        require(manifest['status'] == 'complete' and manifest['sha256'] == SOURCE_SHA
                and Path(manifest['target']).resolve() == SOURCE, 'Wrong fixed source')
        sys.path.insert(0, str(SOURCE / 'scripts'))
        import stage9_source
        stage9_source.require_source_module(stage9_source, SOURCE, 'scripts/stage9_source.py')
        stage9_source.configure_source(SOURCE, W)
        import benchmark_stage9_browser
        import snapshot_stage9_source
        from ai_accounting.kernel import asset_batches, business_queries, catalog as catalog_module
        from ai_accounting.kernel import dashboard as dashboard_module, engine as engine_module
        from ai_accounting.kernel import query_reads, resident_reads, schema_bundle
        from ai_accounting.kernel.types import canonical
        from ai_accounting.kernel.versions import database_format

        modules = [(stage9_source, 'scripts/stage9_source.py'),
                   (benchmark_stage9_browser, 'scripts/benchmark_stage9_browser.py'),
                   (snapshot_stage9_source, 'scripts/snapshot_stage9_source.py'),
                   (catalog_module, 'src/ai_accounting/kernel/catalog.py'),
                   (dashboard_module, 'src/ai_accounting/kernel/dashboard.py'),
                   (engine_module, 'src/ai_accounting/kernel/engine.py'),
                   (business_queries, 'src/ai_accounting/kernel/business_queries.py'),
                   (query_reads, 'src/ai_accounting/kernel/query_reads.py'),
                   (asset_batches, 'src/ai_accounting/kernel/asset_batches.py'),
                   (resident_reads, 'src/ai_accounting/kernel/resident_reads.py'),
                   (schema_bundle, 'src/ai_accounting/kernel/schema_bundle.py')]
        for module, relative in modules:
            stage9_source.require_source_module(module, SOURCE, relative)
        report['module_bindings'] = {module.__name__: {
            'path': str(module.__file__), 'sha256': sha(Path(module.__file__)),
        } for module, _ in modules}

        def check_source():
            inventory = snapshot_stage9_source._inventory(SOURCE)
            require(inventory == manifest['files']
                    and snapshot_stage9_source._digest(inventory) == SOURCE_SHA, 'Source drift')
            require(sha(manifest_path) == MANIFEST_SHA and sha(BOOK) == BOOK_SHA,
                    'Ending attestation drift')

        check_source()
        book = json.loads(BOOK.read_text(encoding='utf-8'))
        benchmark_stage9_browser.require_report_source(book, SOURCE)
        period = benchmark_stage9_browser.validate_book_report(book, company_name='阶段九合成规模企业')
        require(book['requested_months'] == 12 and book['monthly_business_count'] == 1000
                and book['employee_count'] == 50 and book['distribution'] == 'mixed_cumulative',
                'Wrong qualified sample')
        root = stage9_source.synthetic_path(Path(book['root']), W)
        require(root == ROOT and period == '2016-12', 'Wrong authorized root/month')
        company = book['company']
        db = Path(company['path']).resolve(strict=True)
        require(db.is_relative_to(root) and (root / 'catalog.sqlite').is_file(),
                'Existing databases outside pinned root or missing')
        checkpoint_path = root / 'stage9-builder.json'
        checkpoint_sha = sha(checkpoint_path)
        require(checkpoint_sha == book['qualification']['checkpoint_sha256'], 'Checkpoint SHA drift')
        checkpoint = json.loads(checkpoint_path.read_text(encoding='utf-8'))
        expected_state = book['verified_open_preview']['state']
        require(checkpoint['company'] == company and checkpoint['snapshots'] == book['snapshots']
                and checkpoint['epochs'] == expected_state, 'Checkpoint differs from proof')
        expected_identity = {'company_id': company['id'], 'database_id': company['database_id'],
                             'taxpayer_id': company['taxpayer_id']}
        report.update({'root': str(root), 'period': period, 'checkpoint_sha256': checkpoint_sha})

        class ReadOnlyCatalog(catalog_module.Catalog):
            @contextmanager
            def connection(self, *, read_only=False, _cross_thread=False):
                require(read_only, 'Diagnostic forbids catalog writes')
                with super().connection(read_only=True, _cross_thread=_cross_thread) as connection:
                    yield connection

            def recover_operations(self):
                with self.connection(read_only=True) as connection:
                    count = connection.execute(
                        "SELECT count(*) FROM company_operation WHERE status!='succeeded'"
                    ).fetchone()[0]
                require(count == 0, 'Unfinished catalog operation; do not recover')

        bundle = schema_bundle.production_bundle()
        catalog = ReadOnlyCatalog(root, bundle)
        require(catalog.database_format()['status'] == 'released'
                and catalog.database_format()['version'] == 1, 'Wrong catalog contract')
        companies = catalog.companies()
        require([row for row in companies if row['id'] == company['id']] == [company],
                'Catalog company identity changed')
        with catalog.connection(read_only=True) as connection:
            catalog_identity = dict(connection.execute('SELECT * FROM catalog_identity').fetchone())
        pool = resident_reads.ResidentReadPool(maximum=4)
        store = catalog.bind(company['id'], read_pool=pool)
        original_connection = store.connection

        @contextmanager
        def read_only_connection(*, read_only=False):
            require(read_only, 'Diagnostic forbids company writes')
            with original_connection(read_only=True) as connection:
                yield connection

        store.connection = read_only_connection
        engine = engine_module.Engine(store)
        dashboard = dashboard_module.Dashboard(engine, company_name=company['name'], companies=companies)

        def check_state():
            with store.connection(read_only=True) as connection:
                connection.execute('BEGIN')
                state = list(connection.execute('SELECT * FROM state WHERE id=1').fetchone())
                identity = dict(connection.execute(
                    'SELECT company_id,taxpayer_id,database_id FROM identity WHERE id=1').fetchone())
                require(state == expected_state and identity == expected_identity, 'State/identity drift')
                require(database_format(connection, bundle=bundle) == book['integrity_contract'],
                        'Company contract drift')
            with catalog.connection(read_only=True) as connection:
                require(dict(connection.execute('SELECT * FROM catalog_identity').fetchone())
                        == catalog_identity, 'Catalog identity drift')
            require(catalog.companies() == companies, 'Catalog registration drift')
            require(sha(checkpoint_path) == checkpoint_sha, 'Checkpoint drift')
            return {'state': state, 'identity': identity, 'catalog_identity': catalog_identity}

        report['before'] = check_state()
        original = business_queries.BusinessQueries._asset_member_identity_events
        tokens = []

        def cache_scope(reads, selection, cutoff):
            keys = [('asset_owner_identity_selection', cutoff),
                    ('asset_activation_identity_events', cutoff)]
            return {'successful_identity_cache_keys': [key[0] for key in keys
                    if key in reads._report_snapshot_cache],
                    'same_cached_owner_selection':
                    reads._report_snapshot_cache.get(keys[0]) is selection,
                    'full_member_proof_cached_owner_ids': sorted(reads._asset_members)}

        def traced(self, connection, requested_period, *, asset_ids, selection, include_sources=False):
            reads = self._reads(connection)
            require(reads._snapshot_active and reads.connection is connection
                    and reads.store is store and connection.in_transaction,
                    'Identity probe requires the actual owned read snapshot')
            token = reads._snapshot_token
            if not any(item is token for item in tokens):
                tokens.append(token)
            snapshot_number = next(index + 1 for index, item in enumerate(tokens) if item is token)
            frame = inspect.currentframe()
            caller = frame.f_back
            caller_info = {'function': caller.f_code.co_name,
                           'file': str(Path(caller.f_code.co_filename).resolve()),
                           'line': caller.f_lineno}
            del caller, frame
            require(selection is not None, 'Unexpected complete fallback: record failure, do not invent scope')
            events, owners, frozen_membership, _decoded = selection
            owner_ids = sorted({event['calculation_id'] for event in events})
            cutoff = query_reads.YearMonth(requested_period).ordinal
            entry = {'call': len(report['calls']) + 1, 'status': 'entered',
                     'snapshot_number': snapshot_number, 'caller': caller_info,
                     'period': requested_period, 'include_sources': include_sources,
                     'asset_ids': None if asset_ids is None else sorted(asset_ids),
                     'input_event_count': len(events), 'owner_ids': owner_ids,
                     'owner_kind_ids': {kind: sorted(ident for ident in owner_ids
                        if owners[ident]['kind'] == kind)
                        for kind in sorted({owners[ident]['kind'] for ident in owner_ids})},
                     'frozen_owner_ids': sorted(set(owner_ids) & frozen_membership.keys()),
                     'before_cache': cache_scope(reads, selection, cutoff),
                     'proof_execution': 'Untouched original function executes its complete selected directories'}
            report['calls'].append(entry)
            save()
            try:
                result = original(self, connection, requested_period, asset_ids=asset_ids,
                                  selection=selection, include_sources=include_sources)
                entry['returned_count'] = len(result)
                entry['returned_identities'] = [{'owner_id': event['owner_calculation_id'],
                    'member_id': event['calculation_id'], 'subject_id': event.get('subject_id'),
                    'subject_id_present': 'subject_id' in event, 'asset_id': event['asset_id']}
                    for event in result]
                entry['after_cache'] = cache_scope(reads, selection, cutoff)
                entry['status'] = 'succeeded'
                save()
                return result
            except BaseException:
                entry['status'] = 'failed_original_proof'
                entry['after_cache'] = cache_scope(reads, selection, cutoff)
                save()
                raise

        with patch.object(business_queries.BusinessQueries, '_asset_member_identity_events', traced):
            response = dashboard.assets(period, limit=20, preparation='deferred')
        require(response['selected_period']['key'] == period
                and response['read_context']['company_id'] == company['id'], 'Wrong response identity/month')
        for collection in response['data']['collections'].values():
            page = collection['page']
            require(len(collection['items']) == page['returned_count'] == min(20, page['filtered_count']),
                    'Incomplete default page')
        report['response'] = response
        report['response_sha256'] = hashlib.sha256(canonical(response).encode()).hexdigest()
        for left, right in combinations(report['calls'], 2):
            owners_left, owners_right = set(left['owner_ids']), set(right['owner_ids'])
            members_left = {(item['owner_id'], item['member_id']) for item in left['returned_identities']}
            members_right = {(item['owner_id'], item['member_id']) for item in right['returned_identities']}
            report['pairwise'].append({'left_call': left['call'], 'right_call': right['call'],
                'same_snapshot': left['snapshot_number'] == right['snapshot_number'],
                'left_owner_count': len(owners_left), 'right_owner_count': len(owners_right),
                'owner_intersection_ids': sorted(owners_left & owners_right),
                'owner_intersection_count': len(owners_left & owners_right),
                'owner_union_count': len(owners_left | owners_right),
                'returned_member_intersection': [list(item) for item in sorted(members_left & members_right)],
                'returned_member_intersection_count': len(members_left & members_right)})
        report['after'] = check_state()
        check_source()
        require(business_queries.BusinessQueries._asset_member_identity_events is original,
                'Process wrapper not restored')
        report['status'] = 'diagnostic_complete'
        report['limitations'] = ['One default assets call, not page timing or a changed algorithm',
            'Only IDs and caller/cache scope recorded at the identity wrapper; no raw result/fact bodies',
            'Normal asset response retained unchanged; no second oracle read or new financial qualification',
            'Shared owner input proves repeated directory scope, not net benefit or redundant proof semantics',
            'Fallback, fixed-v1, custom filters/paging and main48/main120 not exercised']
        save()
        note(f"Complete: {len(report['calls'])} identity calls; {len(tokens)} owned snapshot(s); no page claim")
    except BaseException:
        report['status'] = 'failed'
        report['error'] = traceback.format_exc()
        if 'check_state' in locals():
            try:
                report['failure_ending_state'] = check_state()
                check_source()
                report['failure_ending_guards'] = 'passed'
            except BaseException:
                report['failure_ending_guard_error'] = traceback.format_exc()
        save()
        note(report['error'])
        raise
    finally:
        if pool is not None:
            pool.close()
        log.close()


if __name__ == '__main__':
    main()
