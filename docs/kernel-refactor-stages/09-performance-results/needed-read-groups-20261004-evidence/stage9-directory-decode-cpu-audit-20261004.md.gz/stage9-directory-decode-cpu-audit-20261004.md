# Stage 9 directory JSON CPU read-only audit — 2026-10-04

## Conclusion

Current family reads materialize all committed descriptor arrays before using a negative filter. With 119 month roots and roughly 4.7 MB of family content, parsing allocates roughly 60,928 descriptor triples even if all queried subjects are absent. The recently changed descriptor index does not remove this parse/allocation work; it addresses subsequent lookups. There is no proved production-ready parser replacement in this audit.

The existing installed `pydantic_core.from_json` is measurably faster on a pure-memory shape-matched fixture, but direct replacement changes accepted JSON and error behavior. A current-only fast parser with CPython fallback is a candidate for further bounded compatibility tests; it must not replace `stored_json.loads_unique`, fixed v1 readers, SHA binding, or downstream validation. This audit does not authorize a code change or claim an assets endpoint improvement.

## Scope and evidence boundaries

- Read repository AGENTS.md, current close/root/report/balance/settlement readers, fixed-history dispatch, unique source JSON handling, and current negative-filter implementation.
- Did not open any SQLite database; no business data, runtime, schema guard, realdata, main samples, preview, service, or whole-company verifier was used. Database guard requirements are therefore not applicable to this strictly in-memory experiment.
- Wrote only this `.tmp` report and the companion pure-memory script/results: `stage9_directory_decode_cpu_audit_20261004.py` / `.json`. Production code and dependencies are unchanged.
- The reported real workload's 119 calls / 4.73 MB / about 85 ms cProfile time was supplied by the parent task; it was not independently reproduced. The micro below is unprofiled, synthetic, and cannot be extrapolated to that 85 ms or an endpoint wall time.

## Current execution inventory

| Current component | Decoder and binding | Existing shape/semantic checks |
|---|---|---|
| close_storage `_validate_header` (461 onward) | `json.loads`; raw manifest SHA bound to support row, logical digest/source marker and company/database | Exact root keys, encoding, period, source-change contract/highwater, identity, derived-root hashes, small metadata |
| close_storage `_decode_family` (599 onward) | `json.loads`; raw content SHA, row digest, header subroot hex | This function itself does **not** check full family shape. Accounting filter reader checks exact accounting root keys and full filter; management reader checks its own shape; bucket readers check requested directory and leaf proofs. Preserve these boundaries rather than silently installing a stricter schema. |
| close_storage `_families_many` (613 onward) | Batch fetches exact missing month roots then calls `_decode_family` independently | Ordered zip and individual month digest bindings remain |
| close_storage `_bucket_rows` (636 onward) | `json.loads`; directory and block SHA | Requested part sequence/count and leaf checks; recently edited descriptor index is outside this audit |
| period_balance_freeze `_verified_root` (359 onward) | `json.loads`; close/publication binding and raw SHA | Exact root keys; complete bucket directory type/range/hash/uniqueness/order checks in reader |
| settlement_freeze `_root` (321 onward) | `json.loads`; close/root digest plus raw SHA | Format/period/close binding; full subject and all/open directory checks. Does not require an exact top-level key set. State/block decoders have distinct validations. |
| report_classification_directory `_read_root` (289 onward), `_Nodes.read` (near 98) | `json.loads`; root/node raw SHA | Canonical byte equality and root counts/filter/tree checks; cannot remove canonical equality as a parser optimization |
| report_flow `load_period_flow` (near 318 onward) | `json.loads`; private parent root binds exact writer string and report/semantic roots | Exact adopted classification reference/voucher proof continues after decode |
| report_semantics `_decode` (near 326), authenticated paths (near 385) | `json.loads`; authenticated and unauthenticated branches differ | Preserve the existing semantic validation, not just parse success |
| report_open_contribution `_decode` (333 onward) | Already `from_json` with manual shape checks | Current implementation is not evidence that another component's CPython error semantics are compatible. Its own-source path uses a `SchemaValidator.validate_json` projection separately. |
| stored_json / source JSON | `json.loads(object_pairs_hook=_unique_object)` | Reject duplicate decoded keys at every object nesting level; ordinary `from_json` accepts last member, so is not a replacement |

`content_history_context` routes close/report/balance/settlement/semantics/classification/open contribution to separate `_v1` modules when historical version is 1. Any future helper should be imported only by active modules, leave all `_v1` implementation/encoding untouched, and have an explicit context dispatch check. This audit made no dispatch changes.

## Pure-memory micro

Environment: repository `.tmp-kernel-venv`, Python 3.12.13, pydantic_core 2.41.5, Windows 10. Payloads: 119 distinct ASCII JSON strings, 4,627,196 bytes total. Each has two 256-entry directory arrays and a negative-filter-shaped value. Digests vary by month; no payload duplicate exists. Three warmups, 15 samples, median reported. The filter string is synthetic; this micro does not call the production filter checker. `sha_and_sample_shape` checks every raw SHA and descriptor basic shape but is **not** a substitute for production full verification.

| Decoder | Parse only median ms | SHA + sample shape median ms |
|---|---:|---:|
| CPython json.loads | 22.522 | 28.781 |
| from_json default | 18.462 | 23.881 |
| from_json ValueError → json.loads fallback | 17.778 | 24.227 |
| from_json cache_strings=False | 17.748 | 24.561 |
| from_json cache_strings='keys' | 19.335 | 23.935 |

On this fixture the default parser reduces checked micro by 4.900 ms (17%). Cache policy variants overlap timing noise and provide no dependable additional improvement. Previous bounded executions produced CPython parse medians 22.276 and 26.625 ms, illustrating run-to-run noise. No cProfile was used, so the result is not a direct comparison with profiled family time. Grouping 119 decodes into one giant JSON document was not tested: it changes failure localization/order and retains an entire group allocation; SQL-side projection would drop full raw structure decoding and is not an equivalent replacement.

## JSON compatibility matrix

The companion JSON records full case outcomes, value type signatures, float hexadecimal representations, and exception messages.

| Case | CPython vs from_json observed result | Consequence |
|---|---|---|
| Duplicate keys; escaped-equivalent keys; nested duplicate | Both keep last value | Compatible for ordinary loads only. Incompatible with unique-source loads, which reject duplicates. |
| NaN, Infinity, -Infinity, overflow 1e999 | Both accept corresponding float values | Do not set allow_inf_nan=False as an optimization; existing writer `canonical(...allow_nan=False)` and later validators separately define writer/reader restrictions. |
| 200-digit integer | Both yield exact Python int | A small observed case, not a general arbitrary-size proof |
| 5,000-digit integer at process default 4,300 limit | Both ValueError, different message | CPython integer limit is process configurable; alternate settings not tested. ValueError fallback restores CPython failure in this fixture. |
| Escaped lone high/low surrogate | CPython accepts; from_json ValueError | ASCII raw JSON survives `_sha`; this is a reachable parser difference, even though normal canonical writer does not emit such text. |
| Valid surrogate pair, Chinese/emoji | Both same Python strings | Confirmed cases only |
| Raw Python string containing lone surrogate | CPython accepts; from_json TypeError | ValueError-only fallback fails this case. For family roots raw UTF-8 `_sha` runs first and already raises UnicodeEncodeError, so this string cannot reach parser through that reader. A reusable general JSON wrapper must still address its input contract. |
| Invalid UTF-8 bytes | UnicodeDecodeError vs ValueError | Family rows are SQLite TEXT; a shared helper supporting bytes would need CPython fallback/error parity. |
| UTF-8 BOM bytes / UTF-16 bytes | CPython accepts; from_json rejects | Unnecessary broad bytes helper must not accidentally narrow old acceptance |
| Root [], null, integer | Both parse same | Parser alone proves no root shape; downstream validation/error mapping must remain. Strict schema validation would change several existing equality/type tolerances and acceptance of extra keys. |
| Trailing tokens | CPython JSONDecodeError vs from_json ValueError | `_decode_family` catches only JSONDecodeError. A direct switch leaks ValueError instead of the existing structured storage error. |
| Nesting depth 210 | CPython accepts; from_json rejects at depth ~202 | Direct switch narrows acceptance, potentially in a directory field not selected by this read |
| Float boundary examples and deterministic 10,000 decimal/exponent values | Exact float signatures matched, 0 observed mismatches | Finite bounded evidence only; not an exhaustive float semantics proof |

A trial wrapper `try from_json; except ValueError: json.loads` restores all matrix ValueError rejection cases to CPython value/error behavior. It does not prove equality for every string accepted by both parsers, differs for raw-surrogate TypeError, and needs process integer-limit evidence. Hence it remains a candidate, not an approved equivalent implementation. Existing raw SHA-first TEXT input narrows its applicable domain and should be explicit in further proof.

## Feasible group-level direction and unresolved evidence

1. Keep all per-row raw SHA, row/header digest equality, same-snapshot identity and exact downstream structure checks. A current-only parser helper after SHA could centralize decoder/error parity across family/root/balance/settlement/report, but each component must retain its own exception mapping. Do not move the optimization into shared `source_json_loads`, and do not change unique-source or fixed-v1 rules. Add compatibility cases for configurable integer limits and actual downstream wrong-root/error outcomes before implementation. Estimated gain from this micro is single-digit milliseconds for this payload, not a demonstrated elimination of all 85 ms.
2. A request-owned pure decode memo keyed by exact raw content can safely avoid repeated JSON materialization **after** every selected row's SHA and header binding still passes. It must not let a digest-only lookup bypass damaged raw content, must not publish partially validated results on group failure, and must not share mutable decoded dicts with per-period modifications (settlement adds root_digest). Actual duplicate family/root count is unverified; the synthetic group has 119 unique contents and gets no reuse benefit. Existing `(period, storage_digest, family)` caches already remove within-request repeated family reads. Do not assume cross-month cache wins.
3. Eliminating descriptor parsing for absent subjects would require a separately authenticated filter root or a different physical authenticated directory representation. That changes storage/schema/forward-adjustment work and cannot be achieved by simply projecting `subject_filter` from the existing JSON while claiming full structure verification. This is a future design option, not a current-scope fix.
4. SchemaValidator fusion can reduce Python validation loops in other components, but a strict typed schema can reject currently accepted bool/int equalities or extra fields, and materialization types can differ. Exact per-component behavior and errors must be compared before any group-wide fusion. No fusion micro or production parity was done here.

Recommendation: do not blindly swap parsers or tighten JSON semantics. If further optimization is authorized, first prototype the raw-SHA-first current TEXT parser helper with CPython fallback, preserving downstream validations and fixed v1 isolation, and run bounded semantic/error parity; only then measure the authorized sample. No database migration, new dependency, service action, production change, or verification skipping is necessary for that prototype.
