# Stage 9 精确读取范围诊断

脚本：`stage9-needed-scope-inventory-20261004.py`；机器回执：同名 `.json`。固定源码SHA `1836585b091d79999bce32980a42ed919246449d7f493593633cf4cbd0768459`，隔离main120来源与资格文件沿用已有profile。使用正常runtime.connect与verify_schema、query_only和BEGIN/rollback；没有计时、完整核验、预览、页面、服务或写入操作。前后company/catalog身份、state、history、repair以及DB/WAL内容guard全部相等，sourceinventory相等。已有资格核验仅为历史来源，不声称本轮重新完整验证。

## 开放月：party与现金利润联合仍覆盖85%行和几乎全部凭证

从2025-12准确selected_voucher_sql得到1005个凭证ID，全部没有close_period；由这些ID精确获取2436行，不按业务kind推断范围。

| 行消费范围 | 行数 | 返回值bytes | 涉及凭证 |
|---|---:|---:|---:|
| RECLASS | 938 | 88,272 | 938 |
| CASH或PROFIT | 1129 | 114,981 | 1003 |
| 两者union | 2067 | 203,253 | 1004 |
| 两者都不消费 | 369 | 35,168 | 150 |
| 全部行 | 2436 | 238,421 | 1005 |

两类账户行互不重叠，但共享大量凭证。union需要84.85%行、85.25%返回bytes、1004/1005凭证。若把现有全月行缓存改为只含RECLASS，现金利润仍需重新请求1129行，且对应source IDs几乎覆盖全月；不能据party只需938行推断贡献body减少到938个。最简单party独立缩窄的收益应降级，不建议盲改缓存。即使合并消费者收窄union，最多只消除369行/35,168返回bytes；原SQL的全月选择证明、1005头、源结果字节认证仍必要。本诊断没有推断新实现时延。

## 冻结资产owner：全部认证将读取6.62MB保存结果

119个已关账月的精确asset_batch_adoptions section声明238个不同owner；重复声明0。只按精确ID读取保存outcome UTF-8字节长度，没有把outcome原文传回Python。

| 诊断kind | owner数 | outcome总bytes | 单个最小／最大bytes |
|---|---:|---:|---:|
| asset_activation_batch | 119 | 118,524 | 996／996 |
| asset_consumption_month | 119 | 6,500,372 | 267／109,061 |
| 总计 | 238 | 6,618,896 | — |

每个2016-01至2025-11月份各2个owner；月合计从1263bytes增长至110057bytes。所有owner原文独立认证再收窄metadata，至少新增6,618,896bytes outcome传输及认证工作，还需对应事实原文/封签证明。必须比较它实际消除的原有读取，不能只看到窄metadata就认定净减少。kind和month仅为诊断分类，不授权运行时据kind信任或跳过源核验。

## 十二个flow：4932个refs全部不同，无跨月header缓存收益

对应profile实际路径的2024-12 checkpoint与2025-01至2025-11闭期flow共12个月。每个flow先认证close header/marker与report、report_semantics、report_flow三个root及精确content，再取其classification_refs，执行与read_report_flow相同的命名ID header查询和membership/digest比较。

每月411 refs，累计4932，union也是4932；重复ID、重复header读取、所有两月非零交集均为0。集合身份仅输出SHA256。实际查询4932返回行/784,188bytes，与原profile完全一致。这里的12次查询是12组不同冻结事实，不能靠共享header缓存消除。

## 实际SQL、计划与步骤

机器回执保留每条实际SQL及实际参数的EXPLAIN QUERY PLAN，参数只记录数量。以下bytes为返回值bytes，不是磁盘IO；VM按100指令采样，含诊断SQL/EXPLAIN规划的观察归属，不作为独立性能结论或精确扫描行数。

| 查询 | 次数 | 返回行 | 返回bytes | 采样VM步骤 |
|---|---:|---:|---:|---:|
| 精确开放月凭证选择 | 1 | 1005 | 454,060 | 218,700 |
| 选中ID凭证行 | 1 | 2436 | 238,421 | 52,700 |
| 精确owner outcome长度 | 1 | 238 | 24,871 | 4,700 |
| flow命名classification headers | 12 | 4932 | 784,188 | 187,600 |

开放月选择用voucher_period(period=?)，其close_reference_lookup、voucher_current、calculation、publication及original均为索引查找；这是未使用已证明no-close省略的保守诊断选择，不把218700步骤宣称为当前页面优化分支实际工作量。凭证行从json_each精确ID驱动voucher_line复合主键(version_id=?)；owner从精确ID驱动calculation主键；classification从命名ID驱动fact_revision、subject、fact_report_classification主键。三者排序均有TEMP B-TREE。计划中的SCAN ids为输入JSON虚表，不是扫描历史业务表。

结论：原审计的party行缩窄候选在main120数据上收益空间很小；classification跨月缓存候选没有收益。冻结owner源认证属于额外约6.62MB输入，不能当成免费窄metadata前置。保持必要原文、冻结与selection核验，下一步范围判断应以上述实测数量为依据。
