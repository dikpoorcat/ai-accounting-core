# 第 9 阶段 current 报表贡献 native 解码候选审查

结论：拒绝本组候选。严格 native 模型没有稳定降低成本，运行源码与测试文件没有修改。没有变更 wire、源证明、缓存、fixed_v1、公司库、服务或真实资料，没有 Git 操作。

## 接受／拒绝语义

独立内存矩阵共 335 项，原 `_decode` 与四个候选的接受／拒绝和返回 JSON 值一致。矩阵检查字段省略、根和 resolution 多余字段、类型、严格整数拒绝 bool、负数与远大于 int64 的整数、不同长度、Unicode digest、空 ID、排序去重 parents、任意嵌套 row[6] dict、resolution 四个 list 的任意成员、publication_id 最后相等检查、重复成员最后值、NaN/Infinity、非法及截断 JSON。

保持原有 digest 仅检查字符串长度 64，未增加 hex 正则。publication_id 仍只与调用方预期值比较；该私有入口原有数值相等行为没有偷偷改成强制字符串。tuple positional validator 输出必须还原 list，本组比较了逐项 function-after(list) 和解码后外层还原两种方式。JSON 返回值以键排序后比较，避免把根对象插入顺序误判为内容变化；嵌套 list 的类型和值均保留。NaN 按 JSON 标量序列化比较，避免 NaN 自身不相等造成假差异。矩阵是有限证据，不宣称覆盖所有 JSON 语法。

## 1000 次内存微测

所有输入均为合成；最后一轮使用代码 `compact_line_fields` 的实际字段形状。每个样本 1000 次解码，11 轮轮换候选顺序，以下是中位数 ms。原始 11 轮数值保存在 JSON `benchmarks.*.samples_ms_1000`。两轮早期探索只保留了中位数，没有伪造原始每轮数据；这些汇总保存在 `earlier_exploratory_rounds`。

| rows 数 | 原解码 | native JSON + 逐项 list-after | native JSON + 外层 list 还原 | from_json + native | from_json + native opaque 实例检查 |
| ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | 4.9657 | 5.7185 | 5.8293 | 6.2183 | 6.0838 |
| 2 | 8.5964 | 12.6857 | 12.9585 | 10.8999 | 9.7813 |
| 8 | 18.3535 | 31.1929 | 31.1961 | 23.8983 | 19.8591 |
| 40 | 73.6340 | 132.0264 | 132.2552 | 96.8111 | 75.3844 |

最后一项在已经使用 from_json、所有对象只能是 JSON 原生 dict/list 的前提下，以 native 实例检查避免重新复制任意 row[6] dict 和 resolution 任意成员列表。即使如此，正常 2 行输入仍更慢；40 行也没有稳定收益。不把本组微测换算为整页用时，也不据此判断数据库读取、源码证明或页面耗时。

## 调用与同类循环审查

`_decode` 的直接调用只有 current `read_open_contributions`。普通报表和开放期 party 投影通过该函数复用贡献，校验 checksum、publication/calculation 身份、精确 source_bindings 和 parents 后才存入当前快照缓存。候选没有绕过这些核验。

`compare_open_contributions` 通过已核验源独立重建，不调用 `_decode`；`repair_open_contributions` 调用 compare 并只重建派生贡献内容。完整 integrity 通过 `content_history_context.report_open_contribution_reader()` 选择 current 或独立 v1 compare，备份／恢复的完整核验因此不能因当前 `_decode` 候选而改写历史规则。`report_open_contribution_v1` 没有共享这个解码器，未修改任何 v1 文件。`verify_published_source_bindings` 的 `_OWN_SOURCE_CONTENT` 是另外的窄来源证明 validator，本组未改其规则或调用。

`selected_open_line` 对一份贡献的 rows 做完整过滤，再检查唯一性；报表与 party 投影按每个来源的选中行调用，因此单来源 n 行、选择 k 行时是 k×n 次匹配。已提供主样本是小的 2 行贡献，不能据此增加缓存。读取侧 `_runtime_resolution` 已按贡献复用，不能把它误算为每行重新构建。

同类循环包括 `report_party_splits`/`report_party_needs_ancestry` 按 line_no 扫 line_relations、`immutable_line_fields` 扫精确关系、`resolve_calculation_relations` 逐来源引用扫描 direct parents 和 source obligations，以及按账户组扫描 lines。其范围均为当前核算的局部集合，不是全公司历史集合。源码也允许大集合，例如 `PayrollReservePayment.allocations` 只有 min_length=1，没有固定 max_length，批量 allocations/relations 可以增长；当前没有实际大集合工作量证据，不能把“可大”写成“主样本实际大”。仅记录后续按确有批量工作量测量的方向，本组没有改其他算法或为 2 行引入索引缓存。

## 验证与保留

一次 targeted 验证：`test_report_open_contribution`、bytes、index、v1、`test_read_repair_version`、`test_stored_json_repair_boundary`、`test_report_party_summary`，40 passed in 61.62s。Ruff 检查这些文件和 current 生产文件全部通过。生产未修改，因此没有新增纯实现细节测试，也没有追加全量回归或主样本测量。

生产文件 SHA256：`7efbf4b43c621662d11ac29c4d1be0e1df74e7e78577289e74d4fb57d069e3da`。捕获的原 `_decode` 函数源与交付时函数源相等。源码文件没有写入操作；除临时探针、原函数留存和本组记录外，没有创建或修改其他资源。

保留文件：本 Markdown、同名 JSON、`.tmp/stage9_report_decode_native_probe.py`、`.tmp/stage9_report_decode_baseline.py`、`.tmp/stage9_report_decode_finalize.py`。探针仅调用本机仓库虚拟环境、合成内存输入，不连接公司数据库。最后一轮 CPU 测试已结束，不再继续测量，等待 root 收口。
