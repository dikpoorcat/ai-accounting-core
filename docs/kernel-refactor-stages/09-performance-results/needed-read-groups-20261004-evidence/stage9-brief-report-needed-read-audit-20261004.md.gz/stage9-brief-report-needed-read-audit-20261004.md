# Stage 9 简报与季度报表必要读取审计（只读）

固定源码：`.tmp/stage9-build-source-two-read-groups-20261004`，SHA256 `1836585b091d79999bce32980a42ed919246449d7f493593633cf4cbd0768459`。已阅读 AGENTS.md、FRONTEND.md。本审计只读取源码与已有诊断 JSON，没有运行测试、计时、服务器、业务数据或服务操作，没有修改代码。

## 诊断证据及边界

数据来源为 `stage9-main120-needed-read-profile-20261004.json` 及同名 summary。instrumented 时间含 cProfile、SQL 返回值观察和 EXPLAIN 开销，只用于调用归因，不能代替正式刷新时延。SQL bytes 是返回值字节数，不是磁盘 IO；VM 步数按100指令采样。brief/report 的 actual_assets_plans 均为空，不能声称已取得它们的查询计划或索引扫描范围。

| 页面 | 主要调用 | 载入/解码 | SQL总量 |
|---|---|---|---|
| 简报 | account_amounts 1次/404.575ms；verify_selected_content 4次/153.825ms | outcome 1009行/1,059,809bytes；成功匹配json解码1008次 | 191calls、14,169返回行、819,400VM步骤 |
| 季度报表 | party_nets_uncached 2次/741.306ms；party_delta 1次/406.62ms；authoritative_rows 1次/175.39ms；read_open_contributions 2次/251.792ms | outcome 1007行/1,058,063bytes，但成功匹配json解码仅3次；contribution _decode 1004次/92.899ms | 255calls、23,512返回行、943,500VM步骤 |

观察器本身的 `__next__`、`_row`、`_value_bytes` 占比较高，因此不能把上述累计毫秒换算成可节省的纯时。

## 简报：完整金额不是首屏明细

`dashboard.py:2578` 的 `_brief_amounts` 使用 `Journal.account_amounts`（dashboard_reads.py:1289）。它必须处理完整月份，首屏20条不能替代月度金额。当前读取顺序为准确选择凭证→核对采用关系及publication→取得关账采用结果/原冲正来源→核对源事实、保存结果→取得完整凭证行→逐行相等、顺序、总额、借贷平衡→聚合账户。

慢SQL `19dba0...` 是 verify_selected_content 的精确ID查询，1006返回行/1,304,842bytes/45,300VM步骤。这里的 outcome 并非为了“元数据”误取：account_amounts 随后实际读取 `outcomes[id]["lines"]`，用于原结果、采用结果和冻结结果的完整行相等核验（dashboard_reads.py:1384–1465）。删除这批结果会削弱金额核验；改用未经证明的monthly_account合计也不能等价替换。

可以继续收窄的是**调用方只消费lines，但通用验证器物化整个outcome dict**。query_reads.py:1677 的 verify_selected_content 总是 `_object(raw)`，即使raw SHA相等也完整解码。建议只在确实有严格依据时增加专用行读取，而不是改变通用验证器返回合同。必须保留物理事实核验、封签身份、完整结果摘要、重复JSON字段拒绝、非canonical等价JSON回退、严格整数与完整lines顺序/形状、原结果与采用结果分别比较以及closed/reversal核验。

现有 stored_json.py 明确要求在非独立锚定情况下，即使byte hash相等也检查重复字段。故“raw hash命中→直接JSON1抽lines”或普通Pydantic忽略其他字段不是可直接批准的等价实现。没有证明重复字段与其他原规则仍等价之前，本候选不应落地。

简报还出现 `_open_items` 210.71ms、settlement_dashboard_open 2次/210.07ms。这是另一个公共清偿/待收待付读取组，并非account_amounts重复；本次未深入该组，不能删显示或据此宣称account优化必达500ms。

## 季度报表：成功快照缓存已存在

`Reports._report`（reports.py:1059）先算年初与期末party position，再读取本年frozen flows及开放月现金/利润行。party_nets两次分别是年初前一个月和期末两个不同cutoff；它们不是同键重复。`_party_balance_nets`、party rows、monthly flow、party_delta、open contribution、closed references、classification验证均已有owned-snapshot缓存。

read_report_flow有23次函数调用，classification SQL只有12次，说明成功月份缓存已复用；不能说“没有缓存”或再加跨请求缓存。`None`、unusable、缺body等失败/回退结果不得缓存为健康成功；下一次正常读取仍应重新核验。

### A. 精确ID但输出偏宽的开放月读取

report_projection.py:939 的 `_party_balance_nets_uncached` 从最近可用checkpoint及后续月份累计，closed月份经read_report_flow认证，开放月份调用 `_authoritative_rows`。后者读取整月所有凭证头与所有科目凭证行，随后 `_party_delta`（337/366）才筛选RECLASS。

因此party用途并不需要物化全部非RECLASS行；但原选择、publication与采用覆盖证明是全月的，不能简单给原SQL加account WHERE后取消全月核验。当前 `_open_source_rows_from_headers` 已把精准selected headers和lines拆开；最小候选是保留全月头/selection证明，把用于party的行payload限定RECLASS，并使现金/利润读取只索取其实际需要的行。现有 `report_open_source_rows` 被reports.py:1262复用为现金/利润输入；改为RECLASS缓存后不能让调用者误当全月行。可保持明确账户范围键、或者保留原全月缓存，避免额外重读吞掉收益。

该组在诊断出现party_delta1次/authoritative_rows1次，是明确实际执行过的路径；它不要求改schema、不改变checkpoint/frozen源。尚未取得各账户行计数，不能估算裁剪比例，也不能保证收益足以过门槛。特别是如果每个工资凭证同时含RECLASS，calculation contribution IDs仍可能基本不减。

### B. Contribution原文字节与完整解码的区别

`read_open_contributions`（report_open_contribution.py:492）按本次source IDs取得body、核对immutable anchor及body checksum、完整_decode、精确parents、source bindings，再由selected_open_line核对选中行和关系。2次查询累计1004返回行/3,403,031bytes；snapshot cache按calculation_id只请求未存储项。调用两次不等于相同body读取两次，诊断未保留参数ID集合，不能推断交集。

`_verify_anchored_source_bytes`（query_reads.py:1920）读取outcome原文以验证锚定结果摘要，canonical字节命中不物化JSON；3个成功json解码与1007行outcome载入的差异证明这个路径已经有效。仅根据“读了outcome”把它当metadata浪费是错误的。保留其完整原文字节哈希、事实原文/身份封签、非canonical精确回退与bindings冲突拒绝。

现有 `_OWN_SOURCE_CONTENT` 原生validator只用于verify_published_source_bindings的own-source证明；它的extra-ignore和跳过rows/resolution适合该用途，不可直接取代read_open_contributions完整shape核验。后者还消费parents、rows、resolution。

### C. 冻结classification SQL12次/4932行不是已证实重复

report_flow.py:310的read_report_flow首先认证close header/marker和三个derived roots，再用冻结content中的精确classification_refs查询headers。SQL `35b1ae...` 共12calls、4932返回行、784,188bytes、187,600VM步骤。它是精确命名的PK/join读取，不是SQL本身无条件全表SELECT。

`_classification_refs`（report_flow.py:35）构造来源是本月fact_period与该月source_vouchers两支，并证明采用关系。read_report_flow逐项检查缺失、kind、typed voucher binding、period/membership及digest，这些属于必要冻结核验；不得只信source_root后跳过。

诊断未保存具体ID参数，4932不能证明跨月重复。若证明重复，可在owned snapshot共享不可变classification header的成功读取（不是共享月度采用结论），每月仍完成自己的expected_refs、membership及digest比较。收益未证实，本轮不建议仅凭总行数先实施该缓存。

## 公共调用影响与保留位置

| 入口 | 当前关系 | 本轮处理边界 |
|---|---|---|
| 五页 | 简报account_amounts；资产balances；资金余额/流水；员工清偿；报表Reports._report；dashboard.py:2753资金相关统计还用party_balance_rows | 不删页面、汇总、按业务/凭证、全部/分页、税务模板；共享读优化需保持各调用方范围合同 |
| CLI/MCP | service.py:729生成Reports适配，803映射dashboard_quarterly_report；cli/mcp经服务命令执行 | 不把页面窄读取变成通用报告、导出或trace合同缩减 |
| 关账 | reports.py:238 check_report_readiness注册；periods.py:745–764在同事务prepare_report_projection/semantics/flow | 不改变准备写入、冻结refs/roots、核验blocking规则 |
| verify | integrity.py:1323比较所有open contribution；1418/1440/1738 require_report_flow；projection require/compare完整重建 | 保留完整原始事实、历史依赖、voucher、锚、body覆盖与冻结重建；不得改为快速页面reader |
| repair | maintenance.py:79 repair_report_flow；report_projection.py:1374；report_open_contribution.py:698先比较不可变anchors再重建derived body | 不改变失败原子性、repair版本推进及修复职责 |
| backup/restore | backup.py:149 _verify_connection选择bundle.company_verifiers；339 verify_file；1016 verify_portable；创建/恢复调用完整verifier | 继续完整验证，不能拿缓存健康或页面成功代替便携包核验 |
| fixed v1 | content_history_context.py的report_reader/report_flow_reader/report_open_contribution_reader等只在historical_content(1)分派_v1 | 本轮current读候选不改_v1源规则、writer格式及历史重复JSON解释；若改公共QueryReads必须覆盖历史上下文 |

## 建议收敛组与未验证事项

已完成另一次精确只读范围诊断，见 `stage9-needed-scope-inventory-20261004.md/json`。开放月RECLASS与CASH/PROFIT的union仍需2067/2436行、203253/238421返回bytes、1004/1005凭证；单独缩party行会使现金利润再读大量共同source。故最初的party payload收窄建议降级，当前证据不足以支持把它当本轮主要修复组。12个月classification_refs每月411、累计4932个全部不同，跨月共享header缓存没有收益。不调整冻结DDL、不添加跨请求cache、不省略全量金额；一般reader与compare/repair/fixedv1保留原路径。

brief专用lines读取的收益候选需要更严格等价证明，现有无独立anchor路径不能直接采用raw-hash/JSON1快捷方式。本审计没有证明安全替代方案，也没有进行实现或回归验证。冻结asset owner238个独立结果原文合计6618896bytes，全部认证后再缩metadata会引入这批原文字节及对应事实证明，须比较净输入变化。当前正式main120失败次数、500ms达标与五页实际刷新行为须由统一后续验证给出，instrumented时间不能据此承诺。
