# 第 9 阶段：group 目录描述符查找

## 范围及根因

只修改 `src/ai_accounting/kernel/close_storage.py` 的 current 物理桶读取。全局检索 `_bucket_rows` 调用后确认：`_buckets_rows` 与 `_buckets_rows_many` 已逐项扫描子根目录构造 present 集合，随后逐桶调用 `_bucket_rows`，每次又通过 `next` 从同一目录开头查找 expected。完整读取含 256 个桶时产生二次线性描述符遍历。普通多桶读取、跨期间／字段 group、完整逻辑字段读取同属此根因。

同类排查覆盖 `_family` / `_families_many` / `_decode_family`、group priming、完整 `_field_values` / `_read_section`、management 单桶以及 reference leaf 单桶路径。子根依旧通过存储 SHA 与 header 中承诺值认证。`close_storage_v1.py` 自有 fixed-v1 路径未修改；current management 与 direct reference 单桶默认查找也保留。

## 修改

两个 group 入口将原 present 集合改为调用内局部 bucket→exact descriptor 字典，通过 `setdefault` 保留原 `next` 的首次命中语义。group 将同一子根的选定描述符传给 `_bucket_rows` 私有 `_expected` 参数；显式 None 代表该子根无此桶，默认 Ellipsis 代表 direct 路径自行查找。未新增跨请求缓存，未改变根字段、wire、schema、业务叶内容或其它读取入口。

`_bucket_rows` 后续目录 SHA、目录承诺 SHA、目录 part 顺序及计数、物理 block 多重集、每块 SHA、块承诺 SHA、块列表类型及长度核验全部保持原样。缓存仍在已有完整 group 成功后发布。原先 `_may_contain_with_positions` 的显式 for 修改保持。

## 验证

仓库 `.tmp-kernel-venv` 运行两个定向文件，选择 cross-period work、owned batch exact/empty scopes、failed group、bucket validator failure、current eligibility、readiness、reference work、reference public grouping、reference group failure 以及 noneligible reference 的节点：**25 passed，14 deselected**。包括真实业务合成 fixture 的 adopted/voucher batch-vs-serial、一致性、失败无前缀发布和 fixed-v1 回退；现有 SQL、返回行／字节、JSON 与 SQLite 工作量断言通过。未执行 main 样本、计时实验、preview、全 Verifier、服务操作或 Git 操作。

可信合成物理存储实验脚本：`.tmp/stage9-close-descriptor-lookup-experiment-20261004.py`。仅使用内存 SQLite，构造 256 个不同 material fact bucket，保存目录、块与承诺 SHA，先由 `_family` 认证子根，再统计描述符元素访问次数。通过复现 former group 的 present 扫描及各桶默认查找、共享同样已提取物理 rows 与全部原 validators，与当前 group 对照：

- 256 桶 group：former **33,152** 次描述符访问，current **256** 次；256 个叶值及位置完全一致。
- 256 桶 cross-group：current **256** 次；与 baseline 完全一致。
- 完整逻辑 material fact field：含初始桶枚举共 **512** 次；256 条真实 fact 值、所属 bucket 与全局位置一致。
- 空 group、缺桶、重复请求桶，以及同一已认证子根中冲突重复 bucket descriptor 的正反排列均检查 direct/group/many；首次 descriptor 正确则成功，首次错误则拒绝，与原首次命中语义一致。

只承诺减少上述已观察的描述符访问，不据此推断毫秒收益。源码未增实现细节型测试；实验与范围记录位于 `.tmp`。未触碰现有数据库、资料或负责人身份。
