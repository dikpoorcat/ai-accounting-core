from pathlib import Path
import sys
w=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(w/'scripts'))
source_path=w/'scripts/benchmark_stage9_browser.py'
source=source_path.read_text('utf-8')
source=source.replace('import argparse','import cProfile\nimport pstats\nimport argparse',1)
source=source.replace('http_requests, dispatch_calls = [], []','http_requests, dispatch_calls, request_profiles = [], [], []; profile_gate = threading.Lock(); profiled_paths = set()',1)
needle='''            start = time.perf_counter()
            self._benchmark_status = None
            try:
                return _original(self)
            finally:
                end = time.perf_counter()'''
replacement='''            start = time.perf_counter()
            self._benchmark_status = None
            profile = None
            profile_path = urlsplit(self.path).path
            if phase[0] == "browser" and profile_path.startswith("/api/dashboard/") and profile_path not in profiled_paths and profile_gate.acquire(blocking=False):
                profiled_paths.add(profile_path)
                profile = cProfile.Profile()
            try:
                return profile.runcall(_original, self) if profile is not None else _original(self)
            finally:
                end = time.perf_counter()
                if profile is not None:
                    profile_gate.release()
                    stats = pstats.Stats(profile).stats
                    functions = [{"function": str(Path(k[0]).name)+":"+str(k[1])+":"+k[2], "calls": v[1], "own_ms":v[2]*1000,"inclusive_ms":v[3]*1000} for k,v in stats.items()]
                    with records_lock:
                        request_profiles.append({"path":urlsplit(self.path).path,"thread":threading.get_ident(),"start_ms":(start-timing_origin)*1000,"end_ms":(end-timing_origin)*1000,"functions":functions})'''
assert source.count(needle)==1
source=source.replace(needle,replacement)
source=source.replace('dispatch_calls=dispatch_calls,','dispatch_calls=dispatch_calls,\n            request_profiles=request_profiles,',1)
globals()['__file__']=str(source_path)
exec(compile(source,str(source_path),'exec'),globals())