"""Read-only SQL prototype; no production patches or browser timing."""
from __future__ import annotations
import hashlib
import json
import sqlite3
import sys
from pathlib import Path

WORKSPACE = Path(__file__).resolve().parents[1]
SOURCE = WORKSPACE / ".tmp/stage9-build-source-owner-final-ui-20261003-release"
SOURCE_SHA = "8672404dd3fcb198f80d3583782b98590b8c8358e2c2e354fa3822b71fefa36b"
OUTPUT = WORKSPACE / ".tmp/stage9-close-support-batch-probe.json"
BOOKS = (
    ("main12", ".tmp/stage9-owner-main12-final-ui-verified.json", "2195134f3ca8fefe5945d8928f78cb09fa99cef62383ed0f66f36201d68db2ab"),
    ("main48", ".tmp/stage9-owner-main48-final-ui-verified.json", "3889368a3656259b0155f3c6e2091286ae8b96d220305fda45e0f48d37376554"),
)
ROOT_SQL = "SELECT storage_digest FROM close_storage_root WHERE period=?"
MARKER_SQL = "SELECT source_digest FROM read_index_source WHERE source_kind='close' AND source_id=?"
IDENTITY_SQL = "SELECT company_id,database_id FROM identity WHERE id=1"
FAMILY_SQL = "SELECT content,digest FROM close_storage_subroot WHERE period=? AND family=?"
HEADER_BATCH = (
    "SELECT r.storage_digest,m.source_digest FROM json_each(?) requested "
    "LEFT JOIN close_storage_root r ON r.period=CAST(requested.value AS INTEGER) "
    "LEFT JOIN read_index_source m ON m.source_kind='close' AND m.source_id=CAST(requested.value AS TEXT) "
    "ORDER BY CAST(requested.key AS INTEGER)"
)
FAMILY_BATCH = (
    "SELECT s.content,s.digest FROM json_each(?) requested "
    "LEFT JOIN close_storage_subroot s ON s.period=CAST(json_extract(requested.value,'$[0]') AS INTEGER) "
    "AND s.family=json_extract(requested.value,'$[1]') ORDER BY CAST(requested.key AS INTEGER)"
)

def sha(path):
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()

def require(ok, message):
    if not ok:
        raise ValueError(message)

def value_bytes(value):
    if value is None:
        return 0
    if isinstance(value, str):
        return len(value.encode("utf-8"))
    return len(value) if isinstance(value, bytes) else 8

class Counted:
    def __init__(self, connection):
        self.connection = connection
        self.calls = self.rows = self.bytes = self.vm = 0
        connection.set_progress_handler(self.progress, 1)
    def progress(self):
        self.vm += 1
        return 0
    def execute(self, sql, parameters=()):
        self.calls += 1
        result = list(self.connection.execute(sql, parameters))
        self.rows += len(result)
        self.bytes += sum(sum(value_bytes(v) for v in row) for row in result)
        return Cursor(result)
    def stop(self):
        self.connection.set_progress_handler(None, 0)
        return {"sql_calls": self.calls, "returned_rows": self.rows,
                "returned_value_bytes": self.bytes, "exact_vm_steps": self.vm}

class Cursor:
    def __init__(self, rows):
        self.rows = rows
    def fetchone(self):
        return self.rows[0] if self.rows else None
    def __iter__(self):
        return iter(self.rows)

class Supports:
    """Untrusted raw support only: original readers still verify every header/family."""
    def __init__(self, connection, rows):
        self.connection, self.rows, self.active = connection, rows, True
    def execute(self, sql, parameters=()):
        require(self.active and self.connection.in_transaction, "Support scope ended")
        value = self.rows[(sql, tuple(parameters))]
        return Cursor([] if value is None else [value])

def header_rows(counter, rows):
    periods = [r["period"] for r in rows]
    selected = list(counter.execute(HEADER_BATCH, (json.dumps(periods),)))
    require(len(selected) == len(periods), "Header request cardinality changed")
    identity = counter.execute(IDENTITY_SQL).fetchone()
    supports = {(IDENTITY_SQL, ()): identity}
    for period, row in zip(periods, selected, strict=True):
        supports[(ROOT_SQL, (period,))] = None if row[0] is None else {"storage_digest": row[0]}
        supports[(MARKER_SQL, (str(period),))] = None if row[1] is None else {"source_digest": row[1]}
    return supports

def family_rows(counter, headers):
    keys = [(h.period, "accounting") for h in headers]
    rows = list(counter.execute(FAMILY_BATCH, (json.dumps(keys),)))
    require(len(keys) == len(rows), "Family request cardinality changed")
    return {(FAMILY_SQL, key): (None if row[0] is None else row) for key, row in zip(keys, rows, strict=True)}

def main():
    require(Path(sys.prefix).resolve() == (WORKSPACE / ".tmp-kernel-venv").resolve(), "Use repo venv")
    require(not OUTPUT.exists(), "Output exists")
    sys.path.insert(0, str(SOURCE / "scripts"))
    import stage9_source
    stage9_source.configure_source(SOURCE, WORKSPACE)
    import snapshot_stage9_source
    import benchmark_stage9_browser
    from ai_accounting.kernel import close_storage
    manifest_path = SOURCE / "source-manifest.json"
    manifest_sha = sha(manifest_path)
    manifest = json.loads(manifest_path.read_text("utf-8"))
    def check_source():
        actual = snapshot_stage9_source._inventory(SOURCE)
        require(manifest["files"] == actual and manifest["sha256"] == SOURCE_SHA
                and snapshot_stage9_source._digest(actual) == SOURCE_SHA
                and sha(manifest_path) == manifest_sha, "Source drift")
    check_source()
    report = {"status": "started", "source_sha256": SOURCE_SHA, "browser_acceptance": False,
              "scope": "metadata SQL only; exact VM counting; wall time intentionally omitted", "samples": {}}
    with OUTPUT.open("x", encoding="utf-8") as output:
        try:
            for name, book_relative, book_sha in BOOKS:
                book_path = WORKSPACE / book_relative
                require(sha(book_path) == book_sha, "Book report changed")
                book = json.loads(book_path.read_text("utf-8"))
                benchmark_stage9_browser.require_report_source(book, SOURCE)
                period = benchmark_stage9_browser.validate_book_report(book, company_name="阶段九合成规模企业")
                root = stage9_source.synthetic_path(Path(book["root"]), WORKSPACE)
                checkpoint = root / "stage9-builder.json"
                checkpoint_sha = sha(checkpoint)
                connection = sqlite3.connect(Path(book["company"]["path"]).as_uri()+"?mode=ro", uri=True)
                connection.row_factory = sqlite3.Row
                try:
                    connection.execute("PRAGMA query_only=ON")
                    connection.execute("BEGIN")
                    def state():
                        return {"state": list(connection.execute("SELECT * FROM state").fetchone()),
                                "identity": dict(connection.execute("SELECT * FROM identity").fetchone())}
                    before = state()
                    require(before["state"] == book["verified_open_preview"]["state"], "State differs from proof")
                    require(before["identity"]["company_id"] == book["company"]["id"]
                            and before["identity"]["database_id"] == book["company"]["database_id"], "Wrong company")
                    rows = list(connection.execute("SELECT * FROM period_close ORDER BY period"))
                    require(len(rows) == book["requested_months"] - 1, "Unexpected frozen scope")
                    counted = Counted(connection)
                    headers = tuple(close_storage.verified_header(counted, row) for row in rows)
                    baseline_header = counted.stop()
                    counted = Counted(connection)
                    header_support = header_rows(counted, rows)
                    proxy = Supports(connection, header_support)
                    candidate_headers = tuple(close_storage.verified_header(proxy, row) for row in rows)
                    candidate_header = counted.stop()
                    require(headers == candidate_headers, "Header behavior changed")
                    proxy.active = False
                    counted = Counted(connection)
                    baseline_families = tuple(close_storage._family(counted, h, "accounting") for h in headers)
                    baseline_family = counted.stop()
                    counted = Counted(connection)
                    family_support = family_rows(counted, headers)
                    proxy = Supports(connection, family_support)
                    candidate_families = tuple(close_storage._family(proxy, h, "accounting") for h in headers)
                    candidate_family = counted.stop()
                    require(baseline_families == candidate_families, "Family behavior changed")
                    proxy.active = False
                    failures = []
                    for label, sql, key, bad_value, kind in (
                        ("missing_root", ROOT_SQL, (rows[-1]["period"],), None, "header"),
                        ("missing_marker", MARKER_SQL, (str(rows[-1]["period"]),), None, "header"),
                        ("wrong_identity", IDENTITY_SQL, (), {"company_id": "wrong", "database_id": "wrong"}, "header"),
                        ("missing_family", FAMILY_SQL, (headers[-1].period, "accounting"), None, "family"),
                        ("bad_family_digest", FAMILY_SQL, (headers[-1].period, "accounting"), {"content": "{}", "digest": b"x"*32}, "family"),
                    ):
                        values = dict(header_support if kind == "header" else family_support)
                        values[(sql, key)] = bad_value
                        proxy = Supports(connection, values)
                        published = {}
                        try:
                            fresh = tuple(close_storage.verified_header(proxy, r) for r in rows) if kind == "header" else tuple(close_storage._family(proxy, h, "accounting") for h in headers)
                            published["success"] = fresh
                            raise AssertionError("Corruption accepted")
                        except close_storage.KernelError as error:
                            require(not published, "Failed group published a success prefix")
                            failures.append({"case": label, "code": error.code, "published": False})
                        finally:
                            proxy.active = False
                    require(state() == before and sha(checkpoint) == checkpoint_sha
                            and sha(book_path) == book_sha, "Source state/checkpoint/proof changed")
                    report["samples"][name] = {"period": period, "close_count": len(rows),
                        "baseline_header": baseline_header, "candidate_header": candidate_header,
                        "baseline_family": baseline_family, "candidate_family": candidate_family,
                        "explain_header": [list(r) for r in connection.execute("EXPLAIN QUERY PLAN "+HEADER_BATCH, (json.dumps([r["period"] for r in rows]),))],
                        "explain_family": [list(r) for r in connection.execute("EXPLAIN QUERY PLAN "+FAMILY_BATCH, (json.dumps([(h.period,"accounting") for h in headers]),))],
                        "failure_fixtures": failures, "state_unchanged": True, "checkpoint_sha256": checkpoint_sha}
                finally:
                    connection.close()
                check_source()
            report["status"] = "diagnostic_complete"
        except BaseException as error:
            report["status"] = "diagnostic_failed"
            report["error"] = {"type": type(error).__name__, "message": str(error)}
            raise
        finally:
            json.dump(report, output, ensure_ascii=False, indent=2)
            output.write("\n")
    print(json.dumps(report, ensure_ascii=False))

if __name__ == "__main__":
    main()
