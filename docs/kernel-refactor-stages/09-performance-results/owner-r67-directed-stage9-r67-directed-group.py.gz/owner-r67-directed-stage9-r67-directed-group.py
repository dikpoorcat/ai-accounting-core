"""One fixed, grouped verification before any r67 timing diagnostic."""
from pathlib import Path
import json
import subprocess
import sys
import time

workspace = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(workspace / 'scripts'))
from snapshot_stage9_source import _inventory, _digest

targets = [
    'tests/kernel/test_employee_roster_scope.py',
    'tests/kernel/test_adopted_asset_head_locator.py',
    'tests/kernel/test_publication_period_reuse.py',
    'tests/kernel/test_publication_headers.py',
    'tests/kernel/test_current_adoption_damage.py',
    'tests/kernel/test_required_money_header_reuse.py',
    'tests/kernel/test_publication_periods.py',
    'tests/kernel/test_period_balance_index_scope.py',
    'tests/kernel/test_period_balance_freeze.py',
    'tests/kernel/test_owner_verified_fact_consumption.py',
    'tests/kernel/test_report_flow_header_aggregate.py',
]
for target in targets:
    if not (workspace / target).is_file():
        raise FileNotFoundError(target)
command = [sys.executable, '-X', 'utf8', '-m', 'pytest', *targets, '-q',
           '--junitxml=.tmp/stage9-r67-directed-group.xml']
before = _inventory(workspace)
start = time.perf_counter()
with (workspace / '.tmp/stage9-r67-directed-group.log').open('x', encoding='utf-8') as output:
    output.write(json.dumps(command) + '\n')
    output.flush()
    result = subprocess.run(command, cwd=workspace, stdout=output, stderr=subprocess.STDOUT)
after = _inventory(workspace)
receipt = {
    'exit_code': result.returncode, 'elapsed_seconds': time.perf_counter()-start,
    'source_unchanged': before == after, 'before_sha256': _digest(before),
    'after_sha256': _digest(after), 'targets': targets,
    'changed_files': [name for name in before.keys() | after.keys()
                      if before.get(name) != after.get(name)],
}
with (workspace / '.tmp/stage9-r67-directed-group.json').open('x', encoding='utf-8') as handle:
    json.dump(receipt, handle, ensure_ascii=False, indent=2)
print(json.dumps(receipt), flush=True)
raise SystemExit(result.returncode or (0 if before == after else 2))
