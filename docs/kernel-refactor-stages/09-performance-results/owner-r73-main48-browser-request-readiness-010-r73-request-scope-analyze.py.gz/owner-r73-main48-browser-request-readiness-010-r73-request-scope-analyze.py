from pathlib import Path
import json,collections
w=Path(__file__).resolve().parents[1]
d=json.loads((w/'.tmp/stage9-r73-request-scope-browser-diagnostic-attempt3.json').read_text('utf8'))
profiles=[]
for p in d['request_profiles']:
    fs=p['functions']
    top=sorted(fs,key=lambda f:f['inclusive_ms'],reverse=True)[:18]
    selected=[f for f in fs if any(k in f['function'] for k in ['authorize','_transaction','_check_catalog','verify_schema','metadata','runtime.py','validate_response','dump_json','validate_python','sqlite3.Connection','_dispatch','connection','json_reply','acquire'])]
    profiles.append({'path':p['path'],'top':top,'selected':selected})
http=[r for r in d['http_requests'] if r['phase']=='browser' and r['path'].startswith('/api/dashboard/')]
summary={'status':d['status'],'pages':d.get('pages'),'http_count':dict(collections.Counter(r['path'] for r in http)),'dispatch_count':dict(collections.Counter(r['command'] for r in d['dispatch_calls'] if r['phase']=='browser')),'requests':http,'profiles':profiles,'credentials_revoked':d['synthetic_credentials_revoked']}
with (w/'.tmp/r73-request-scope-summary.json').open('x',encoding='utf8') as f: json.dump(summary,f,ensure_ascii=False,indent=2)
print(json.dumps({'status':summary['status'],'http_count':summary['http_count'],'dispatch_count':summary['dispatch_count'],'profile_paths':[p['path'] for p in profiles],'credentials_revoked':summary['credentials_revoked']},ensure_ascii=False))
for p in profiles:
    print(p['path'])
    print(json.dumps(p['top'][:11],ensure_ascii=False))
    print(json.dumps(p['selected'],ensure_ascii=False))