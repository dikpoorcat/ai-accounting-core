"""PROTOTYPE: same-source Journal-only anchored complete-lines diagnostics."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
import tempfile
import traceback
from collections import Counter
from contextlib import contextmanager
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
BOOTSTRAP = ROOT / ".tmp/stage9-owner-final-ui-native-work.py"


def bootstrap():
    # Reuse the fixed-source bootstrap and every original read-only/source/
    # identity/checkpoint guard. Never run or replace its existing report.
    source = BOOTSTRAP.read_text(encoding="utf-8")
    prefix = source.split("    operations = {", 1)[0]
    prefix = prefix.replace('require(not OUTPUT.exists(), "Diagnostic output must not exist")', "pass")
    prefix += "    return locals()\n"
    namespace = {"__file__": str(BOOTSTRAP), "__name__": "stage9_original_read_bootstrap"}
    exec(compile(prefix, str(BOOTSTRAP), "exec"), namespace)
    return namespace["main"](), namespace


def prototype(events):
    from pydantic_core import SchemaValidator, ValidationError, core_schema

    from ai_accounting.kernel import query_reads
    from ai_accounting.kernel.dashboard_reads import Journal
    from ai_accounting.kernel.integrity import _invalid, _lines
    from ai_accounting.kernel.query_reads import QueryReads
    from ai_accounting.kernel.report_open_contribution import verify_published_source_bindings
    from ai_accounting.kernel.types import canonical

    # Preserve generic JSON values inside exact line objects; _lines remains
    # the unchanged strict type, integer-fen, shape and balancing authority.
    line_schema = core_schema.typed_dict_schema({
        key: core_schema.typed_dict_field(core_schema.any_schema())
        for key in ("account", "debit", "credit", "cashflow")
    }, strict=True, extra_behavior="forbid")
    decoder = SchemaValidator(core_schema.typed_dict_schema({
        "lines": core_schema.typed_dict_field(core_schema.list_schema(line_schema, strict=True)),
    }, strict=True, extra_behavior="ignore"))
    original_content = QueryReads.verify_selected_content
    original_account = Journal.account_amounts
    busy = False
    proof_names = (
        "_anchored_source_bytes", "_verified_publication_ids", "_verified_source_contents",
        "_verified_saved_input_identities", "_raw_calculation_outcomes", "_verified_sql_outcomes",
    )

    class CursorTap:
        def __init__(self, cursor, captured):
            self.cursor, self.captured = cursor, captured

        def __iter__(self):
            for row in self.cursor:
                if row["outcome"] is not None:
                    self.captured[row["id"]] = row["outcome"].encode("utf-8")
                yield row

        def __getattr__(self, name):
            return getattr(self.cursor, name)

    def narrow(reads, identifiers):
        nonlocal busy
        identifiers = set(identifiers)
        if busy or not query_reads._owns_current_selector_snapshot(reads, reads.connection):
            return original_content(reads, identifiers)
        if getattr(reads.store.registry, "content_version", None) == 1:
            return original_content(reads, identifiers)
        saved = {name: getattr(reads, name).copy() for name in proof_names}
        line_cache = reads._report_snapshot_cache.setdefault("PROTOTYPE_verified_lines", {})
        selected = identifiers - line_cache.keys() - reads._verified_source_contents.keys()
        if not selected:
            return {
                ident: reads._verified_source_contents[ident]
                if ident in reads._verified_source_contents else {"lines": line_cache[ident]}
                for ident in identifiers
            }
        before = Counter(getattr(reads.connection, "counts", {}))
        captured, pending = {}, {}
        original_execute = reads.connection.execute

        def execute(statement, parameters=()):
            cursor = original_execute(statement, parameters)
            if "THEN c.outcome END outcome" in statement:
                return CursorTap(cursor, captured)
            return cursor

        try:
            # Exact requested IDs only; classification supplies no proof.
            rows = list(reads.connection.execute(
                "SELECT c.id,c.kind,c.period,p.posting_period,"
                "coalesce((SELECT max(period) FROM period_close),-1) closed_through "
                "FROM json_each(?) ids JOIN calculation c ON c.id=ids.value "
                "LEFT JOIN calculation_publication p ON p.calculation_id=c.id",
                (canonical(sorted(selected)),),
            ))
            if {row["id"] for row in rows} != selected:
                _invalid("calculation", "*", "referenced_calculation_missing")
            eligible = {
                row["id"] for row in rows
                if row["kind"] not in {"asset_activation", "asset_consumption"}
                and (row["posting_period"] > row["closed_through"]
                     if row["posting_period"] is not None else row["period"] > row["closed_through"])
            }
            busy = True
            reads.connection.execute = execute
            try:
                fallback = set(verify_published_source_bindings(reads, eligible))
                # Missing repairable bodies retain the original saved-input
                # identity check after an exact read-only anchor rebuild.
                complete = dict(reads.verify_saved_input_identity(fallback)) if fallback else {}
                complete.update(original_content(reads, selected - eligible))
            finally:
                reads.connection.execute = original_execute
                busy = False
            noncanonical = set()
            # Independently anchored exact bytes alone permit skipping generic
            # duplicate-member materialization. Same-row digest is insufficient.
            for ident in sorted(eligible - fallback):
                raw = captured.get(ident, reads._raw_calculation_outcomes.get(ident))
                binding = reads._anchored_source_bytes.get(ident)
                if raw is None or binding is None:
                    _invalid("calculation", ident, "prototype_exact_raw_proof_missing")
                if hashlib.sha256(raw).hexdigest() != binding[1]:
                    noncanonical.add(ident)
                    continue
                try:
                    value = decoder.validate_json(raw, strict=True)
                except ValidationError:
                    _invalid("calculation", ident, "prototype_invalid_lines_json")
                _lines(value["lines"], "calculation", ident)
                pending[ident] = value["lines"]
            complete.update(original_content(reads, noncanonical))
            # Publish this diagnostic line cache and exact raw bytes only after
            # every eligible/fallback row has succeeded. Never mark these as
            # ordinary complete decoded outcomes.
            line_cache.update(pending)
            reads._raw_calculation_outcomes.update(
                (ident, captured[ident]) for ident in pending if ident in captured
            )
            events.append({
                "eligible": len(eligible), "narrow_lines": len(pending),
                "fallback": len(selected - eligible) + len(fallback) + len(noncanonical),
                "narrow_json_input_bytes": sum(len(captured.get(
                    ident, reads._raw_calculation_outcomes.get(ident, b""),
                )) for ident in pending),
                "work": dict(Counter(getattr(reads.connection, "counts", {})) - before),
            })
            return {
                ident: reads._verified_source_contents[ident]
                if ident in reads._verified_source_contents else {"lines": line_cache[ident]}
                for ident in identifiers
            }
        except BaseException:
            reads.connection.execute = original_execute
            busy = False
            for name, previous in saved.items():
                value = getattr(reads, name)
                value.clear()
                value.update(previous)
            raise

    @contextmanager
    def installed():
        def amounts(journal):
            with patch.object(QueryReads, "verify_selected_content", narrow):
                return original_account(journal)

        with patch.object(Journal, "account_amounts", amounts):
            yield narrow

    return installed


def visible(response):
    value = {**response, "data": dict(response["data"])}
    value["data"].pop("generated_at", None)
    return value


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--group", choices=("native", "fixtures", "all"), default="all")
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("x+", encoding="utf-8") as target:
        report = {"status": "running", "prototype": True, "page_timing": False,
                  "native": {}, "fixtures": [], "errors": []}

        def checkpoint():
            target.seek(0)
            json.dump(report, target, indent=2, ensure_ascii=False)
            target.write("\n")
            target.truncate()
            target.flush()

        checkpoint()
        pool = None
        try:
            environment, fixed = bootstrap()
            pool = environment["pool"]
            from stage9_metrics import measure_work
            from ai_accounting.kernel.types import canonical

            report.update({"source": str(fixed["SOURCE"]),
                           "source_sha256": fixed["SOURCE_SHA256"],
                           "book_report_sha256": fixed["REPORT_SHA256"]})
            report["before"] = environment["check_state"]()
            if args.group in {"native", "all"}:
                engine, page, period = (environment[key] for key in ("engine", "dashboard", "period"))
                baseline_work, response = measure_work(engine, lambda: page.brief(period, limit=20))
                report["native"]["baseline"] = baseline_work
                report["native"]["visible_sha256"] = hashlib.sha256(canonical(visible(response)).encode()).hexdigest()
                checkpoint()
                events = []
                with prototype(events)():
                    prototype_work, compared = measure_work(engine, lambda: page.brief(period, limit=20))
                report["native"].update({"prototype_work": prototype_work, "events": events,
                                         "complete_visible_equal": visible(response) == visible(compared)})
                checkpoint()
                assert report["native"]["complete_visible_equal"], "prototype changed native brief"
                del response, compared
            if args.group in {"fixtures", "all"}:
                fixture_checks(report, checkpoint)
            report["after"] = environment["check_state"]()
            environment["check_source"]()
            report["status"] = "diagnostic_completed"
            checkpoint()
        except BaseException as error:
            report["status"] = "failed"
            report["errors"].append({"type": type(error).__name__, "message": str(error),
                                     "traceback": traceback.format_exc()})
            checkpoint()
            raise
        finally:
            if pool is not None:
                pool.close()
    print(json.dumps({"status": report["status"], "output": str(args.output)}))


def fixture_checks(report, checkpoint):
    from test_engine import close, engine as engine_fixture, publish, save
    from test_integrity_content import damage
    from ai_accounting.kernel.contracts import KernelError
    from ai_accounting.kernel.query_reads import QueryReads

    with tempfile.TemporaryDirectory(prefix="stage9-anchor-lines-", dir=ROOT / ".tmp") as name:
        for case in ("ordinary", "review_no_impact", "frozen", "missing_anchor",
                     "duplicate_and_matching_own_digest", "missing_body", "noncanonical"):
            folder = Path(name) / case
            folder.mkdir()
            engine = engine_fixture.__wrapped__(folder)
            save(engine)
            publish(engine)
            if case == "review_no_impact":
                save(engine, revision=1, request="second")
                publish(engine, request="second-publish")
            elif case == "frozen":
                close(engine)
            with engine.store.connection(read_only=True) as connection:
                ids = {row[0] for row in connection.execute("SELECT id FROM calculation")}
                original_rows = list(connection.execute("SELECT id,outcome FROM calculation"))
            if case == "missing_anchor":
                damage(engine, "report_open_contribution_anchor",
                       "DELETE FROM report_open_contribution_anchor", foreign_keys=False)
            elif case == "duplicate_and_matching_own_digest":
                row = original_rows[0]
                raw = row["outcome"].replace('{"account":', '{"account":"wrong","account":', 1)
                damage(engine, "calculation", "UPDATE calculation SET outcome=?,digest=? WHERE id=?",
                       (raw, hashlib.sha256(raw.encode()).digest(), row["id"]))
            elif case == "noncanonical":
                row = original_rows[0]
                raw = json.dumps(json.loads(row["outcome"]), ensure_ascii=False, indent=2)
                damage(engine, "calculation", "UPDATE calculation SET outcome=? WHERE id=?", (raw, row["id"]))
            elif case == "missing_body":
                with engine.store.connection() as connection:
                    connection.execute("BEGIN IMMEDIATE")
                    connection.execute("DELETE FROM report_open_contribution")
                    connection.commit()
            events = []
            with prototype(events)() as narrow, QueryReads.snapshot(engine) as reads:
                previous = {name: getattr(reads, name).copy() for name in (
                    "_anchored_source_bytes", "_verified_source_contents", "_verified_publication_ids",
                )}
                try:
                    result = narrow(reads, ids)
                except KernelError as error:
                    assert case in {"missing_anchor", "duplicate_and_matching_own_digest"}
                    assert error.code == "content_integrity_failed"
                    assert all(getattr(reads, key) == value for key, value in previous.items())
                    actual = {"error": error.code, "reason": error.details.get("reason"),
                              "failure_no_partial_proofs": True}
                else:
                    assert case not in {"missing_anchor", "duplicate_and_matching_own_digest"}
                    expected = {row["id"]: json.loads(row["outcome"])["lines"] for row in original_rows}
                    assert {ident: value["lines"] for ident, value in result.items()} == expected
                    actual = {"lines_equal": True, "decoded_cache_count": len(reads._verified_source_contents),
                              "anchored_count": len(reads._anchored_source_bytes)}
                report["fixtures"].append({"case": case, **actual, "events": events})
                checkpoint()


if __name__ == "__main__":
    main()
