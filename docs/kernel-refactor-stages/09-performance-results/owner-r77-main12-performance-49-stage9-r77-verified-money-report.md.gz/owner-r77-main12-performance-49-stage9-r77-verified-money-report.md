# r77 当前已核资金 effect 输入组

本组只修改 `src/ai_accounting/kernel/dashboard_funds.py`，新增 `tests/kernel/test_funds_verified_money_effects.py`。没有改 DDL、查询通用层、看板合同、生成文件或文档，没有操作真实资料、现存服务、提交或推送。

最终源码 SHA256：
- dashboard_funds.py: `5319396e6279a2e2503fae6023fe54c0c92e2fd06b863709789f8b428f962e15`
- 新 tests: `4db4d0e6010b70fa3c3ddca4fea657184fed09294c651f82a22009ec89c6fe46`

## 范围与证明边界

`movements` 仅由 `account_summary` 消费，资金汇总与分页继续使用同一 source。events 的普通 selection、adoption、frozen/source、body/JSON 与 close_reference 检查全部保留。`events` 完整成功后，把当前默认 money scope 已实际筛选的同份 headers 保留在 FundsRead 私有字段；`movements` 之后消费它，不再重新扫描月度 headers/lines。失败不发布该字段或 event query；后次成功可复用同份选择，但每次 effect 构造不缓存。

只有普通 owned snapshot、未关闭月、同体系 readers、实际 Journal 成功月度 money proof、精确 basis 的 decoded body 均满足时，才构造 period/event/number/basis/kind/sign/effect_index/category/key/amount/actual_date 输入。既有 body cache 按实际 basis 精确查找，不遍历无关结果。metadata/anchor 不能代替 decoded body。没有 Journal 成功 headers 的普通 funds 即使 events 证明了 body，也不扩大读取来制造命中。closed/fixed/未 owned/未 decoded/非普通 shape 原路。

effects 仅保留现金、银行、平台且非零的项目；原 effect_index 保留，local_index 仍由原 SQLite row_number 计算；内部互转及 sum、负冲正、全部汇总、筛选与分页 SQL 不变，整数溢出仍由 SQLite 原路径拒绝。广义 events 的投资 fields/cost/members/settlement 消费保持原 query。current-period reversal 继续通过 events 核对原 frozen 来源。

## 定向验证

最终一次命令：`.tmp-kernel-venv/Scripts/python.exe -m pytest tests/kernel/test_funds_verified_money_effects.py -q --junitxml=.tmp/stage9-r77-verified-money-final3.xml`。

结果：21 passed in 22.81s。涵盖现金/银行/平台及三类互转、与原 SQL 全行/完整 summary/filtered page/末页相等、无关与 no-voucher/no-money 结果不进入输入、缺 body/metadata-only/未 owned/fixed、七类非普通 shape 原路、未知日期/空 effect/跳过非money与零 effect 保留局部编号、超过 2^53 与 int64 上界精确、SQLite group 整数溢出、开放替换及无影响复核、closed review 原路、current reversal 原 frozen body 与负冲正汇总、四种新请求缺失/损坏拒绝、events 引用证明失败不发布输入且成功重试只取一次物理选择。

随后只新增并定向运行独立实际工作量增长测试，未机械重跑21例，也不把两次通过数相加宣称新整组吞吐。growth3.xml/log：1 passed in 10.75s。3条money来源之后新增当月24条非money expense、历史24条expense，并由测试专用纯evaluator给3条funding生成并正式保存、发布、核验每条16KiB无关values。前后窄carrier均为3行/580 UTF-8 bytes；实际SQLite VM均800，返回3行/831 bytes，消费时新增body加载均为0。完整月proof另行measure_work，其body加载字节1,062→64,090、结果解码3→27，证明必要month正文核验随当前业务/正文增长，未伪装为本组减少。

最终只对本组两文件 Ruff：`ruff-final4.log` 为 All checks passed。Ruff格式化仅新test文件。growth3之后仅把记录property的长调用断行，未改测试语义，不再重复已过测试。

首次/中间失败全部保留：narrow(3个测试资料/触发错误)、narrow2(1个 fixture tuple 错误)、final2(缓存headers后 fixed reader负例指出缺guard，生产已补同体系reader护栏)。mixed 单独修复验证、final(此前20通过)均保留；最终以 final3 的21通过为本组结果，不以拆分通过数替代。

最小相关组建议由根统一选择：`test_funds_required_summary_work.py`、`test_funds_source_integrity.py`、`test_funds_summary_page.py`、`test_dashboard_funds_alignment.py`、`test_v1_stored_json_isolation.py`。本agent不跑大套、五页浏览器或统一回归。

## 只读实际 A/B

只读数据库为 `.tmp/stage9-owner-main48-r63`，身份绑定 `.tmp/stage9-owner-main48-r73-verified.json`。未重跑当前体系 full integrity，未写入或 preview。基线源码为固定 `.tmp/stage9-build-source-owner-r76-release`；cost2/cost3 仅 overlay 本组 dashboard_funds 源码，以固定 released 合同读该已验证 synthetic 库。直接工作区 draft 源码读取 released synthetic 库被版本核验拒绝，失败日志 cost 保留，未修改数据库以绕过。

生产未改前实验：504条当前 money effects，全 outcome 物化源 365,814 UTF-8 bytes，候选窄 carrier 118,561 bytes；相同504行返回229,441 bytes。movement SQL VM204,100→110,900。完整响应排除 `data.generated_at` 后 SHA 一致。前两次把时间戳纳入等价断言失败的 experiment/native 报告和日志均保留；native2 修正后8对 brief median419.47→416.28ms。

cost2（尚有第二次 headers/lines扫描）的20次已warm、完整proof后 movement+group median18.18→13.85ms，构造与 canonical median2.96ms；12对 brief native median484.02→454.96ms。

最终 cost3（复用同份物理 headers）的20次 movement+group median17.80→12.44ms，包含输入构造及 SQL 的净成本，窄构造与 canonical median1.84ms；VM195,600→105,000。12对完整 brief native median442.08→443.27ms。局部净收益成立；整页 native 差异仍在波动，未证明稳定的整页时延收益，不能据此宣称500ms验收通过。此前不同轮的3ms/29ms改善及本轮1.19ms反向波动均保留。

最终完整 instrumented brief A/B：SQL425、返回20,071行/10,180,408 bytes、body加载1,016次/994,988 bytes、body解码1,015次、stdlib.loads1,503次均完全相同；VM1,527,700→1,435,800。收益来自 SQL 内部反复 materialize/extract 的宽 body 改为窄 carrier，不声称减少 Python 返回 body搬运、decode 或必要 proof。保留的 window/group 本身仍有105,000 VM，不将之前245,500VM归为 JSON重复。

完整 SQL、每轮 VM/native、work SQL、rows/bytes/decodes与 source SHA 在 experiment/native2/cost2/cost3 JSON；最终 cost3 为本组候选的实际工作记录。所有执行/失败日志、脚本和XML均独占 `.tmp/stage9-r77-verified-money-*`。
