"""Prepare one paired native timing diagnostic, without SQL/profile instruments."""
from pathlib import Path
import hashlib
import json

W = Path(__file__).resolve().parents[1]
source = W / '.tmp/stage9-open-scope-group-work-20261004.py'
target = W / '.tmp/stage9-open-scope-native-20261004.py'
assert not target.exists()
text = source.read_text(encoding='utf-8')
text = text.replace('import sys\n', 'import sys\nimport time\n')
text = text.replace("output.name.startswith('stage9-open-scope-group-work-')", "output.name.startswith('stage9-open-scope-native-')")
text = text.replace("    sys.path.insert(0, str(source / 'tests/kernel'))\n    import stage9_metrics\n", '')
text = text.replace("'operations_per_page': 1, 'warmup_operations': 0, 'observations': [],", "'operations_per_page': 30, 'warmup_operations': 3, 'observations': [],\n        'native_timing_only': True, 'sql_profile_or_allocation_instruments': False,")
start = "            work, response = stage9_metrics.measure_work(engine, operation)"
end = "            print(json.dumps({'page': name, 'counters': work['counters']}, ensure_ascii=False), flush=True)"
a, b = text.index(start), text.index(end) + len(end)
text = text[:a] + '''            for _ in range(3):
                operation()
            observation = {'page': name, 'samples_ms': [], 'business_response_sha256': None,
                           'successful_responses': 0}
            report['observations'].append(observation)
            for _ in range(30):
                started = time.perf_counter_ns()
                response = operation()
                elapsed = (time.perf_counter_ns() - started) / 1_000_000
                observation['samples_ms'].append(elapsed)
                response_sha = response_hash(response, business=True)
                if observation['business_response_sha256'] is None:
                    observation['business_response_sha256'] = response_sha
                assert observation['business_response_sha256'] == response_sha
                observation['successful_responses'] += 1
            samples = sorted(observation['samples_ms'])
            observation['median_ms'] = (samples[14] + samples[15]) / 2
            observation['p95_ms'] = samples[28]
            observation['max_ms'] = samples[-1]
            observation['at_or_above_500_count'] = sum(x >= 500 for x in samples)
            print(json.dumps({key:value for key,value in observation.items()
                              if key != 'samples_ms'}, ensure_ascii=False), flush=True)''' + text[b:]
text = text.replace('Instrumented actual work is not pure timing.', 'Native kernel calls exclude HTTP authorization, context/main concurrency and browser rendering; not 500 ms page acceptance.')
target.write_text(text, encoding='utf-8')
print(json.dumps({'source_helper':str(source),'source_helper_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
                  'timing_helper':str(target),'timing_helper_sha256':hashlib.sha256(target.read_bytes()).hexdigest()}))
