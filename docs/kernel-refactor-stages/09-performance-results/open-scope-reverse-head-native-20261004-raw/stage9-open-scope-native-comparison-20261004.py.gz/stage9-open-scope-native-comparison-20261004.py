"""Retain sequential native timings and their uncontrolled-environment limits."""
import hashlib
import json
from pathlib import Path

W = Path(__file__).resolve().parents[1]
paths = [W / ('.tmp/stage9-open-scope-native-' + name + '-20261004.json') for name in ('before', 'after')]
reports = [json.loads(path.read_text(encoding='utf-8')) for path in paths]
assert all(report['status'] == 'diagnostic_complete' and report['native_timing_only']
           and not report['sql_profile_or_allocation_instruments']
           and report['all_file_identity_state_history_registration_repair_guards_equal']
           and report['source_inventory_unchanged'] for report in reports)
observations = []
for before, after in zip(*(report['observations'] for report in reports), strict=True):
    assert before['page'] == after['page']
    assert before['business_response_sha256'] == after['business_response_sha256']
    assert before['successful_responses'] == after['successful_responses'] == 30
    assert len(before['samples_ms']) == len(after['samples_ms']) == 30
    observations.append({'page':before['page'], 'business_response_equal':True,
        'before':{key:before[key] for key in ('median_ms','p95_ms','max_ms','at_or_above_500_count')},
        'after':{key:after[key] for key in ('median_ms','p95_ms','max_ms','at_or_above_500_count')}})
out = {'status':'diagnostic_comparison_complete',
    'files':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},
    'source_pair_changes_one_production_file':True,
    'native_calls_each_source':180, 'browser_acceptance':False,
    'stable_latency_or_causal_speedup_established':False,
    'observations':observations,
    'limitations':[
        'Sequential source runs, not interleaved or a controlled OS load comparison.',
        'No regressions, builds, qualification or SQL/profile instruments ran concurrently with these timed calls.',
        'A post-window OS counter observation reported substantial game/cloud/antimalware CPU activity. No interval-wide CPU monitoring was collected; it does not establish the cause of any individual slow sample.',
        'The post-window counter was observed via tool stdout; no original persistent CPU receipt exists and none is fabricated.',
        'All slow samples are retained. No HTTP, browser, real account or real service was used or modified.',
        'Observed game/sync processes were not stopped, paused or changed.',
        'Business response normalization uses only the exact source-bound top read_context.read_version and declared clocks. No other IDs, amounts, cursors, versions or states change.',
        'The page 500 ms target remains unmet/unverified; native times do not establish page acceptance.'
    ]}
target=W / '.tmp/stage9-open-scope-native-comparison-20261004.json'
assert not target.exists()
target.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':out['status'],'observations':observations},ensure_ascii=False))
