# r73公共HTTP请求与历史构造准备

主48固定r73纯浏览器实际150次成功响应中79次≥500ms，性能失败；主12先前5／150失败与r70先前37／150失败各保留原件，内容完整核验通过不替代性能通过。固定source SHA420ceb395fc5aec17ddaedf8914c7fc8de640da9f08cb35aded8a3a99a4eb7f4，browser backend build及静态hash与保存的snapshot manifest绑定；本次不重新扫描全树。

| 页面 | 慢样本／30 | median／p95／max ms |
| --- | --- | --- |
| 简报 | 30 | 636.6／697.0／735.3 |
| 资金 | 4 | 436.8／535.6／536.3 |
| 员工 | 0 | 316.7／471.9／473.2 |
| 资产 | 17 | 515.9／596.3／715.4 |
| 报表 | 28 | 556.8／615.1／616.0 |

冷开与首次加载另存原JSON，不能并入热刷新成功结论；切公司为single_eligible_company unavailable。六路native各3样本小于500ms没有证明本轮browser通过。

## 请求范围与必要安全检查

| 问题类型 | 已保存证据与结论 | 未验证边界 |
| --- | --- | --- |
| 五页重复请求／请求串行 | attempt3请求计数和HTTP/dispatch时间表确认正常五页热刷新没有重复主请求，相关请求启动间距小于2ms，已并行。setup、warmup和冷开请求仍在完整记录中，不能按总计数声称重复。 | 该诊断受主48设置活动影响，不是独占纯浏览器计时，不能用3次样本替代30次失败。 |
| 并发cProfile归因 | browser attempt3保存真实仪表化结果；Python3.12并发profile可能污染调用图，不能按其中函数图断言某个请求独占耗时或精确调用归属。 | 不据污染图归因GIL／network或关闭安全复验。 |
| 串行请求边界 | sequential attempt2成功串行context／brief／close-review；各endpoint实际4次metadata、4次schema、2次_check_catalog、1次authorize、1次response validate、1次dump，SQLite实际open通常2次，首次context3次。 | schema自身own时间<1ms，不等于包含连接开销的inclusive耗时<1ms；摘要检查／序列化小于1ms，authorize约12.8ms是brief样本，首次context与其他路径独立，不外推所有请求。安全职责仍须对应真实复验。 |
| 初失败与尝试身份 | browser初次warmups>=1断言失败；attempt2 close-review prepared等待超时／ERR_EMPTY_RESPONSE；sequential初次failed保留。attempt3 over_target、sequential attempt2 passed各为独立原件。 | 没有独立保存的请求runner stdout/log不补造；当前存在的JSON、runners及profile summaries完整归档。 |

## 历史manifest与构造准备

历史source inventory曾被当前required-file集合解释，因历史没有frontend/local-api-proxy.ts被错误阻断。工具守卫改为按各旧固定source原manifest声明核完整路径／字节／汇总SHA；当前r73仍按当前完整source guard执行。轻量guard实际验证三种旧source及current_r73，负例覆盖缺文件、改字节、错汇总、路径逃逸、未知CASE拒绝；健康小fixture通过。它没有读取SQLite、构造、内容核验或preview。

readiness现为static_ready_runtime_guards_mandatory，保留initial_preflight_result原失败与实际后续静态结果。main120／independent48仍built_not_verified；independent120旧verified保留旧source身份。main120的186,767,161字节checkpoint本批不读取、不复制、不压缩；原SHA在准备报告中引用，JSON完整source guard仍留实际构造前执行。源SQLite身份／FK／冻结row digest与目标注册完整核验及真实开放preview尚未由readiness证明；磁盘预算只是保守规划估算。不能把准备、源码负例或语法通过写为构造通过。

原件集中见[本批manifest](owner-r73-main48-browser-request-readiness-manifest.json)，保存raw／gzip双SHA、bytes／mtime并解压逐字节核对。全部未实际检查的事项保持未验证。本次仅档案与文档整理，无SQL、tests、服务、构造或计时。
