"""Run the unchanged old46 singleton with observational error-code receipt."""

import hashlib
import json
import sys
from pathlib import Path

WORKSPACE = Path(__file__).resolve().parents[1]
SOURCE = WORKSPACE / '.tmp/stage9-build-source-owner-read-groups-20261003-release'
TEST = SOURCE / 'tests/kernel/test_report_open_contribution.py'
SOURCE_SHA = '46f84508afd54165f23af5a83434b1881002ab45490f4358f0c1755c743748be'
QUERY_SHA = '2f0b4b4c238c9a2e6bcfacef71d9dc221d011d198f5d6f73659b5150df14332a'
TEST_SHA = 'dfd03d93b08b63cfe93b5b84e9347f671a5ad4f4da12a8a4e440e0396a8da69f'
OUTPUT = WORKSPACE / '.tmp/stage9-old46-noimpact-publication-repro.json'
LOG = WORKSPACE / '.tmp/stage9-old46-noimpact-publication-repro.log'
TEMP = WORKSPACE / '.tmp/stage9-old46-noimpact-publication-pytest'


def file_hash(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def main():
    assert not OUTPUT.exists() and not LOG.exists() and not TEMP.exists()
    assert Path(sys.prefix).resolve() == (WORKSPACE / '.tmp-kernel-venv').resolve()
    manifest = json.loads((SOURCE / 'source-manifest.json').read_text(encoding='utf-8'))
    assert manifest['sha256'] == SOURCE_SHA and manifest['status'] == 'complete'
    assert file_hash(TEST) == TEST_SHA
    query_path = SOURCE / 'src/ai_accounting/kernel/query_reads.py'
    assert file_hash(query_path) == QUERY_SHA
    sys.path.insert(0, str(SOURCE / 'scripts'))
    import stage9_source
    stage9_source.configure_source(SOURCE, WORKSPACE)
    from ai_accounting.kernel import contracts, query_reads, report_projection
    for module, relative in (
        (stage9_source, 'scripts/stage9_source.py'),
        (contracts, 'src/ai_accounting/kernel/contracts.py'),
        (query_reads, 'src/ai_accounting/kernel/query_reads.py'),
        (report_projection, 'src/ai_accounting/kernel/report_projection.py'),
    ):
        stage9_source.require_source_module(module, SOURCE, relative)
    report = {'scope': 'unchanged_old46_singleton_reproduction', 'source': str(SOURCE),
              'source_sha256': SOURCE_SHA, 'test_sha256': TEST_SHA, 'query_reads_sha256': QUERY_SHA,
              'test': 'test_open_report_rejects_missing_no_impact_review_publication',
              'module_bindings': {m.__name__: str(m.__file__) for m in
                                  (contracts, query_reads, report_projection)}, 'observed_errors': []}
    original_init = contracts.KernelError.__init__

    def observed_init(self, code, message, **details):
        original_init(self, code, message, **details)
        if message in {'正式发布缺少精确当前核算来源', '当前凭证缺少正式发布采用'}:
            report['observed_errors'].append({'code': self.code, 'message': str(self),
                                              'details': self.details})

    class Tee:
        def __init__(self, stream, log):
            self.stream, self.log = stream, log

        def write(self, text):
            self.stream.write(text)
            self.log.write(text)

        def flush(self):
            self.stream.flush()
            self.log.flush()

        def __getattr__(self, name):
            return getattr(self.stream, name)

    import pytest
    arguments = ['-q', '-x', '-c', str(SOURCE / 'pyproject.toml'),
                 '--confcutdir', str(SOURCE), '--basetemp', str(TEMP),
                 str(TEST) + '::' + report['test']]
    report['pytest_arguments'] = arguments
    contracts.KernelError.__init__ = observed_init
    with LOG.open('x', encoding='utf-8') as log:
        original_stdout, original_stderr = sys.stdout, sys.stderr
        sys.stdout, sys.stderr = Tee(original_stdout, log), Tee(original_stderr, log)
        try:
            report['pytest_exit_code'] = pytest.main(arguments)
        finally:
            sys.stdout, sys.stderr = original_stdout, original_stderr
            contracts.KernelError.__init__ = original_init
    assert file_hash(TEST) == TEST_SHA and file_hash(query_path) == QUERY_SHA
    OUTPUT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'pytest_exit_code': report['pytest_exit_code'],
                      'observed_errors': report['observed_errors']}, ensure_ascii=False), flush=True)
    assert report['pytest_exit_code'] == 1 and report['observed_errors'] == [
        {'code': 'content_integrity_failed', 'message': '正式发布缺少精确当前核算来源', 'details': {}}
    ], 'Old46 did not reproduce the same specific failure'


if __name__ == '__main__':
    main()
