"""Isolated read-only split-header prototype; no production replacement or latency claim."""

from __future__ import annotations

import hashlib
import json
import sys
import time
import traceback
from collections import Counter, defaultdict
from contextlib import contextmanager
from pathlib import Path
from types import SimpleNamespace

WORKSPACE = Path(__file__).resolve().parents[1]
SOURCE = WORKSPACE / '.tmp/stage9-build-source-owner-read-groups-20261003-release'
SOURCE_SHA = '46f84508afd54165f23af5a83434b1881002ab45490f4358f0c1755c743748be'
MANIFEST_SHA = 'f6712860b71bda18b8c41078410c8fba918f97da6fd6426d47992e4a8130283a'
BOOK = WORKSPACE / '.tmp/stage9-owner-main48-read-groups-qualified.json'
BOOK_SHA = 'edca0e5294a91520cbfeacb71df0f4b90862c12d89236c9399465ca675f0d846'
OUTPUT = WORKSPACE / '.tmp/stage9-report-source-split-46f845-fix1.json'
LOG = WORKSPACE / '.tmp/stage9-report-source-split-46f845-fix1.log'


def require(value, message):
    if not value:
        raise ValueError(message)


def file_hash(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def main():
    require(not OUTPUT.exists() and not LOG.exists(), 'Refuse existing diagnostic output/log')
    require(Path(sys.prefix).resolve() == (WORKSPACE / '.tmp-kernel-venv').resolve(),
            'Use repository virtual environment')
    log = LOG.open('x', encoding='utf-8')
    report = {'status': 'started', 'scope': 'read_only_owned_open_source_split_prototype',
              'production_modified': False, 'latency_acceptance': False,
              'source': str(SOURCE), 'source_sha256': SOURCE_SHA, 'cases': []}
    OUTPUT.open('x', encoding='utf-8').close()

    def save():
        OUTPUT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

    def note(message):
        print(message, flush=True)
        log.write(message + '\n')
        log.flush()

    try:
        require(file_hash(SOURCE / 'source-manifest.json') == MANIFEST_SHA, 'Manifest drift')
        require(file_hash(BOOK) == BOOK_SHA, 'Qualified book receipt drift')
        manifest = json.loads((SOURCE / 'source-manifest.json').read_text(encoding='utf-8'))
        require(manifest['sha256'] == SOURCE_SHA and manifest['status'] == 'complete'
                and Path(manifest['target']).resolve() == SOURCE, 'Wrong source manifest')
        sys.path.insert(0, str(SOURCE / 'scripts'))
        import stage9_source
        stage9_source.configure_source(SOURCE, WORKSPACE)
        import snapshot_stage9_source
        import stage9_metrics
        from ai_accounting.kernel import query_reads, report_projection, schema_bundle, storage
        from ai_accounting.kernel.types import YearMonth, canonical
        from ai_accounting.kernel.versions import database_format
        modules = ((stage9_source, 'scripts/stage9_source.py'),
                   (snapshot_stage9_source, 'scripts/snapshot_stage9_source.py'),
                   (stage9_metrics, 'tests/kernel/stage9_metrics.py'),
                   (query_reads, 'src/ai_accounting/kernel/query_reads.py'),
                   (report_projection, 'src/ai_accounting/kernel/report_projection.py'),
                   (schema_bundle, 'src/ai_accounting/kernel/schema_bundle.py'),
                   (storage, 'src/ai_accounting/kernel/storage.py'))
        for module, relative in modules:
            stage9_source.require_source_module(module, SOURCE, relative)
        inventory = snapshot_stage9_source._inventory(SOURCE)
        require(inventory == manifest['files']
                and snapshot_stage9_source._digest(inventory) == SOURCE_SHA, 'Source bytes drift')
        report['module_bindings'] = {module.__name__: str(module.__file__) for module, _ in modules}
        book = json.loads(BOOK.read_text(encoding='utf-8'))
        root = stage9_source.synthetic_path(Path(book['root']), WORKSPACE)
        require(root == WORKSPACE / '.tmp/stage9-owner-main48-r63'
                and Path(book['source']).resolve() == SOURCE and book['requested_months'] == 48,
                'Wrong synthetic sample')
        company = book['company']
        database = Path(company['path']).resolve(strict=True)
        require(database.is_relative_to(root), 'Database outside bound root')
        bundle = schema_bundle.production_bundle()
        store = storage.Store(database, bundle, company['id'], company['database_id'],
                              taxpayer_id=company['taxpayer_id'])
        original_connection = store.connection

        def prototype(connection, period, reads):
            # Copy only the real owned-current positive branch prologue and its
            # exact selector. Other branches are outside this prototype.
            require(query_reads._owns_current_selector_snapshot(reads, connection),
                    'Prototype requires owned current reader')
            reads.verify_open_voucher_scope(period, posting_period=period)
            require(connection.execute('SELECT 1 FROM period_close WHERE period=?',
                                       (period,)).fetchone() is None, 'Closed month in prototype')
            require(connection.execute(
                'SELECT 1 FROM voucher_version v INDEXED BY voucher_period '
                'CROSS JOIN close_reference r INDEXED BY close_reference_lookup '
                "ON r.reference_type='voucher' AND r.reference_id=v.id AND r.close_period<=? "
                'WHERE v.period=? LIMIT 1', (period, period)).fetchone() is None,
                'Unexpected frozen references: retain original path')
            reads._report_snapshot_cache['open_voucher_period', period, period] = True
            selected, params = report_projection.selected_voucher_sql(
                YearMonth.from_ordinal(period), posting_period=YearMonth.from_ordinal(period),
                no_close_references=True)
            headers = list(connection.execute(
                'WITH selected AS (' + selected + ') '
                'SELECT v.period,v.id,v.voucher_calculation_id AS calculation_id,'
                'v.basis_calculation_id,p.id publication_id,v.reverses_id,'
                'c.kind,c.fact_id,c.period calculation_period,'
                'c.subject_id calculation_subject_id,c.digest result_digest,'
                'v.voucher_id,v.voucher_subject_id,v.close_period '
                'FROM selected v JOIN calculation c ON c.id=v.basis_calculation_id '
                'LEFT JOIN calculation_publication p ON p.calculation_id=v.basis_calculation_id '
                'ORDER BY v.id', params))
            ids = sorted({header['id'] for header in headers})
            lines = list(connection.execute(
                'SELECT l.version_id,l.line_no,l.account,l.debit,l.credit,l.cashflow '
                'FROM json_each(?) ids CROSS JOIN voucher_line l ON l.version_id=ids.value '
                'ORDER BY l.version_id,l.line_no', (canonical(ids),))) if ids else []
            assembly_started = time.perf_counter()
            grouped_headers, grouped_lines = defaultdict(list), defaultdict(list)
            for header in headers:
                grouped_headers[header['id']].append(header)
            for line in lines:
                grouped_lines[line['version_id']].append(line)
            rows = [
                ('open', header['period'], header['id'], line['line_no'],
                 header['calculation_id'], header['basis_calculation_id'], header['publication_id'],
                 header['reverses_id'], line['account'], line['debit'], line['credit'], line['cashflow'],
                 header['kind'], header['fact_id'], header['calculation_period'],
                 header['calculation_subject_id'], header['result_digest'])
                for ident in ids for line in grouped_lines[ident] for header in grouped_headers[ident]
            ]
            used_headers = {header['id']: header for header in headers if grouped_lines[header['id']]}
            assembly_ms = (time.perf_counter() - assembly_started) * 1000
            publications = report_projection._selected_current_voucher_publications(
                reads, tuple(used_headers.values()), period=period, cutoff=period)
            if publications is None:
                report_projection.verify_current_voucher_publications(connection, {row[2] for row in rows})
            return (rows, True), {'selected_header_count': len(headers), 'all_line_count': len(lines),
                                  'assembly_diagnostic_ms': assembly_ms,
                                  'proof_header_ids': sorted(used_headers)}

        def run(period_string, kind):
            counts, statements, work = Counter(), Counter(), defaultdict(Counter)
            @contextmanager
            def counted_connection(*, read_only=False):
                require(read_only, 'Diagnostic forbids writes')
                with original_connection(read_only=True) as raw:
                    def progress():
                        counts['sqlite_vm_steps'] += 100
                        return 0
                    raw.set_progress_handler(progress, 100)
                    try:
                        yield stage9_metrics._Connection(raw, counts, statements, work, set())
                    finally:
                        raw.set_progress_handler(None, 0)
            store.connection = counted_connection
            with query_reads.QueryReads.snapshot(SimpleNamespace(store=store)) as reads:
                connection = reads.connection
                initial = list(connection.execute('SELECT * FROM state WHERE id=1').fetchone())
                require(initial == book['verified_open_preview']['state'], 'Sample state drift')
                format_receipt = database_format(connection, bundle=bundle)
                require(format_receipt == book['integrity_contract'], 'Schema drift')
                # Schema binding is not counted as endpoint work, matching native diagnostic scope.
                counts.clear()
                statements.clear()
                work.clear()
                period = YearMonth(period_string).ordinal
                started = time.perf_counter()
                if kind == 'original':
                    result = report_projection._authoritative_rows(
                        connection, 'open', period, with_absence=True, reads=reads)
                    extra = {}
                else:
                    result, extra = prototype(connection, period, reads)
                diagnostic_ms = (time.perf_counter() - started) * 1000
                require(list(connection.execute('SELECT * FROM state WHERE id=1').fetchone()) == initial,
                        'State changed in read transaction')
                wire = [[value.hex() if isinstance(value, bytes) else value for value in row]
                        for row in result[0]]
                metrics = {'kind': kind, 'diagnostic_ms': diagnostic_ms,
                           'counters': dict(counts), 'output_rows': len(wire),
                           'tuple_digest': hashlib.sha256(canonical(wire).encode()).hexdigest(),
                           'no_close_references': result[1],
                           'publication_proof_ids': sorted(reads._verified_current_voucher_publications),
                           'sql': [{'statement': sql, 'calls': statements[sql], **dict(work[sql])}
                                   for sql in statements], **extra}
                return result, metrics

        for period_string in ('2019-12', '2020-01'):
            original, before = run(period_string, 'original')
            alternative, after = run(period_string, 'prototype')
            require(original == alternative, 'Original/prototype tuples or absence differ')
            require(before['publication_proof_ids'] == after['publication_proof_ids'],
                    'Publication proof identity set differs')
            case = {'period': period_string,
                    'collection': 'main48_nonempty' if period_string == '2019-12' else 'empty_future_month',
                    'same_ordered_tuples': True, 'same_publication_proof_ids': True,
                    'original': before, 'prototype': after}
            report['cases'].append(case)
            save()
            note(f"{period_string}: exact rows={before['output_rows']} "
                 f"VM {before['counters'].get('sqlite_vm_steps', 0)}->{after['counters'].get('sqlite_vm_steps', 0)} "
                 f"bytes {before['counters']['returned_value_bytes']}->{after['counters']['returned_value_bytes']}")
        require(snapshot_stage9_source._inventory(SOURCE) == inventory, 'Fixed source drift')
        require(file_hash(BOOK) == BOOK_SHA, 'Qualified receipt drift')
        report['status'] = 'diagnostic_complete'
        save()
        note('complete; no production change, no latency claim, small nonempty fixture not exercised')
    except BaseException as exc:
        report['status'] = 'failed'
        report['error'] = {'type': type(exc).__name__, 'message': str(exc), 'traceback': traceback.format_exc()}
        save()
        note(report['error']['traceback'])
        raise
    finally:
        log.close()


if __name__ == '__main__':
    main()
