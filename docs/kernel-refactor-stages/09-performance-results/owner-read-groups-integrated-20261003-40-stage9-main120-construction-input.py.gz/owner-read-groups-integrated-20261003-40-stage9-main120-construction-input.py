"""After completed raw copy, emit construction metadata, never qualification proof."""
from __future__ import annotations

import argparse
import hashlib
import json
import sqlite3
import sys
from contextlib import closing
from pathlib import Path

WORKSPACE = Path(__file__).resolve().parents[1]
TARGET = WORKSPACE / ".tmp/stage9-main120-candidate-cache-group-20261003"
CURRENT = WORKSPACE / ".tmp/stage9-build-source-owner-read-groups-20261003-release"
CURRENT_SHA = "46f84508afd54165f23af5a83434b1881002ab45490f4358f0c1755c743748be"
COPY_SOURCE = WORKSPACE / ".tmp/stage9-build-source-owner-cache-group-20261003-release"
COPY_SOURCE_SHA = "19ae7d824077e8e988ffe254120f7d8ee7ed42708c5fdf8fb6eff2ffb3e49941"
COVERAGE = ("sources", "historical_adoption", "projections", "read_indexes")


def sha(path):
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def require(ok, message):
    if not ok:
        raise ValueError(message)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--copy-report-sha256", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(CURRENT / "scripts"))
    from stage9_source import configure_source, require_source_module, synthetic_path

    configure_source(CURRENT, WORKSPACE)
    import benchmark_stage9_browser as browser
    import prepare_stage9_main120 as preparation
    import rebase_stage9_synthetic_book as original
    from ai_accounting.kernel import schema_bundle
    from ai_accounting.kernel.permissions import reject_reparse_path
    from ai_accounting.kernel.types import YearMonth
    from ai_accounting.kernel.versions import verify_schema

    for module, relative in (
        (browser, "scripts/benchmark_stage9_browser.py"),
        (preparation, "scripts/prepare_stage9_main120.py"),
        (original, "scripts/rebase_stage9_synthetic_book.py"),
        (schema_bundle, "src/ai_accounting/kernel/schema_bundle.py"),
    ):
        require_source_module(module, CURRENT, relative)
    output = synthetic_path(args.output, WORKSPACE)
    copy_path = TARGET / "stage9-main120-copy-report.json"
    for path in (CURRENT, COPY_SOURCE, TARGET, copy_path, output):
        reject_reparse_path(path)
    require(not output.exists(), "Construction output must not exist")
    require(len(args.copy_report_sha256) == 64 and all(
        char in "0123456789abcdef" for char in args.copy_report_sha256
    ), "Explicit completed-copy SHA256 is required")
    require(sha(copy_path) == args.copy_report_sha256, "Completed copy report bytes changed")
    copy = original._read_json(copy_path)
    preparation.require_manifest(CURRENT, expected=CURRENT_SHA)
    preparation.require_manifest(COPY_SOURCE, expected=COPY_SOURCE_SHA)
    require(copy.get("status") == "copied_content_unverified"
            and copy.get("content_verified") is False
            and copy.get("root") == str(TARGET)
            and copy.get("source") == str(COPY_SOURCE),
            "Only the named completed, unverified raw copy is accepted")
    provenance = copy["provenance"]
    case = preparation.CASE
    old_root = WORKSPACE / ".tmp" / preparation.CASE_NAME
    old_source = WORKSPACE / ".tmp" / case["source_tree"]
    old_report = WORKSPACE / ".tmp" / case["report"]
    for path in (old_root, old_source, old_report):
        reject_reparse_path(path)
    preparation.require_manifest(old_source, expected=case["source_snapshot"], historical=True)
    _, checkpoint_name, old_checkpoint, report, period = original._source_guard(
        old_root, old_report, old_source, case
    )
    require(provenance.get("mode") == "synthetic_raw_copy_not_migration"
            and provenance.get("source_root") == str(old_root)
            and provenance.get("source_tree") == str(old_source)
            and provenance.get("source_report_sha256") == case["report_sha256"]
            and provenance.get("source_checkpoint_sha256") == case["checkpoint_sha256"]
            and provenance.get("source_snapshot_sha256") == case["source_snapshot"]
            and provenance.get("target_snapshot_sha256") == COPY_SOURCE_SHA
            and provenance.get("target_source") == str(COPY_SOURCE)
            and provenance.get("source_status") == "built_not_verified"
            and copy.get("period") == period,
            "Copy provenance differs from the pinned main120 construction")
    for name, recorded in (
        ("prepare_stage9_main120.py", "executor_sha256"),
        ("rebase_stage9_synthetic_book.py", "copy_helpers_sha256"),
    ):
        require(provenance.get(recorded) == sha(COPY_SOURCE / "scripts" / name),
                "Copy executor/helper provenance changed")
    bundle = schema_bundle.production_bundle()
    preparation.require_factory_sql(bundle)
    content_relative = "src/ai_accounting/kernel/schema_contracts/content-v1.json"
    content = original._read_json(CURRENT / content_relative)
    copied_content = original._read_json(COPY_SOURCE / content_relative)
    require(content == copied_content
            and provenance.get("target_content_contract") == content["sha256"]
            and provenance.get("target_company_contract") == bundle.current("company")["sha256"],
            "Current candidate schema/content differs from the raw-copy contract")
    copy_bundle = schema_bundle.load_bundle(
        bundle.registry, COPY_SOURCE / "src/ai_accounting/kernel/schema_contracts",
        family=schema_bundle.FAMILY, application_id=schema_bundle.APPLICATION_ID,
    )
    for kind in ("company", "catalog"):
        require(copy_bundle.current(kind) == bundle.current(kind),
                "Copy and qualification structure contracts differ")
    company = {**report["company"],
               "path": str(TARGET / report["company"]["taxpayer_id"] / "company.sqlite")}
    checkpoint_path = TARGET / checkpoint_name
    reject_reparse_path(checkpoint_path)
    checkpoint = original._read_json(checkpoint_path)
    require(checkpoint == {**old_checkpoint, "company": company},
            "Copied checkpoint differs beyond the explicit isolated company path")
    before = {path: sha(path) for path in (copy_path, checkpoint_path, old_report,
                                         old_root / checkpoint_name)}
    target_digests = copy.get("all_target_table_digests")
    source_digests = copy.get("all_source_table_digests")
    require(isinstance(target_digests, dict) and isinstance(source_digests, dict)
            and set(target_digests) - set(source_digests) == original.NEW_TABLES
            and not set(source_digests) - set(target_digests), "Copy table attestation is incomplete")
    for table, digest in source_digests.items():
        require(table in {"schema_meta", "schema_history"} or target_digests[table] == digest,
                "Copy report did not retain original table bytes")
    require(all(target_digests[table]["rows"] == 0 for table in original.NEW_TABLES),
            "Raw-copy new tables were not empty")

    def readonly(path):
        reject_reparse_path(path)
        connection = sqlite3.connect(path.resolve(strict=True).as_uri() + "?mode=ro", uri=True)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA query_only=ON")
        connection.execute("BEGIN")
        return connection

    with closing(readonly(TARGET / "catalog.sqlite")) as connection:
        verify_schema(connection, bundle=bundle, kind="catalog")
        require([dict(row) for row in connection.execute("SELECT * FROM company")] == [company],
                "Copied catalog identity or isolated path changed")
    with closing(readonly(Path(company["path"]))) as connection:
        verify_schema(connection, bundle=bundle)
        expected_identity = {"company_id": company["id"], "taxpayer_id": company["taxpayer_id"],
                             "database_id": company["database_id"]}
        require(dict(connection.execute(
            "SELECT company_id,taxpayer_id,database_id FROM identity WHERE id=1"
        ).fetchone())
                == expected_identity, "Copied database identity changed")
        require([list(row) for row in connection.execute("SELECT * FROM state")]
                == [checkpoint["epochs"]], "Copied epochs changed")
        closes = {str(YearMonth.from_ordinal(row[0])): row[1] for row in connection.execute(
            "SELECT period,json_extract(manifest,'$.preview_digest') FROM period_close"
        )}
        require(closes == {p: s["preview_digest"] for p, s in checkpoint["snapshots"].items()
                           if s["closed"]}, "Copied frozen snapshot metadata changed")
        require(set(original._tables(connection)) == set(target_digests),
                "Copied table inventory changed")
        for table in original.NEW_TABLES:
            require(not connection.execute(f"SELECT 1 FROM {original._quoted(table)} LIMIT 1")
                    .fetchone(), "Copied new table is no longer empty")
        # No business-byte digest rescan, registered verifier or preview runs here.
    construction = {
        "status": "unverified", "content_verified": False, "source": str(CURRENT),
        "root": str(TARGET), "company": company, "distribution": report["distribution"],
        "employee_count": report["employee_count"],
        "monthly_business_count": report["monthly_business_count"],
        "business_count": report["business_count"], "requested_months": report["requested_months"],
        "months": checkpoint["month_stats"], "snapshots": checkpoint["snapshots"],
        "default_page_limit": 20, "measurements": {},
        "integrity": {"status": "unverified", "coverage": {k: "unverified" for k in COVERAGE},
                      "limitations": ["Independent current registered verification not run"]},
        "construction_integrity": {"status": "unverified", "final_full_verification_required": True},
        "construction_input": {
            "mode": "construction_only_for_independent_current_qualification",
            "copy_report_sha256": args.copy_report_sha256,
            "checkpoint_sha256": before[checkpoint_path],
            "original_report_sha256": case["report_sha256"],
            "original_checkpoint_sha256": case["checkpoint_sha256"],
            "original_construction_source_sha256": case["source_snapshot"],
            "raw_copy_source_sha256": COPY_SOURCE_SHA, "qualification_source_sha256": CURRENT_SHA,
            "historical_month_stats_seconds": "Original construction telemetry; not current timing",
            "table_byte_attestation": "Copy report only; not reverified by this helper",
            "schema_checked": True, "content_contract_compatible": True,
            "content_verified": False, "preview_verified": False,
            "helper_sha256": sha(Path(__file__)),
        },
    }
    require(browser.validate_book_report(construction, company_name=company["name"],
                                        require_verified=False) == period, "Construction period changed")
    dimensions = browser.qualification_dimensions(construction)
    require(all(checkpoint.get(k) == value for k, value in dimensions.items()),
            "Exact qualification construction dimensions differ")
    preparation.require_manifest(CURRENT, expected=CURRENT_SHA)
    preparation.require_manifest(COPY_SOURCE, expected=COPY_SOURCE_SHA)
    require(all(sha(path) == digest for path, digest in before.items()), "Input bytes changed")
    with output.open("x", encoding="utf-8") as handle:
        json.dump(construction, handle, ensure_ascii=False, indent=2)
        handle.write("\n")


if __name__ == "__main__":
    main()
