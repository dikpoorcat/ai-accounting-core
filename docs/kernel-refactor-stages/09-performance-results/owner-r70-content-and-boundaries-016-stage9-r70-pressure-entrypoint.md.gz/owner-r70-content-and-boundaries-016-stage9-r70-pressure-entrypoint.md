# r70压力样本承接入口准备（只读）

本次只stat、读报告/合同/脚本和许可大小内checkpoint，计算文件SHA及合同SQL字符串比较；没有运行测试、timing、数据库SQL、服务、构库或constructor。下面是待实现/待执行准备，不是当前压力验收通过。

## 原样本已保存事实

root：`.tmp/stage9-release-stress-12`。公司名“阶段九合成规模企业”，company_id=`a28ca844c09e4c20b0088e44bfb873dd`，taxpayer_id=`91310000123456789S`，database_id=`38284843c52a4934960b9b1e533545c7`。与普通main公司具有相同税号/名称但不同公司及库身份，不能复用main的硬编码identity。

| 文件 | 状态／来源 | 本次文件SHA256 |
| --- | --- | --- |
| stage9-release-stress-12-verified-r19.json（9071B） | complete；source=stage9-build-source-r19-release；当时integrity verified，四coverage全verified，limitations=[] | 2e4e789c0577113d5f8df4092d866439ef2fa36c4a4454b722aff99046bd96f3 |
| stage9-release-stress-12-build-r16.json（8423B） | built_not_verified；source=stage9-build-source-r16-release；构造deferred_historical_verification，后续完整核验必需 | 4f45bd8dc599b41d9eff378b5680bc7dc929182bde47510c9497423294400298 |
| stage9-release-stress-12/stage9-builder.json | 94,535,433B，约90.2MiB，小于100MiB，已读取 | c231c4ae2e370fc054a8bb1d81382fbd19efd1789fb2b78b347c87b9515f7be7 |

两报告均200员工、monthly_business_count=5000、business_count=60000、requested_months=12、mixed_cumulative。每月2016-01至2016-12恰好5000业务，前11月closed=true，末月closed=false；全部snapshots有owner_confirmation和preview_digest。Checkpoint employees_count=200、businesses=5000、business_subjects=60000、month_stats/snapshots各12、epochs=[1,1618,276,230,60058,0]；company、month_stats和snapshots与r19报告精确相同。本次不读取巨大saved输入/结果用于任何重算。

r19完整核验counts为facts151629、calculations61517、vouchers61413、closes11、evidence85。这是r19当时记录，不认证当前r70。r19报告尚无verified_open_preview，不能直接喂当前browser门禁；旧default_page_limit=100即使保留，也不能当当前20条首屏口径。

## 固定源码与合同来源

| 固定源码 | source-manifest声明source SHA | 本次manifest文件SHA |
| --- | --- | --- |
| stage9-build-source-r16-release | 3c78dcc2008fb88d97cb06d9e0e301f9321f4dcdbe061beaa79b4c849503cbf6 | 659588f5d8d7b4125f19c9b607804836d7f007dbede95a472e51dd1ecb1632da |
| stage9-build-source-r19-release | a98b8399f719df9ca8e76bf7db3516caba403b4696ff113b2d3a2f27951c9da8 | 93bc8c15ca8a606ce2d0a3bcb529c2023a0a63bda58b9d85d93eabcc63801a9a |
| stage9-build-source-owner-r70-release | 402024802800938685bfb59983e6d717ae32fa55c555bad0a3ced3f3d8a8e404 | e41c270d929a371fa2f4afad6a301ae012dea3a7174a39e46b14824c7f297398 |

以上读取manifest并hash其文件，不代表本次逐文件重新验证整份source inventory。实际constructor仍须现有_require_snapshot核完整清单。

r16/r19 company指纹相同：`c16b169268f62d31e58d74596af1bc80658488364830ffd615497cac220f5ec7`，文件SHA `4cd0a8b735bd36981d5006501c8b2220d7add6bddd42f36003516de445c421a7`。三源catalog指纹同为 `b484d315272bb64de3856b458f04d2d4881da05db7552250864260916c69a4ee`，文件SHA `ca7ea76f47f9339ca168acdc28f780fb9e8412fb4ce3a683de508072b19d3971`。

Content必须按真实source区分：r16=`ceba2091a600f2549a12bec8a81310581745d2ca65bc2469a81d224649e898cd`（file SHA a858ac4917405b975ea6b1964273203f79e2ce657d2563f6437f775c3deffeda）；r19=`b32facb8a88cbd6068ec7f29308ab751b12ae3d5e328425a001249144cb8bd76`（file SHA 3d7db0d2f453e72bd13af4832f4c72eeb77642b4cea7c36bfc3ec97557dbeea1）。使用complete r19作为承接来源时不能拿r16 content或build状态替代。

r70 target company=`c9f9f7051bca67f1241ee5c89676fb9476bc819dc8f92c1a0c0bd1e940f459cb`（file SHA b729080164e04dc9ddb3eaf80ba2d6a8a7fbed410dbabc9f4360cc35b005f3b7），content=`ac6d042b8478d87add37376fab5e5c9b4ae99b6ccab89c1e2f52678b779fe5f8`（file SHA 1a1d5463795777f1df82421400adedada9d8e56e6a547388e9a9b3f57ed896f9）。隔离released1不等于仓库正式freeze。

## 与r49已知delta的关系

仅比较包内company合同objects的SQL字符串：r19→r70新增恰好两cover index、fact_managed_reserve_internal_movement/schema_draft_history两表及其6个trigger；无删除。变化只有fact_pass_through、fact_payment和fact_seal_shape。两表变更精确为beneficiary_id/counterparty_id的TEXT NOT NULL→TEXT；seal精确追加managed_reserve_internal_movement分支。两cover index SQL也与r49 COVER_INDEXES相等。属于r49 `_require_delta(...,pre_cover=True)`支持的同一种已知合同形态，不需扩充ADDED/CHANGED或放松未知变化拒绝。

这是静态合同一致性，不证明原SQLite实际保存的SQL／数据完整性或迁移成功。实际constructor还必须_require_actual、verify_schema及逐表rowid/bytes摘要，未知SQL拒绝，不能只补指纹。

## 最少专用包装调整

现有r49不会接收压力样本：CASES没有stage9-release-stress-12；COMPANIES['main']绑定普通main identity；_source_guard:244–278硬编码1000／50、每月1000及总月份×1000；_target_name从target_stem和NEW_TREE轮次形成精确目标，_paths核目标/源report/source名全部匹配。仅修改NEW_TREE/SHA不够。

另建压力专属wrapper，保留r49原件，不改生产模块：

1. NEW_TREE/NEW_SNAPSHOT绑定固定r70；NEW_COMPANY/NEW_CONTENT/CATALOG继续使用当前相同指纹。CASES只含stage9-release-stress-12一个精确case：kind=main、months=12、status=complete、pre_cover=True、source_tree=r19、source_snapshot/content/report/reportSHA/checkpointSHA绑定本页原值。禁止从report自动猜CASE。
2. COMPANIES['main']只在此专属模块实例绑定压力identity和stage9-builder.json。自定义case.target_stem=`stage9-owner-stress12`，现有_target_name产生`stage9-owner-stress12-r70`，目标和.staging必须都不存在。RESUMABLE_STAGING空集合，不接续未知失败staging。
3. 替换压力版_source_guard，只将上述维度硬值改为200／5000／60000；保留身份、路径、report/source/status、四coverage/limitations、12月闭开、全部原owner_confirmation/preview_digest、epochs和报告/checkpointSHA全部严格检查。不要把kind改为stress导致现有if-main/else走独立分布，也不要全局放宽普通main维度。
4. 不改_copy_rows/_attest_copy/_require_delta/_require_content_proof。业务原表、rowid、冻结manifest/历史采用与依赖原样复制；只生成目标合同元数据和相同identity，新增两表为空。原根和原报告不写。目标路径改到新root时仅checkpoint.company.path调整，原epochs/snapshots及所有冻结历史保持原文含义。
5. 当前目标bundle注册的完整checker必须核sources/historical_adoption/projections/read_indexes、counts与实际逐表复制数量，真实open preview单独产生verified_open_preview。核验/preview前后源和目标数据摘要不变，目标注册及staging发布在成功后完成。保留失败staging/诊断，不覆盖重跑。旧r19verified不能替代目标r70checker。

包装器尚未实现/运行。待其准备和独立核对完成后，调用形状为：

```powershell
& ./.tmp-kernel-venv/Scripts/python.exe -X utf8 .tmp/stage9-rebase-stress-r70.py --workspace . --source-root .tmp/stage9-release-stress-12 --target-root .tmp/stage9-owner-stress12-r70 --source .tmp/stage9-build-source-r19-release --target-source .tmp/stage9-build-source-owner-r70-release --source-report .tmp/stage9-release-stress-12-verified-r19.json
```

上例stage9-rebase-stress-r70.py当前不存在，不能现在执行。constructor成功已做current full verify/preview时直接保存其当前source报告，不为了名字再跑同一verify一次。只有确需独立验证或构造没有完成该证明时使用主benchmark --read-existing --verify-only、--months12 --employees200 --businesses5000，输出另选全新stage9-文件。

后续browser采用当前source complete且verified_open_preview完整报告，default20、release静态；200/5000会标pressure_diagnostic，不能改label冒充主规模candidate。最终阶段验收如何评价压力分布按已批准范围记录，不把旧r19或本次准备写成r70压力通过。
