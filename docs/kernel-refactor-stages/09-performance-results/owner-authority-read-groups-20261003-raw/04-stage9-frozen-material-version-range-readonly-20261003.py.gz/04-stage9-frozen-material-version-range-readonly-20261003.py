"""Physical version-reference statistics for the explicitly allowed synthetic main48."""
import hashlib
import json
import sqlite3
from pathlib import Path

from ai_accounting.kernel.schema_bundle import production_bundle
from ai_accounting.kernel.versions import database_format

repo = Path(__file__).resolve().parent.parent
report_path = repo / ".tmp/stage9-owner-current-consumption-main48-20261003-qualified.json"
book = json.loads(report_path.read_text(encoding="utf-8"))
root = (repo / ".tmp/stage9-draft-fixture-main48-20261003").resolve(strict=True)
company_path = (root / "91310000123456789S/company.sqlite").resolve(strict=True)
assert Path(book["root"]).resolve(strict=True) == root
assert Path(book["company"]["path"]).resolve(strict=True) == company_path
assert book["company"]["name"] == "阶段九合成规模企业"
assert book["status"] == "complete" and book["requested_months"] == 48
assert book["monthly_business_count"] == 1000 and book["business_count"] == 48000
assert len(book["months"]) == len(book["snapshots"]) == 48
assert book["integrity"]["status"] == "verified" and book["integrity"]["limitations"] == []
assert all(value == "verified" for value in book["integrity"]["coverage"].values())
periods = [month["period"] for month in book["months"]]
assert len(set(periods)) == 48 and set(periods) == set(book["snapshots"])
for index, month in enumerate(book["months"]):
    snapshot = book["snapshots"][month["period"]]
    assert month["business_count"] == 1000
    assert month["closed"] is (index < 47)
    assert snapshot["closed"] is month["closed"]
    assert snapshot["preview_digest"] and snapshot["owner_confirmation"]
with (root / "stage9-builder.json").open("rb") as handle:
    checkpoint_sha = hashlib.file_digest(handle, "sha256").hexdigest()
assert checkpoint_sha == book["checkpoint_sha256"] == book["qualification"]["checkpoint_sha256"]
expected_identity = {
    "company_id": book["company"]["id"],
    "taxpayer_id": book["company"]["taxpayer_id"],
    "database_id": book["company"]["database_id"],
}
expected_state = book["verified_open_preview"]["state"]
fields = {
    "source_versions": ("material_source_v2", "fact_material_source_v2"),
    "allocation_versions": ("material_period_allocation", "fact_material_period_allocation"),
    "resolution_versions": ("material_resolution_v2", "fact_material_resolution_v2"),
    "group_versions": ("material_group_resolution", "fact_material_group_resolution"),
}
result = {"report": str(report_path), "company_path": str(company_path),
          "checkpoint_sha256": checkpoint_sha, "timing_performed": False}
connection = sqlite3.connect(company_path.as_uri() + "?mode=ro", uri=True)
connection.row_factory = sqlite3.Row
try:
    connection.execute("PRAGMA query_only=ON")
    connection.execute("BEGIN")

    def guard():
        assert dict(connection.execute(
            "SELECT company_id,taxpayer_id,database_id FROM identity WHERE id=1"
        ).fetchone()) == expected_identity
        assert list(connection.execute("SELECT * FROM state WHERE id=1").fetchone()) == expected_state

    guard()
    installed = database_format(connection, bundle=production_bundle())
    assert installed == book["integrity_contract"]
    result["guards"] = {"identity_matches": True, "state_matches": True,
                        "schema": installed, "book_months": 48, "closed_months": 47}
    close_periods = [row[0] for row in connection.execute("SELECT period FROM period_close ORDER BY period")]
    expected_periods = [(int(value[:4]) - 1) * 12 + int(value[5:]) - 1 for value in periods[:-1]]
    assert close_periods == expected_periods
    by_period = {period: {field: set() for field in fields} for period in close_periods}
    selected_fields = ["material_coverage." + field for field in fields]
    physical_blocks = 0
    for row in connection.execute(
        "SELECT period,field,content,digest FROM close_storage_block "
        "WHERE field IN (SELECT value FROM json_each(?)) ORDER BY period,field,bucket,part",
        (json.dumps(selected_fields),),
    ):
        content = row["content"]
        assert hashlib.sha256(content.encode()).digest() == bytes(row["digest"])
        entries = json.loads(content)
        field = row["field"].split(".", 1)[1]
        for position, ident in entries:
            assert type(position) is int and type(ident) is str
            assert ident not in by_period[row["period"]][field]
            by_period[row["period"]][field].add(ident)
        physical_blocks += 1
    union = {field: set() for field in fields}
    summed = {field: 0 for field in fields}
    previous = {field: set() for field in fields}
    monthly = []
    for period in close_periods:
        row = {"period": f"{period // 12 + 1:04d}-{period % 12 + 1:02d}", "versions": {}}
        for field, identifiers in by_period[period].items():
            row["versions"][field] = {"count": len(identifiers),
                                      "repeated_prior_union": len(identifiers & union[field]),
                                      "new_to_union": len(identifiers - union[field]),
                                      "removed_from_previous": len(previous[field] - identifiers)}
            union[field].update(identifiers)
            summed[field] += len(identifiers)
            previous[field] = identifiers
        monthly.append(row)
    result["physical_blocks"] = physical_blocks
    result["physical_block_hashes_match"] = True
    result["monthly"] = monthly
    result["totals"] = {
        field: {"all_month_references": summed[field], "union_revisions": len(union[field]),
                "repeat_references": summed[field] - len(union[field]),
                "repeat_share": (summed[field] - len(union[field])) / summed[field] if summed[field] else 0}
        for field in fields
    }
    plans = {}
    for field, (kind, table) in fields.items():
        identifiers = sorted(by_period[close_periods[-1]][field])
        if kind == "material_source_v2":
            sql = ("SELECT f.subject_id,ids.value FROM json_each(?) ids "
                   "CROSS JOIN fact_revision f ON f.id=ids.value "
                   "CROSS JOIN fact_seal seal ON seal.fact_id=f.id "
                   "CROSS JOIN subject s ON s.id=f.subject_id AND s.kind=? "
                   f"CROSS JOIN {table} t ON t.revision_id=f.id")
        else:
            sql = (f"SELECT t.source_id,ids.value FROM json_each(?) ids CROSS JOIN {table} t "
                   "ON t.revision_id=ids.value CROSS JOIN fact_revision f ON f.id=t.revision_id "
                   "CROSS JOIN fact_seal seal ON seal.fact_id=f.id "
                   "CROSS JOIN subject s ON s.id=f.subject_id AND s.kind=?")
        plans[field] = {"candidate_count": len(identifiers), "sql": sql,
                        "plan": [tuple(row) for row in connection.execute(
                            "EXPLAIN QUERY PLAN " + sql, (json.dumps(identifiers), kind)
                        )]}
    result["exact_query_plans"] = plans
    guard()
finally:
    connection.rollback()
    connection.close()
output = repo / ".tmp/stage9-frozen-material-version-range-readonly-20261003.json"
output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps({"guards": result["guards"], "physical_blocks": physical_blocks,
                  "totals": result["totals"], "output": str(output)}, ensure_ascii=False))
