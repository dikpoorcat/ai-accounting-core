# 第 9 阶段：报表普通汇总的镜像引用消费补查

2026-10-03；只读当前代码、已有148d profile JSON、既有工作量scope及损坏测试。未执行新的SQLite查询、测试、profile、资格、构建或真实服务操作；未改生产代码。使用 GPT-6.1 Sol 高推理。行号指当前工作区。

## 决定

这组没有发现 settlement._read_root 那种“认证 immutable root 后仍遍历完全不消费的派生 refs 镜像”。`report_flow.read_report_flow` 已不读取 cumulative readiness/close_reference 分类目录；其4932分类引用对应实际 fact_revision/header 与 typed voucher binding，影响普通读的损坏拒绝或选择变化回退，不能按镜像删除。`stored_month`实际是 `report_projection._party_balance_nets_uncached` 内部函数，不在report_flow模块；底层 `_stored_month` 的额外 source/party/checkpoint 集合共同参与不可变report root哈希，也不是完全不消费的镜像。

没有本轮新的可直接实施删除点。后续如要复用跨月相同classification实际header成功证明，需要先证明ID并集/重叠及字段检查完全一致；4932次数本身不能证明重复，已有成功月flow缓存也已经避免23次调用全部重读。这只是进一步分析前提，未建议此轮引入新缓存或token。

## 最小决定表

| 普通读取位置 | 实际权威来源 / 消费目录或字段 | 可移走、必须保留及失败行为 |
| --- | --- | --- |
| `report_flow.py:310–344` flow认证 | immutable close header与report、report_semantics、report_flow三个derived roots；stored content字符串重新算_root并匹配bound | 保留三个root、content全字节与close_digest绑定。flow行是可维修表示，不能以其自root_digest单独信任。缺行/根或内容变化为content_integrity_failed。没有额外镜像refs。 |
| `report_flow.py:346–387` exact classification refs | authenticated content中的完整命名 `(revision ID,digest)`、source_vouchers；实际 `fact_revision.id/digest/period`、`subject.kind`、`fact_report_classification.voucher_version_id` | 保留实际源header及typed绑定检查。missing ID/kind/typed为content_integrity_failed，实际digest不同为content_integrity_failed，仍存在但不再属于本月/所选voucher则None回到详细路径。移掉会吞digest损坏、missingtyped、选择变化，不等同移动close_reference镜像认证。原累计 `_classification_refs` 的close_reference分支不在普通flow读调用，已排除。 |
| `report_projection.py:950–964` 内部stored_month | engine普通页路径优先read_report_flow；缓存report_party_month后用于年末checkpoint和本年party增量 | 保留checkpoint_usable、checkpoint_rows、party_usable、party_rows及flow选择失败回退。`reports.py:1247`再取同年flow会命中同owned snapshot cache；不能按调用总数推断全部重读。engine=None独立 `_stored_month` 路径不获得普通flow信任。 |
| `report_projection.py:533–631` `_stored_month` | report_line_source全17字段、party增量、checkpoint/input roots共同进入_report_root:312；source、party、checkpoint seals检查各自数量/摘要；immutable header的report derived root最终认证全部 | source_rows虽在旧v1/party消费者不返回，仍是计算不可变root的必要输入；current语义还直接消费source_rows。不能只删源行读取后仍声称认证同root。年末checkpoint与非年末必须不存在checkpoint均须保留。 |
| `_stored_month→_seal:228–256` | 当前实际calculation_publication在冻结posting month及原highwater内的id/sequence/mode/calculation_id，和所读source rows共同校验source_seal | 这是实际publication范围，不是close_reference派生镜像。source_seal digest没有作为独立字段进入_report_root，但这次检查能揭示实际publication/header改变；删除将缩小ordinary读拒绝范围。没有本轮证据或明确业务决定支持删去。不可把“不用于最终余额”当作“不用于证明”。 |
| `report_semantics.py:430–477` | immutable语义root，所有selected semantic row与semantic seal；已认证report source_rows；_check_source_keys精确比对 `(version_id,line_no)` 及calculation/fact/result digest | 保留semantic整集合及source identity集合，漏/额外/错source均拒绝。底层 `_stored_month` 读取party/checkpoint虽语义消费者不显示，但它们共同构成report root；现合同没有单独source subroot可供无读认证。已有owned snapshot的source_rows复用，不能以mutable source_seal自digest替代report root。 |
| `report_classification_directory.py:291–340,507–550` | immutable report_classifications bound root，完整root字节和filter数量；root node counters；requested voucher keys的authenticated trie路径、精确membership、全局conflict与unsafe及conflict memberships | 无全tree普通遍历。root node counters用于确保metadata/exception范围一致。全局conflict/unsafe即使不直接显示当前行，也阻断错误报表/保留issue顺序。_exceptional_entries:481先消费node flags再决定是否继续，没有边上独立子树flags可无读跳过。此轮clean样本exception traversal已有profile仅约0.015ms，非候选。 |

## 实际调用边界

五页中 `Dashboard.quarterly_report:2309–2377` 直接在一个 QueryReads.snapshot 调Reports._report：opened `_issues_only=True` 仍完整生成三表；只有quarter-end已关才再算closed plan。报表 `reports.py:1211` 的年初/期末party_balance位置调用 `_party_balance_position_lines→_party_balance_nets→stored_month`，`1247`读本年完整flow，`764`选择当前/冻结分类，`1402`只对未采用clean frozen flow的月份读完整semantic。正常clean flow免读其详细历史body，不能再删实际header约束。

当前简报 `dashboard.py:1887` 调 `_brief_amounts:2567`，该路径不直接使用report_flow/semantic/classification目录。`dashboard._position:2607` 的旧精确party帮助函数存在分类目录和party_balance fallback调用，但静态src搜索未找到生产调用该函数，不能把其潜在读成本算作当前简报实际链。资金、员工、资产页没有调用本组三个普通report读取器；它们各自的settlement等证明不在本组。五页共同的read context也不因此获得或省掉报表full核验。

MCP `mcp.py:38` 通过 finance_local_command→service.dispatch；`service.py:777–780` 的report、preview_report_export、confirm_report_export映射Reports同入口。普通MCP报表完整plan还消费report_fact_ids/source_closes/digest，不能删除完整reference名单。`reports.py:1852–1878` export准备在自己的snapshot算source=closed完整报表，确认时仍按完整plan/epoch/维修revision检查。`run_report_jobs:2717` 消费已冻结job plan，核身份/digest/template并生成文件，不再次调用普通flow/semantic/目录读；因此本组修改不会自动减少export worker源读取。

close preview / full位于 `integrity.py:1392–1439,1716–1751`：分别从实际source和logical close重建report_projection、report_semantics、report_flow、classification_directory expected；既有verified archive/paired report proofs仅复用本次实际核验结果。它们不会用read_report_flow接受维修行代替源重建。classification full `553–658`每月精确root与最终所有actual节点payload/set比较保留；此前范围组的expanded-subtree改动已经减少相同已完整展开子树，不是移掉ordinary分类源。

新close writer `periods.py:750–759` 正常prepare report/semantics/flow/directory，`786–811` bind immutable roots并persist，不能借普通页面proof接受未准备源。年末 `_prepare_checkpoint:641–694` 必须消费前year checkpoint root与每月party增量；current `_stored_month`里看似不用source的读取仍用于同一report root认证。

维修 `maintenance.py:46–100` 来源先核、report→semantics→flow→directory独立expected重建、写后再核。`repair_classification_directory`依expected flow恢复实际节点/root集合；不以repairableflow或node存量推导采用。backup `_verify_connection:149–185` 经schema bundle对应verifier进入full；source snapshot、复制目标、restore目标各独立连接/字节。不能因普通flow删mirror保持通过，就减少这些完整源/索引再核。

fixed v1分派在 `content_history_context.py:135–164`，独立report_projection_v1、report_semantics_v1、report_flow_v1、classification_directory_v1。`report_flow_v1.py`没有read_report_flow普通汇总读函数，只有独立content重建和compare/require；不能把current普通读修改推广其full规则。v1 `_stored_month:298–398`仍读所有source用于report root，虽返回值不含source_rows；v1 read_report_semantics:451独立verify_report_lines再严格_decode，不继承current semantic/source rows证明。v1 directory `_read_root:277`和scope:470有同型exact-key与exception证明，未发现mirror refs，也未改历史模块。

## 已有损坏测试对决定的约束

本轮只阅读，没有执行：

- `test_report_flow.py:295` missing repairable close_reference不改变已bound flow，而full为read_index_integrity_failed；这是当前正确分界，普通flow已无该镜像依赖。
- `test_report_flow.py:266` frozen actual fact digest损坏必须为content_integrity_failed，不能变None；`:493` missing typed classification同时拒绝flow和party。`:422,474` old flow root/used或unused分类digest损坏拒绝。这些要求恰由flow实际header/typed query保持。
- `test_report_flow.py:174` wrong derived flow必须拒绝并能从source维修；`:202` ordinaryflow不再使用cumulative classification selector；`:397`没有flow覆盖的old unused分类走完整selection。
- `test_report_semantics.py:252–277` semantic row损坏/缺seal拒绝并显式维修；`:364`即使rooted cash line选择变化也不漏frozen source；`:394`同snapshot源月复用成功、独立snapshot须再核。
- `test_report_classification_directory.py:211` bound filter损坏page及full拒绝；`:234`rooted/full payload一致；`:413`多个conflict保留header issue顺序；`:477`实际消费sameyearbody时损坏拒绝；`:498`未读取old body可继续rooted flow，而full实际content必须拒绝。该明确分层不授权吞actual header缺失或digest改变。
- `test_report_projection.py:182–224` 年末精确payable与损坏checkpoint拒绝；`:228`十年party读仅latest checkpoint+tail；`:309`成功月仅owned snapshot复用。

## 既有诊断的正确使用与未测项

已有148d工作量scope记录flow23 calls、12个真实body、4932references、约63ms，后11次已有缓存；其引用次数不是未消费mirror，更不是已证明union重复。高分辨率已有 `.tmp/stage9-owner-brief-reports-profile-148d-hires-20261003.json` 中 quarterly_report 的read_report_flow23 calls cumulative64.6294ms/self10.6044ms，stored_month13 calls67.0132ms；两者嵌套不能相加。classification_directory_scope2 calls24.1073ms，_read_root1 call0.8325ms，_exceptional_entries2 calls0.0147ms。profile有观测开销，不是pure 500ms验收。

本轮没有新SQL计数、source ID overlap统计、AB、损坏测试、资格或内存测量。实际classification refs还可能在不同月因source_voucher重复出现，但未证明本148d4932的union范围；也未证明current普通月份内已validated scalar header缓存与flow header证明字段完全可替代。不能据此硬称同类收益，更不能复用r24全QueryReads、跨requestcache、自digest信任或关闭源核验。本组建议维持现状，不与已批准settlement未消费refs修复打包删除。
