"""Exact owned synthetic root/ref counts and query plans; no page, full verify or timing."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sqlite3
import sys

WORKSPACE = Path(__file__).resolve().parents[1]
SOURCE = WORKSPACE / '.tmp/stage9-build-source-owner-current-consumption-20261003'
ROOT = WORKSPACE / '.tmp/stage9-draft-fixture-main48-20261003'
QUALIFIED = WORKSPACE / '.tmp/stage9-owner-current-consumption-main48-20261003-qualified.json'
BOOK = WORKSPACE / '.tmp/stage9-owner-main48-draft-period-group-construction-input.json'
PRIOR = WORKSPACE / '.tmp/stage9-owner-brief-reports-profile-148d-hires-20261003.json'
PREFIX = WORKSPACE / '.tmp/stage9-owner-settlement-root-ref-counts-148d-20261003'
SOURCE_SHA = '148d6fffc9aacd1857b6837401bd6138eb4ba3ff7193277f97c40229e27d9760'
QUALIFIED_SHA = '6a582a04ed0b03036fd26b63ace4b6e2f7d8614aef39fabe5058677c8fd46aea'
MANIFEST_SHA = '95444b11b4655fc3c0224e8a66a8f1d432e8b572527b2ea674c11f8988277a20'
BOOK_SHA = 'a73ded22688073e7aecb7a79d56a6e31d9d6be202e1083738b091d42d3671d93'
CHECKPOINT_SHA = 'f00aa0cf0a631a961707a6f74345cbdb5f53db2ff90ad60f8c594d03ca7cefbb'
IDENTITY = {'company_id': 'c73e4f4d144340c98ade475b8dd8c8b9',
            'database_id': '6cc5f6cbe6cd402ebdfd072195398780',
            'taxpayer_id': '91310000123456789S'}
STATE = [1, 2065, 1164, 152, 48238, 0]
QUERY = ('SELECT r.ordinal,r.first_key,r.last_key,r.row_count,r.block_digest,'
         'b.digest FROM settlement_freeze_ref r '
         'LEFT JOIN settlement_freeze_block b ON b.digest=r.block_digest '
         'WHERE r.period=? AND r.kind=? ORDER BY r.ordinal')

def require(value, message):
    if not value:
        raise ValueError(message)

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def main():
    require(Path(sys.prefix).resolve() == WORKSPACE / '.tmp-kernel-venv', 'Use repo venv')
    output = PREFIX.with_suffix('.json')
    require(not output.exists(), 'Preserve first diagnostic')
    gate_path = PREFIX.with_suffix('.gate.json')
    expected_gate = {
        'status': 'settlement_root_ref_counts_readonly_authorized',
        'source_sha256': SOURCE_SHA, 'root': str(ROOT),
        'qualification_sha256': QUALIFIED_SHA, 'source_manifest_sha256': MANIFEST_SHA,
        'checkpoint_sha256': CHECKPOINT_SHA, 'construction_input_sha256': BOOK_SHA,
        'identity': IDENTITY, 'state': STATE, 'repair_revision': 0,
        'script_sha256': sha(__file__), 'output_prefix': str(PREFIX),
        'scope': 'one_exact_authenticated_root_headers_and_ref_counts_and_exact_explain_only',
        'native_page_calls': 0, 'profile_calls': 0, 'full_integrity_calls': 0,
    }
    require(json.loads(gate_path.read_text(encoding='utf-8')) == expected_gate, 'Gate mismatch')
    gate_sha = sha(gate_path)
    qualified = json.loads(QUALIFIED.read_text(encoding='utf-8'))
    manifest_path = SOURCE / 'source-manifest.json'
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    prior = json.loads(PRIOR.read_text(encoding='utf-8'))
    require(prior['status'] == 'complete' and prior['source_sha256'] == SOURCE_SHA, 'Prior source mismatch')
    require(Path(qualified['root']).resolve() == ROOT and Path(qualified['source']).resolve() == SOURCE
            and qualified['requested_months'] == 48, 'Wrong qualified root')
    company = qualified['company']
    require(company['id'] == IDENTITY['company_id'] and company['database_id'] == IDENTITY['database_id']
            and company['taxpayer_id'] == IDENTITY['taxpayer_id'], 'Qualified identity mismatch')
    db = ROOT / IDENTITY['taxpayer_id'] / 'company.sqlite'
    require(Path(company['path']).resolve() == db, 'Wrong DB path')
    require(manifest['status'] == 'complete' and manifest['sha256'] == SOURCE_SHA
            and Path(manifest['target']).resolve() == SOURCE, 'Wrong source manifest')
    sys.path.insert(0, str(SOURCE / 'scripts'))
    import stage9_source
    stage9_source.require_source_module(stage9_source, SOURCE, 'scripts/stage9_source.py')
    stage9_source.configure_source(SOURCE, WORKSPACE)
    import snapshot_stage9_source
    from ai_accounting.kernel import close_storage, schema_bundle
    from ai_accounting.kernel.read_state import repair_revision
    from ai_accounting.kernel.types import YearMonth
    from ai_accounting.kernel.versions import database_format
    for module in (close_storage, schema_bundle):
        stage9_source.require_source_module(module, SOURCE, f'src/ai_accounting/kernel/{module.__name__.rsplit(".", 1)[-1]}.py')
    def check_files():
        inventory = snapshot_stage9_source._inventory(SOURCE)
        require(inventory == manifest['files'] and snapshot_stage9_source._digest(inventory) == SOURCE_SHA,
                'Source inventory drift')
        require(sha(QUALIFIED) == QUALIFIED_SHA and sha(manifest_path) == MANIFEST_SHA
                and sha(BOOK) == BOOK_SHA and sha(ROOT / 'stage9-builder.json') == CHECKPOINT_SHA
                and sha(gate_path) == gate_sha, 'Evidence drift')
    check_files()
    bundle = schema_bundle.production_bundle()
    def check_state(connection):
        state = list(connection.execute('SELECT * FROM state WHERE id=1').fetchone())
        identity = dict(connection.execute('SELECT company_id,database_id,taxpayer_id FROM identity WHERE id=1').fetchone())
        require(state == STATE and identity == IDENTITY, 'State/identity drift')
        result = {'state': state, 'identity': identity, 'repair_revision': repair_revision(connection),
                  'format': database_format(connection, bundle=bundle)}
        require(result == prior['after'] and result['format'] == qualified['integrity_contract']
                and result['repair_revision'] == 0, 'Prior format/repair drift')
        return result
    report = {'status': 'started', 'diagnostic_only': True, 'performance_acceptance': False,
              'gate': expected_gate, 'gate_sha256': gate_sha, 'query': QUERY}
    try:
        with sqlite3.connect(db.as_uri() + '?mode=ro', uri=True) as connection:
            connection.row_factory = sqlite3.Row
            connection.execute('PRAGMA query_only=ON')
            require(connection.execute('PRAGMA query_only').fetchone()[0] == 1, 'Readonly guard')
            connection.execute('BEGIN')
            report['before'] = check_state(connection)
            cutoff = YearMonth(qualified['verified_open_preview']['period']).ordinal
            base = connection.execute('SELECT max(period) FROM period_close WHERE period<=?', (cutoff,)).fetchone()[0]
            latest = connection.execute('SELECT max(period) FROM period_close').fetchone()[0]
            require(base == latest and base is not None, 'Unexpected two-root scope')
            close = connection.execute('SELECT period,manifest,digest FROM period_close WHERE period=?', (base,)).fetchone()
            header = close_storage.verified_header(connection, close)
            expected = close_storage.derived_root(header, 'settlement')
            stored = connection.execute('SELECT close_digest,root_json,root_digest FROM settlement_freeze_root WHERE period=?', (base,)).fetchone()
            require(expected is not None and stored is not None and bytes(stored['close_digest']) == bytes(close['digest'])
                    and bytes(stored['root_digest']) == expected
                    and hashlib.sha256(stored['root_json'].encode('utf-8')).digest() == expected, 'Root anchor mismatch')
            root = json.loads(stored['root_json'])
            require(root['format'] == 'settlement-freeze/2' and root['period'] == base
                    and root['close_digest'] == bytes(close['digest']).hex(), 'Root identity mismatch')
            report['root'] = {'period': base, 'month': str(YearMonth.from_ordinal(base)),
                              'cutoff': cutoff, 'latest_close': latest,
                              'root_digest': expected.hex(), 'raw_utf8_bytes': len(stored['root_json'].encode('utf-8')),
                              'groups': len(root['groups'])}
            report['directories'] = {kind: {'header_count': len(directory),
                                           'member_count': sum(item[3] for item in directory)}
                                     for kind, directory in root['directories'].items()}
            report['subject_directory'] = {'header_count': len(root['subject_directory']),
                                           'subject_count': sum(item[3] for item in root['subject_directory'])}
            report['actual_refs'] = [dict(row) for row in connection.execute(
                'SELECT kind,count(*) reference_count,sum(row_count) member_count FROM settlement_freeze_ref '
                'WHERE period=? GROUP BY kind ORDER BY kind', (base,))]
            report['explain'] = {kind: [list(row) for row in connection.execute('EXPLAIN QUERY PLAN ' + QUERY, (base, kind))]
                                 for kind in ('all', 'open')}
            report['after'] = check_state(connection)
            require(report['before'] == report['after'], 'Snapshot drift')
            connection.rollback()
            connection.execute('BEGIN')
            report['after_fresh_snapshot'] = check_state(connection)
            require(report['before'] == report['after_fresh_snapshot'], 'Fresh snapshot drift')
        check_files()
        report['status'] = 'complete'
    except BaseException as error:
        report.update(status='failed', error_type=type(error).__name__, error=str(error))
        raise
    finally:
        with output.open('x', encoding='utf-8') as stream:
            json.dump(report, stream, ensure_ascii=False, indent=2)
            stream.write('\n')
    print(json.dumps({'status': report['status'], 'root': report['root'],
                      'directories': report['directories'], 'subject_directory': report['subject_directory'],
                      'actual_refs': report['actual_refs'], 'explain': report['explain']}))

if __name__ == '__main__':
    main()
