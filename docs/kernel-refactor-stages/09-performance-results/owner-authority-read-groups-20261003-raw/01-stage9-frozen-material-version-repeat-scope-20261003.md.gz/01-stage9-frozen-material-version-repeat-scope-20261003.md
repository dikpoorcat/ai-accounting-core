# 第 9 阶段：累计资料版本的窄匹配证明重复

2026-10-03。本轮先只读代码与已有py-spy结果，随后按主代理明确授权，只访问现有 `.tmp/stage9-draft-fixture-main48-20261003/91310000123456789S/company.sqlite` 做物理资料版本ID计数及exact SQL EXPLAIN。之后依主代理批准实施 current 的窄 typed-version 成功匹配 ledger，仅修改 frozen_material.py、close_storage.py、integrity.py 与独立 test_frozen_material_version_ledger.py。首轮定向24项全部通过，尚未执行本新组统一受影响回归；此前176项是前组结果，不能继承作新组通过。没有真实库/服务、前端、构建、新profile或资格运行，没有操作旧main120/checkpoint。统计脚本与输出分别为 `.tmp/stage9-frozen-material-version-range-readonly-20261003.py/.json`。

## 证据与诊断边界

已有 `.tmp/stage9-owned-main120-synchronous-profile-20261003.raw` 共193个计权samples：96含 `_frozen_versions`（其中95停在非source分支 `frozen_material.py:289` 的fetchall，1在294组装）；109含 `_material_summaries`；179含decode_close；7含JSON raw_decode。路径是qualification的 `preview_close→_manifest→verify_close_integrity→decode_close→_material_summaries`。这些是一次10秒诊断窗口中的同步stack samples，不是全程序CPU占比、总耗时占比或优化幅度。另有早先stack JSON停在connect，不能把两个瞬时/短窗状态当成全运行阶段分布。旧e0e main120停止时没有资格结果，本报告不声称其通过。

统计前后在同一个 `mode=ro`、query_only、BEGIN 中核对：company/database/taxpayer身份与qualified报告一致，state为 `[1,2065,1164,152,48238,0]`；schema实际SQL、draft ancestry和包合同经database_format只做schema核验，匹配 `ai-accounting-kernel/2 / company / draft / 0 / c9f9f7051bca67f1241ee5c89676fb9476bc819dc8f92c1a0c0bd1e940f459cb`；qualified book为48月×1000业务、50员工且47closed/1open，month/snapshot集合、状态及证明字段一致；stage9-builder.json流式SHA为既有 `f00aa0cf0a631a961707a6f74345cbdb5f53db2ff90ad60f8c594d03ca7cefbb`。未解析其100MB历史业务payload。

只读取四个 `material_coverage.*_versions` 的物理close_storage_block，共26,293块；逐块payload hash与存储digest一致后，解析 `[position, revision_id]` 数ID与集合。未decode逻辑close，未重建任何资料/source proof。统计是对受guard样本中存储引用的观察，不能把存储块hash或统计副产当成已验证typed source。

| 版本种类 | 47个月引用次数总和 | 不同revision并集 | 重复引用 | 首月→末closed月 |
| --- | ---: | ---: | ---: | --- |
| source | 7,896 | 329 | 7,567 | 7→329 |
| allocation | 7,896 | 329 | 7,567 | 7→329 |
| resolution | 1,128,047 | 47,001 | 1,081,046 | 1,001→47,001 |
| group | 0 | 0 | 0 | 0→0 |

source/allocation每月新增7；resolution除首月1,001外每月新增1,000。2016-12/2017-12/2018-12/2019-11的resolution累计数为12,001/24,001/36,001/47,001。该样本四类集合全部无上月版本移除；重复引用约95.83%是引用次数份额，不是耗时份额。实际产品允许某月集合收窄或不规则变化，不能把本样本单调性写进token契约。

EXPLAIN只生成计划，没有执行version joins。current四类原exact SQL均先SCAN `json_each`候选，随后按revision-id SEARCH typed表、fact_revision、fact_seal和subject-kind索引；source使用fact_id_subject_cover及typed PK covering，resolution/allocation typed和fact采用各自PK索引。没有全业务实体扫描。`tests/kernel/test_exact_id_query_work.py` 已有增无关subject/revision后VM工作保持有界与current/v1损坏拒绝测试；那证明单次exact ID查找不受无关对象增加影响，未覆盖“每月累计同一ID重复查找”。因此这轮根因是实际候选集合跨月重叠，不是重新调表序或新增DDL索引的依据。

## 当前与固定 v1 的实际重复

current `close_storage.decode_close:1593` 重建六个逻辑section，核完整directory/block集合、logical digest和preview digest，随后用 `_material_summaries:239` 从完整proof独立重建所有source summaries。四种版本ID的分source映射经 `frozen_material._frozen_versions:310` 生成；原路径每次查询全部ID，新显式 ledger 路径仅查询该次尚未实际匹配成功的ID。

该函数每次先核list、string项和重复项；source query实际匹配fact_revision、seal、subject.kind、typed source行，返回fact.subject_id；其他种类实际匹配typed revision、fact_revision、seal、subject.kind，返回typed.source_id。查找少一行即 `frozen_material_fact_seal_missing`。它只证明此次版本身份存在、kind匹配与分source映射，不证明整个typed body、source_fact_id目标、资料覆盖内容、负责人采用或当前source未变。

完整资料集合会累计有代码依据：`materials.check_completeness_many:2044–2076` 除review月本身，还包括任何origin≤closed_through的分配来源；`3016–3026` 输出所选source/处置版本并结合已冻结版本，`3036–3040` 生成其fact_ids并集。这是历史完整覆盖职责，不能把旧ID从当前每月proof删掉。

fixed v1没有 `frozen_material_v1.py`：独立匹配是 `close_storage_v1._v1_frozen_versions:165–194`，独立 summaries 为 `197–209`，`decode_close:762/823` 重新比较。它目前同型重复SQL工作，但list/duplicate错误路径和历史合同独立；不能调用current helper/token替代其证明。本轮未读取v1样本，未测其实际重叠与耗时。

## 调用边界：可以移窄证明的位置与不能合并的操作

| 边界 | 实际decode/重复范围 | 现有proof生命周期与限制 |
| --- | --- | --- |
| 默认full | `integrity._check_closes:837–855` 每close decode一次；后续VerifiedCloseArchive供report/material/index使用，已经不是所有阶段重decode | `verify_integrity:1221–1225` include_projections且transaction时包已有verified_source_lease；可在这次多月decode输入范围内共享窄mapping |
| preview/close历史核验 | `periods._manifest:244`→verify_close_integrity；`integrity:1578/1604–1612` 已有lease下先逐closed月decode/pack，再1635起_check_closes消费predecoded，不再重复完整decode | 窄mapping必须在该初始decode loop生效，等_check_sources/source token之后再建不能解决已采样栈；scope随这次verify_close_integrity结束 |
| 新close writer | `close_storage.write_close:324` 独立从待写逻辑manifest算summaries | 不带旧proof/token；close的历史verify已经结束，writer须实际核此次输入，不把之前historicaldecode的mapping自动带进写入 |
| 维修 | `maintenance:46` 先full来源核验；`material_watch.repair:683` 等重建路径还独立decode；`maintenance:100` 再核 | 修改前/后不能共享proof；repair前include_projections=False没有当前现有lease；projections后核有lease，indexes后核无。不可将一份memo扩成整个维修写事务 |
| backup/restore | `backup._verify_connection:173` 注册verifier走相应current/v1 full；源snapshot、复制后文件、restore/upgrade前后各有自己连接/实际字节 | 可受益于每次full内部优化；不能跨备份源/目标或源/升级后继承成功map，更不能删目标再核 |
| standalone report/flow/classification/index/closed_report | 没有VerifiedCloseArchive时会decode；`Periods.closed_report:862` 是一个完整close；read-index维修 `924` 在破坏marker时独立完整decode | 原有缺proof的独立路径保留。单close本次证明大多没有跨月收益；显式优化其内部同种ID再次请求可以另测，不默认套全源cache |

普通页面不是该完整decode路径的同义词：`frozen_material.verified_frozen_material_summary:101–135` 当前优先material_watch，否则经verified_header→material_source_summaries读取所请求source的已绑定子根/buckets；`close_storage.material_source_summaries:1296–1321` 只认证窄summary。它再比较当前版本和coverage-rule/watch来源，不能因此声称已重新核所有物理stored summaries与实际typed源。完整资料资格或关账需要的 `verified_frozen_materials:498–513` 则会读完整manifest，再 `550` 核source版本，其余种类 `_changed_sources`仍检查完整current/frozen差异。它不能被简单替换为页面summary proof。

## 已实施的窄边界：本次实际匹配成功的版本ledger

current 显式私有proof位于 `frozen_material._MaterialVersionLedger:50` 与 factory `76`。full 在 `integrity:1323` 已有lease内创建并传到 `_check_closes` decode loop；preview/close 在 `_verify_close_integrity_leased:1623` 初始decode loop创建并传递。token沿 `decode_close→_material_summaries→_frozen_versions` 流动；普通调用不传，writer `close_storage:334` 始终不传。fixed v1 reader身份不匹配current模块时不创建token。没有全QueryReads、整个source dict、第24方案或跨requestcache。

ledger只保存 `(kind, typed-table, revision-id) → source-id` 的成功实际匹配；source种类的source-id从actual fact.subject_id取得，其他从actual typed.source_id取得。原 exact SQL 实际完成 revision、subject-kind、typed行、seal 匹配后，结果行数与精确ID集合全部吻合才登记；不从stored material_source_summaries、冻结count/digest、当前latest source header或统计得到条目。表/kind限于声明的四组且绑定current proof namespace，不让caller提供另一个表来冒充。

每次调用仍执行原list/string/duplicate检查，再划分本次所点名ID的已证/未证集；只对未证ID运行同一个exact SQL。完整核对所有未证ID行数/身份、seal和kind成功后才原子登记，没有negative cache，也不在partial failure时登记部分成功。之后按**本月原始ID列表**从map重建source→set，不消费旧月摘要，不要求prefix单调。旧缓存ID只是窄identity/mapping lemma成功，不意味着该月coverage、closed adoption或manifest已验证。每期仍重建全部summary、核logical/source body/directory/preview root等原证明，并与stored summary精确比较。

lease必须属于同connection、同一次private verifier scope并仍有效（`verified_source_lease:26–40/75–78`已有SAVEPOINT事务终止见证）。ledger在创建时记录 total_changes 与 schema_version，每次使用和SQL完整成功后再次核对。错连接、嵌套另一lease、退出、COMMIT/ROLLBACK后新BEGIN、同连接写入甚至rollback后的total_changes变化、DDL都拒绝。WeakSet仅记录token身份所有权、不保存业务结果；未知producer与未登记伪对象不能使用，匹配表是当次对象内私有字段。任何repair写入后或下一次verify重新创建ledger，通用lease模块未修改。嵌套v1 position临时lease不能继承current ledger。

SQL identity匹配次数可从Σ各月版本数移到本次union数；main48存储观察给currentresolution的理论候选对照是1,128,047→47,001，**未在main48重跑核验，不能当实际已证source或实测收益**。每期完整ID列表shape/duplicate检查、重新分source组装、version-set排序/hash、coverage/file summary核验和physical blocks读取仍为各期实际完整量，不能称整个资格从二次变线性。ledger增加O(union)窄映射，以及每次scope/SAVEPOINT/schema guard开销；未测RAM或资格/page时间。group为空、只有一个close、各月没有复用ID时无重复查询收益，普通窄summary页面也不直接受益。

## 首轮定向验证与剩余风险

2026-10-03 首轮运行 `test_frozen_material_version_ledger.py + test_exact_id_query_work.py`：24 passed，15.43s，失败0。首份 `.tmp/stage9-material-version-ledger-first-20261003.xml/.log` 已保留。四个归属文件 Ruff check通过。新文件真实三月 book 经正常业务API建小合成库并关账，对 full 与 close 直接核验分别以factory返回None的原 exact query路径作off对照：完整API返回精确相同；独立完整decode三份manifest得到Σ与union作为预期，实际SQL候选每边界9→3（source/allocation/resolution各3→1，group0）。JUnit properties保存按kind明细。这是查询候选工作量减少66.67%，不能称整个核验或页面快3倍。

四种kind独立小SQL夹具各测集合 `[old]→[old,new]→[new]→[old]`，增12个无关subject/revision，原查询5→ledger2，结果与独立直接读取完全一致。shape/duplicate、kind/table错配、伪dict/对象/未登记同类型对象、未知producer均拒绝；missing revision、missing typed、missing seal、wrong kind混合valid的batch失败后，valid仍重新查询，候选2+1=3证明无局部登记。wrongconnection、嵌套/退出lease、事务重启、写入/rollback写、DDL失效均通过。真实writer逐月调用均无ledger；真实合成typed resolution的source_id被改成forged后，ledger与独立decode均拒绝，不从stored source summary取得mapping。

本轮未运行本新组全受影响回归（由root集中调度），未重复前组176大套、未测main48/full qualification时间、内存或main120。existing exact-ID测试同时验证current/v1单次查询对无关历史有界与source/seal/kind损坏拒绝，但fixed v1本组未改、未优化，也无跨月ledger。维修/backup各阶段独立证明、no-lease fallback、v1调用分派仍需新组整体验证；已有material/close损坏、目录/摘要hash与维修/恢复原子失败测试须保留，不以新候选数取代业务断言。尚未加入新的大容量RAM验证或跨source多文件工作量夹具，不能推广小三月比例为实际规模收益。
