# Settlement root 目录镜像消费职责审查与窄修改

2026-10-03；GPT-6.1 Sol，高推理。仅现有合成证据、静态代码、一次严格限定只读 counts/EXPLAIN 和父任务随后授权的 current 窄实现及定向合成测试。没有第三轮 profile、真实库/服务、页面计时、preview/qualification、构建、生成规模数据或 Git 操作。

结论：普通读不需要 `settlement_freeze_ref` 完整镜像才能消费认证的 root.groups 或通过 root headers 定位选中内容。本次 current 普通 `_read_root` 移除两个 ref/block 镜像查询；全部 root 目录仍严格检查，选中叶块、revision、主体 chunks、实际采用源、开放尾部及期间 seal 检查保留。完整核验仍独立从源重建再对照全部保存内容。收益未经测量。

## 1. 根因与实测触发范围

148d hires profile 中 brief 的 `_read_root` 只有一次调用，self 76.058 ms / inclusive 90.729 ms（父任务统计）；不能称为 cache 重复，不能将全部 self 时间当成 ref 扫描或未来节省值。原读取在验证父 close、原文 SHA 和 root 格式后，对同一个累积 root 的 all/open 目录逐 ref 做 LEFT JOIN block.digest，完整建立 actual 列表并比较镜像。它不扫描全部 close periods，但该 root 已累积过往月份的目录。

独立只读补证绑定既有 main48 148d immutable source：2019-11 是 as_of 2019-12 的 base 和 latest close。root 原文 679,013 B、2,914 groups。all 1,154 headers / 35,203 members；open 304 / 8,272；subject 803 / 23,406。实际 all/open refs 数及成员数一致，共 1,458 refs。EXPLAIN 原查询已走 ref `(period,kind)` 主键索引及 block.digest covering index；多余的是全镜像消费范围，不是缺索引。

原查询只查 `b.digest` 是否存在，没有验证未命中 block 的 payload 或任何 state 原文。因此它原来就不等于完整历史完整性核验。既有 nonhit state 故障测试已经明确普通有限页可以成功而 full 必须拒绝。

证据：`stage9-owner-settlement-root-ref-counts-148d-20261003.py/.gate.json/.json/.log`。脚本 SHA `b712a1b3f1dfb7475994c36eea63495581b0e7c3f2878402bea7821b168f5f3e`。gate 精确约束 source `148d6fffc9aacd1857b6837401bd6138eb4ba3ff7193277f97c40229e27d9760`、qualified SHA `6a582a04ed0b03036fd26b63ace4b6e2f7d8614aef39fabe5058677c8fd46aea`、manifest/book/checkpoint SHA、company/database/taxpayer、state `[1,2065,1164,152,48238,0]`、repair 0、draft 0 完整格式。使用 repo venv、sqlite mode=ro/query_only；0 native page、0 profile、0 full 调用。执行成功，前后及新快照状态完全相同；source inventory 与所有绑定文件摘要不变。只读取一个 root、两类 count 和 EXPLAIN；没有遍历 ref payload 或实际执行原 1,458 行 query 作计时。

## 2. authority → writer → ordinary duties

`close_storage.write_close` 在同一关账事务内将 prepared settlement root digest 写入私有 close root 的 `derived_roots[settlement]`，canonical close 原文 SHA 存入独立 `close_storage_root`。`verified_header` 验证 close 原文 storage SHA、逻辑 digest/marker、实际 company/database 身份、父 root 类型和格式。`derived_root` 从该已验证父 root 取 settlement 摘要。`_read_root` 继续要求 `root.close_digest == period_close.digest`、保存 root_digest 等于父值、整个 root_json UTF-8 SHA 等于父值，再完整 parse 和检查身份、目录结构。这是父摘要绑定完整 root 字节，不是把 settlement 行自报 root_digest 当 authority。

真实 writer 的 `_build_prepared` 从经 `verify_settlement_periods` 检查的 actual settlement_change/publication/calculation 和前期认证 root/选中叶状态确定构造 all/open/subject headers、精确 groups/period amounts/change-period counts，canonical 编码后计算整个 root 摘要；`persist_freeze_projection` 验证新 close 采用该 prepared root，再从同一 root_json.directories 直接生成 ref。ref 不参与根摘要和金额计算，也不是正式输入。修复从源重新构造相同原文和镜像，不用普通 read 的 saved directories 作为重建输入。

保留架构 §1.1 及同账户文件控制的既有边界：父和全部原始源被一致伪造不在这里新增防御承诺。此变更不把 self-digest、ref locator 或派生 state当成独立来源；不删 types/shape/unique/member/amount/unknown/反向证明，不新增跨 request cache。

## 3. 逐消费方范围

| 入口 | 实际消费 / 本次影响 |
| --- | --- |
| brief `_open_items` | 历史/当前两个 scope 的 groups 聚合，分页通过 root all/open headers 选块；当前实际 tail 完整检查。scope/root 缓存已经限定同 snapshot，本次不新增缓存。summary_only 仍按原算法检查 cursor/page headers，但不 hydrate 非显示 state。 |
| employees | `frozen_employee_net_summary`/主体 summary 使用认证 groups、period_amounts、subject directory、命中 source/direct chunks 和选中 all headers/state；source/publication/身份核验保留。fallback 的无主体完整 SQL reducer原样。 |
| assets | 选中 acquisition/source subjects 的付款 summary 经 `frozen_subject_summary`；不从 ref 定位。资产 summary_only 无选中卡则不请求该付款主体 scope。必要 acquisition/activation 身份源不变。 |
| funds | 本页资金主体读取没有直接调用 settlement freeze ref/root；本组不能承诺资金页收益。 |
| quarterly reports | deferred 报表主体使用独立 report flow/contribution/source proof，不因本组优化 1,004 contribution；complete preparation 可走 BusinessQueries 的 settlement followup summary，属于同一 scope 职责。 |
| close owner review | current `_position` 经 `settlement_position_rows` 消费认证 groups；主体/按需业务查询仍核命中叶和实际来源。 |
| CLI/MCP | command_schema/service 将 dashboard、准备、完整核验等命令接至同一 kernel。BusinessQueries.settlement_summary 有 subject_ids 时走冻主体证明；无 subject_ids 仍走原完整 normalized SQL reducer，本次不缩其核验。 |
| internal frozen_root/page/key | root返回认证 headers；page/key 直接按 header digest 查 block，再按 committed state digest 查 revision，不用 ref locator。选中缺行仍失败。 |
| v1 | 独立 `settlement_freeze_v1._read_root` 原镜像扫描完全未改。普通 `position_v1` 的 frozen_position_rows 只需 groups，但本组不优化它。历史内容验证经 historical_content(1) 选择 v1 reader/registry，未混 current token/算法。 |

全仓当前 ref 引用只出现在 DDL、原 `_read_root`、persist、全量比较/repair 和故障测试定位 SQL；没有生产普通 detail/cursor/subject 查询从 ref 选出成员。主体 chunks 甚至独立存在于同一 block 表，原 all/open 镜像扫描也没有证明未命中的主体 chunk 完整。

## 4. 关账、完整核验、修复、备份与版本

正式生产 `prepare_freeze_projection` 唯一直接调用者是 `Periods.close.operation`。操作先调用 `_manifest`，该函数在同一事务中先 `verify_close_integrity`，其路径独立 `require_settlement_projection` 和 `require_frozen_settlement_projection` 全源重建并全对照历史 roots/refs/blocks/revisions；然后才计算新 prepared root。本次不在 prepare 再加第二遍全扫描，也不添加认证 token。关账前 missing ref 仍阻断事务。

另一直接调用仅为 `tests/kernel/test_t7_quarter_coverage.py:insert_closes` 的合成 envelope 构造器，未预先 full；不能宣称 prepare 函数自身完成独立完整验收。它不是正式业务写入口，仍检查前期 parent/root/选中叶，后续正式 full 的职责未改变。没有为测试辅助器暗加全扫描。

`_authoritative_freezes` 从 actual source/outcomes/publication chain 独立构造 expected roots、内存 blocks/revisions；前期 root 也来自重新构造结果，而不是 `_read_root`。`_frozen_difference` 比较全部保存 roots 原文/摘要、全部 ref 元组、全部 block payload、全部 revision key/payload。本次只将原 ref set 比较提取成职责明确 `_directory_references_differ`，比较内容与顺序未减。full 和 close 两条调用保留独立 source proof 与 source verified lease 精确归属检查。

repair 的前置 authority-only 检查、独立 frozen 重建、全差异对照、原子修复和后置核验/repair_revision 保留。备份/恢复/前向调整的 source/target `_verify_connection` 仍使用按 format 注册的 company verifier → verify_integrity → 全部冻结比较；v1 注册自己的 registry/reader。没有改 integrity、close_storage、维修、备份或 fixed-v1 代码。

## 5. 最窄实现及损坏检测变化

只改 current `settlement_freeze.py` 和 `tests/kernel/test_settlement_freeze.py`：普通 `_read_root` 不读镜像；subject/all/open 复用严格 `_validate_directory`（完整 list 元素、5字段、连续非 bool integer ordinal、字符串范围、正非 bool integer count、64位小写 hex digest、严格不重叠）；明确 directories 为 dict，避免原 all/open 弱类型路径的 IndexError。所有既有 raw parent/root SHA 和后续金额/来源检查保留。没有格式、DDL、业务输出、公开参数或 cache 修改。

ordinary 的损坏检测有明确变化：任意未消费 ref 的缺失、额外、ordinal/range/count/digest 错误，以及仅由未消费 ref 指向的缺失 block，不再单独阻断普通请求；完整核验/关账/备份仍必须拒绝并允许合规派生修复。即使恰好与选中 root header 对应的 ref 被删，普通读仍以父认证 header 定位，完整业务来源不缺。命中 block/revision/chunk 缺失或原文变更、root原文/父摘要变更、主体 source-membership/事件反向关系错误、开放 tail 贡献缺失/期间 seal不符仍拒绝。未消费 block payload 损坏或非命中 revision 原本就主要由 full 发现，职责未削弱为“成功读即全库完好”。

## 6. 实际定向验证和限制

首次 `.tmp/stage9-settlement-root-ref-duty-first-20261003.log/.xml`：39 passed、1 failed、9 deselected，32.25 s。唯一失败为新增关账故障测试传空 epochs，Engine._write 在 full 前先拒绝 preview_expired；生产实现无需修正。测试改为实际 store.epochs 后，仅复跑该1项：`.tmp/stage9-settlement-root-ref-duty-repair-first-20261003.log/.xml`，1 passed，8.95 s。两个归属文件小 Ruff 通过。

共40个定向用例通过（分两份保留证据）：current 普通/历史/当前业务与独立原 normalized reducer一致；缺失及额外100条 ref普通仍返回精确原业务、actual SQL trace完全同量且无ref查询，仍查选中 block/revision；full拒绝并repair恢复；实际 close事务在准备前拒绝缺失ref；选中 block/revision、主体 chunk、修改 publication、删除 source contribution拒绝；30个 all/open/subject malformed header 边界返回 KernelError而非 IndexError；既有 v1 source-independent full测试通过。v1 ordinary ref损坏测试未新增或运行，v1源码未变；本轮不是完整回归，相关 full/close/repair/backup/v1/copy统一范围由父任务收口。

没有移除、重试或替换必要 query_reads current source proof；没有重试 compiled validator、partial own-line、shared QueryReads、GC或未变化浏览器组。没有性能收益/500ms达标结论；当前 148d 的150成功7超线是原固定源验收事实，本组需后续固定 source 后按父任务统一真实预览/测量才可评估收益。
