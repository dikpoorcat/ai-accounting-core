# r74 必要金额读取只读审计

本轮是 r73 固定源码的诊断，不是 r74 代码候选或 500ms 验收。没有修改生产、字段、DDL、历史合同；没有运行浏览器、pytest、完整核验、服务、构造或备份。模型为 GPT-6.1 Sol / high。

## 证据与限制

- 固定 source `.tmp/stage9-build-source-owner-r73-release`，manifest SHA `420ceb395fc5aec17ddaedf8914c7fc8de640da9f08cb35aded8a3a99a4eb7f4`。本轮读取的 10 个公共内核文件逐字节等于 repo，并匹配固定 manifest 的文件 SHA。
- 主 48 来源 `.tmp/stage9-owner-main48-r73-verified.json`，完整 sources / historical_adoption / projections / read_indexes 已 verified、limitations 空；本轮没有重跑该核验。只打开该报告绑定的合成 company.sqlite，URI `mode=ro`、`query_only=ON`、BEGIN，结束 rollback/close。
- 已有 `.tmp/stage9-resident-r73-main48-profile.json` 及 brief/funds/reports `.prof` 是 instrumented/native 诊断，不是 HTTP 浏览器验收。其 profile 的 `current_source_full_integrity=not_run` 不能冒充新核验；此次另核上面的 r73 完整报告。
- `.tmp/stage9-r73-request-scope-sequential-diagnostic-attempt2.json` 实际 root 是 **main12**；不能把该 12.8ms 授权结论当成 main48 分阶段实测。网络/前端请求重复问题本轮没有重新测量。
- 原始只读 SQL 结果在同名 `.json/.log`，执行器在 `.py`。命令：`.tmp-kernel-venv/Scripts/python.exe -X utf8 .tmp/stage9-r74-required-money-audit.py`。返回行字节是 SQLite 值的计量，VM 按 100 步向下量化；没有记录 SQL 耗时。

## 实际主要成本与必要范围

1. **brief 全月金额不是误扫资金科目。** `dashboard.py:2499 _brief_amounts -> dashboard_reads.py:1233 Journal.account_amounts` 消费全月 1005 凭证，核整个 line 集合，再与 monthly_account 精确比较，并保留未映射科目的非零金额风险。profile account_amounts 246.72ms（含子调用），自身 28.46ms；verify_selected_content 该调用 74.37ms，完整 JSON _object 总 1009 次/33.29ms，_lines 1006 次/33.34ms。work 全页结果加载 1016、解码 1015，约 995KB，包含 off-page 必要来源，不能把这些全算成重复解码。当前已有结果与 line 缓存被 activity_classification、funds 共用，没有发现同 1005 body 再做完整 Python decode 的证据。
2. **资金汇总已经先定位命中科目。** `FundsRead.events -> journal.select(accounts=...).sql -> _account_voucher_ids` 当月先以 voucher_period 定位、voucher_line_account(account,version_id) 做 EXISTS，之后 `_verify_event_sources/verify_selected_content` 只认证实际选择的 basis 和期初等独立来源。现场 locator 504 个物理候选、22600VM；此前“541”是旧版本线索，r73 该当月物理候选应以 504 为准，全资金页加载/解码 542 含 state/其他来源。不能把全页 542 当作一个 542 个凭证集合。没有发现先全月 bodyproof 再按资金科目过滤。
3. **开放 forward proof 确实是全页共同的必要独立范围。** Journal._sql:1042、reports._report:1089 / report_projection._authoritative_rows:123 都在缩小 voucher/body 之前核开放 terminal publication；同时从实际 physical open voucher 反向检查 publication/current/source，防止删除头或修改月份被空候选掩盖。main48 2019-12，maxclose=2019-11，1006 terminal（984 initial /21 open_replace /1 review_no_impact）。这不能缩到 money accounts 或本页 20 条。
4. **报表没有重复 1004 个完整来源 decode 的证据。** reports 全页 1007 结果加载、仅 3 个结果 JSON decode；1004 个 open contribution decode /3,059,132B，read_open_contributions 108.27ms，_verify_anchored_source_bytes 44.03ms，_party_delta 216.48ms。现有 private anchor 严核 source/fact bytes、seal、精确 binding，保留普通 bodyproof 与 byteproof 的区别；两次 contribution 调用第二次可按 exact ID 命中，同 1004 个 body 不再次解析。完整三表、unknown/mapping 与 line/party 范围不能裁到 RECLASS。4932 分类 refs 的 12 次 SQL /187600VM /784188B 沿用此前 unique 范围判断；本轮没有重新证明它们的 ID 交集，也没有改 aggregateauthority 或 decoder。
5. context 只有 4SQL/96 行/850B/11000VM，没有金额核验。default/detail/分页请求各自需要独立 owned snapshot：不能跨 HTTP 请求借前一页成功结果。owner preparation、close-review 真正消费资料、工资/采用来源/闭期审核时与 brief 的窄金额职责不同，不能据 brief 的摘要字段把完整审核删掉。

## 已证实的同类重复搬运

`query_reads.py:262 verify_open_voucher_scope -> :140 verify_current_publication_voucher_heads -> :88 verify_current_voucher_publications -> :406 _verify_current_voucher_publication_rows` 首次成功路径仍有连续物理 lookup。成功 scope/relation 缓存已经阻止后续同 owned scope 的完整重做；本问题在**第一次批次内部**。

|实际 SQL职责|main48精确范围|VM|返回行|值字节|
|---|---:|---:|---:|---:|
|terminal p.* + current c/f/subject|1006 terminal|57600|1006|429624|
|再次 json_each(pubIDs) LEFT p/h/v|同1006 IDs|33200|1006|388724|
|再次 json_each(versionIDs) LEFT v/c/h|已有 profile 五页1005版本|34200|1005|320548|
|再取 calculation_current|已有 profile 五页1004 subject|8000|1004|84726|
|再取 original/current p.* + successor|已有 profile 五页1005 calculation|23100–23200|1005|204675|

本轮现场普通 normal head 只有 1004；五页 profile 的 ID lookup 1005 包含一个 correction reverse，不能用 normal 批次冒充 reverse 的完整证明。现场 diagnostic normal-ID lookup 1004/34100VM/320112B 与 normal forward 的 actual version 集合完全相等；whole-month selector 1005 与 normal 集合不等是合法冲正，已保留此 negative equality 原始输出。

**实际可合并的第一块：**只在 terminal 查询加精确 LEFT h/v aliases，原 posting 范围、NOT EXISTS successor、source/current/fact身份完全保持，诊断得到 1006 行/656978B/77700VM，物理 h/v 字段对原独立查询完全相等。两条原 SQL 合计 2012行/818348B/90800VM；可省 1006行/161370B/13100VM。计划仍为 publication_posting exact-month seek + 所有 PK lookup；不存在隐藏的全历史扫描。这里只核物理字段等价，没有执行合并后的完整证明，也没有推算 native 净收益。

后面 normal ID/header lookup 也是已有实际物理头再搬一次，不是删掉必要检查的理由。复用范围须涵盖 normal physical calculation 的**真实 subject**，不能把 terminal p.subject 直接填进 signature；review 所持旧 calculation 的 subject 仍须独立绑定。不可仅因字段相似就免 original/head/successor 关系核验。

## 推荐一组公共修改，待根授权

优先改首次开放 scope 的物理头传递，范围 `query_reads.py` 的 scope/head/current relation 内部公共路径与专属行为/work测试；不改 dashboard 各页字段、不改 source proof、事实/正文 decoder、DDL 或固定合同。

- 从实际 terminal SQL 携带 h/v 和必要 immutable voucher-calculation subject；LEFT JOIN 保留缺 head/version/source，原 terminal 元数据核验、publication digest、withdrawn、反向完整 physical-open 检查不变。
- 在这个受控实际 SQL 分支调用内部 head verifier；普通 public `verify_current_publication_voucher_heads(connection, publications)`、unowned/direct/core 来源继续独立 lookup，不能接受调用方任选 alias 就当物理证明。
- 把确实成功的 normal physical rows 接现有 signature/original-current 关系检查，省去其 ID→version 第二次读取；review 旧原版与 reverse 继续由确切独立来源定位。normal/current/original publication 相同的记录可消费真实 terminal 行与已认证 current ID，但 ancestor/review/reverse 的 original pub 仍需精确读取/核验。须先做实际 exact ID 分区，不许把一整个月 cache 当本批关系成功。
- whole-batch 成功之后才发布既有 owned cache；失败撤回本批新摘要证明，旧成功保留；只限当前 reader、同 connection、in_transaction、active owned snapshot。只用已有缓存，不新增跨请求根/flag/cache；不将 header proof 提升成 body/adoption proof。
- 前两块可直接按真实 work 核少搬多少行/字节/VM。最后 current/original map 合并在尚未证明复杂分支等价前，不承诺全部 8000+23100VM 都能省；复杂度高可先保留它。

## 另一个真实重复解析候选，先保留

`dashboard_funds.py:336 events /415 movements /462 account_summary` 在 brief 已有全月 decoded outcome、verified_rows、voucher_lines 后，`_verified_current_event_rows` 已复用相关 header/line，`verify_sql_outcomes` 已复用成功内容 proof；但随后 SQL 仍 JOIN calculation 读取同一 basis 的 outcome，json_each($.balances)、json_extract(values.actual_date) 再处理。brief 的汇总 SQL 245500VM/2行，funds 的 summary+page SQL261400VM/21行；它们只有小输出，成本来自实际 JSON/selection/window/分组，不能把这些 VM 全说成重复 JSON 成本。

具体适合的窄职责是 **FundsRead.movements 的 current money events**，而不是替换通用 events。现有 `investment_source` / `investment_events` 还消费完整 values.settlements、fund_id、members、confirmation_date/cost；不能把它们一起换成只有余额/日期的投影。

可在 `_verify_event_sources` 和原 exact选择/adoption/reference检查成功后，仅从实际同 reads 的 `_verified_source_contents` 点取本批 basis IDs；这些内容已经由 brief account_amounts 或 funds 自己的 source证明完整解码。保留现有 selected rows/lines/subject/accounts筛选，构造每个 actual event 的 `period,event_id,number,calculation_id,kind,sign,opening,balances,actual_date` 窄输入，接原 money/window/transfer/group/page SQL。直接数据来自受控读对象，不给 public API 增加 verified flag，不转用 report contribution anchor冒充 body。

最窄首入口应要求 `_verified_current_event_rows` 实际返回完整 headers（brief前置account_amounts已经留下），且每个 exact basis ID已有完整decoded内容。**普通资金页目前没有 account_amounts 所留下的完整 verified_rows**，只因542个decoded内容存在仍不足以构造event_id/number/period/sign关系；该页先保持原支路。若今后要同时优化普通funds，可把其现有 sources locator返回扩为exact physical headers，但那会新增搬运，必须另做净work比较，不能假定白得。不要给另一个snapshot传headers或以缺字段自行拼接物理身份。

为保持原 SQL 语义，窄入口只接受已经 decoded 的普通 shape：balances是list、effect是dict、category/key是str、amount是严格非bool int且int64，values是dict、actual_date为str/None，数组原次序完整保留；任何非普通 shape **继续原 JSON SQL分支**，不能丢行或新增默认值。仍以原分类/账户过滤、effect_index及money local_index维持cursor顺序；sign/反转、SQLite sum/window、所有合法bank/cash/platform内部转款与kind门禁不变，不能按20条页码截金额。独立期初、unknown、states零账户、资金关闭余额和 period_balance proof 全部保持当前account_summary路径。current=False、unowned、fixed reader、缺完整decoded ID时仍原支路；混合情况可全批fallback，不能把一部分来源无声遗漏。

这个分支有实际重复body SQL证据，但本轮没有测净收益，不先实施。后续若授权诊断应记录窄输入构造/序列化成本、实际VM/bytes/decodes与summary+page逐字段等价，再决定；不以245500VM全部当可省JSON工作量。严格duplicate/noncanonical结果仍由原完整source证明承担，投影不改变正文语义或自造新的成功证明。没有足够证据支持新的 money authority 框架、从 report contribution 转接 Journal bodyproof 或全库机械替换 dict(row)。

根补充的 same-service paired 实测：native brief464.9/399.2/407.0ms，正常dispatch/http_json427.5/446.7/455.2ms，公共+46SQL、median额外39.64ms；RSS约284MB稳定。browser-after-preview RSS约900MB、briefmedian636.6ms，剩余约190ms未归因。首次guard省13100VM不能推达标，也不能把长服务RSS或GC扫描当已证实根因；本agent没有测GC、生命周期或preview对象保留。

## 全局调用与处理决定

|调用范围|当前职责及决定|
|---|---|
|五页 Journal / assets / employee / funds / reports|均可受首次 scope 公共物理传递收益；各页 scopes/body范围保持。资产3universes/47close目录/20card 已由根审过，本轮不重开。|
|core accounting `_current_accounting_heads` business_queries:875/917|精确 open publication 前向核验；无受控 terminal scope物理行时保持独立 lookup。不得因五页 owned 优化免除 scoped core 保护。|
|Reports/report projection direct `_authoritative_rows` 及季度/closed|通过 current guard。readonlyowned可用同护栏受益；closed采用仍独立 frozen source，不把 frozen月份当 open。17字段source tuple不变。|
|CLI/MCP|cli/mcp → LocalService._dispatch/service:759–766 → 同 Dashboard/Reports/CloseReview 实现，不另造 page特判；普通direct未owned仍独立路径。|
|owner preparation / close-review|完整资料来源为真实消费；close_review:477 reads.verify_selected_content 和精确 fact/依赖仍保留。没有本轮 workload 的重复结论。|
|关账 / publication before-write|periods._manifest、prepare_report_projection、verify_prepared_sources/verify_sources 承担完整来源、历史和原子发布；写事务不能套只读 owned 证明。|
|full integrity|integrity._check_sources:503–516，decode/chain/lines之后独立 forward + correction source proof；profile reports额外4次调用实际来自被请求事实的完整 source核验（约12.85ms合计），不是 `_authoritative_rows` 开放 scope调用了5次。保持独立。|
|repair|maintenance:46源完整核验且include_projections=False/indexes=False，然后repair、再verify_integrity；不可把 ordinary page头证明当维修authority。|
|backup|backup._verify_connection及便携 snapshot/content完整校验；未测其work，不因相似代码改。|
|fixed v1|current verify_open_voucher_scope 明确skip fixedreader；integrity分派publication_v1.verify_open_voucher_heads及verify_open_correction_heads。current优化不接fixed模型；fixed独立读/编码/历史核验继续。|

没有发现新的必要金额漏核缺陷；确认的是首次公共 guard 内部物理头重复搬运，及 brief 已核 body 仍被资金 SQL处理的真实候选。其余未量化部分明确未验证，不能归成“所有汇总问题已排除”。

## 后续最小验证建议（本轮未运行）

若授权首次 guard 整类修复，先以 `test_open_publication_snapshot_work.py` 的真实 actual work 和 `test_report_selector_header_reuse.py` 同范围测试证明初次少行/字节/VM、后次命中，不依 mock调用次数。强负例覆盖缺source/fact/pub/current、原版pub/subject/period/voucher改变、successor、normal/review、合法清零、withdrawn、未来、sourceperiod move、闭期连续更正及reverse版+head同时删除；失败batch不cache、旧成功不被清空。采用 `test_open_correction_publication_heads.py` 与 `test_publication_periods.py` 的对应分支，fixed隔离用 `test_v1_stored_json_isolation.py`，unowned保持独立。收敛后根集中跑受影响组，旧289组不机械全部再跑。最终仍需统一固定源码五页native/browser实测，不能从本次VM减少直接宣称500ms通过。
