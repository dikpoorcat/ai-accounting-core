"""Exclusive receipts for only the authorized small public-head test groups."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]
assert Path(sys.executable).resolve() == root / '.tmp-kernel-venv/Scripts/python.exe'
assert sys.argv[1] in ('early', 'related', 'negative')
prefix = root / ('.tmp/stage9-r74-open-head-' + sys.argv[1])
paths = {suffix: prefix.with_suffix('.' + suffix) for suffix in ('log', 'xml', 'json', 'command.txt')}
assert not any(p.exists() for p in paths.values())
new_test = 'tests/kernel/test_open_scope_physical_heads.py'
selection = ([new_test + '::test_normal_scope_reduces_actual_rows_bytes_and_vm_without_body_proof',
              new_test + '::test_posted_money_equals_independent_scope_for_legal_publications[initial]']
             if sys.argv[1] == 'early' else [
                 new_test + '::test_missing_publication_failure_repeats_actual_scope_work'
             ] if sys.argv[1] == 'negative' else [
                 new_test,
                 'tests/kernel/test_open_publication_snapshot_work.py',
                 'tests/kernel/test_report_selector_header_reuse.py',
             ])
command = [sys.executable, '-X', 'utf8', '-m', 'pytest', '-q', *selection,
           '--junitxml=' + str(paths['xml']), '--basetemp=' + str(prefix) + '-fixtures']
tracked = ('src/ai_accounting/kernel/query_reads.py', new_test)
def hashes():
    return {p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in tracked}
before = hashes()
paths['command.txt'].write_text(subprocess.list2cmdline(command) + '\n', encoding='utf-8')
with paths['log'].open('x', encoding='utf-8') as output:
    outcome = subprocess.run(command, cwd=root, stdout=output, stderr=subprocess.STDOUT)
result = {'command': command, 'exit_code': outcome.returncode, 'files_before': before,
          'files_after': hashes(), 'scope': 'isolated_synthetic_targeted_tests_not_performance_acceptance'}
if paths['xml'].exists():
    suites = list(ET.parse(paths['xml']).getroot().iter('testsuite'))
    result['xml_counts'] = {k: sum(int(s.get(k, 0)) for s in suites)
                            for k in ('tests', 'failures', 'errors', 'skipped')}
    result['xml_seconds'] = sum(float(s.get('time', 0)) for s in suites)
with paths['json'].open('x', encoding='utf-8') as output:
    json.dump(result, output, ensure_ascii=False, indent=2)
print(json.dumps(result, ensure_ascii=False), flush=True)
print(paths['log'].read_text(encoding='utf-8'), flush=True)
raise SystemExit(outcome.returncode)
