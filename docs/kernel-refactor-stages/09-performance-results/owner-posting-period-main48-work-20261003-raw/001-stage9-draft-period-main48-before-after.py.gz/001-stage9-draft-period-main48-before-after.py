"""Pinned, read-only instrumented diagnostic; this is never browser acceptance timing."""

from __future__ import annotations

import ast
import hashlib
import json
import time
import sys
from contextlib import contextmanager
from pathlib import Path

WORKSPACE = Path(__file__).resolve().parents[1]
SOURCE = WORKSPACE / ".tmp/stage9-build-source-owner-draft-period-group-20261003"
MANIFEST = SOURCE / "source-manifest.json"
import argparse

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--months', type=int, choices=(48,), required=True)
parser.add_argument('--book-report', type=Path, required=True)
parser.add_argument('--report-sha256', required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--qualification-report', type=Path)
parser.add_argument('--qualification-sha256')
parser.add_argument('--native-gate', type=Path, help='Root-issued exclusive native authorization; absent means work-only')
args = parser.parse_args()
BOOK_REPORT = args.book_report.resolve(strict=True)
OUTPUT = args.output.resolve()
assert BOOK_REPORT.is_relative_to(WORKSPACE / '.tmp')
assert OUTPUT.is_relative_to(WORKSPACE / '.tmp') and not OUTPUT.exists()
SOURCE_SHA256 = '22ef17f6aa6b40025eaf9fe939a209f15f7d4c73605e982925859fe42a1cfff3'
REPORT_SHA256 = 'a73ded22688073e7aecb7a79d56a6e31d9d6be202e1083738b091d42d3671d93'
assert args.report_sha256 == REPORT_SHA256, "Only this pinned draft construction input is permitted"
assert BOOK_REPORT == (WORKSPACE / '.tmp/stage9-owner-main48-draft-period-group-construction-input.json').resolve()
assert OUTPUT.name.startswith('stage9-draft-period-main48-')


def file_hash(path):
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def main():
    require(
        Path(sys.prefix).resolve() == (WORKSPACE / ".tmp-kernel-venv").resolve(),
        "Use the repository virtual environment",
    )
    require(not OUTPUT.exists(), "Diagnostic output must not exist")
    manifest_hash = file_hash(MANIFEST)
    require(file_hash(BOOK_REPORT) == REPORT_SHA256, "Pinned verified report bytes changed")
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    require(
        manifest["status"] == "complete"
        and manifest["sha256"] == SOURCE_SHA256
        and Path(manifest["target"]).resolve() == SOURCE.resolve(),
        "Wrong source manifest",
    )

    # Bootstrap only from the fixed candidate, before importing any accounting module.
    sys.path.insert(0, str(SOURCE / "scripts"))
    import stage9_source

    stage9_source.require_source_module(stage9_source, SOURCE, "scripts/stage9_source.py")
    stage9_source.configure_source(SOURCE, WORKSPACE)
    import benchmark_stage9_browser
    import snapshot_stage9_source
    import stage9_metrics

    from ai_accounting.kernel import catalog as catalog_module
    from ai_accounting.kernel import dashboard as dashboard_module
    from ai_accounting.kernel import engine as engine_module
    from ai_accounting.kernel import resident_reads, schema_bundle
    from ai_accounting.kernel.types import canonical
    from ai_accounting.kernel.versions import database_format

    for module, relative in (
        (snapshot_stage9_source, "scripts/snapshot_stage9_source.py"),
        (benchmark_stage9_browser, "scripts/benchmark_stage9_browser.py"),
        (stage9_metrics, "tests/kernel/stage9_metrics.py"),
        (catalog_module, "src/ai_accounting/kernel/catalog.py"),
        (dashboard_module, "src/ai_accounting/kernel/dashboard.py"),
        (engine_module, "src/ai_accounting/kernel/engine.py"),
        (resident_reads, "src/ai_accounting/kernel/resident_reads.py"),
        (schema_bundle, "src/ai_accounting/kernel/schema_bundle.py"),
    ):
        stage9_source.require_source_module(module, SOURCE, relative)

    def check_source():
        inventory = snapshot_stage9_source._inventory(SOURCE)
        require(
            inventory == manifest["files"]
            and snapshot_stage9_source._digest(inventory) == SOURCE_SHA256,
            "Fixed source bytes drifted",
        )
        require(
            file_hash(MANIFEST) == manifest_hash and file_hash(BOOK_REPORT) == REPORT_SHA256,
            "Pinned attestations drifted",
        )

    check_source()
    book = json.loads(BOOK_REPORT.read_text(encoding="utf-8"))
    OLD_SOURCE = WORKSPACE / '.tmp/stage9-build-source-owner-draft-read-group-20261003'
    old_manifest_path = OLD_SOURCE / 'source-manifest.json'
    old_manifest_hash = file_hash(old_manifest_path)
    old_manifest = json.loads(old_manifest_path.read_text(encoding='utf-8'))
    require(old_manifest['sha256'] == 'd198eab959be1d3a1237744778b3329bbe4f01379d7917541bc4e017f31cf045'
            and old_manifest['status'] == 'complete'
            and Path(old_manifest['target']).resolve() == OLD_SOURCE, 'Wrong old sealed source')
    contract_prefix = 'src/ai_accounting/kernel/schema_contracts/'
    current_contracts = {k: v for k, v in manifest['files'].items() if k.startswith(contract_prefix)}
    old_contracts = {k: v for k, v in old_manifest['files'].items() if k.startswith(contract_prefix)}
    require(current_contracts and current_contracts == old_contracts, 'Contracts differ')
    period = book['period']
    require(book['status'] == 'copied_content_unverified' and book['content_verified'] is False,
            'Construction input must not be relabelled qualification')
    require(book['requested_months'] == 48 and book['employee_count'] == 50
            and book['monthly_business_count'] == 1000
            and book['distribution'] == 'mixed_cumulative', 'Wrong sample dimensions')
    root = stage9_source.synthetic_path(Path(book['root']), WORKSPACE)
    require(root == WORKSPACE / '.tmp/stage9-draft-fixture-main48-20261003', 'Wrong draft root')
    company = book['company']
    require(company['id'] == 'c73e4f4d144340c98ade475b8dd8c8b9'
            and company['database_id'] == '6cc5f6cbe6cd402ebdfd072195398780'
            and company['taxpayer_id'] == '91310000123456789S'
            and company['name'] == '阶段九合成规模企业'
            and Path(company['path']).resolve() == root / company['taxpayer_id'] / 'company.sqlite',
            'Wrong synthetic business identity')
    checkpoint_path = root / 'stage9-builder.json'
    checkpoint_hash = file_hash(checkpoint_path)
    checkpoint = json.loads(checkpoint_path.read_text(encoding='utf-8'))
    dimensions = benchmark_stage9_browser.qualification_dimensions(book)
    require(checkpoint['company'] == company and checkpoint['snapshots'] == book['snapshots']
            and all(checkpoint.get(key) == value for key, value in dimensions.items())
            and len(checkpoint.get('business_subjects', [])) == 48000
            and len(checkpoint.get('epochs', [])) == 6
            and all(type(value) is int for value in checkpoint['epochs']),
            'Checkpoint mismatch')
    expected_state = checkpoint['epochs']
    qualification = None
    qualification_hash = None
    if args.qualification_report is not None:
        require(args.qualification_sha256 is not None, 'Qualification SHA required')
        qualification_path = args.qualification_report.resolve(strict=True)
        require(qualification_path.parent == WORKSPACE / '.tmp', 'Qualification must be synthetic')
        qualification_hash = file_hash(qualification_path)
        require(qualification_hash == args.qualification_sha256, 'Qualification bytes changed')
        qualified = json.loads(qualification_path.read_text(encoding='utf-8'))
        benchmark_stage9_browser.require_report_source(qualified, SOURCE)
        require(benchmark_stage9_browser.validate_book_report(
            qualified, company_name=company['name']) == period, 'Qualification period mismatch')
        require(qualified['company'] == company and Path(qualified['root']).resolve() == root
                and qualified['verified_open_preview']['state'] == expected_state
                and qualified['qualification']['checkpoint_sha256'] == checkpoint_hash,
                'Qualification does not bind current sample')
        qualification = {'path': str(qualification_path), 'sha256': qualification_hash}
        del qualified
    expected_identity = {
        "company_id": company["id"],
        "database_id": company["database_id"],
        "taxpayer_id": company["taxpayer_id"],
    }
    integrity_contract = book["copy_provenance"]["target_company_format"]
    del checkpoint, book
    require(
        (root / "catalog.sqlite").is_file() and Path(company["path"]).is_file(),
        "Existing databases are required",
    )

    class ReadOnlyCatalog(catalog_module.Catalog):
        @contextmanager
        def connection(self, *, read_only=False, _cross_thread=False):
            require(read_only, "Diagnostic forbids catalog writes")
            with super().connection(read_only=True, _cross_thread=_cross_thread) as connection:
                yield connection

        def recover_operations(self):
            # Never resume pending publications during a read diagnostic.
            with self.connection(read_only=True) as connection:
                count = connection.execute(
                    "SELECT count(*) FROM company_operation WHERE status!='succeeded'"
                ).fetchone()[0]
            require(
                count == 0, "Catalog has unfinished operations; diagnostic will not recover them"
            )

    bundle = schema_bundle.production_bundle()
    require(bundle.status == 'draft' and dict(bundle.current_versions) == {'company': 0, 'catalog': 0}, 'Actual factory must be draft0')
    catalog = ReadOnlyCatalog(root, bundle)
    require(
        catalog.database_format()["status"] == "draft"
        and catalog.database_format()["version"] == 0,
        "Wrong catalog contract",
    )
    companies = catalog.companies()
    require(
        [row for row in companies if row["id"] == company["id"]] == [company],
        "Catalog company identity changed",
    )
    with catalog.connection(read_only=True) as connection:
        catalog_identity = dict(connection.execute("SELECT * FROM catalog_identity").fetchone())

    pool = resident_reads.ResidentReadPool(maximum=4)
    store = catalog.bind(company["id"], read_pool=pool)
    original_connection = store.connection

    @contextmanager
    def read_only_connection(*, read_only=False):
        require(read_only, "Diagnostic forbids company writes")
        with original_connection(read_only=True) as connection:
            yield connection

    store.connection = read_only_connection
    engine = engine_module.Engine(store)
    dashboard = dashboard_module.Dashboard(
        engine, company_name=company["name"], companies=companies
    )
    year, month = map(int, period.split("-"))
    quarter = (month - 1) // 3 + 1

    def check_state():
        require(file_hash(old_manifest_path) == old_manifest_hash, "Old source manifest drifted")
        old_inventory = snapshot_stage9_source._inventory(OLD_SOURCE)
        require(old_inventory == old_manifest['files']
                and snapshot_stage9_source._digest(old_inventory) == old_manifest['sha256'],
                'Old sealed inventory drifted')
        if qualification is not None:
            require(file_hash(Path(qualification['path'])) == qualification_hash,
                    'Current qualification bytes drifted')
        for relative, digest in old_contracts.items():
            require(file_hash(OLD_SOURCE / relative) == digest, "Old qualification contracts drifted")
        with store.connection(read_only=True) as connection:
            connection.execute("BEGIN")
            state = list(connection.execute("SELECT * FROM state WHERE id=1").fetchone())
            identity = dict(
                connection.execute(
                    "SELECT company_id,taxpayer_id,database_id FROM identity WHERE id=1"
                ).fetchone()
            )
            require(
                state == expected_state and identity == expected_identity,
                "Company identity, business state or repair revision changed",
            )
            require(
                database_format(connection, bundle=bundle) == integrity_contract,
                "Company format differs from verified source",
            )
        with catalog.connection(read_only=True) as connection:
            require(
                dict(connection.execute("SELECT * FROM catalog_identity").fetchone())
                == catalog_identity,
                "Catalog identity changed",
            )
        require(catalog.companies() == companies, "Catalog registration changed")
        require(file_hash(checkpoint_path) == checkpoint_hash, "Construction checkpoint changed")
        return {"state": state, "identity": identity, "catalog_identity": catalog_identity}


    from ai_accounting.kernel import period_balances, settlement_freeze, settlement_projection

    changes = {}
    for module, name in (
        (period_balances, '_totals'), (settlement_freeze, '_tail_rows'),
        (settlement_projection, '_summary_scope'),
    ):
        relative = 'src/ai_accounting/kernel/' + Path(module.__file__).name
        stage9_source.require_source_module(module, SOURCE, relative)
        old_path, new_path = OLD_SOURCE / relative, SOURCE / relative
        old_tree = ast.parse(old_path.read_text(encoding='utf-8'))
        new_tree = ast.parse(new_path.read_text(encoding='utf-8'))
        def remaining(tree):
            return ast.dump(ast.Module(body=[node for node in tree.body
                if not (isinstance(node, ast.FunctionDef) and node.name == name)],
                type_ignores=[]), include_attributes=False)
        require(remaining(old_tree) == remaining(new_tree), relative + ': other top-level semantics differ')
        node = next(node for node in old_tree.body
                    if isinstance(node, ast.FunctionDef) and node.name == name)
        current = getattr(module, name)
        # Compile with the actual new module globals, never an old imported module.
        exec(compile(ast.fix_missing_locations(ast.Module(body=[node], type_ignores=[])),
                     str(old_path), 'exec'), vars(module))
        baseline = getattr(module, name)
        setattr(module, name, current)
        changes[relative] = {'path': str(old_path), 'sha256': file_hash(old_path),
                            'owner': module, 'pairs': [(name, baseline, current)]}

    def select(label):
        for change in changes.values():
            for name, old, current in change['pairs']:
                setattr(change['owner'], name, old if label == 'baseline' else current)
    operations = {
        'context': dashboard.context,
        'brief': lambda: dashboard.brief(period, limit=20, preparation='deferred'),
        'funds': lambda: dashboard.funds(period, limit=20, preparation='deferred', movement_account_selection='first'),
        'employees': lambda: dashboard.employees(period, limit=20, preparation='deferred'),
        'assets': lambda: dashboard.assets(period, limit=20, preparation='deferred'),
        'quarterly_report': lambda: dashboard.quarterly_report(year, quarter, preparation='deferred'),
    }
    report = {
        'status': 'diagnostic_started', 'scope': 'posting_period_discovery_three_functions',
        'source': str(SOURCE), 'source_sha256': SOURCE_SHA256,
        'source_manifest_sha256': manifest_hash,
        'baseline_source': str(OLD_SOURCE), 'baseline_source_sha256': old_manifest['sha256'],
        'baseline_manifest_sha256': old_manifest_hash,
        'construction_input': str(BOOK_REPORT), 'construction_input_sha256': REPORT_SHA256,
        'current_qualification': qualification, 'current_source_full_verification': qualification is not None,
        'old_qualification_inherited': False, 'checkpoint_sha256': checkpoint_hash,
        'qualification_reused_or_created': False, 'browser_acceptance': False,
        'root': str(root), 'period': period, 'default_page_limit': 20,
        'prototype_files': {name: {'path': item['path'], 'sha256': item['sha256']}
                            for name, item in changes.items()},
        'script_sha256': file_hash(Path(__file__)), 'measurements': {}, 'native_clocks': {},
        'notes': ['Normal saved-source validations remain; synthetic-root identity/checkpoint/epochs unchanged.',
                  'All work counters finish before native timing; root must attest exclusive owned CPU gate.',
                  'Native timing is before/after evidence, not browser 500ms acceptance.'],
    }
    with OUTPUT.open('x', encoding='utf-8') as output:
        try:
            report['before'] = check_state()
            for name, operation in operations.items():
                observations, responses, generated = {}, {}, {}
                for label in ('baseline', 'prototype'):
                    select(label)
                    work, result = stage9_metrics.measure_work(engine, operation)
                    generated[label] = {'root': result.get('generated_at'),
                                        'data': result.get('data', {}).get('generated_at')}
                    if name == 'quarterly_report':
                        generated[label]['checked_at'] = result['checked_at']
                        result['checked_at'] = '<response check time>'
                    if 'generated_at' in result:
                        result['generated_at'] = '<response generation time>'
                    if 'generated_at' in result.get('data', {}):
                        result['data']['generated_at'] = '<response generation time>'
                    observations[label], responses[label] = work, result
                observations['generated_at'] = generated
                observations['response_sha256_by_label'] = {
                    label: hashlib.sha256(canonical(result).encode()).hexdigest()
                    for label, result in responses.items()
                }
                report['measurements'][name] = observations
                require(canonical(responses['baseline']) == canonical(responses['prototype']),
                        name + ': complete business response differs')
                observations['complete_response_equal_except_generation_time'] = True
                observations['complete_response_sha256'] = hashlib.sha256(
                    canonical(responses['baseline']).encode()).hexdigest()
                del responses
            report['native_samples_ms'] = {}
            if args.native_gate is not None:
                gate_path = args.native_gate.resolve(strict=True)
                require(gate_path.parent == WORKSPACE / '.tmp', 'Gate must be isolated .tmp')
                gate = json.loads(gate_path.read_text(encoding='utf-8'))
                require(gate == {'status': 'native_authorized', 'source_sha256': SOURCE_SHA256,
                    'construction_input_sha256': REPORT_SHA256, 'root': str(root),
                    'output': str(OUTPUT), 'owned_cpu_quiet': True}, 'Root exclusive native gate mismatch')
                report['native_gate'] = {'path': str(gate_path), 'sha256': file_hash(gate_path)}
                for name, operation in operations.items():
                    samples = {'baseline': [], 'prototype': []}
                    clocks = {'baseline': [], 'prototype': []}
                    for _ in range(3):
                        for label in ('baseline', 'prototype'):
                            select(label)
                            operation()
                    for index in range(10):
                        order = ('baseline', 'prototype') if index % 2 == 0 else ('prototype', 'baseline')
                        for label in order:
                            select(label)
                            started = time.perf_counter()
                            result = operation()
                            elapsed = (time.perf_counter() - started) * 1000
                            clocks[label].append({
                                'generated_at': result.get('generated_at'),
                                'data_generated_at': result.get('data', {}).get('generated_at'),
                                'checked_at': result.get('checked_at'),
                            })
                            if name == 'quarterly_report':
                                result['checked_at'] = '<response check time>'
                            if 'generated_at' in result:
                                result['generated_at'] = '<response generation time>'
                            if 'generated_at' in result.get('data', {}):
                                result['data']['generated_at'] = '<response generation time>'
                            require(hashlib.sha256(canonical(result).encode()).hexdigest()
                                    == report['measurements'][name]['complete_response_sha256'],
                                    name + ': pure native response differs')
                            samples[label].append(elapsed)
                    report['native_samples_ms'][name] = samples
                    report['native_clocks'][name] = clocks

            report['after'] = check_state()
            check_source()
            for change in changes.values():
                require(file_hash(Path(change['path'])) == change['sha256'], 'Old sealed function bytes changed')
            report['status'] = 'diagnostic_complete'
        except BaseException as error:
            report.update(status='diagnostic_failed', error_type=type(error).__name__, error=str(error))
            raise
        finally:
            select('prototype')
            json.dump(report, output, ensure_ascii=False, indent=2)
            output.write('\n')
            pool.close()
    print(json.dumps({'status': report['status'], 'browser_acceptance': False}, ensure_ascii=False))


if __name__ == '__main__':
    main()

