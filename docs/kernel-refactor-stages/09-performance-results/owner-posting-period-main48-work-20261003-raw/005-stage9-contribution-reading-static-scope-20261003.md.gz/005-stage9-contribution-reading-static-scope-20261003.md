# 贡献正文读取职责：r3原件与静态调用链

未运行DB/新probe/计时/回归。证据为已有 signature-assets-main48-diagnostic-r3.json 的实际SQL；不是当前22ef新测量。不能将SQL ms、cProfile或native当500ms验收。

## brief：只消费 own binding，但完整正文目前是该 proof 的载体

Dashboard.brief → _brief_amounts/Journal.account_amounts 成功整月 money proof → Snapshot.activity_classification（dashboard.py:1158）。正常路径 :1197 或 SQL fallback :1302 调 verify_published_source_bindings；两条分支互斥，r3实际只1调用。它认证当月所有非冲正实际付款 settlement slots 的精确 source_calculation，先证明后按kind/creditor/obligation分类，不能先按expense过滤。这包括跨月来源及页外付款。

r3 SELECT source-binding candidates：1SQL/20300VM/495行/1,557,339B，_checksum495次，full contribution _decode0。_OWN_SOURCE_CONTENT原生严格validator只取format/publication/calculation/result_digest/fact_id/source_bindings，忽略rows/resolution/parents；金额或活动摘要不从贡献rows取。但为了将own binding绑定到immutable anchor，当前仍必须对整content bytes计算checksum并匹配anchor+body_digest。不能以存储body_digest或SQL json_extract代替正文bytes验证。

随后 _verify_anchored_source_bytes SQL495行121835B且outcome字段不含body：说明本样本这些源result已经被Journal/其他消费成功核验，避免二次result transfer的既有保护正在工作，不是未修重复加载。activity分类实际使用已解码source.values.creditor_kind/obligations，SQL fallback对剩余精确ID json_extract。来源正文proof、own publication/anchor身份proof与result money proof职责不同。

现有 QueryReads.verify_selected_content仅证明实际result/fact body，不证明saved calculation input identity。verify_saved_input_identity可以在已有decoded body上核验program、dependency scopes/versions及两种calc-id规则，但它不能自动代替当前明确要求的own publication/immutable anchor，且现有test_published_source_bindings覆盖anchor/body损坏必须拒绝、缺body只有限完整fallback。仅因495body已decoded跳过anchor会削保护。

合理方案线索：若将来只评估“已decoded direct source的身份职责能否由现有saved-input verifier承担”，必须同时明确现有anchor/缺body/坏body/跨月/冲正拒绝如何完整保留，并比较新增dependency SQL/编码工作。此不是已证明等价或净收益方案；若仍须整body checksum就不能声称节省1.56MB。另一合理复用仅是同snapshot已经完整认证过的contribution或own binding，本brief无此前认证的证据，不能新增cache后宣称本样本收益。

## reports：两批总计1004，不是每批1004或重复解码

Reports._report → cached_party_balance(年初前、期末) → report_projection._party_balance_nets/_party_delta（:337, :482）为RECLASS往来分配解析精确source。Reports._report本身 :1442为full_rows（冻结语义未覆盖的cash/profit/其他line）请求另一集合；selected_open_line核对voucher/line/account/debit/credit/cashflow，并返回immutable_line_fields和resolution供往来、现金流、利润与附表。这些消费需要rows/resolution，不仅own binding。

r3合并SQL记录：2calls/24100VM/1004returned rows/3,322,180B；read_open_contributions2calls、_decode1004。函数的report_open_contributions cache按missing ID加载，第二consumer对交集已成功验证的ID命中cache，因此本原件不能支持“同一1004正文读两遍”。两个cutoff余额不同，stored_month/party_delta成功结果也已同snapshot复用。

full read对body checksum/strict shape、sortunique/金额/extra/null、所有direct source_bindings及精确parents核验后才入cache。_verify_anchored_source_bytes两SQL1005行1,237,060B代表不同来源/首次body proof，未证明重复；现有bytes测试证明payment→另一份工资contribution能复用已核source，而新的另一工资必须核。selected_open_line无法匹配或usable=false走原完整relation fallback。缺body可repair/fallback；present坏body或坏anchor拒绝，不能忽略。

## 同类职责与边界

- report_open_contribution.verify_published_source_bindings:416：brief两互斥classification分支；绑定来源，不解释贡献全部金融字段。
- report_open_contribution.read_open_contributions:501：Reports._report:1442、report_projection._party_delta:482；消费完整rows/resolution并验证direct parents。
- QueryReads._verify_anchored_source_bytes:1871：共同实际body/fact proof，已按成功ID复用；不制造decoded outcome或adoption。
- QueryReads.verify_saved_input_identity:1768：Funds的owner/source摘要、分页消费等使用；必要saved inputs，与完整ancestor核验不同，不可把当前body proof旗标当input identity。
- sync/prepare_open_contribution是发布写入；compare/repair_open_contributions是完整核验/修复，必须重建预期并验证immutable anchor。不能把normal窄own binding证明移作full verification。
- fixed-v1/unowned/closed/report frozen flow原有独立readers保留。默认20不限制全部月份汇总source集合。

保护原件/测试范围只读：test_brief_activity_reuse.py、test_published_source_bindings.py、test_published_payment_source_scope.py、test_anchored_source_transfer.py、test_decoded_source_reuse.py、test_report_open_contribution.py、test_report_open_contribution_bytes.py。未新增或运行测试。本轮未找到当前同快照二次contribution正文加载的实际证据；下一步若调查替代proof，先以职责等价和完整负例界定，再单组实际work比较，不重复已撤own-line/compiled decoder方案。
