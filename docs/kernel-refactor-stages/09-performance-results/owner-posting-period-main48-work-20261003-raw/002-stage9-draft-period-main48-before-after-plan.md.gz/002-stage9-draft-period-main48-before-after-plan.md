# 主48 draft月份发现前后对照：准备，未执行

脚本 .tmp/stage9-draft-period-main48-before-after.py。使用repo venv；22ef模块/factory/globals，仅三函数绑d198 AST，各模块其余顶层AST语义必须相同。before/after完整两源inventory和manifest、construction report、实际draft factory、Catalog/bind/readonly、身份/epochs/checkpoint不变。source/report是诊断输入而非qualified：默认current_source_full_verification=false，不制造coverage；可显式提供当前22ef complete资格report+SHA校验其四coverage/preview/checkpoint/source。

必须由root协调独占：不能与main120copy、资格、MCP/mock或测试并行native。脚本不自行暂停进程，不读写真实服务。所有输出路径必须新.tmp stage9-draft-period-main48-*。

仅工作量（可单独先run，绝无native）：
```powershell
& .tmp-kernel-venv/Scripts/python.exe -B -X utf8 .tmp/stage9-draft-period-main48-before-after.py --months 48 --book-report .tmp/stage9-owner-main48-draft-period-group-construction-input.json --report-sha256 a73ded22688073e7aecb7a79d56a6e31d9d6be202e1083738b091d42d3671d93 --output .tmp/stage9-draft-period-main48-work-first.json
```

一次工作量后接native，需root先创建独占gate JSON（root输出绝对路径必须和--output相同）：
```json
{"status":"native_authorized","source_sha256":"22ef17f6aa6b40025eaf9fe939a209f15f7d4c73605e982925859fe42a1cfff3","construction_input_sha256":"a73ded22688073e7aecb7a79d56a6e31d9d6be202e1083738b091d42d3671d93","root":"D:\\GitHub\\ai-accounting-core\\.tmp\\stage9-draft-fixture-main48-20261003","output":"D:\\GitHub\\ai-accounting-core\\.tmp\\stage9-draft-period-main48-native-first.json","owned_cpu_quiet":true}
```

```powershell
& .tmp-kernel-venv/Scripts/python.exe -B -X utf8 .tmp/stage9-draft-period-main48-before-after.py --months 48 --book-report .tmp/stage9-owner-main48-draft-period-group-construction-input.json --report-sha256 a73ded22688073e7aecb7a79d56a6e31d9d6be202e1083738b091d42d3671d93 --output .tmp/stage9-draft-period-main48-native-first.json --native-gate .tmp/stage9-draft-period-main48-root-native-gate.json
```

若资格完成，可额外 --qualification-report <当前22efqualified报告> --qualification-sha256 <实际SHA>，不能假填。六读取work均重做，不继承r3；同响应只归一化原顶层/data.generated_at和报告checked_at，保存两边原时钟。measure_work统一记录SQL/VM/returnedrows/bytes及全部既有decode/adoption/material计数。工作插桩结束才3warmups/10each alternating native，不改计数器，native原时钟另记。finally恢复22ef三函数，失败报告保留。不作500ms验收，纯browser另验。

本准备任务仅运行repo venv的AST解析/compile；未执行脚本、模块import、Ruff、DB或计时，root统一调度。不修改sealed source/旧r3/DB。

静态复核完成：脚本和三份旧函数均parse/compile通过，三模块排除指定函数后的顶层AST实际相等（新posting_periods import在被排除函数内部，不影响比较）。修正了真实checkpoint字段误用：通过现有qualification_dimensions核对employees_count/businesses/month_stats/distribution，而不是不存在的requested_months/employee_count字段。失败response比较前先保存两边工作量、时钟及response SHA。实际22ef模块globals沿原模块defs/imports成立；未执行import/DB/native。readonly包装与gate不改变产品入口，无新增通用guard体系。

