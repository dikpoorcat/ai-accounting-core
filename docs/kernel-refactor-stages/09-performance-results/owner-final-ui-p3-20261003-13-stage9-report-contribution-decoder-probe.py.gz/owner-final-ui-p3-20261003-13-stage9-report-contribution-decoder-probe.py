"""Raw synthetic body decoder differential probe; never accounting proof or page timing."""

from __future__ import annotations

import gc
import hashlib
import json
import sqlite3
import statistics
import sys
import time
from pathlib import Path

sys.dont_write_bytecode = True
WORKSPACE = Path(__file__).resolve().parents[1]
SOURCE = WORKSPACE / ".tmp/stage9-build-source-owner-final-ui-20261003-release"
BOOK_REPORT = WORKSPACE / ".tmp/stage9-owner-main12-final-ui-verified.json"
OUTPUT = WORKSPACE / ".tmp/stage9-report-contribution-decoder-probe-final-ui.json"
SOURCE_SHA256 = "8672404dd3fcb198f80d3583782b98590b8c8358e2c2e354fa3822b71fefa36b"
REPORT_SHA256 = "2195134f3ca8fefe5945d8928f78cb09fa99cef62383ed0f66f36201d68db2ab"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def file_hash(path):
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def main():
    require(
        Path(sys.prefix).resolve() == (WORKSPACE / ".tmp-kernel-venv").resolve(),
        "Use repository virtual environment",
    )
    require(not OUTPUT.exists(), "Exclusive probe output already exists")
    require(file_hash(BOOK_REPORT) == REPORT_SHA256, "Verified report changed")
    sys.path.insert(0, str(SOURCE / "scripts"))
    from stage9_source import configure_source, require_source_module, synthetic_path

    configure_source(SOURCE, WORKSPACE)
    import benchmark_stage9_browser
    import snapshot_stage9_source
    from pydantic_core import SchemaValidator, ValidationError, core_schema

    from ai_accounting.kernel import report_open_contribution as production
    from ai_accounting.kernel.contracts import KernelError
    from ai_accounting.kernel.types import YearMonth

    require_source_module(
        production, SOURCE, "src/ai_accounting/kernel/report_open_contribution.py"
    )
    manifest = json.loads((SOURCE / "source-manifest.json").read_text(encoding="utf-8"))

    def check_source():
        inventory = snapshot_stage9_source._inventory(SOURCE)
        require(
            inventory == manifest["files"]
            and snapshot_stage9_source._digest(inventory) == SOURCE_SHA256,
            "Pinned source changed",
        )
        require(file_hash(BOOK_REPORT) == REPORT_SHA256, "Verified report changed")

    check_source()
    book = json.loads(BOOK_REPORT.read_text(encoding="utf-8"))
    benchmark_stage9_browser.require_report_source(book, SOURCE)
    period = benchmark_stage9_browser.validate_book_report(book, company_name="阶段九合成规模企业")
    root = synthetic_path(Path(book["root"]), WORKSPACE)
    database = Path(book["company"]["path"]).resolve(strict=True)
    require(
        database.is_relative_to(root) and database.name == "company.sqlite",
        "Only bound synthetic company database is allowed",
    )

    string = core_schema.str_schema(strict=True)
    digest_string = core_schema.str_schema(strict=True, min_length=64, max_length=64)
    integer = core_schema.int_schema(strict=True)
    arbitrary_dict = core_schema.dict_schema(strict=True)
    arbitrary_list = core_schema.list_schema(strict=True)

    def positional_list(items):
        # JSON arrays validate natively as fixed positional tuples. Convert only
        # these small containers back to the original public list representation.
        return core_schema.no_info_after_validator_function(
            list, core_schema.tuple_schema(items, strict=True)
        )

    def exact_dict(fields):
        return core_schema.typed_dict_schema(
            {key: core_schema.typed_dict_field(schema) for key, schema in fields.items()},
            strict=True,
            extra_behavior="forbid",
        )

    validator = SchemaValidator(
        exact_dict(
            {
                "format": core_schema.literal_schema(
                    ["ai-accounting-kernel/2/report-open-contribution/1"]
                ),
                "publication_id": string,
                "calculation_id": string,
                "result_digest": digest_string,
                "fact_id": string,
                "parents": core_schema.list_schema(string, strict=True),
                "source_bindings": core_schema.list_schema(
                    positional_list([string, digest_string, string, digest_string]),
                    strict=True,
                ),
                "rows": core_schema.list_schema(
                    positional_list(
                        [
                            string,
                            integer,
                            string,
                            integer,
                            integer,
                            core_schema.nullable_schema(string),
                            arbitrary_dict,
                        ]
                    ),
                    strict=True,
                ),
                "resolution": exact_dict(
                    {
                        "issues": arbitrary_list,
                        "line_relations": arbitrary_list,
                        "own_party_accounts": arbitrary_list,
                        "party_candidates_by_account": arbitrary_list,
                    }
                ),
                "usable": core_schema.bool_schema(strict=True),
            }
        )
    )

    def candidate(content, publication_id):
        # Shape decoding is never a proof: callers must retain immutable-anchor
        # checksum, exact saved-byte bindings, parents and selection checks.
        try:
            value = validator.validate_json(content, strict=True)
            if value["publication_id"] != publication_id or (
                value["parents"] != sorted(set(value["parents"]))
            ):
                raise ValueError("invalid contribution identity or parent order")
            return value
        except (ValidationError, ValueError, TypeError, KeyError) as error:
            raise KernelError("content_integrity_failed", "当前报表行贡献格式不一致") from error

    def representation(value):
        if type(value) is dict:
            return {key: representation(item) for key, item in value.items()}
        if type(value) is list:
            return ("list", tuple(representation(item) for item in value))
        return (type(value).__name__, value)

    def outcome(decoder, raw, publication_id):
        try:
            return ("value", representation(decoder(raw, publication_id)))
        except KernelError as error:
            return ("error", error.code, str(error))

    connection = sqlite3.connect(database.as_uri() + "?mode=ro", uri=True)
    try:
        connection.execute("PRAGMA query_only=ON")
        connection.execute("BEGIN")

        def state_identity():
            return {
                "state": list(connection.execute("SELECT * FROM state WHERE id=1").fetchone()),
                "identity": list(
                    connection.execute(
                        "SELECT company_id,taxpayer_id,database_id FROM identity WHERE id=1"
                    ).fetchone()
                ),
            }

        before = state_identity()
        require(
            before["state"] == book["verified_open_preview"]["state"]
            and before["identity"]
            == [book["company"][key] for key in ("id", "taxpayer_id", "database_id")],
            "Company state or identity changed",
        )
        selected = list(
            connection.execute(
                "SELECT p.id,d.content,a.content_digest,d.content_digest "
                "FROM calculation_publication p "
                "JOIN report_open_contribution_anchor a ON a.publication_id=p.id "
                "JOIN report_open_contribution d ON d.publication_id=p.id "
                "WHERE p.posting_period=? ORDER BY p.id",
                (YearMonth(period).ordinal,),
            )
        )
        require(selected, "Synthetic month contains no saved contributions")
        bodies = []
        for publication_id, raw, anchor, checksum in selected:
            require(
                hashlib.sha256(raw.encode("utf-8")).digest() == anchor == checksum,
                "Raw contribution no longer matches its immutable anchor",
            )
            original = production._decode(raw, publication_id)
            require(
                representation(candidate(raw, publication_id)) == representation(original),
                "Candidate changed saved-content values or list/dict representation",
            )
            bodies.append((raw, publication_id))
        after = state_identity()
        require(before == after, "Company changed during body collection")
    finally:
        connection.close()

    # Differences must preserve permissive historical values too; stricter
    # minima/hex/ranges are not silently introduced into the existing format.
    sample = next(
        value for raw, ident in bodies if (value := production._decode(raw, ident))["rows"]
    )
    publication_id = sample["publication_id"]
    probes = []

    def probe(label, change=None, *, raw=None, requested_id=publication_id):
        value = json.loads(json.dumps(sample))
        if change:
            change(value)
        encoded = json.dumps(value, ensure_ascii=False) if raw is None else raw
        baseline = outcome(production._decode, encoded, requested_id)
        actual = outcome(candidate, encoded, requested_id)
        require(baseline == actual, f"Malformed/historical input differs: {label}")
        probes.append({"case": label, "outcome": baseline[0]})

    probe("unchanged")
    probe("malformed JSON", raw="{")
    probe("root null", raw="null")
    probe("root array", raw="[]")
    probe("wrong requested publication", requested_id="other")
    for key in sample:
        probe("missing root " + key, lambda value, key=key: value.pop(key))
        probe("null root " + key, lambda value, key=key: value.__setitem__(key, None))
    probe("extra root", lambda value: value.update(extra="forbidden"))
    probe("extra resolution", lambda value: value["resolution"].update(extra=[]))
    for key in sample["resolution"]:
        probe("missing resolution " + key, lambda value, key=key: value["resolution"].pop(key))
        probe(
            "non-list resolution " + key,
            lambda value, key=key: value["resolution"].__setitem__(key, {}),
        )
    probe("duplicate parents", lambda value: value.update(parents=["a", "a"]))
    probe("unsorted parents", lambda value: value.update(parents=["b", "a"]))
    probe("non-string parent", lambda value: value.update(parents=[1]))
    for digest in ("a" * 63, "g" * 64, ""):
        probe(
            "digest length/hex " + str(len(digest)),
            lambda value, digest=digest: value.update(result_digest=digest),
        )
    probe("non-boolean usable", lambda value: value.update(usable=1))
    for field in ("publication_id", "calculation_id", "fact_id"):
        probe("non-string " + field, lambda value, field=field: value.__setitem__(field, 1))
    for index in range(4):
        probe(
            "binding non-string " + str(index),
            lambda value, index=index: value["source_bindings"][0].__setitem__(index, 1),
        )
    probe("binding too short", lambda value: value["source_bindings"][0].pop())
    probe("binding too long", lambda value: value["source_bindings"][0].append("extra"))
    if sample["rows"]:
        for index in (1, 3, 4):
            for wrong in (True, 1.0, "1", None):
                probe(
                    f"row strict integer {index}/{type(wrong).__name__}",
                    lambda value, index=index, wrong=wrong: value["rows"][0].__setitem__(
                        index, wrong
                    ),
                )
            for historical in (0, -1, 900719925474099301):
                probe(
                    f"row historical integer {index}/{historical}",
                    lambda value, index=index, historical=historical: value["rows"][0].__setitem__(
                        index, historical
                    ),
                )
        probe("row null cashflow", lambda value: value["rows"][0].__setitem__(5, None))
        probe("row non-string cashflow", lambda value: value["rows"][0].__setitem__(5, 1))
        probe("row compact extra allowed", lambda value: value["rows"][0][6].update(extra=None))
        probe("row compact must be dict", lambda value: value["rows"][0].__setitem__(6, []))
        probe("row too short", lambda value: value["rows"][0].pop())
        probe("row too long", lambda value: value["rows"][0].append("extra"))

    measurements = {"original": [], "compiled_candidate": []}
    decoders = {"original": production._decode, "compiled_candidate": candidate}
    # Alternate order. This measures decoder construction on already collected
    # bytes, excluding DB, shape comparison, checksums and all accounting proof.
    for round_number in range(7):
        order = tuple(decoders) if round_number % 2 == 0 else tuple(reversed(decoders))
        for name in order:
            gc.collect()
            started = time.perf_counter()
            decoded = [decoders[name](raw, ident) for raw, ident in bodies]
            elapsed = (time.perf_counter() - started) * 1000
            require(len(decoded) == len(bodies), "Decoder result count differs")
            measurements[name].append(elapsed)
            del decoded
    check_source()
    # Reopen to exclude a write hidden by the collection transaction snapshot.
    with sqlite3.connect(database.as_uri() + "?mode=ro", uri=True) as connection:
        actual_state = list(connection.execute("SELECT * FROM state WHERE id=1").fetchone())
        actual_identity = list(
            connection.execute(
                "SELECT company_id,taxpayer_id,database_id FROM identity WHERE id=1"
            ).fetchone()
        )
    require(
        actual_state == before["state"] and actual_identity == before["identity"],
        "Company changed after the decoder probe",
    )
    report = {
        "status": "differential_probe_passed",
        "scope": "synthetic_raw_decoder_diagnostic",
        "page_timing": False,
        "accounting_proof": False,
        "source": str(SOURCE),
        "source_sha256": SOURCE_SHA256,
        "book_report_sha256": REPORT_SHA256,
        "period": period,
        "dataset": "all saved publications in the open month",
        "body_count": len(bodies),
        "body_bytes": sum(len(raw.encode()) for raw, _ in bodies),
        "raw_values_and_representation_equal": True,
        "probes": probes,
        "before": before,
        "after": {"state": actual_state, "identity": actual_identity},
        "decoder_only_ms": {
            name: {"samples": values, "median": statistics.median(values)}
            for name, values in measurements.items()
        },
        "notes": [
            "No production changes, content verifier, preview construction or business writes.",
            "Decoder output is shape-only; it is never an authenticated contribution.",
            "Immutable anchor, saved bytes, parents, current/frozen selector proofs stay separate.",
            "Fixed v1 decoder is untouched. No full-page performance conclusion.",
        ],
    }
    with OUTPUT.open("x", encoding="utf-8") as output:
        json.dump(report, output, ensure_ascii=False, indent=2)
        output.write("\n")
    print(
        json.dumps(
            {
                "output": str(OUTPUT),
                "body_count": report["body_count"],
                "probe_count": len(probes),
                "decoder_only_ms": report["decoder_only_ms"],
            }
        )
    )


if __name__ == "__main__":
    main()
