from pathlib import Path

previous = Path(__file__).with_name('stage9-r74-preview-lifecycle.py')
source = previous.read_text(encoding='utf8')
source = source.replace("'.tmp/stage9-r74-preview-lifecycle.json'", "'.tmp/stage9-r74-preview-lifecycle-attempt2.json'")
source = source.replace("args.update(quarter='2016-Q4', source='open')", "args.update(year=2016, quarter=4, preparation='deferred')")
source = source.replace("assert parsed['company']['company_id'] == cid if 'company_id' in parsed['company'] else parsed['company']['id'] == cid", "assert parsed['read_context']['company_id'] == cid")
exec(compile(source, str(previous), 'exec'))
