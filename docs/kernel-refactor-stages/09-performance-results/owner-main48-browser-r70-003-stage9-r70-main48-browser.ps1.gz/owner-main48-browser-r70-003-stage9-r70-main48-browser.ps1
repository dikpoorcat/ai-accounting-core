# Run only after the r70 registered full verification and every heavy job ends.
& ./.tmp-kernel-venv/Scripts/python.exe -X utf8 `
  .tmp/stage9-build-source-owner-r70-release/scripts/benchmark_stage9_browser.py `
  --source .tmp/stage9-build-source-owner-r70-release --workspace . `
  --book-report .tmp/stage9-owner-main48-r70-verified.json `
  --output .tmp/stage9-owner-main48-browser-r70.json `
  --node 'D:/Program Files/nodejs/node.exe' `
  --playwright-module 'C:/Users/MD01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright' `
  --static-build release --browser-channel msedge --repeats 30 --warmups 3 `
  --timing-ready-file .tmp/stage9-owner-main48-r70-timing-ready.json `
  --timing-start-file .tmp/stage9-owner-main48-r70-timing-start.json `
  > .tmp/stage9-owner-main48-browser-r70.log 2>&1
exit $LASTEXITCODE
