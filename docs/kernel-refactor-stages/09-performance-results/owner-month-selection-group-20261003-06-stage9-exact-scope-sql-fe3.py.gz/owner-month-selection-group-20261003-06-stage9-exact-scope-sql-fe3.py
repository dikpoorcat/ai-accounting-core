"""Read-only exact-scope plans on qualified synthetic samples; not page timing."""
from __future__ import annotations

import hashlib
import json
import sys
import traceback
from pathlib import Path

W = Path(__file__).resolve().parents[1]
S = W / '.tmp/stage9-build-source-owner-summary-groups-20261003-release'
SHA = 'fe3a0ba43267bb05f3159bf38aeca13bf90f8cdc8c9b774882a6a560f27bc8f6'
MANIFEST = '07b8a5b67a25d6d6df93fc60f7246b224f22a252fe3fe9b222744731a66ba463'
NATIVE = W / '.tmp/stage9-owner-main12-summary-groups-native-work.json'
OUT = W / '.tmp/stage9-exact-scope-sql-fe3.json'
LOG = W / '.tmp/stage9-exact-scope-sql-fe3.log'
BOOKS = [
    ('12', W / '.tmp/stage9-owner-main12-summary-groups-qualified.json',
     'e8a8c24ede162b9f0ebe84e2fab484cf16ba4cd5acc2177fe14b774c83dc2568'),
    ('48', W / '.tmp/stage9-owner-main48-read-groups-qualified.json',
     'edca0e5294a91520cbfeacb71df0f4b90862c12d89236c9399465ca675f0d846'),
]

def require(value, reason):
    if not value:
        raise ValueError(reason)

def digest(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()

def main():
    require(not OUT.exists() and not LOG.exists(), 'Refuse existing output/log')
    require(Path(sys.prefix).resolve() == (W / '.tmp-kernel-venv').resolve(), 'Use repo venv')
    report = {'status': 'started', 'source_sha256': SHA, 'production_modified': False,
              'read_only': True, 'page_latency_claim': False, 'samples': []}
    OUT.open('x').close()
    log = LOG.open('x', encoding='utf-8')
    def save():
        OUT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    def note(message):
        print(message, flush=True)
        log.write(message + '\n')
        log.flush()
    try:
        require(digest(S / 'source-manifest.json') == MANIFEST, 'Source manifest drift')
        manifest = json.loads((S / 'source-manifest.json').read_text(encoding='utf-8'))
        require(manifest['sha256'] == SHA and manifest['status'] == 'complete', 'Wrong source')
        sys.path.insert(0, str(S / 'scripts'))
        import stage9_source
        stage9_source.configure_source(S, W)
        import snapshot_stage9_source
        from ai_accounting.kernel import schema_bundle, storage, dashboard_owner, query_reads
        from ai_accounting.kernel.types import YearMonth, canonical
        from ai_accounting.kernel.versions import database_format
        modules = [(stage9_source, 'scripts/stage9_source.py'),
                   (schema_bundle, 'src/ai_accounting/kernel/schema_bundle.py'),
                   (storage, 'src/ai_accounting/kernel/storage.py'),
                   (dashboard_owner, 'src/ai_accounting/kernel/dashboard_owner.py'),
                   (query_reads, 'src/ai_accounting/kernel/query_reads.py')]
        for module, rel in modules:
            stage9_source.require_source_module(module, S, rel)
        inventory = snapshot_stage9_source._inventory(S)
        require(inventory == manifest['files'] and snapshot_stage9_source._digest(inventory) == SHA,
                'Source bytes drift')
        report['source'] = str(S)
        report['module_bindings'] = {m.__name__: {'path': str(m.__file__), 'sha256': digest(Path(m.__file__))}
                                     for m, _ in modules}
        report['native_sha256'] = digest(NATIVE)
        native = json.loads(NATIVE.read_text(encoding='utf-8'))
        require(native['source_sha256'] == SHA, 'Wrong native source')
        bsql = [q['statement'] for q in native['measurements']['brief']['sql']]
        rsql = [q['statement'] for q in native['measurements']['quarterly_report']['sql']]
        owner = next(q for q in bsql if q.startswith('SELECT f.id FROM fact_revision f INDEXED'))
        pub = next(q for q in bsql if q.startswith('SELECT p.*,a.calculation_id current_id,c.id calculation_exists,c.subject_id'))
        missing = next(q for q in bsql if q.startswith('SELECT v.id FROM voucher_version v INDEXED BY voucher_period CROSS JOIN voucher_current'))
        classification = next(q for q in rsql if 'SELECT f.id,f.digest,c.voucher_version_id FROM open_periods p' in q)
        kinds = (*dashboard_owner.PAYROLL_KINDS, *dashboard_owner.PLAN_KINDS, dashboard_owner.NO_CHANGE_KIND)
        bundle = schema_bundle.production_bundle()
        for label, book_path, book_hash in BOOKS:
            require(digest(book_path) == book_hash, 'Qualified receipt drift')
            book = json.loads(book_path.read_text(encoding='utf-8'))
            root = stage9_source.synthetic_path(Path(book['root']), W)
            require(root == W / ('.tmp/stage9-owner-main12-r43' if label == '12' else '.tmp/stage9-owner-main48-r63'),
                    'Wrong synthetic root')
            company = book['company']
            db = Path(company['path']).resolve(strict=True)
            require(db.is_relative_to(root), 'DB outside synthetic root')
            month_string = book['months'][-1]['period']
            month = YearMonth(month_string).ordinal
            sample = {'months': int(label), 'root': str(root), 'period': month_string,
                      'qualification_source': book['source'], 'qualification_receipt_sha256': book_hash,
                      'reader_source_differs_from_qualification': Path(book['source']).resolve() != S,
                      'queries': {}}
            report['samples'].append(sample)
            store = storage.Store(db, bundle, company['id'], company['database_id'], taxpayer_id=company['taxpayer_id'])
            with store.connection(read_only=True) as c:
                c.execute('BEGIN')
                require(list(c.execute('SELECT * FROM state WHERE id=1').fetchone()) == book['verified_open_preview']['state'], 'State drift')
                require(database_format(c, bundle=bundle) == book['integrity_contract'], 'Schema drift')
                identity = c.execute('SELECT company_id,taxpayer_id,database_id FROM identity WHERE id=1').fetchone()
                require(tuple(identity) == (company['id'], company['taxpayer_id'], company['database_id']), 'Identity drift')
                closed = c.execute('SELECT max(period) FROM period_close WHERE period<=?', (month,)).fetchone()[0]
                sample['indexes'] = [dict(row) for row in c.execute("SELECT name,tbl_name,sql FROM sqlite_master WHERE type='index' AND tbl_name IN ('fact_revision','fact_current','subject','calculation_publication','voucher_version','voucher','voucher_current') ORDER BY name")]
                sample['cardinalities'] = {
                    'fact_revisions': c.execute('SELECT count(*) FROM fact_revision').fetchone()[0],
                    'month_fact_revisions': c.execute('SELECT count(*) FROM fact_revision WHERE period=?', (month,)).fetchone()[0],
                    'owner_kind_subjects': c.execute('SELECT count(*) FROM subject WHERE kind IN(SELECT value FROM json_each(?))', (canonical(kinds),)).fetchone()[0],
                    'month_voucher_versions': c.execute('SELECT count(*) FROM voucher_version WHERE period=?', (month,)).fetchone()[0],
                    'all_voucher_versions': c.execute('SELECT count(*) FROM voucher_version').fetchone()[0],
                    'month_publications': c.execute('SELECT count(*) FROM calculation_publication WHERE posting_period=?', (month,)).fetchone()[0],
                }
                def run(key, sql, params):
                    plan = [list(row) for row in c.execute('EXPLAIN QUERY PLAN ' + sql, params)]
                    steps = 0
                    def tick():
                        nonlocal steps
                        steps += 100
                        return 0
                    c.set_progress_handler(tick, 100)
                    try:
                        rows = [tuple(row) for row in c.execute(sql, params)]
                    finally:
                        c.set_progress_handler(None, 0)
                    size = sum(sum(0 if v is None else len(v.encode()) if isinstance(v, str) else len(v) if isinstance(v, bytes) else 8 for v in row) for row in rows)
                    # Hash complete returned tuples; do not save any business body or ID list.
                    wire = [[v.hex() if isinstance(v, bytes) else v for v in row] for row in rows]
                    sample['queries'][key] = {'sql': sql, 'parameters': params, 'plan': plan,
                                              'vm_steps_sampled100': steps, 'rows': len(rows), 'returned_value_bytes': size,
                                              'tuple_digest_ordered': hashlib.sha256(canonical(wire).encode()).hexdigest(),
                                              'tuple_digest_sorted': hashlib.sha256(canonical(sorted(wire, key=repr)).encode()).hexdigest()}
                    note(f'{label} {key}: VM={steps} rows={len(rows)} bytes={size}')
                    save()
                    return rows
                original = run('owner_original', owner, (month, canonical(kinds)))
                for name, sql in [('owner_period_first', owner.replace('JOIN fact_current', 'CROSS JOIN fact_current').replace('JOIN subject', 'CROSS JOIN subject')),
                                  ('owner_kind_first', 'SELECT f.id FROM subject s CROSS JOIN fact_current c ON c.subject_id=s.id CROSS JOIN fact_revision f ON f.id=c.fact_id WHERE f.period=? AND s.kind IN(SELECT value FROM json_each(?))')]:
                    alternative = run(name, sql, (month, canonical(kinds)))
                    require(sorted(original) == sorted(alternative), 'Owner exact ID mismatch')
                run('current_publication_scope', pub, (month, closed, month))
                run('missing_current_publication', missing, (month, closed, month))
                orig = run('classification_original', classification, (month, month))
                alt = run('classification_period_first', classification.replace('JOIN fact_current', 'CROSS JOIN fact_current').replace('JOIN subject', 'CROSS JOIN subject').replace('JOIN fact_report_classification', 'CROSS JOIN fact_report_classification'), (month, month))
                require(sorted(orig) == sorted(alt), 'Classification tuple mismatch')
                selected, params = query_reads.selected_voucher_sql(YearMonth(month_string), posting_period=YearMonth(month_string), no_close_references=True)
                journal = 'SELECT j.* FROM (' + selected + ') j WHERE 1=1 AND j.period=?'
                jparams = [*params, month]
                run('month_journal_headers', journal, jparams)
                # These SQL diagnostics do not claim no_close_references is proven for API use.
                # Actual source has zero close references for this selected open month; check exact scope.
                require(c.execute("SELECT 1 FROM voucher_version v JOIN close_reference r ON r.reference_id=v.id AND r.reference_type='voucher' AND r.close_period<=? WHERE v.period=? LIMIT 1", (month, month)).fetchone() is None, 'Unexpected frozen voucher scope')
                run('default_journal_page', journal + ' AND j.number>? ORDER BY j.number,j.id LIMIT ?', [*jparams, 0, 21])
                run('focused_journal_number', journal + ' AND j.number=? ORDER BY j.number,j.id LIMIT ?', [*jparams, c.execute('SELECT min(n.number) FROM voucher_version v JOIN voucher n ON n.id=v.voucher_id WHERE v.period=?', (month,)).fetchone()[0], 21])
                require(list(c.execute('SELECT * FROM state WHERE id=1').fetchone()) == book['verified_open_preview']['state'], 'Ending state drift')
                c.rollback()
            require(digest(book_path) == book_hash, 'Receipt changed')
            save()
        require(snapshot_stage9_source._inventory(S) == manifest['files'], 'Ending source drift')
        report['status'] = 'diagnostic_complete'
        report['limitations'] = ['No page/app/service/proof invocation; SQL only', 'No latency acceptance',
                                 '48-month receipt qualified under 46f845; fe3 reader/schema/identity/state bound here',
                                 'Normal existing data only; no corruption or missing-row mutation',
                                 'No synthetic history writes or new sample construction']
        save()
    except BaseException:
        report['status'] = 'failed'
        report['error'] = traceback.format_exc()
        note(report['error'])
        save()
        raise
    finally:
        log.close()

if __name__ == '__main__':
    main()
