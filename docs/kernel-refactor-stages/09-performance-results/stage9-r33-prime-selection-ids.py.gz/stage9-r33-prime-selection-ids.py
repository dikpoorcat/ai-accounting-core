"""One-shot parent-snapshot Read selection attribution on verified synthetic books.

It leaves the fixed source and databases unchanged and does not instrument spawned
brief workers. Timing is deliberately not used for acceptance.
"""

from __future__ import annotations

import argparse
import collections
import hashlib
import json
import sys
import threading
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp/stage9-build-source-r33-release"
sys.path.insert(0, str(SOURCE / "src"))


def _read_label(read):
    return {
        "source": read.source,
        "kind": read.kind,
        "key": read.key,
        "before_period": str(read.before_period) if read.before_period is not None else None,
    }


def _summarize(calls):
    by_phase = {}
    for phase in ("readiness", "other_parent"):
        chosen = [call for call in calls if call["phase"] == phase]
        selected = collections.Counter(
            (slot["read"]["source"], ident)
            for call in chosen for slot in call["slots"] for ident in slot["ids"]
        )
        decoded = collections.Counter(
            item["id"] for call in chosen for item in call["calculation_constructions"]
        )
        by_kind = collections.defaultdict(lambda: {"slots": 0, "selected": 0, "unique_ids": set()})
        for call in chosen:
            for slot in call["slots"]:
                key = (slot["read"]["source"], slot["read"]["kind"])
                entry = by_kind[key]
                entry["slots"] += 1
                entry["selected"] += len(slot["ids"])
                entry["unique_ids"].update(slot["ids"])
        by_phase[phase] = {
            "select_many_calls": len(chosen),
            "requested_reads": sum(len(call["slots"]) for call in chosen),
            "selected_ids_with_slot_multiplicity": sum(selected.values()),
            "unique_selected_source_ids": len(selected),
            "selected_cross_slot_repeat_excess": sum(count - 1 for count in selected.values()),
            "calculation_construct_calls": sum(decoded.values()),
            "unique_constructed_calculation_ids": len(decoded),
            "calculation_repeat_construct_excess": sum(count - 1 for count in decoded.values()),
            "constructed_outcome_bytes_with_repeats": sum(
                item["outcome_bytes"] for call in chosen
                for item in call["calculation_constructions"]
            ),
            "by_source_kind": [
                {"source": source, "kind": kind, "slots": info["slots"],
                 "selected": info["selected"], "unique_ids": len(info["unique_ids"])}
                for (source, kind), info in sorted(by_kind.items())
            ],
            "reconstructed_calculation_ids": [
                {"id": ident, "count": count} for ident, count in sorted(decoded.items())
                if count > 1
            ],
        }
    return by_phase


def run(book_report):
    from ai_accounting.kernel.daemon import _prepare_static_runtime
    from ai_accounting.kernel.dashboard import Dashboard
    from ai_accounting.kernel.periods import Periods
    from ai_accounting.kernel.service import LocalService
    from ai_accounting.kernel.storage import Store

    assert Path(sys.prefix).resolve() == (ROOT / ".tmp-kernel-venv").resolve()
    book = json.loads(book_report.read_text(encoding="utf-8"))
    assert book["status"] == "complete"
    assert book["integrity"]["status"] == "verified"
    assert not book["integrity"]["limitations"]
    assert Path(book["root"]).is_dir()
    assert book["integrity_contract"]["fingerprint"] == (
        "c16b169268f62d31e58d74596af1bc80658488364830ffd615497cac220f5ec7"
    )
    period = book["verified_open_preview"]["period"]
    service = LocalService(
        book["root"], enable_read_pool=True, enable_parallel_brief=True,
        _static_runtime=_prepare_static_runtime(),
    )
    local = threading.local()
    calls = []
    original_select = Store.select_many
    original_calculation = Store.calculation
    original_collect = Periods.collect_current_readiness

    def select_many(self, connection, reads, *, fact_loader=None):
        requested = tuple(reads)
        call = {
            "phase": "readiness" if getattr(local, "in_readiness", False) else "other_parent",
            "slots": [],
            "calculation_constructions": [],
        }
        calls.append(call)
        previous = getattr(local, "call", None)
        local.call = call
        try:
            result = original_select(self, connection, requested, fact_loader=fact_loader)
        finally:
            local.call = previous
        call["slots"] = [
            {"read": _read_label(read), "ids": [item.id for item in result[read]]}
            for read in requested
        ]
        return result

    def calculation(row):
        call = getattr(local, "call", None)
        if call is not None:
            raw = row["outcome"]
            call["calculation_constructions"].append({
                "id": row["id"], "kind": row["kind"], "period": row["period"],
                "outcome_bytes": len(raw.encode("utf-8")) if isinstance(raw, str) else len(raw),
            })
        return original_calculation(row)

    def collect(self, *args, **kwargs):
        previous = getattr(local, "in_readiness", False)
        local.in_readiness = True
        try:
            return original_collect(self, *args, **kwargs)
        finally:
            local.in_readiness = previous

    Store.select_many = select_many
    Store.calculation = staticmethod(calculation)
    Periods.collect_current_readiness = collect
    try:
        engine = service.engine(book["company"]["id"], dashboard_read=True)
        result = service._dashboard_brief(
            Dashboard(engine), engine,
            {"period": period, "limit": 100, "preparation": "complete"},
        )
        response = json.dumps(result, sort_keys=True, separators=(",", ":"), default=str)
        return {
            "source": str(SOURCE),
            "verified_book_report": str(book_report),
            "verified_book_source": book["source"],
            "period": period,
            "months": book["requested_months"],
            "entry": "LocalService._dashboard_brief complete, limit=100, production three-worker service",
            "coverage": "parent process only; spawned workers not instrumented",
            "timing_boundary": "background work may run; no latency/acceptance claim",
            "response_sha256": hashlib.sha256(response.encode("utf-8")).hexdigest(),
            "response_keys": sorted(result),
            "summary": _summarize(calls),
            "calls": calls,
        }
    finally:
        Periods.collect_current_readiness = original_collect
        Store.calculation = staticmethod(original_calculation)
        Store.select_many = original_select
        service.close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--report", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    result = run(args.report.resolve())
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(args.output)
    print(json.dumps(result["summary"], ensure_ascii=False)[:3000])


if __name__ == "__main__":
    main()
