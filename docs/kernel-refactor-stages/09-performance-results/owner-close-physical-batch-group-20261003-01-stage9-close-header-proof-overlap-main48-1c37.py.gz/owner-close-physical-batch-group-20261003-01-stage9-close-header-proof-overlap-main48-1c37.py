"""Pinned, read-only instrumented diagnostic; this is never browser acceptance timing."""

from __future__ import annotations

import hashlib
import json
import sys
from contextlib import contextmanager
from pathlib import Path

WORKSPACE = Path(__file__).resolve().parents[1]
SOURCE = WORKSPACE / ".tmp/stage9-build-source-owner-month-reads-20261003-release"
MANIFEST = SOURCE / "source-manifest.json"
import argparse

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--months', type=int, choices=(48,), required=True)
parser.add_argument('--book-report', type=Path, required=True)
parser.add_argument('--report-sha256', required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
BOOK_REPORT = args.book_report.resolve(strict=True)
OUTPUT = args.output.resolve()
assert BOOK_REPORT.is_relative_to(WORKSPACE / '.tmp')
assert OUTPUT.is_relative_to(WORKSPACE / '.tmp') and not OUTPUT.exists()
MANIFEST_FILE_SHA256 = '845318d7e9857cbae422033a7e8b87a5fb7edd2896f1c5f0617709eabca1c979'
SOURCE_SHA256 = '1c37c576cb0026b0b39c199b74672a60890c43a7d9e2b944416179fe2bf398e9'
REPORT_SHA256 = '029e0eb04fdf4a51cde2d2f1ce235031a3086f33735eec92d70321d562f54656'
assert args.report_sha256 == REPORT_SHA256, "Only this current main48 qualification is permitted"
assert BOOK_REPORT == (WORKSPACE / '.tmp/stage9-owner-main48-month-reads-qualified.json').resolve()
assert OUTPUT == (WORKSPACE / '.tmp/stage9-close-header-proof-overlap-main48-1c37.json').resolve()


def file_hash(path):
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def main():
    require(
        Path(sys.prefix).resolve() == (WORKSPACE / ".tmp-kernel-venv").resolve(),
        "Use the repository virtual environment",
    )
    require(not OUTPUT.exists(), "Diagnostic output must not exist")
    require(file_hash(MANIFEST) == MANIFEST_FILE_SHA256, "Pinned manifest bytes changed")
    require(file_hash(BOOK_REPORT) == REPORT_SHA256, "Pinned verified report bytes changed")
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    require(
        manifest["status"] == "complete"
        and manifest["sha256"] == SOURCE_SHA256
        and Path(manifest["target"]).resolve() == SOURCE.resolve(),
        "Wrong source manifest",
    )

    # Bootstrap only from the fixed candidate, before importing any accounting module.
    sys.path.insert(0, str(SOURCE / "scripts"))
    import stage9_source

    stage9_source.require_source_module(stage9_source, SOURCE, "scripts/stage9_source.py")
    stage9_source.configure_source(SOURCE, WORKSPACE)
    import benchmark_stage9_browser
    import snapshot_stage9_source
    import stage9_metrics

    from ai_accounting.kernel import catalog as catalog_module
    from ai_accounting.kernel import dashboard as dashboard_module
    from ai_accounting.kernel import engine as engine_module
    from ai_accounting.kernel import resident_reads, schema_bundle, close_storage, query_reads, storage
    from ai_accounting.kernel.types import canonical
    from ai_accounting.kernel.versions import database_format

    for module, relative in (
        (snapshot_stage9_source, "scripts/snapshot_stage9_source.py"),
        (benchmark_stage9_browser, "scripts/benchmark_stage9_browser.py"),
        (stage9_metrics, "tests/kernel/stage9_metrics.py"),
        (catalog_module, "src/ai_accounting/kernel/catalog.py"),
        (dashboard_module, "src/ai_accounting/kernel/dashboard.py"),
        (engine_module, "src/ai_accounting/kernel/engine.py"),
        (resident_reads, "src/ai_accounting/kernel/resident_reads.py"),
        (schema_bundle, "src/ai_accounting/kernel/schema_bundle.py"),
        (close_storage, "src/ai_accounting/kernel/close_storage.py"),
        (query_reads, "src/ai_accounting/kernel/query_reads.py"),
        (storage, "src/ai_accounting/kernel/storage.py"),
    ):
        stage9_source.require_source_module(module, SOURCE, relative)

    def check_source():
        inventory = snapshot_stage9_source._inventory(SOURCE)
        require(
            inventory == manifest["files"]
            and snapshot_stage9_source._digest(inventory) == SOURCE_SHA256,
            "Fixed source bytes drifted",
        )
        require(
            file_hash(MANIFEST) == MANIFEST_FILE_SHA256 and file_hash(BOOK_REPORT) == REPORT_SHA256,
            "Pinned attestations drifted",
        )

    check_source()
    book = json.loads(BOOK_REPORT.read_text(encoding="utf-8"))
    benchmark_stage9_browser.require_report_source(book, SOURCE)
    period = benchmark_stage9_browser.validate_book_report(book, company_name="阶段九合成规模企业")
    require(
        book["requested_months"] == args.months
        and book["employee_count"] == 50
        and book["monthly_business_count"] == 1000
        and book["distribution"] == "mixed_cumulative",
        "Wrong main sample dimensions",
    )
    root = stage9_source.synthetic_path(Path(book["root"]), WORKSPACE)
    company = book["company"]
    require(root == (WORKSPACE / ".tmp/stage9-owner-main48-r63").resolve(), "Only qualified synthetic main48 root is permitted")
    checkpoint_path = root / "stage9-builder.json"
    checkpoint_hash = file_hash(checkpoint_path)
    require(checkpoint_hash == book["qualification"]["checkpoint_sha256"], "Qualified checkpoint fingerprint changed")
    checkpoint = json.loads(checkpoint_path.read_text(encoding="utf-8"))
    preview = book["verified_open_preview"]
    require(
        checkpoint["company"] == company
        and checkpoint["snapshots"] == book["snapshots"]
        and checkpoint["epochs"] == preview["state"],
        "Checkpoint no longer matches proof",
    )
    expected_state = preview["state"]
    expected_identity = {
        "company_id": company["id"],
        "database_id": company["database_id"],
        "taxpayer_id": company["taxpayer_id"],
    }
    integrity_contract = book["integrity_contract"]
    del checkpoint, book
    require(
        (root / "catalog.sqlite").is_file() and Path(company["path"]).is_file(),
        "Existing databases are required",
    )

    class ReadOnlyCatalog(catalog_module.Catalog):
        @contextmanager
        def connection(self, *, read_only=False, _cross_thread=False):
            require(read_only, "Diagnostic forbids catalog writes")
            with super().connection(read_only=True, _cross_thread=_cross_thread) as connection:
                yield connection

        def recover_operations(self):
            # Never resume pending publications during a read diagnostic.
            with self.connection(read_only=True) as connection:
                count = connection.execute(
                    "SELECT count(*) FROM company_operation WHERE status!='succeeded'"
                ).fetchone()[0]
            require(
                count == 0, "Catalog has unfinished operations; diagnostic will not recover them"
            )

    bundle = schema_bundle.production_bundle()
    catalog = ReadOnlyCatalog(root, bundle)
    require(
        catalog.database_format()["status"] == "released"
        and catalog.database_format()["version"] == 1,
        "Wrong catalog contract",
    )
    companies = catalog.companies()
    require(
        [row for row in companies if row["id"] == company["id"]] == [company],
        "Catalog company identity changed",
    )
    with catalog.connection(read_only=True) as connection:
        catalog_identity = dict(connection.execute("SELECT * FROM catalog_identity").fetchone())

    pool = resident_reads.ResidentReadPool(maximum=4)
    store = catalog.bind(company["id"], read_pool=pool)
    original_connection = store.connection

    @contextmanager
    def read_only_connection(*, read_only=False):
        require(read_only, "Diagnostic forbids company writes")
        with original_connection(read_only=True) as connection:
            yield connection

    store.connection = read_only_connection
    engine = engine_module.Engine(store)
    dashboard = dashboard_module.Dashboard(
        engine, company_name=company["name"], companies=companies
    )
    year, month = map(int, period.split("-"))
    quarter = (month - 1) // 3 + 1

    def check_state():
        with store.connection(read_only=True) as connection:
            connection.execute("BEGIN")
            state = list(connection.execute("SELECT * FROM state WHERE id=1").fetchone())
            identity = dict(
                connection.execute(
                    "SELECT company_id,taxpayer_id,database_id FROM identity WHERE id=1"
                ).fetchone()
            )
            require(
                state == expected_state and identity == expected_identity,
                "Company identity, business state or repair revision changed",
            )
            require(
                database_format(connection, bundle=bundle) == integrity_contract,
                "Company format differs from verified source",
            )
        with catalog.connection(read_only=True) as connection:
            require(
                dict(connection.execute("SELECT * FROM catalog_identity").fetchone())
                == catalog_identity,
                "Catalog identity changed",
            )
        require(catalog.companies() == companies, "Catalog registration changed")
        require(file_hash(checkpoint_path) == checkpoint_hash, "Construction checkpoint changed")
        return {"state": state, "identity": identity, "catalog_identity": catalog_identity}

    operations = {
        "brief": lambda: dashboard.brief(period, limit=20, preparation="deferred"),
        "quarterly_report": lambda: dashboard.quarterly_report(year, quarter, preparation="deferred"),
    }
    report = {
        "status": "diagnostic_started",
        "scope": "normal_native_close_header_overlap_observation",
        "instrumented": True,
        "browser_acceptance": False,
        "source": str(SOURCE), "source_sha256": SOURCE_SHA256,
        "manifest_sha256": MANIFEST_FILE_SHA256,
        "verified_report": str(BOOK_REPORT), "verified_report_sha256": REPORT_SHA256,
        "root": str(root), "checkpoint_sha256": checkpoint_hash,
        "period": period, "quarter": f"{year}-Q{quarter}",
        "calls": [], "responses": {},
        "notes": [
            "Two normal native page calls only; no verifier, preview, cProfile or acceptance timing.",
            "Every patched invocation always calls original verified_header; cache never bypasses proof.",
            "Before-call cache presence and full returned header equality are observed without mutation.",
            "Current registry version excludes fixed-v1; original historical decoder remains untouched.",
        ],
    }
    original = close_storage.verified_header
    active_page = None

    def observe(connection, row, *, require_marker=True):
        reads = storage._active_fact_reads.get()
        is_query_reads = isinstance(reads, query_reads.QueryReads)
        same_connection = is_query_reads and reads.connection is connection
        snapshot_active = is_query_reads and reads._snapshot_active
        content_version = getattr(reads.store.registry, "content_version", None) if is_query_reads else None
        owned = query_reads._owns_current_selector_snapshot(reads, connection)
        requested_period = row["period"]
        cache_present = is_query_reads and requested_period in reads._close_headers
        cached = reads._close_headers.get(requested_period) if cache_present else None
        frame = sys._getframe(1)
        callers = []
        for _ in range(5):
            if frame is None:
                break
            filename = Path(frame.f_code.co_filename).resolve()
            if filename.is_relative_to(SOURCE):
                callers.append({"file": filename.relative_to(SOURCE).as_posix(),
                                "function": frame.f_code.co_name, "line": frame.f_lineno})
            frame = frame.f_back
        del frame
        record = {
            "page": active_page, "period_ordinal": requested_period,
            "is_query_reads": is_query_reads, "same_connection": same_connection,
            "snapshot_active": bool(snapshot_active),
            "in_transaction": bool(connection.in_transaction),
            "content_version": content_version, "owned_current_snapshot": owned,
            "cache_present_before": cache_present, "require_marker": require_marker,
            "callers": callers, "status": "started",
        }
        report["calls"].append(record)
        try:
            actual = original(connection, row, require_marker=require_marker)
        except BaseException as error:
            record.update(status="original_failed", error_type=type(error).__name__,
                          error_code=getattr(error, "code", None),
                          cache_present_after=is_query_reads and requested_period in reads._close_headers)
            raise
        record.update(status="original_succeeded",
                      actual_logical_digest=actual.logical_digest.hex(),
                      actual_storage_digest=actual.storage_digest.hex(),
                      cached_header_full_equal=(cached == actual) if cached is not None else None,
                      cached_logical_digest=cached.logical_digest.hex() if cached is not None else None,
                      cached_storage_digest=cached.storage_digest.hex() if cached is not None else None)
        return actual

    with OUTPUT.open("x", encoding="utf-8") as output:
        try:
            report["before"] = check_state()
            close_storage.verified_header = observe
            try:
                for name, operation in operations.items():
                    active_page = name
                    result = operation()
                    require(result.get("read_context", {}).get("company_id") == company["id"],
                            f"{name}: wrong response company")
                    if name == "brief":
                        require(result["selected_period"]["key"] == period, "Wrong brief period")
                        for section, collection in result["data"]["collections"].items():
                            page = collection["page"]
                            require(len(collection["items"]) == page["returned_count"] == min(20, page["filtered_count"]),
                                    f"brief/{section}: incomplete default page")
                    report["responses"][name] = {
                        "schema_version": result["schema_version"],
                        "response_sha256": hashlib.sha256(canonical(result).encode("utf-8")).hexdigest(),
                    }
                    del result
                    check_state()
            finally:
                close_storage.verified_header = original
                active_page = None
            report["after"] = check_state()
            check_source()
            report["status"] = "diagnostic_complete"
        except BaseException as error:
            report["status"] = "diagnostic_failed"
            report["error"] = {"type": type(error).__name__, "message": str(error)}
            raise
        finally:
            close_storage.verified_header = original
            pool.close()
            json.dump(report, output, ensure_ascii=False, indent=2)
            output.write("\n")
    print(json.dumps({"status": report["status"], "output": str(OUTPUT)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
