# 24b9硬边界一次完整正确性结果

本轮只执行一次固定源原`benchmark_stage9_boundaries.py --full`，exit0，源756文件／manifest／完整额外文件清单及主仓库schema_contracts前后不变。与主48语义资格并行执行，所有elapsed／RSS仅诊断，不计纯性能验收。未启动240／1536MiB或前台浏览器，未重跑345回归或前端。

| 范围 | 真实结果 |
|---|---|
| 单份20MiB | 20971520 B实际登记；独立摘要18921b81551d588c3966d002dc7079104de9b66246b02a933bb7b4d6e0e25854，内容长度及新增evidence行断言通过 |
| 多1字节 | 20971521 B以evidence_too_large拒绝；evidence／fact_revision／bank children／request／audit物理计数全部不变 |
| 银行100000原行 | CSV7389036 B（8列，表头与控制行另计）；Materials.inspect公共第一页ready/item_count100000，全inspect_bytes解析100000原行无issues，整数分合计12300000；typed bank_statement实际保存100000子行，fact_revision/request/audit各增1 |
| 银行100001原行 | 原件合法登记后，公开Materials.inspect以material_too_large拒绝，物理计数不变：evidence3、fact_revision1、bank children100000、request5、audit5；未尝试typed超界保存 |
| 批量5000事实 | Engine.save_facts返回5000 results、事实版本实际增5000，request/audit各增1 |
| 批量5001事实 | ValueError拒绝；五类物理计数与接受后完全相同，无半写入 |

最终实际计数evidence3、fact_revision5001、fact_bank_statement_entries100000、request8、audit8。独立只读SQLite核查再次与原report一致；catalog/company均family ai-accounting-kernel/2、draft/0，必要identity与schema_history存在，读取前后数据库字节SHA不变。合成catalog owner/session均0，无凭据创建或Windows vault写入；本次无HTTP/server/browser进程。child exited、root和原件保留，未操作真实root、5173或已有进程。

原report SHA `037ad84be28775997968fb6b13a077cff143450b8c80b5d680e423e2dae7802e`；源SHA `24b9b8b65723cee8c6982b1f41235dce380e62788db33f100176f92c714571fc`；manifest文件SHA `9d81e82d7e2637637cc052cd42ff80946c6a0274264473d53f1d22a6f48fcef5`。

原件：`stage9-open-scope-evidence-resource-20261004-boundaries-root/report.json`、`-boundaries-runner.json`、`-boundaries-run.log`、`-boundaries-inspection.json`，均位于`.tmp`。首个post-run owned只读inspector遗漏database_format必需bundle参数而TypeError，原helper和`-boundaries-inspection-first-failure.json`保留；新`-boundaries-inspect-fix1.py`传入明确production_bundle/kind后一次读取通过，未重跑任何业务边界。该辅助检查错误不隐藏、不合并成首轮通过。

本次没有5000事实的计算预览／发布、十万银行行整页浏览器或超界typed银行直接保存实证；不存在证据规模／备份恢复／前台渲染／500ms性能结论。两档资源验收继续等待主任务明确开始。
