import hashlib
import json
from pathlib import Path
import sqlite3
import sys

workspace = Path(__file__).resolve().parents[1]
source = workspace / '.tmp/stage9-build-source-open-scope-group-candidate-20261004'
root = workspace / '.tmp/stage9-open-scope-evidence-resource-20261004-boundaries-root'
output = workspace / '.tmp/stage9-open-scope-evidence-resource-20261004-boundaries-inspection.json'
assert not output.exists()
sys.path.insert(0, str(source / 'src'))
from ai_accounting.kernel.versions import database_format
from ai_accounting.kernel.schema_bundle import production_bundle

report = json.loads((root / 'report.json').read_text(encoding='utf-8'))
runner = json.loads((workspace / '.tmp/stage9-open-scope-evidence-resource-20261004-boundaries-runner.json').read_text(encoding='utf-8'))
assert runner['exit_code'] == 0 and runner['source_and_contract_unchanged']
result = {'status': 'passed', 'timing_class': 'diagnostic_concurrent_with_main48_qualification_not_performance_acceptance',
    'observations': {}, 'report_sha256': runner['report_sha256'], 'source_and_contract_unchanged': True}
for kind, path, table in [('catalog', root / 'catalog.sqlite', 'catalog_identity'),
                          ('company', next(root.glob('*/company.sqlite')), 'identity')]:
    before = hashlib.sha256(path.read_bytes()).hexdigest()
    connection = sqlite3.connect(path.as_uri() + '?mode=ro', uri=True)
    try:
        connection.execute('PRAGMA query_only=ON')
        format_ = database_format(connection, bundle=production_bundle(), kind=kind)
        assert format_['status'] == 'draft' and format_['version'] == 0 and format_['kind'] == kind
        identity = connection.execute(f'SELECT * FROM {table}').fetchall()
        history = connection.execute('SELECT version,hex(fingerprint),installed_at FROM schema_history').fetchall()
        data = {'database_format': format_, 'identity': identity, 'schema_history': history}
        if kind == 'catalog':
            data['owner_count'] = connection.execute('SELECT count(*) FROM security_owner').fetchone()[0]
            data['session_count'] = connection.execute('SELECT count(*) FROM security_session').fetchone()[0]
            assert data['owner_count'] == data['session_count'] == 0
        else:
            counts = {name: connection.execute(f'SELECT count(*) FROM {name}').fetchone()[0]
                      for name in report['final_physical_counts']}
            assert counts == report['final_physical_counts']
            data['physical_counts_match_report'] = counts
    finally:
        connection.close()
    data['database_sha256'] = hashlib.sha256(path.read_bytes()).hexdigest()
    assert data['database_sha256'] == before
    data['inspection_did_not_change_database_bytes'] = True
    result['observations'][kind] = data
with output.open('x', encoding='utf-8', newline='\n') as stream:
    json.dump(result, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
print(json.dumps({'status': result['status'], 'output': str(output)}, ensure_ascii=False))
