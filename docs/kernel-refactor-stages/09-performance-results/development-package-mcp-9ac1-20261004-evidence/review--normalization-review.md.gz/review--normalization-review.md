# MCP response comparison: bounded read-only review

This is the root's record of the completed read-only review reported by
`converged_draft_package_check`, not an independently rerun test or a replacement
for the original request/response records. No source, product data, helper,
receipt, or response artifact was modified by this review.

The `stable(v)` helper in
`.tmp/stage9-development-delivery-directory-converged-9ac1-20261004/mcp-nonempty-read/attempt5/run.py`
at lines 31-34 recursively removes keys named `generated_at` and `checked_at`
at every depth. Comparison calls occur at lines 128, 130, 144, and 147. This is
overbroad and must not be described as a path whitelist implementation.

The agent compared the saved baseline and both generations of the 44 actual
command responses before normalization. The only differing paths were
`/data/generated_at` in the three monthly `dashboard_brief` responses and
`/checked_at` in the quarterly report. There are exactly four matching
metadata locations in this baseline. The fixed source's `dashboard.py` lines
1780, 1982, and 4769 produce those response values using
`datetime.now(UTC).isoformat()`.

The frozen January/February reports and adopted content, asset details,
business dates, request results, pagination, and selected-account responses
had no other raw differences. Frozen business evidence in these responses did
not contain matching nested keys that the helper could have erased. The
actual bounded comparison therefore remains supported by the raw records;
the helper's general correctness is not established. Future helpers should
exclude only the explicitly known dynamic response paths.

This review did not run tests, access databases, start services, or measure
performance. It does not expand the MCP run to payroll, GUI interaction,
forced interruption, multiple companies, or 500 ms acceptance.
