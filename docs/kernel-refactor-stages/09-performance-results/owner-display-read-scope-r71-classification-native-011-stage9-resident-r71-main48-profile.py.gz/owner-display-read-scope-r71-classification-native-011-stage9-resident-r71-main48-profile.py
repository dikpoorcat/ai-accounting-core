"""Run the established fixed-source diagnostic with distinct r71 artifacts.

The existing synthetic book is read only. Prior full verification is identified
as prior evidence; these native/profile measurements are not page acceptance.
"""
from pathlib import Path

previous = Path(__file__).with_name("stage9-resident-r64-main48-profile.py")
source = previous.read_text(encoding="utf-8")
assert source.count("stage9-build-source-owner-r64-release") == 1
assert source.count("stage9-owner-main48-r63-verified.json") == 1
exec(compile(source.replace("r64", "r71"), str(previous), "exec"))
