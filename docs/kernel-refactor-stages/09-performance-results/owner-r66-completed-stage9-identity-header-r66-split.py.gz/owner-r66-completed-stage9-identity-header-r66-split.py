"""Read-only SQL transport diagnostic; never used as an accounting response."""
from pathlib import Path
import ast
import inspect
import json
import sys
import textwrap
import time

w = Path(__file__).resolve().parents[1]
src = w / '.tmp/stage9-build-source-owner-r66-release'
sys.path.insert(0, str(src / 'scripts'))
from stage9_source import configure_source
configure_source(src, w)
from ai_accounting.kernel.catalog import Catalog
from ai_accounting.kernel.query_reads import QueryReads
from ai_accounting.kernel.resident_reads import ResidentReadPool
from ai_accounting.kernel.types import canonical, YearMonth

book = json.loads((w / '.tmp/stage9-owner-main48-r63-verified.json').read_text('utf-8'))
catalog = Catalog(Path(book['root']))
pool = ResidentReadPool()
with catalog.connection(read_only=True) as connection:
    company = dict(connection.execute('SELECT * FROM company WHERE id=?',
                                     (book['company']['id'],)).fetchone())
    store = catalog._bound_store(company, read_pool=pool)
tree = ast.parse(textwrap.dedent(inspect.getsource(QueryReads.calculation_identity_headers)))
sql = next(node.args[0].value for node in ast.walk(tree) if isinstance(node, ast.Call)
           and isinstance(node.func, ast.Attribute) and node.func.attr == 'execute')
out = {'scope':'read_only_header_sql_transport_diagnostic_not_page_acceptance',
       'source':str(src), 'root':str(store.path), 'variants':{}}
try:
    with pool.borrow(store) as connection:
        connection.execute('BEGIN')
        ids = [row[0] for row in connection.execute(
            "SELECT c.id FROM calculation_current h JOIN calculation c ON c.id=h.calculation_id "
            "JOIN subject s ON s.id=c.subject_id WHERE s.kind IN ('payroll','bounded_payroll') "
            "AND c.period<=?", (YearMonth('2019-12').ordinal,))]
        out['identity_count'] = len(ids)
        out['cache_kib'] = -connection.execute('PRAGMA cache_size').fetchone()[0]
        cases = {
            'full_header':sql,
            # A diagnostic control only: NULL values never go to a consumer.
            'without_post_body_fields':sql.replace('c.digest source_digest,',
                'NULL source_digest,').replace('c.program_version source_program_version,',
                'NULL source_program_version,'),
        }
        for name, statement in cases.items():
            params = (canonical(sorted(ids)),)
            out['variants'][name] = {'plan':[tuple(row) for row in connection.execute(
                'EXPLAIN QUERY PLAN '+statement, params)], 'samples':[]}
            for attempt in range(5):
                begin = time.perf_counter()
                cursor = connection.execute(statement, params)
                executed = time.perf_counter()
                rows = cursor.fetchall()
                fetched = time.perf_counter()
                names = [item[0] for item in cursor.description]
                values = [dict(zip(names,row,strict=True)) for row in rows]
                converted = time.perf_counter()
                out['variants'][name]['samples'].append({
                    'execute_ms':(executed-begin)*1000,'fetch_ms':(fetched-executed)*1000,
                    'convert_ms':(converted-fetched)*1000,'rows':len(values)})
        connection.rollback()
    with (w / '.tmp/stage9-identity-header-r66-split.json').open('x',encoding='utf-8') as handle:
        json.dump(out,handle,ensure_ascii=False,indent=2)
    print(json.dumps(out,ensure_ascii=False),flush=True)
finally:
    pool.close()
