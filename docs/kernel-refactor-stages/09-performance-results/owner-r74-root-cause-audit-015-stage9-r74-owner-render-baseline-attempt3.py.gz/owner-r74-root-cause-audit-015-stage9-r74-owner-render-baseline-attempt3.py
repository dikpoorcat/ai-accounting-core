from pathlib import Path
import sys,json,threading,subprocess,os
w=Path(__file__).resolve().parents[1];src=w/'.tmp/stage9-build-source-owner-r73-release'
sys.path.insert(0,str(src/'scripts'))
from stage9_source import configure_source
configure_source(src,w)
from ai_accounting.kernel.daemon import _prepare_static_runtime,ServiceClient,build_native_security_controller
from ai_accounting.kernel.service import LocalService
from ai_accounting.kernel.http import create_server
from ai_accounting.kernel.security.credentials import InMemoryCredentialStore
from pydantic import SecretStr
book=json.loads((w/'.tmp/stage9-owner-main12-r73-verified.json').read_text('utf8'))
assert book['status']=='complete' and book['source']==str(src)
root=Path(book['root']);assert root==w/'.tmp/stage9-owner-main12-r43'
output=w/'.tmp/stage9-r74-owner-render-baseline-attempt3.json';assert not output.exists()
app=LocalService(root,enable_read_pool=True,_static_runtime=_prepare_static_runtime())
token=None;server=None;result={'status':'failed'}
try:
    with app.catalog.connection(read_only=True) as c: owners=[r[0] for r in c.execute('SELECT login_name FROM security_owner')]
    assert owners==['synthetic-stage9-owner']
    token=app.security.login(owners[0],SecretStr('Synthetic-stage9-browser-only-2026')).session_token
    credentials=InMemoryCredentialStore();credentials.save_session_token(token)
    server,capability=create_server(app,port=0,static_directory=src/'src/ai_accounting/static/dashboard')
    app.security_controller=build_native_security_controller(app,server,capability,credential_store=credentials,window_opener=lambda _:None)
    thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    metadata={'protocol':2,'database_format':app.catalog.database_format(),'pid':os.getpid(),'port':server.server_port,'capability':capability,'catalog_id':app.security.catalog_instance_id,'build_id':server.build_id}
    client=ServiceClient(root,metadata=metadata,credential_store=credentials)
    cfg={'origin':f'http://127.0.0.1:{server.server_port}','ticket_url':client.browser_url()['url'],'company_id':book['company']['id'],'period':'2019-12'}
    env=dict(os.environ,STAGE9_PLAYWRIGHT_MODULE='C:/Users/MD01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright')
    proc=subprocess.run(['C:/Users/MD01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe',str(w/'.tmp/stage9-r74-owner-render-baseline.cjs')],input=json.dumps(cfg),capture_output=True,text=True,encoding='utf8',env=env,timeout=90)
    result=json.loads(proc.stdout);result['returncode']=proc.returncode
finally:
    if token is not None:app.security.logout(token);result['session_revoked']=True
    if server is not None:server.shutdown();thread.join(timeout=5);server.server_close()
    app.close();result.update(source=str(src),root=str(root),app_closed=True,preview_created=False)
    with output.open('x',encoding='utf8') as f:json.dump(result,f,ensure_ascii=False,indent=2)
print(json.dumps(result,ensure_ascii=False))
