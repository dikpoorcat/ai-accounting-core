from pathlib import Path
import hashlib
import json
import statistics
import sys
import time

w=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(w/'scripts'))
from stage9_source import configure_source
configure_source(w,w)
from ai_accounting.kernel.catalog import Catalog
from ai_accounting.kernel.dashboard import Dashboard
from ai_accounting.kernel.dashboard_funds import FundsRead
from ai_accounting.kernel.daemon import _prepare_static_runtime
from ai_accounting.kernel.engine import Engine
from ai_accounting.kernel.resident_reads import ResidentReadPool
from ai_accounting.kernel.types import canonical
from stage9_metrics import measure_work

book=json.loads((w/'.tmp/stage9-owner-main48-r73-verified.json').read_text('utf-8'))
assert book['status']=='complete' and book['integrity']['status']=='verified'
assert Path(book['root'])==w/'.tmp/stage9-owner-main48-r63'
_prepare_static_runtime()
pool=ResidentReadPool()
catalog=Catalog(Path(book['root']))
with catalog.connection(read_only=True) as connection:
    row=dict(connection.execute('SELECT * FROM company WHERE id=?',(book['company']['id'],)).fetchone())
    store=catalog._bound_store(row,read_pool=pool)
engine=Engine(store)
dashboard=Dashboard(engine,company_name=row['name'],companies=[row])
helper=FundsRead._verified_money_effects
out={'status':'running','source':str(w),'root':book['root'],'prior_verified_source':book['source'],
     'current_full_integrity':'not_run','diagnostic_not_browser_acceptance':True,
     'source_sha256':{p:hashlib.sha256((w/p).read_bytes()).hexdigest() for p in ('src/ai_accounting/kernel/dashboard_funds.py','tests/kernel/test_funds_verified_money_effects.py')},
     'native_runs':[],'isolated':{},'work':{}}
try:
    with dashboard._snapshot('2019-12') as snap:
        snap.month_journal.account_amounts()
        reader=FundsRead(snap)
        reader.events(current=True)
        def measure(call):
            vm=[0]
            def progress(): vm[0]+=100; return 0
            snap.connection.set_progress_handler(progress,100)
            started=time.perf_counter()
            result=call()
            elapsed=(time.perf_counter()-started)*1000
            snap.connection.set_progress_handler(None,0)
            return result, {'ms':elapsed,'vm_steps':vm[0]}
        for name, method in [('original_sql',lambda self:None),('verified_effects',helper)]:
            FundsRead._verified_money_effects=method
            measurements=[]
            for _ in range(20):
                def call():
                    source,params=reader.movements()
                    return [dict(r) for r in snap.connection.execute('SELECT category,balance_key,sum(signed_amount) amount,count(*) n FROM ('+source+') GROUP BY category,balance_key',params)]
                result, sample=measure(call)
                measurements.append(sample)
                if name=='original_sql': expected=result
                else: assert result==expected
            out['isolated'][name]={'samples':measurements,'median_ms':statistics.median(x['ms'] for x in measurements),'median_vm_steps':statistics.median(x['vm_steps'] for x in measurements)}
        FundsRead._verified_money_effects=helper
        construction=[]
        for _ in range(20):
            started=time.perf_counter();effects=helper(reader);raw=canonical(effects)
            construction.append((time.perf_counter()-started)*1000)
        event_source,event_params=reader.events(current=True)
        source_rows=snap.connection.execute(event_source+'SELECT count(*) rows,sum(length(CAST(outcome AS BLOB))) bytes FROM events',event_params).fetchone()
        out['input']={'effects_rows':len(effects),'effects_utf8_bytes':len(raw.encode()),'source_events_rows':source_rows['rows'],'source_events_outcome_utf8_bytes':source_rows['bytes'],
                      'construction_ms':construction,'construction_median_ms':statistics.median(construction),
                      'body_proof_decodes_added':0,'note':'Source bytes describe the former materialized events relation; returned application rows/bytes are measured separately.'}
    for _ in range(2): dashboard.brief('2019-12',limit=20)
    for i in range(12):
        order=[('original_sql',lambda self:None),('verified_effects',helper)]
        if i%2: order.reverse()
        for name,method in order:
            FundsRead._verified_money_effects=method
            started=time.perf_counter();response=dashboard.brief('2019-12',limit=20)
            elapsed=(time.perf_counter()-started)*1000
            out['native_runs'].append({'name':name,'ms':elapsed})
            response['data']['generated_at']=None
            hashed=hashlib.sha256(canonical(response).encode()).hexdigest()
            if 'response_hash' not in out: out['response_hash']=hashed
            assert out['response_hash']==hashed
    for name,method in [('original_sql',lambda self:None),('verified_effects',helper)]:
        FundsRead._verified_money_effects=method
        work,response=measure_work(engine,lambda:dashboard.brief('2019-12',limit=20))
        out['work'][name]=work
    out['native_median_ms']={name:statistics.median(x['ms'] for x in out['native_runs'] if x['name']==name) for name in ('original_sql','verified_effects')}
    out['status']='complete'
except BaseException as error:
    out['status']='failed';out['error']=repr(error)
    raise
finally:
    FundsRead._verified_money_effects=helper
    pool.close()
    (w/'.tmp/stage9-r77-verified-money-cost.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:out[k] for k in ('status','native_median_ms') if k in out}),flush=True)
