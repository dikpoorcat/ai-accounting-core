from pathlib import Path
import json
import sqlite3
import sys
from contextlib import closing

root = Path(__file__).resolve().parents[1]
source = root / '.tmp/stage9-build-source-r35-release'
sys.path.insert(0, str(source / 'src'))
from ai_accounting.kernel.schema_bundle import production_bundle
from ai_accounting.kernel.versions import verify_schema

staging = root / '.tmp/stage9-reseed-main-12-r35.staging'
bundle = production_bundle()
result = {'status': 'failed_construction_preserved', 'final_root_exists': (root / '.tmp/stage9-reseed-main-12-r35').exists()}
assert not result['final_root_exists']
with closing(sqlite3.connect((staging / 'catalog.sqlite').as_uri() + '?mode=ro', uri=True)) as connection:
    connection.row_factory = sqlite3.Row
    connection.execute('BEGIN')
    verify_schema(connection, bundle=bundle, kind='catalog')
    result['bound_companies'] = connection.execute('SELECT count(*) FROM company').fetchone()[0]
    result['operations'] = connection.execute('SELECT count(*) FROM company_operation').fetchone()[0]
with closing(sqlite3.connect((staging / '91310000123456789S/company.sqlite').as_uri() + '?mode=ro', uri=True)) as connection:
    connection.row_factory = sqlite3.Row
    connection.execute('BEGIN')
    verify_schema(connection, bundle=bundle)
    result['target_initial_rows'] = {}
    for row in connection.execute("SELECT name FROM sqlite_schema WHERE type='table' AND name NOT LIKE 'sqlite_%'"):
        name = row[0]
        quoted = '"' + name.replace('"', '""') + '"'
        count = connection.execute(f'SELECT count(*) FROM {quoted}').fetchone()[0]
        if count:
            result['target_initial_rows'][name] = count
    result['target_business_counts'] = {name: connection.execute(f'SELECT count(*) FROM {name}').fetchone()[0]
                                       for name in ('fact_revision', 'calculation', 'period_close', 'evidence')}
assert result['bound_companies'] == result['operations'] == 0
assert set(result['target_business_counts'].values()) == {0}
out = root / '.tmp/stage9-reseed-r35-failure-audit.json'
with out.open('x', encoding='utf-8') as handle:
    json.dump(result, handle, ensure_ascii=False, indent=2)
print(json.dumps(result, ensure_ascii=False))
