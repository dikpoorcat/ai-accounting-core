"""Restore exactly this group's three guarded originals; preserve the prototype."""
from pathlib import Path
import hashlib
import json
import os

W = Path(__file__).resolve().parents[1]
capsule = W / '.tmp/stage9-journal-contribution-candidate-source-20261004'
manifest_path = capsule / 'manifest.json'
manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
targets = {name: W / 'src/ai_accounting/kernel' / name for name in manifest}
test = W / 'tests/kernel/test_journal_contribution_summary.py'
sealed_test = W / '.tmp/stage9-build-source-journal-contribution-candidate-fixed-20261004/tests/kernel' / test.name
saved_test = capsule / (test.name + '.candidate')
output = capsule / 'withdrawal.json'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

assert not output.exists() and not saved_test.exists()
assert set(targets) == {'dashboard_reads.py', 'query_reads.py', 'report_open_contribution.py'}
for name, target in targets.items():
    assert target.resolve().parent == W / 'src/ai_accounting/kernel'
    assert sha(target) == sha(capsule / (name + '.candidate')) == manifest[name]['candidate_sha256']
    assert sha(capsule / (name + '.before')) == manifest[name]['before_sha256']
assert sha(test) == sha(sealed_test)
with saved_test.open('xb') as handle:
    handle.write(test.read_bytes())
restored = []
for name, target in targets.items():
    pending = target.with_name(target.name + '.journal-withdraw.pending')
    assert not pending.exists()
    with pending.open('xb') as handle:
        handle.write((capsule / (name + '.before')).read_bytes())
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(pending, target)
    assert sha(target) == manifest[name]['before_sha256']
    restored.append(name)
assert sha(test) == sha(saved_test)
test.unlink()
record = {'status': 'withdrawn', 'production_files_restored_exact_originals': restored,
          'prototype_test_preserved_sha256': sha(saved_test),
          'prototype_test_removed_from_active_test_suite': not test.exists(),
          'other_production_tests_or_original_archives_changed': False,
          'reason': 'Full-contribution reader increases brief returned bytes and VM work; one report row saved is immaterial.',
          'snapshot_candidate_preserved': True, 'databases_services_or_realdata_operated': False}
with output.open('x', encoding='utf-8') as handle:
    json.dump(record, handle, ensure_ascii=False, indent=2)
    handle.write('\n')
print(json.dumps(record, ensure_ascii=False))
