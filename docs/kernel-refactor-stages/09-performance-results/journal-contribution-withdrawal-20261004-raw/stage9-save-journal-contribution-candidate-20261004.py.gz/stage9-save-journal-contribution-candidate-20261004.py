from pathlib import Path
import hashlib,json
root=Path.cwd(); out=root/'.tmp/stage9-journal-contribution-candidate-source-20261004'; out.mkdir(exist_ok=True)
baseline=root/'.tmp/stage9-build-source-surviving-read-consumers-fixed-20261003/src/ai_accounting/kernel'
files=['dashboard_reads.py','query_reads.py','report_open_contribution.py']; records={}
for name in files:
 p=root/'src/ai_accounting/kernel'/name
 candidate=p.read_bytes(); text=p.read_text(encoding='utf-8')
 (out/(name+'.candidate')).write_bytes(candidate)
 if name=='dashboard_reads.py':
  text=text.replace('            _owns_current_selector_snapshot,\n','',1)
  text=text.replace('        Open owned publications can prove their exact rows through immutable\n        contributions; other selections consume the saved owner/adopted result.\n        Full historical verification retains its complete independent checks.','        This consumes the saved owner and adopted result, not their ancestors\n        or a second financial-position calculation. Full historical verification\n        retains its independent complete dependency and evidence checks.',1)
  start=text.index('        # The contribution never selects an owner, current head or frozen leaf.')
  end=text.index('        outcomes = reads.verify_selected_content(identifiers - eligible.keys())',start)+len('        outcomes = reads.verify_selected_content(identifiers - eligible.keys())\n')
  text=text[:start]+text[end:]
  text=text.replace('        expected_lines = {}\n\n\n','        expected_lines = {}\n\n',1)
  marker='        metadata = reads.metadata(\n            {frozen_vouchers[row["id"]]["adopted_calculation_id"]'
  assert text.count(marker)==1
  text=text.replace(marker,'        outcomes = reads.verify_selected_content(identifiers)\n'+marker,1)
 elif name=='query_reads.py':
  text=text.replace('        self._verified_physical_facts = set()\n','',1)
  start=text.index('        reusable = (',text.index('    def _verify_selected_fact_bodies'))
  end=text.index('        kinds, fact_periods, fact_digests = {}, {}, {}',start)
  text=text[:start]+'        headers = tuple(headers)\n'+text[end:]
  text=text.replace('            if reusable:\n                self._verified_physical_facts.update(keys)\n','',1)
  text=text.replace('        if reusable:\n            self._verified_physical_facts.update(keys)\n','',1)
 else:
  start=text.index('def read_journal_contributions(');end=text.index('def read_open_contributions(',start)
  text=text[:start]+text[end:]
 old=(baseline/name).read_bytes()
 if text!=(baseline/name).read_text(encoding='utf-8'):
  print(''.join(__import__('difflib').unified_diff((baseline/name).read_text(encoding='utf-8').splitlines(keepends=True),text.splitlines(keepends=True))))
  raise AssertionError(name)
 (out/(name+'.before')).write_bytes(old)
 records[name]={'before_sha256':hashlib.sha256(old).hexdigest(),'candidate_sha256':hashlib.sha256(candidate).hexdigest(),'baseline_exact_after_reversing_candidate':True}
(out/'manifest.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
print(json.dumps(records,indent=2))
