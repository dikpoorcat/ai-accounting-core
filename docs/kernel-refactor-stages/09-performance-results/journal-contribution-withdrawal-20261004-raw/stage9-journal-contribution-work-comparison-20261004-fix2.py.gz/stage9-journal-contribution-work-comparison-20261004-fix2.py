"""Compare retained actual work, preserving both earlier metadata failures."""
from pathlib import Path
import hashlib
import json

W = Path(__file__).resolve().parents[1]
def load(name):
    return json.loads((W / '.tmp' / name).read_text(encoding='utf-8'))
old_name = 'stage9-journal-contribution-work-before-dd86-20261004.json'
new_name = 'stage9-journal-contribution-work-after-candidate-20261004.json'
old, new = load(old_name), load(new_name)
reg = load('stage9-input-and-verified-totals-regression-20261004.json')
output = W / '.tmp/stage9-journal-contribution-work-comparison-20261004-fix2.json'
assert not output.exists()
assert old['status'] == new['status'] == 'diagnostic_complete'
for item in (old, new):
    assert item['all_file_identity_state_history_registration_repair_guards_equal']
    assert item['source_inventory_unchanged']
rows = []
for before, after in zip(old['observations'], new['observations'], strict=True):
    assert before['page'] == after['page']
    a, b = before['actual_work']['counters'], after['actual_work']['counters']
    rows.append({'page': before['page'],
        'complete_response_equal_except_response_clocks': before['complete_response_sha256'] == after['complete_response_sha256'],
        'before_after': {key: [a[key], b[key]] for key in (
            'sql_calls', 'sqlite_vm_steps', 'returned_rows', 'returned_value_bytes',
            'calculation_result_rows_loaded', 'calculation_result_bytes_loaded',
            'calculation_result_json_decodes', 'report_contribution_json_decodes')},
        'instrumented_times_not_latency_acceptance_ms': [before['actual_work']['instrumented_ms'], after['actual_work']['instrumented_ms']]})
current = {name: hashlib.sha256((W / name).read_bytes()).hexdigest() for name in reg['files_before']}
assert current == reg['files_before'] and reg['files_unchanged'] is True
record = {'status': 'candidate_rejected_and_exactly_withdrawn',
    'original_before_sha256': hashlib.sha256((W / '.tmp' / old_name).read_bytes()).hexdigest(),
    'original_after_sha256': hashlib.sha256((W / '.tmp' / new_name).read_bytes()).hexdigest(),
    'comparison_script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'observations': rows,
    'current_all_prior_316_regression_source_and_test_hashes_match_exactly': True,
    'prior_regression_bound_files': len(current), 'new_regression_browser_or_business_read_operations': 0,
    'earlier_comparison_failures_preserved': [
        {'script': 'stage9-journal-contribution-work-comparison-20261004.py', 'type': 'AssertionError', 'scope': 'Response digest equality, context equal but five main responses unequal.'},
        {'script': 'stage9-journal-contribution-work-comparison-20261004-fix1.py', 'type': 'KeyError', 'scope': "Regression receipt contains files_unchanged and files_before, not files_after."}],
    'reason': 'Brief returned bytes nearly double and VM work materially increases. One report row/40 bytes saved is insufficient to keep the physical-proof-only candidate.',
    'limitations': [
        'Before is sealed dd86; later evidence-input and nonnegative-sum groups also differ. Their response semantics and row/decode/read-byte scopes are unchanged.',
        'VM steps are sampled every 100 instructions; a 100-step difference is not evidence of benefit or regression.',
        'Instrumented elapsed time and native reads are not pure HTTP/browser 500 ms acceptance.',
        'Five main response hashes include build-bound read_context.read_version and differ. Full cross-source response equivalence is unverified; no extra read was made to claim it.',
        'Exact current code/test identity with the successful 316 regression creates no new qualification or page performance result.']}
with output.open('x', encoding='utf-8') as handle:
    json.dump(record, handle, ensure_ascii=False, indent=2)
    handle.write('\n')
print(json.dumps({'status': record['status'], 'bound_files': len(current), 'observations': rows}, ensure_ascii=False, indent=2))
