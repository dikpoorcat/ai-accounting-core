# Stage 9 金额贡献独立核验

2026-10-04，GPT-6.1 Sol / high。只读设计及源码核验；仅写此临时记录。已读 AGENTS.md 与 stage9-money-contribution-summary-design-20261004.md。未改 production、tests、docs、DB 或服务；未跑测试、benchmark 或 qualification。本文不表示性能收益已验证。

## 静态结论

方向成立，不能以“每次读取都必须 full decode”否定。`Engine.confirm.operation` 在同一 `BEGIN IMMEDIATE` 事务内先发布真实凭证，再 mint contribution，最后 `integrity.verify_publication` 完整 `_check_sources`，逐行严格核实际 voucher 与 saved outcome.lines，并验证 balance、total、publication。`_write` 只在这些检查成功后 commit，异常回滚。因此，已提交的独立 immutable anchor 可承载当时已证明的 line 语义。读取时贡献正文 SHA 对独立 anchor、source binding 对真实 header digest、raw canonical SHA 对真实来源字节，三层均成立时，可复用当时 line 语义，不必再解码同一 outcome。

这只说明当前实际行等于提交时已核验行，以及源仍匹配独立绑定。它不是当次重新解析 outcome.lines，也不是完整 saved-input、ancestor、evidence、current/frozen selection 或 close adoption proof。原有 Journal 只消费 owner/basis/必要 frozen 和 reversal source；不得借窄证明扩大或缩小这些来源范围。

## 必要保护条件

1. eligibility 在权威 selection 成功之后确定。仅真正 owned、当前 codec 的同 connection、active transaction snapshot；优先统一 `_owns_current_selector_snapshot` 的条件。正式月份或任意 selected frozen reference 保留旧路径。逐 voucher 分流，不能一项不合格令健康 eligible 全月失效。
2. owner、basis、selected calculation 必须同一 ID，非 reversal，publication mode 为 initial/open_replace。保留 publication record hash、subject、posting period、voucher_id 和当前版本关系核验。review_no_impact 沿用旧 owner，closed correction/reversal 必须保留 original 与 frozen adopted proof。initial 并不等于 opening：期初及 asset member 仍须明确排除，不能只凭有 publication 推定允许。asset batch/month owner 若自身符合这些条件，仅证明其 own voucher lines；不得借此取消独立 member 消费者的 membership/采用核验。
3. 贡献正文来源必须是独立 anchor。缺 immutable anchor 是损坏，拒绝；存在的坏 body/digest/anchor/identity/source binding/parents 不得 fallback 掩盖。缺 repairable body 才能走既有 full source 重建并核原 anchor；读取不得 mint 新 anchor、写 DB 或启动 repair。
4. 贡献里的当前 own version 行必须精确、连续 1..N、无重复/额外同 version 行，完整匹配 actual 四字段并用 `_lines` 严格整数、非负、单边、account/cashflow、int64 与平衡规则核验，再核 total。只找到每个 actual 行不足以排除 contribution 多出的同 version 行。
5. source binding 必须绑定独立贡献中的 result digest/fact ID/fact digest；来源实际 header identity、calculation/fact seals 与 physical period/child order 均核验。parents 必须与实际 dependency_calculation 全集合一致；直接消费来源仍需是已记录 parent 并核其实体来源。未消费 ancestor 不因本 proof 自动获得完整成功标记。
6. raw SHA 成功不是 decoded semantic proof，但这里独立 anchor 把历史 canonical bytes 与已核 line 语义连接起来。同改 source + live digest 仍与旧 anchor binding 冲突，必须拒绝。raw SHA 不匹配时只走既有 strict `_object`/unique-member decoder 和 decoded digest 对比；等价非 canonical JSON 可保留旧语义，duplicate JSON 必须拒绝。不得写一个仅解析 lines 的新 decoder。
7. Journal summary/count/verified rows 仅整月全部 row 分支成功后发布。窄 proof 不得写 `_verified_source_contents`、`_verified_saved_input_identities`、full adoption 完成标记。缓存只接受成功 proof，失败不能留下可复用成功结论；普通外部 QueryReads 和 fixed v1 保持原行为。
8. physical fact 成功复用 key 至少 `(fact_id,fact_kind,fact_period,fact_digest)`，只在 owned/current snapshot，且调用方每次仍验证实际 header identity/seals。child order、physical period、raw/scalar hashes 或 strict decoder 的全部待核事实成功后才批量发布成功 key。`_raw_fact_data`、raw hash 命中、某一 scalar 成功不单独提升为完整 physical proof；reset 清空。

## 消费者边界

Journal 只复用四字段凭证金额语义。funds 仍需其 full outcomes，employees/assets/期初/累计/闭期采用沿用完整领域路径。按需 activity/voucher 明细若消费完整正文仍调用原 full content reader。report `_party_delta` 和 `Reports.report` 已有 contribution 字段/关系快路径：它们匹配权威 selected line，保留 classification 与 party fallback，不能因本次 Journal 改动取消其范围或 current/frozen 核验。关闭、备份、恢复、独立 full verification、维修仍完整核验与重建，不消费窄 proof 为完成结论。source_bindings 验真自身不证明 publication/owner 权威；Journal 不能仅调用它代替既有 selection 检查。

## 最小针对验证建议

- healthy initial/open_replace 及同月混合 review/reversal/closed：响应金额和整月 summary 与原路径等价；只有 eligible owner 避免 full decode，后续真正 full consumer 仍 decode。
- source outcome 改 lines，source+live digest 同改，fact/source seal 缺失，physical fact child order/period 破坏，parents 删改，body+body digest 同改但 anchor 不变：均失败，且不发布 summary/full source proof。physical fact 分组本身失败不得发布该组任何新 key；物理 proof 已完整成功而后续 outcome 失败时，物理成功 key 仍是真实结论，不属于 poison。
- immutable anchor 缺失拒绝；repairable body 缺失经 full source 重建与原 anchor 相等后可读，DB/repair revision 不变；重建不等则失败。
- noncanonical 等价 raw 使用 strict fallback；duplicate member 即使普通 JSON decoder 能读也拒绝。current own version 多行、重复 line_no、bool/float 金额、额外同 version 行和 total 异常均拒绝。
- 同 snapshot anchored proof 后 full consumer 对完全相同 facts 只做一次 physical proof；混合 pending 失败不发布任何 pending key；新 snapshot、nonowned、v1、不同 binding/period/kind/digest 均不可借旧成功结论。scope 拒绝后 summary/verified rows 为空；独立 close/full verifier 仍调用完整来源路径。

## 当前审查范围

已静态核对 engine mint/commit、integrity `_lines`/`_check_sources`、QueryReads snapshot/anchored source/fact proofs、Journal account_amounts 与 report contribution consumers。以上是验收边界，并非测试通过结论。

## 首轮实现只读核对

已读实现 agent 写入的三处候选（未运行）。Journal 保留旧 selection/frozen/reversal/publication 检查，在 publication 检查之后确定 ordinary/nonopening，贡献只给 expected_lines，full identifiers 仅剔除成功 own rows；原 actual 全行比较、total、basis、frozen、summary 发布仍在末端。过滤贡献当前 version 完整集合，再核连续 line_no，最终 actual 与 expected 全列表相等，能排除贡献重复/额外当前 version 行。`read_journal_contributions` 拒绝缺 immutable anchor；缺 repairbody 用原 prepare 重建 checksum 核旧 anchor 后保留旧结果证明，不写 DB。

physical fact 复用保持 child order/physical period/hash/strict fallback 全组成功后发布完整 key，检查冲突 header identity，不污染 full source/input/adoption cache。Journal eligibility 与 fact reusable 初稿手写条件缺 `_active_fact_reads` 当前上下文归属和 current close_reader 条件；实现 agent 已改为统一 `_owns_current_selector_snapshot`，回读确认该点已收口。没有看到需要每次 full outcome decode 的语义理由。

另向实现 agent 反馈两项保守边界：本轮缺 asset batch/month 专门冻结成员故障验证，建议排除 asset_activation_batch/asset_consumption_month/reimbursed_asset_batch，保持既有资产路径；full identifiers 明确保留 original reversal calculation IDs 与 frozen adopted IDs，即使它们与 eligible 意外交集也不剔除。这是防止对未验领域扩大 eligibility、避免依赖交集不可达的隐含前提；不是发现健康提交必然产生该交集。等最终实现及针对 tests 完成后由根节点确认，本文不宣称运行验收通过。
