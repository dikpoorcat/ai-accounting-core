from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parents[1] / '.tmp'
old = root / 'stage9-journal-contribution-work-comparison-20261004.py'
new = root / 'stage9-journal-contribution-work-comparison-20261004-fix1.py'
failure = root / 'stage9-journal-contribution-work-comparison-20261004-first-failure.json'
assert not new.exists() and not failure.exists()
text = old.read_text(encoding='utf-8')
text = text.replace("out_path = W / '.tmp/stage9-journal-contribution-work-comparison-20261004.json'",
                    "out_path = W / '.tmp/stage9-journal-contribution-work-comparison-20261004-fix1.json'")
text = text.replace("    assert before['complete_response_sha256'] == after['complete_response_sha256']\n", "")
text = text.replace("'complete_response_equal_except_response_clocks': True",
                    "'complete_response_equal_except_response_clocks': before['complete_response_sha256'] == after['complete_response_sha256']")
text = text.replace("'limitations': [", "'limitations': ['First comparison rejected the unequal response hashes and is preserved. Context is equal; five main responses have build-bound read_version differences. Full cross-source response equivalence is unverified and no second business read was added to claim it.', ")
assert text != old.read_text(encoding='utf-8')
with new.open('x', encoding='utf-8') as handle:
    handle.write(text)
record = {'status': 'first_comparison_failed', 'original_script_sha256': hashlib.sha256(old.read_bytes()).hexdigest(),
          'operation': 'read existing response hash receipts; no new DB reads',
          'error_type': 'AssertionError',
          'error_location': "before['complete_response_sha256'] == after['complete_response_sha256']",
          'stderr_source': 'tool-captured process exit 1',
          'original_inputs_changed': False, 'repair_creates_new_script_and_receipt': True}
with failure.open('x', encoding='utf-8') as handle:
    json.dump(record, handle, ensure_ascii=False, indent=2)
    handle.write('\n')
print(new)
