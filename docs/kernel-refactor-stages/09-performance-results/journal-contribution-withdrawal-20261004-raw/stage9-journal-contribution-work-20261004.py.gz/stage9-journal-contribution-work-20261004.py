"""One read-only group workload comparison; not page timing or qualification."""
from __future__ import annotations

import argparse
from contextlib import contextmanager
import hashlib
import json
from pathlib import Path
import sqlite3
import sys

W = Path(__file__).resolve().parents[1]
Q = W / '.tmp/stage9-surviving-read-main48-20261003-qualified.json'
B = W / '.tmp/stage9-owner-main48-draft-period-group-construction-input.json'


def sha(path):
    with Path(path).open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    source, output = args.source.resolve(), args.output.resolve()
    assert Path(sys.prefix).resolve() == W / '.tmp-kernel-venv'
    assert source.parent == W / '.tmp' and source.name.startswith('stage9-build-source-')
    assert output.parent == W / '.tmp' and output.name.startswith('stage9-journal-contribution-work-')
    assert not output.exists()
    manifest_path = source / 'source-manifest.json'
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    q = json.loads(Q.read_text(encoding='utf-8'))
    assert manifest['status'] == q['status'] == 'complete'
    assert Path(manifest['target']).resolve() == source
    assert sha(B) == 'a73ded22688073e7aecb7a79d56a6e31d9d6be202e1083738b091d42d3671d93'
    company, root = q['company'], Path(q['root'])
    db = Path(company['path'])
    assert root == W / '.tmp/stage9-draft-fixture-main48-20261003'
    assert q['requested_months'] == 48 and q['business_count'] == 48000

    def guard():
        result = {'files': {str(p): sha(p) if p.exists() else None for p in (
            Q, B, manifest_path, root / 'stage9-builder.json', root / 'catalog.sqlite',
            db, Path(str(db) + '-wal'), Path(str(root / 'catalog.sqlite') + '-wal'))}}
        for name, path in (('company', db), ('catalog', root / 'catalog.sqlite')):
            with sqlite3.connect(path.as_uri() + '?mode=ro', uri=True) as con:
                con.execute('PRAGMA query_only=ON')
                con.execute('BEGIN')
                tables = ('identity', 'state', 'schema_history', 'read_repair_state') if name == 'company' else (
                    'catalog_identity', 'security_owner', 'schema_history', 'company')
                result[name] = {}
                for table in tables:
                    if con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone():
                        result[name][table] = hashlib.sha256(repr(con.execute('SELECT * FROM ' + table).fetchall()).encode()).hexdigest()
                if name == 'company':
                    assert con.execute('SELECT company_id,database_id,taxpayer_id FROM identity').fetchone() == (
                        company['id'], company['database_id'], company['taxpayer_id'])
                    assert list(con.execute('SELECT * FROM state WHERE id=1').fetchone()) == [1, 2065, 1164, 152, 48238, 0]
                con.rollback()
        return result

    before = guard()
    assert sha(root / 'stage9-builder.json') == q['qualification']['checkpoint_sha256']
    sys.path.insert(0, str(source / 'scripts'))
    import stage9_source
    stage9_source.configure_source(source, W)
    import snapshot_stage9_source
    from ai_accounting.kernel.catalog import Catalog
    from ai_accounting.kernel.schema_bundle import production_bundle
    from ai_accounting.kernel.engine import Engine
    from ai_accounting.kernel.dashboard import Dashboard
    from ai_accounting.kernel.resident_reads import ResidentReadPool
    from ai_accounting.kernel.read_state import repair_revision
    from ai_accounting.kernel.types import canonical
    inventory = snapshot_stage9_source._inventory(source)
    assert inventory == manifest['files'] and snapshot_stage9_source._digest(inventory) == manifest['sha256']

    class ReadOnlyCatalog(Catalog):
        @contextmanager
        def connection(self, *, read_only=False, _cross_thread=False):
            assert read_only
            with super().connection(read_only=True, _cross_thread=_cross_thread) as connection:
                assert connection.execute('PRAGMA query_only').fetchone()[0] == 1
                yield connection

        def recover_operations(self):
            with self.connection(read_only=True) as connection:
                assert connection.execute("SELECT count(*) FROM company_operation WHERE status!='succeeded'").fetchone()[0] == 0

    bundle = production_bundle()
    assert bundle.status == 'draft' and dict(bundle.current_versions) == {'company': 0, 'catalog': 0}
    catalog = ReadOnlyCatalog(root, bundle)
    companies = catalog.companies()
    assert [item for item in companies if item['id'] == company['id']] == [company]
    pool = ResidentReadPool(maximum=1)
    store = catalog.bind(company['id'], read_pool=pool)
    native_connection = store.connection

    @contextmanager
    def readonly(*, read_only=False):
        assert read_only
        with native_connection(read_only=True) as connection:
            assert connection.execute('PRAGMA query_only').fetchone()[0] == 1
            assert repair_revision(connection) == 0
            yield connection

    store.connection = readonly
    engine = Engine(store)
    board = Dashboard(engine, company_name=company['name'], companies=companies)
    operations = {
        'context': board.context,
        'brief': lambda: board.brief('2019-12', limit=20),
        'funds_first': lambda: board.funds('2019-12', limit=20, preparation='deferred', movement_account_selection='first'),
        'employees': lambda: board.employees('2019-12', limit=20, preparation='deferred'),
        'assets': lambda: board.assets('2019-12', limit=20, preparation='deferred'),
        'quarterly_report': lambda: board.quarterly_report(2019, 4, preparation='deferred'),
    }
    sys.path.insert(0, str(source / 'tests/kernel'))
    import stage9_metrics

    def response_hash(result):
        result = dict(result)
        for field in ('generated_at', 'checked_at'):
            if field in result:
                result[field] = '<response clock>'
        if isinstance(result.get('data'), dict):
            result['data'] = dict(result['data'])
            if 'generated_at' in result['data']:
                result['data']['generated_at'] = '<response clock>'
        return hashlib.sha256(canonical(result).encode()).hexdigest()

    report = {
        'status': 'started', 'diagnostic_only': True, 'browser_acceptance': False,
        'qualification_created_or_reused_as_current_acceptance': False,
        'source_sha256': manifest['sha256'], 'source_files': manifest['file_count'],
        'source_manifest_sha256': sha(manifest_path), 'script_sha256': sha(__file__),
        'old_qualification_only_guards_the_existing_synthetic_book': True,
        'operations_per_page': 1, 'warmup_operations': 0, 'observations': [],
        'limitations': ['Instrumented actual work is not pure timing.',
                        'No HTTP authentication, browser rendering or close preview is run.',
                        'funds_first is a native parameter path, not proof of actual selected-account browser refresh.',
                        'Actual parent source proof is retained; no new semantic qualification is claimed.'],
    }
    try:
        for name, operation in operations.items():
            work, response = stage9_metrics.measure_work(engine, operation)
            report['observations'].append({'page': name, 'actual_work': work,
                                           'complete_response_sha256': response_hash(response)})
            print(json.dumps({'page': name, 'counters': work['counters']}, ensure_ascii=False), flush=True)
        report['status'] = 'diagnostic_complete'
    except Exception as error:
        report['status'] = 'diagnostic_failed'
        report['error'] = {'type': type(error).__name__, 'message': str(error)}
        raise
    finally:
        pool.close()
        after = guard()
        report['all_file_identity_state_history_registration_repair_guards_equal'] = before == after
        report['source_inventory_unchanged'] = snapshot_stage9_source._inventory(source) == manifest['files']
        report['before'] = before
        report['after'] = after
        with output.open('x', encoding='utf-8') as handle:
            json.dump(report, handle, ensure_ascii=False, indent=2)
            handle.write('\n')
        assert before == after and report['source_inventory_unchanged']


if __name__ == '__main__':
    main()
