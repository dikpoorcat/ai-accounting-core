"""Read existing original workload evidence and confirm exact group withdrawal."""
from pathlib import Path
import hashlib
import json

W = Path(__file__).resolve().parents[1]
old_path = W / '.tmp/stage9-journal-contribution-work-before-dd86-20261004.json'
new_path = W / '.tmp/stage9-journal-contribution-work-after-candidate-20261004.json'
reg_path = W / '.tmp/stage9-input-and-verified-totals-regression-20261004.json'
out_path = W / '.tmp/stage9-journal-contribution-work-comparison-20261004-fix1.json'
assert not out_path.exists()
old, new, reg = (json.loads(p.read_text(encoding='utf-8')) for p in (old_path, new_path, reg_path))
assert old['status'] == new['status'] == 'diagnostic_complete'
for item in (old, new):
    assert item['all_file_identity_state_history_registration_repair_guards_equal']
    assert item['source_inventory_unchanged']
rows = []
for before, after in zip(old['observations'], new['observations'], strict=True):
    assert before['page'] == after['page']
    a, b = before['actual_work']['counters'], after['actual_work']['counters']
    rows.append({'page': before['page'], 'complete_response_equal_except_response_clocks': before['complete_response_sha256'] == after['complete_response_sha256'],
        'before_after': {key: [a[key], b[key]] for key in (
            'sql_calls', 'sqlite_vm_steps', 'returned_rows', 'returned_value_bytes',
            'calculation_result_rows_loaded', 'calculation_result_bytes_loaded',
            'calculation_result_json_decodes', 'report_contribution_json_decodes')},
        'instrumented_times_not_latency_acceptance_ms': [before['actual_work']['instrumented_ms'], after['actual_work']['instrumented_ms']]})
current = {name: hashlib.sha256((W / name).read_bytes()).hexdigest() for name in reg['files_before']}
assert current == reg['files_before'] == reg['files_after']
record = {'status': 'candidate_rejected_and_exactly_withdrawn',
    'original_before_sha256': hashlib.sha256(old_path.read_bytes()).hexdigest(),
    'original_after_sha256': hashlib.sha256(new_path.read_bytes()).hexdigest(),
    'comparison_script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'observations': rows,
    'current_all_prior_316_regression_source_and_test_hashes_match_exactly': True,
    'prior_regression_bound_files': len(current), 'new_large_regression_or_browser_runs': 0,
    'reason': 'Brief loads approximately twice as many returned value bytes and materially more VM work. The one row/40 bytes saved in quarterly report is insufficient to retain the physical-proof-only candidate.',
    'limitations': ['First comparison rejected the unequal response hashes and is preserved. Context is equal; five main responses have build-bound read_version differences. Full cross-source response equivalence is unverified and no second business read was added to claim it.', 'Before is sealed dd86; later evidence-input and nonnegative-sum groups also differ, but their response semantics and row/decode/read-byte scopes are unchanged.',
                    'VM steps are sampled every 100 instructions; 100-step differences are not proof of a regression or benefit.',
                    'Instrumented elapsed time and six native reads are not pure HTTP/browser 500 ms acceptance.',
                    'Current source and tests match the previous successful 316 run after exact withdrawal; that does not create new qualification or performance evidence.']}
with out_path.open('x', encoding='utf-8') as handle:
    json.dump(record, handle, ensure_ascii=False, indent=2)
    handle.write('\n')
print(json.dumps({'status': record['status'], 'bound_files': len(current), 'observations': rows}, ensure_ascii=False, indent=2))
