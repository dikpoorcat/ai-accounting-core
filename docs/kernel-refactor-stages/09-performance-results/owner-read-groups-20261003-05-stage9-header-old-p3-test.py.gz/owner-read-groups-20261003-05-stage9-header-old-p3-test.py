"""Run the unchanged repository regression against the fixed pre-header P3 source."""
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp/stage9-build-source-owner-cache-group-20261003-release"
manifest = json.loads((SOURCE / "source-manifest.json").read_text(encoding="utf-8"))
assert manifest["sha256"] == "19ae7d824077e8e988ffe254120f7d8ee7ed42708c5fdf8fb6eff2ffb3e49941"
sys.path.insert(0, str(SOURCE / "src"))
from ai_accounting.kernel import query_reads
from ai_accounting.kernel.contracts import KernelError

assert Path(query_reads.__file__).resolve() == SOURCE / "src/ai_accounting/kernel/query_reads.py"
relative = "src/ai_accounting/kernel/query_reads.py"
actual = hashlib.sha256(Path(query_reads.__file__).read_bytes()).hexdigest()
assert actual == manifest["files"][relative]
print(json.dumps({"source": str(SOURCE), "source_sha256": manifest["sha256"],
                  "query_reads": query_reads.__file__, "query_reads_sha256": actual}))
original_init = KernelError.__init__

def logged_init(self, code, message, **details):
    original_init(self, code, message, **details)
    if code == "content_integrity_failed":
        print("KERNEL_ERROR=" + json.dumps({"code": code, "message": message,
                                            "details": details}, ensure_ascii=True))

KernelError.__init__ = logged_init
import pytest

raise SystemExit(pytest.main([
    str(ROOT / "tests/kernel/test_query_reads.py") +
    "::test_batch_calculation_still_requires_exact_fact_version", "-q", "-s",
]))
