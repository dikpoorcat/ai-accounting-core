"""Finite corrected receipt gate: vouchers are immutable voucher_version rows, not numbered voucher headers."""
import hashlib
import importlib.util
from datetime import datetime
from pathlib import Path
W=Path(__file__).resolve().parents[1];T=W/'.tmp'
ORIGINAL=T/'stage9-followup-distribution-browser-525f-20261005.py'
ORIGINAL_SHA='f078f6aa22e85ab1963eef1ed95ffe5b88af096778e1342f2391ca203536e752'
def file_sha(path):
    with Path(path).open('rb') as handle:return hashlib.file_digest(handle,'sha256').hexdigest()
assert file_sha(ORIGINAL)==ORIGINAL_SHA
_spec=importlib.util.spec_from_file_location('_immutable_f078_receipt_definitions',ORIGINAL)
_base=importlib.util.module_from_spec(_spec);_spec.loader.exec_module(_base)
sha=_base.sha
read=_base.read
COPY_HELPER=_base.COPY_HELPER
UPGRADE_HELPER=_base.UPGRADE_HELPER
COPY_HELPER_SHA=_base.COPY_HELPER_SHA
UPGRADE_HELPER_SHA=_base.UPGRADE_HELPER_SHA
COPY_PARAMETERS_SHA=_base.COPY_PARAMETERS_SHA
SOURCE_SHA=_base.SOURCE_SHA
MANIFEST_SHA=_base.MANIFEST_SHA
S=_base.S
COVERAGE=_base.COVERAGE

def receipt_gate(sample, table, cfg):
    """No database opens; only exact successful copy and final-v2 upgrade receipts."""
    assert sha(COPY_HELPER) == COPY_HELPER_SHA and sha(UPGRADE_HELPER) == UPGRADE_HELPER_SHA
    copy_path, upgrade_path, input_path = map(Path, (cfg['copy_receipt'], cfg['upgrade_receipt'], cfg['target_input']))
    if sample == 'independent12':
        assert sha(upgrade_path) == 'e877a96c03e77c6f0fa396637c4effad87a8e22d075c7499c7b0b19c88732d0a'
    copied, upgraded = read(copy_path), read(upgrade_path)
    assert copied['status'] == 'copied_content_unverified'
    assert copied['source_bytes_identity_state_history_and_sessions_unchanged'] is True
    assert copied['source_inventory_unchanged'] is True
    assert copied['source_before'] == copied['source_after']
    assert copied['source_before']['input_sha256'] == cfg['source_input_sha256'] == sha(cfg['source_input'])
    assert copied['source_before']['company']['format'] == cfg['recorded_company_format']
    assert copied['source_sha256'] == table['copy_source']['sha256']
    assert copied['source_builder_name'] == cfg['source_builder_name']
    assert copied['source_builder_sha256'] == cfg['source_builder_sha256']
    assert copied['source_attestation_sha256'] == cfg['source_attestation_sha256'] == sha(cfg['source_attestation'])
    assert copied['sample'] == upgraded['sample'] == sample
    assert copied['parameters_sha256'] == upgraded['parameters_sha256'] == COPY_PARAMETERS_SHA
    assert copied['helper_sha256'] == COPY_HELPER_SHA
    assert upgraded['helper_sha256'] == UPGRADE_HELPER_SHA
    assert upgraded['status'] == 'declared_upgrade_verified'
    assert upgraded['source_sha256'] == SOURCE_SHA and upgraded['manifest_sha256'] == MANIFEST_SHA
    assert upgraded['source_file_count'] == 777 and upgraded['source_inventory_unchanged'] is True
    upgrade_module = S / 'src/ai_accounting/kernel/offline_development_upgrade.py'
    assert Path(upgraded['actual_upgrade_module']) == upgrade_module
    assert upgraded['actual_upgrade_module_sha256'] == sha(upgrade_module)
    assert Path(upgraded['interpreter']) == W / '.tmp-kernel-venv/Scripts/python.exe'
    assert upgraded['copy_receipt_sha256'] == sha(copy_path)
    assert copied['input_sha256'] == upgraded['input_sha256'] == sha(input_path)
    assert upgraded['root'] == copied['target'] == cfg['target_root']
    assert upgraded['target_fingerprint'] == table['expected_target_company_fingerprint']
    assert upgraded['transaction_closed'] and upgraded['foreign_keys_enabled']
    assert upgraded['foreign_key_check_empty'] and upgraded['checkpoint'] == [0, 0, 0]
    assert upgraded['state_unchanged'] and upgraded['schema_history_unchanged']
    actual = upgraded['upgrade']
    assert actual['status'] == 'upgraded'
    assert actual['source_fingerprint'] == table['expected_source_company_fingerprint']
    assert actual['target_fingerprint'] == table['expected_target_company_fingerprint']
    assert len(actual['steps']) == 1
    assert actual['verification']['status'] == 'verified' and actual['verification']['limitations'] == []
    assert actual['verification']['coverage'] == COVERAGE
    phases = [row for row in upgraded['phases'] if row['phase'].startswith('content_')]
    assert [row['phase'] for row in phases] == ['content_1', 'content_2', 'content_3']
    assert all(row['status'] == 'passed' and row['verification']['status'] == 'verified'
               and row['verification']['limitations'] == []
               and row['verification']['coverage'] == COVERAGE for row in phases)
    book = read(input_path)
    original_book = read(cfg['source_input'])
    assert all(row['verification']['counts'] == book['counts'] for row in phases)
    assert actual['verification']['counts'] == book['counts'] == original_book['counts']
    assert set(book['counts']) == {'facts', 'calculations', 'vouchers', 'closes', 'evidence'}
    assert all(type(value) is int and value >= 0 for value in book['counts'].values())
    rows = [row for row in upgraded['phases'] if row['phase'].startswith('all_original_rows_')]
    assert [row['phase'] for row in rows] == ['all_original_rows_1', 'all_original_rows_2']
    contract = read(S / ('src/ai_accounting/kernel/schema_contracts/development/company/'
                         + table['expected_source_company_fingerprint'] + '.json'))
    assert contract['sha256'] == table['expected_source_company_fingerprint']
    expected_tables = {obj['name'] for obj in contract['objects'] if obj['type'] == 'table'}
    assert actual['original_table_count'] == len(expected_tables) == 247
    assert all(row['status'] == 'passed' and set(row['table_counts']) == expected_tables for row in rows)
    assert rows[0]['table_counts'] == rows[1]['table_counts']
    assert rows[0]['rows_digest'] == rows[1]['rows_digest'] == actual['original_rows_digest']
    assert type(actual['original_rows_digest']) is str and len(actual['original_rows_digest']) == 64
    for count, name in (('facts', 'fact_revision'), ('calculations', 'calculation'),
                        ('vouchers', 'voucher_version'), ('closes', 'period_close'), ('evidence', 'evidence')):
        assert rows[0]['table_counts'][name] == book['counts'][count]
    assert rows[0]['table_counts']['schema_draft_history'] == 0
    expected_step = {'sequence': 1, 'source_fingerprint': table['expected_source_company_fingerprint'],
                     'target_fingerprint': table['expected_target_company_fingerprint']}
    assert actual['steps'] == [expected_step] and len(upgraded['draft_history']) == 1
    installed = upgraded['draft_history'][0]
    assert {key: installed[key] for key in expected_step} == expected_step
    assert installed['retained_history_digest'] == actual['retained_history_digest']
    assert len(installed['retained_history_digest']) == 64
    assert datetime.fromisoformat(installed['installed_at']).tzinfo is not None
    assert Path(book['root']) == Path(cfg['target_root'])
    assert book['period'] == cfg['period'] and book['distribution'] == cfg['distribution']
    for key in ('requested_months', 'monthly_business_count', 'business_count',
                'registered_object_count', 'employee_count'):
        assert book.get(key) == cfg[key], key
    assert book['company'] == {'id': cfg['company_id'], 'database_id': cfg['database_id'],
                              'taxpayer_id': cfg['taxpayer_id'], 'name': cfg['company_name'],
                              'path': str(Path(cfg['target_root']) / cfg['taxpayer_id'] / 'company.sqlite')}
    assert book['source'] == cfg['recorded_construction_source']
    assert book['construction_provenance'] == original_book['copy_provenance']
    assert book['copy_provenance']['mode'] == 'same_draft_sqlite_snapshot_copy_pending_declared_upgrade'
    assert book['copy_provenance']['installation_and_history_rewritten'] is False
    assert book['copy_provenance']['only_catalog_company_path_changed'] is True
    assert sha(input_path) == sha(Path(cfg['target_root']) / 'stage9-draft-copy-book.json')
    assert copied['target_checkpoint_sha256'] == sha(Path(cfg['target_root']) / cfg['source_builder_name'])
    return {'copy_sha256': sha(copy_path), 'upgrade_sha256': sha(upgrade_path),
            'input_sha256': sha(input_path), 'upgrade': upgraded}, book
