"""Fixed r75 diagnostic on the existing synthetic, r73-verified history."""
from pathlib import Path

previous = Path(__file__).with_name("stage9-resident-r64-main48-profile.py")
source = previous.read_text(encoding="utf-8")
assert source.count("stage9-owner-main48-r63-verified.json") == 1
source = source.replace("stage9-owner-main48-r63-verified.json", "stage9-owner-main48-r73-verified.json")
source = source.replace("r64", "r75")
exec(compile(source, str(previous), "exec"))
