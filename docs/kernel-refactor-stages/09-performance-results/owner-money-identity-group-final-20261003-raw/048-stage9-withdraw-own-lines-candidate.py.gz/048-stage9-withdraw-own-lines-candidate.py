"""Withdraw the measured no-gain prototype, preserving only prior proven code."""
import hashlib
import shutil
from pathlib import Path

root = Path(__file__).resolve().parents[1]
original = root / ".tmp/stage9-build-source-owner-reference-group-20261003-release"
archive = root / ".tmp/stage9-own-line-rejected-production-source-20261003"
archive.mkdir()
files = ("dashboard_reads.py", "dashboard.py", "dashboard_funds.py",
         "report_open_contribution.py")
for name in files:
    current = root / "src/ai_accounting/kernel" / name
    before = original / "src/ai_accounting/kernel" / name
    with current.open("rb") as source, (archive / name).open("xb") as destination:
        shutil.copyfileobj(source, destination)
    current.write_bytes(before.read_bytes())
    assert hashlib.sha256(current.read_bytes()).digest() == hashlib.sha256(before.read_bytes()).digest()
test = root / "tests/kernel/test_owner_month_anchored_lines.py"
with test.open("rb") as source, (archive / test.name).open("xb") as destination:
    shutil.copyfileobj(source, destination)
test.unlink()
print("Withdrawn only four reviewed candidate files and new prototype-only tests; archives retained.")
