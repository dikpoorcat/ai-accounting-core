"""Pinned, read-only instrumented diagnostic; this is never browser acceptance timing."""

from __future__ import annotations

import cProfile
import hashlib
import json
import pstats
import sys
from contextlib import contextmanager
from pathlib import Path

WORKSPACE = Path(__file__).resolve().parents[1]
SOURCE = WORKSPACE / ".tmp/stage9-build-source-owner-reference-group-20261003-release"
MANIFEST = SOURCE / "source-manifest.json"
import argparse

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--months', type=int, choices=(48,), required=True)
parser.add_argument('--book-report', type=Path, required=True)
parser.add_argument('--report-sha256', required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
BOOK_REPORT = args.book_report.resolve(strict=True)
OUTPUT = args.output.resolve()
assert BOOK_REPORT.is_relative_to(WORKSPACE / '.tmp')
assert OUTPUT.is_relative_to(WORKSPACE / '.tmp') and not OUTPUT.exists()
MANIFEST_FILE_SHA256 = '9de4a38ae2f93fc575d5a68898ad3cba334ab4dc5786c67731a6c1eead1d52b5'
SOURCE_SHA256 = '6688df6c46f5416ca03917def0d29a701cb20e8ae45b962c59df4a1290f8da62'
REPORT_SHA256 = '2ac7c29d02e920826d27bae8fdb2ff4deb740fa184e3a502aaa9e09521e804a3'
assert args.report_sha256 == REPORT_SHA256, "Only this pinned old-qualified main48 qualification is permitted"
assert BOOK_REPORT == (WORKSPACE / '.tmp/stage9-owner-main48-reference-group-qualified.json').resolve()
assert OUTPUT == (WORKSPACE / '.tmp/stage9-signature-assets-main48-diagnostic-r2.json').resolve()


def file_hash(path):
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def main():
    require(
        Path(sys.prefix).resolve() == (WORKSPACE / ".tmp-kernel-venv").resolve(),
        "Use the repository virtual environment",
    )
    require(not OUTPUT.exists(), "Diagnostic output must not exist")
    require(file_hash(MANIFEST) == MANIFEST_FILE_SHA256, "Pinned manifest bytes changed")
    require(file_hash(BOOK_REPORT) == REPORT_SHA256, "Pinned verified report bytes changed")
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    require(
        manifest["status"] == "complete"
        and manifest["sha256"] == SOURCE_SHA256
        and Path(manifest["target"]).resolve() == SOURCE.resolve(),
        "Wrong source manifest",
    )

    # Bootstrap only from the fixed candidate, before importing any accounting module.
    sys.path.insert(0, str(SOURCE / "scripts"))
    import stage9_source

    stage9_source.require_source_module(stage9_source, SOURCE, "scripts/stage9_source.py")
    stage9_source.configure_source(SOURCE, WORKSPACE)
    import benchmark_stage9_browser
    import snapshot_stage9_source
    import stage9_metrics

    from ai_accounting.kernel import catalog as catalog_module
    from ai_accounting.kernel import dashboard as dashboard_module
    from ai_accounting.kernel import engine as engine_module
    from ai_accounting.kernel import resident_reads, schema_bundle
    from ai_accounting.kernel.types import canonical
    from ai_accounting.kernel.versions import database_format

    for module, relative in (
        (snapshot_stage9_source, "scripts/snapshot_stage9_source.py"),
        (benchmark_stage9_browser, "scripts/benchmark_stage9_browser.py"),
        (stage9_metrics, "tests/kernel/stage9_metrics.py"),
        (catalog_module, "src/ai_accounting/kernel/catalog.py"),
        (dashboard_module, "src/ai_accounting/kernel/dashboard.py"),
        (engine_module, "src/ai_accounting/kernel/engine.py"),
        (resident_reads, "src/ai_accounting/kernel/resident_reads.py"),
        (schema_bundle, "src/ai_accounting/kernel/schema_bundle.py"),
    ):
        stage9_source.require_source_module(module, SOURCE, relative)

    def check_source():
        inventory = snapshot_stage9_source._inventory(SOURCE)
        require(
            inventory == manifest["files"]
            and snapshot_stage9_source._digest(inventory) == SOURCE_SHA256,
            "Fixed source bytes drifted",
        )
        require(
            file_hash(MANIFEST) == MANIFEST_FILE_SHA256 and file_hash(BOOK_REPORT) == REPORT_SHA256,
            "Pinned attestations drifted",
        )

    check_source()
    book = json.loads(BOOK_REPORT.read_text(encoding="utf-8"))
    OLD_SOURCE = WORKSPACE / ".tmp/stage9-build-source-owner-reference-group-20261003-release"
    old_manifest_path = OLD_SOURCE / "source-manifest.json"
    require(file_hash(old_manifest_path) == "9de4a38ae2f93fc575d5a68898ad3cba334ab4dc5786c67731a6c1eead1d52b5", "Old qualification source manifest changed")
    old_manifest = json.loads(old_manifest_path.read_text(encoding="utf-8"))
    contract_prefix = "src/ai_accounting/kernel/schema_contracts/"
    current_contracts = {k: v for k, v in manifest["files"].items() if k.startswith(contract_prefix)}
    old_contracts = {k: v for k, v in old_manifest["files"].items() if k.startswith(contract_prefix)}
    require(current_contracts and current_contracts == old_contracts, "Diagnostic requires identical manifest contracts")
    for relative, digest in current_contracts.items():
        require(file_hash(SOURCE / relative) == digest and file_hash(OLD_SOURCE / relative) == digest, "Contract bytes changed")
    benchmark_stage9_browser.require_report_source(book, OLD_SOURCE)
    period = benchmark_stage9_browser.validate_book_report(book, company_name="阶段九合成规模企业")
    require(
        book["requested_months"] == args.months
        and book["employee_count"] == 50
        and book["monthly_business_count"] == 1000
        and book["distribution"] == "mixed_cumulative",
        "Wrong main sample dimensions",
    )
    root = stage9_source.synthetic_path(Path(book["root"]), WORKSPACE)
    company = book["company"]
    checkpoint_path = root / "stage9-builder.json"
    checkpoint_hash = file_hash(checkpoint_path)
    require(checkpoint_hash == book["qualification"].get("checkpoint_sha256"), "Old qualified checkpoint changed")
    checkpoint = json.loads(checkpoint_path.read_text(encoding="utf-8"))
    preview = book["verified_open_preview"]
    require(
        checkpoint["company"] == company
        and checkpoint["snapshots"] == book["snapshots"]
        and checkpoint["epochs"] == preview["state"],
        "Checkpoint no longer matches proof",
    )
    expected_state = preview["state"]
    expected_identity = {
        "company_id": company["id"],
        "database_id": company["database_id"],
        "taxpayer_id": company["taxpayer_id"],
    }
    integrity_contract = book["integrity_contract"]
    del checkpoint, book
    require(
        (root / "catalog.sqlite").is_file() and Path(company["path"]).is_file(),
        "Existing databases are required",
    )

    class ReadOnlyCatalog(catalog_module.Catalog):
        @contextmanager
        def connection(self, *, read_only=False, _cross_thread=False):
            require(read_only, "Diagnostic forbids catalog writes")
            with super().connection(read_only=True, _cross_thread=_cross_thread) as connection:
                yield connection

        def recover_operations(self):
            # Never resume pending publications during a read diagnostic.
            with self.connection(read_only=True) as connection:
                count = connection.execute(
                    "SELECT count(*) FROM company_operation WHERE status!='succeeded'"
                ).fetchone()[0]
            require(
                count == 0, "Catalog has unfinished operations; diagnostic will not recover them"
            )

    bundle = schema_bundle.production_bundle()
    catalog = ReadOnlyCatalog(root, bundle)
    require(
        catalog.database_format()["status"] == "released"
        and catalog.database_format()["version"] == 1,
        "Wrong catalog contract",
    )
    companies = catalog.companies()
    require(
        [row for row in companies if row["id"] == company["id"]] == [company],
        "Catalog company identity changed",
    )
    with catalog.connection(read_only=True) as connection:
        catalog_identity = dict(connection.execute("SELECT * FROM catalog_identity").fetchone())

    pool = resident_reads.ResidentReadPool(maximum=4)
    store = catalog.bind(company["id"], read_pool=pool)
    original_connection = store.connection

    @contextmanager
    def read_only_connection(*, read_only=False):
        require(read_only, "Diagnostic forbids company writes")
        with original_connection(read_only=True) as connection:
            yield connection

    store.connection = read_only_connection
    engine = engine_module.Engine(store)
    dashboard = dashboard_module.Dashboard(
        engine, company_name=company["name"], companies=companies
    )
    year, month = map(int, period.split("-"))
    quarter = (month - 1) // 3 + 1

    def check_state():
        require(file_hash(old_manifest_path) == "9de4a38ae2f93fc575d5a68898ad3cba334ab4dc5786c67731a6c1eead1d52b5", "Old source manifest drifted")
        for relative, digest in old_contracts.items():
            require(file_hash(OLD_SOURCE / relative) == digest, "Old qualification contracts drifted")
        with store.connection(read_only=True) as connection:
            connection.execute("BEGIN")
            state = list(connection.execute("SELECT * FROM state WHERE id=1").fetchone())
            identity = dict(
                connection.execute(
                    "SELECT company_id,taxpayer_id,database_id FROM identity WHERE id=1"
                ).fetchone()
            )
            require(
                state == expected_state and identity == expected_identity,
                "Company identity, business state or repair revision changed",
            )
            require(
                database_format(connection, bundle=bundle) == integrity_contract,
                "Company format differs from verified source",
            )
        with catalog.connection(read_only=True) as connection:
            require(
                dict(connection.execute("SELECT * FROM catalog_identity").fetchone())
                == catalog_identity,
                "Catalog identity changed",
            )
        require(catalog.companies() == companies, "Catalog registration changed")
        require(file_hash(checkpoint_path) == checkpoint_hash, "Construction checkpoint changed")
        return {"state": state, "identity": identity, "catalog_identity": catalog_identity}


    import ast
    import time
    from ai_accounting.kernel import query_reads, business_queries

    changes = {}
    for module, names, klass in (
        (query_reads, ('_current_voucher_signature', '_verify_current_voucher_publication_rows'), None),
        (business_queries, ('_selected_asset_member_heads',), 'BusinessQueries'),
    ):
        path = WORKSPACE / 'src/ai_accounting/kernel' / Path(module.__file__).name
        tree = ast.parse(path.read_text(encoding='utf-8'))
        nodes = tree.body if klass is None else next(
            node.body for node in tree.body if isinstance(node, ast.ClassDef) and node.name == klass)
        namespace = dict(vars(module))
        owner = module if klass is None else getattr(module, klass)
        pairs = []
        for name in names:
            node = next(node for node in nodes if isinstance(node, ast.FunctionDef) and node.name == name)
            exec(compile(ast.fix_missing_locations(ast.Module(body=[node], type_ignores=[])),
                         str(path), 'exec'), namespace)
            pairs.append((name, getattr(owner, name), namespace[name]))
        changes[path.name] = {
            'path': str(path), 'sha256': file_hash(path), 'owner': owner, 'pairs': pairs}

    def select(label):
        for change in changes.values():
            for name, old, proposed in change['pairs']:
                setattr(change['owner'], name, proposed if label == 'prototype' else old)

    operations = {
        'context': dashboard.context,
        'brief': lambda: dashboard.brief(period, limit=20, preparation='deferred'),
        'funds': lambda: dashboard.funds(period, limit=20, preparation='deferred', movement_account_selection='first'),
        'employees': lambda: dashboard.employees(period, limit=20, preparation='deferred'),
        'assets': lambda: dashboard.assets(period, limit=20, preparation='deferred'),
        'quarterly_report': lambda: dashboard.quarterly_report(year, quarter, preparation='deferred'),
    }
    report = {
        'status': 'diagnostic_started', 'scope': 'signature_and_consumption_only_identity_group',
        'source': str(SOURCE), 'source_sha256': SOURCE_SHA256,
        'qualified_report': str(BOOK_REPORT), 'qualified_report_sha256': REPORT_SHA256,
        'qualification_reused_or_created': False, 'browser_acceptance': False,
        'root': str(root), 'period': period, 'default_page_limit': 20,
        'prototype_files': {name: {'path': item['path'], 'sha256': item['sha256']}
                            for name, item in changes.items()},
        'script_sha256': file_hash(Path(__file__)), 'measurements': {},
        'notes': ['Normal saved-source validations remain; synthetic-root identity/checkpoint/epochs unchanged.',
                  'All work counters finish before pure native timing; no concurrent CPU jobs.',
                  'Native timing is before/after evidence, not browser 500ms acceptance.'],
    }
    with OUTPUT.open('x', encoding='utf-8') as output:
        try:
            report['before'] = check_state()
            for name, operation in operations.items():
                observations, responses, generated = {}, {}, {}
                for label in ('baseline', 'prototype'):
                    select(label)
                    work, result = stage9_metrics.measure_work(engine, operation)
                    generated[label] = {'root': result.get('generated_at'),
                                        'data': result.get('data', {}).get('generated_at')}
                    if 'generated_at' in result:
                        result['generated_at'] = '<response generation time>'
                    if 'generated_at' in result.get('data', {}):
                        result['data']['generated_at'] = '<response generation time>'
                    observations[label], responses[label] = work, result
                require(canonical(responses['baseline']) == canonical(responses['prototype']),
                        name + ': complete business response differs')
                observations['complete_response_equal_except_generation_time'] = True
                observations['complete_response_sha256'] = hashlib.sha256(
                    canonical(responses['baseline']).encode()).hexdigest()
                observations['generated_at'] = generated
                report['measurements'][name] = observations
                del responses
            report['native_samples_ms'] = {}
            for name, operation in operations.items():
                samples = {'baseline': [], 'prototype': []}
                for _ in range(3):
                    for label in ('baseline', 'prototype'):
                        select(label)
                        operation()
                for index in range(10):
                    order = ('baseline', 'prototype') if index % 2 == 0 else ('prototype', 'baseline')
                    for label in order:
                        select(label)
                        started = time.perf_counter()
                        result = operation()
                        elapsed = (time.perf_counter() - started) * 1000
                        if 'generated_at' in result:
                            result['generated_at'] = '<response generation time>'
                        if 'generated_at' in result.get('data', {}):
                            result['data']['generated_at'] = '<response generation time>'
                        require(hashlib.sha256(canonical(result).encode()).hexdigest()
                                == report['measurements'][name]['complete_response_sha256'],
                                name + ': pure native response differs')
                        samples[label].append(elapsed)
                report['native_samples_ms'][name] = samples
            report['after'] = check_state()
            check_source()
            for change in changes.values():
                require(file_hash(Path(change['path'])) == change['sha256'], 'Primary prototype changed')
            report['status'] = 'diagnostic_complete'
        except BaseException as error:
            report.update(status='diagnostic_failed', error_type=type(error).__name__, error=str(error))
            raise
        finally:
            select('baseline')
            json.dump(report, output, ensure_ascii=False, indent=2)
            output.write('\n')
            pool.close()
    print(json.dumps({'status': report['status'], 'browser_acceptance': False}, ensure_ascii=False))


if __name__ == '__main__':
    main()
