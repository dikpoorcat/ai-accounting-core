"""Pin one before/after diagnostic for the remaining converged reading group."""
from pathlib import Path

root = Path(__file__).resolve().parents[1]
old = root / ".tmp/stage9-owner-month-anchored-lines-prototype-main48-r3.py"
target = root / ".tmp/stage9-signature-assets-main48-diagnostic.py"
text = old.read_text(encoding="utf-8").replace(
    "stage9-owner-month-anchored-lines-prototype-main48-r3",
    "stage9-signature-assets-main48-diagnostic")
assert text.count("    import ast\n") == 1
prefix = text.split("    import ast\n")[0]
body = r'''
    import ast
    import time
    from ai_accounting.kernel import query_reads, business_queries

    changes = {}
    for module, names, klass in (
        (query_reads, ('_current_voucher_signature', '_verify_current_voucher_publication_rows'), None),
        (business_queries, ('_selected_asset_member_heads',), 'BusinessQueries'),
    ):
        path = WORKSPACE / 'src/ai_accounting/kernel' / Path(module.__file__).name
        tree = ast.parse(path.read_text(encoding='utf-8'))
        nodes = tree.body if klass is None else next(
            node.body for node in tree.body if isinstance(node, ast.ClassDef) and node.name == klass)
        namespace = dict(vars(module))
        owner = module if klass is None else getattr(module, klass)
        pairs = []
        for name in names:
            node = next(node for node in nodes if isinstance(node, ast.FunctionDef) and node.name == name)
            exec(compile(ast.fix_missing_locations(ast.Module(body=[node], type_ignores=[])),
                         str(path), 'exec'), namespace)
            pairs.append((name, getattr(owner, name), namespace[name]))
        changes[path.name] = {
            'path': str(path), 'sha256': file_hash(path), 'owner': owner, 'pairs': pairs}

    def select(label):
        for change in changes.values():
            for name, old, proposed in change['pairs']:
                setattr(change['owner'], name, proposed if label == 'prototype' else old)

    operations = {
        'context': dashboard.context,
        'brief': lambda: dashboard.brief(period, limit=20, preparation='deferred'),
        'funds': lambda: dashboard.funds(period, limit=20, preparation='deferred', movement_account_selection='first'),
        'employees': lambda: dashboard.employees(period, limit=20, preparation='deferred'),
        'assets': lambda: dashboard.assets(period, limit=20, preparation='deferred'),
        'quarterly_report': lambda: dashboard.quarterly_report(year, quarter, preparation='deferred'),
    }
    report = {
        'status': 'diagnostic_started', 'scope': 'signature_and_consumption_only_identity_group',
        'source': str(SOURCE), 'source_sha256': SOURCE_SHA256,
        'qualified_report': str(BOOK_REPORT), 'qualified_report_sha256': REPORT_SHA256,
        'qualification_reused_or_created': False, 'browser_acceptance': False,
        'root': str(root), 'period': period, 'default_page_limit': 20,
        'prototype_files': {name: {'path': item['path'], 'sha256': item['sha256']}
                            for name, item in changes.items()},
        'script_sha256': file_hash(Path(__file__)), 'measurements': {},
        'notes': ['Normal saved-source validations remain; synthetic-root identity/checkpoint/epochs unchanged.',
                  'All work counters finish before pure native timing; no concurrent CPU jobs.',
                  'Native timing is before/after evidence, not browser 500ms acceptance.'],
    }
    with OUTPUT.open('x', encoding='utf-8') as output:
        try:
            report['before'] = check_state()
            for name, operation in operations.items():
                observations, responses, generated = {}, {}, {}
                for label in ('baseline', 'prototype'):
                    select(label)
                    work, result = stage9_metrics.measure_work(engine, operation)
                    generated[label] = result.get('data', {}).get('generated_at')
                    if 'generated_at' in result.get('data', {}):
                        result['data']['generated_at'] = '<response generation time>'
                    observations[label], responses[label] = work, result
                require(canonical(responses['baseline']) == canonical(responses['prototype']),
                        name + ': complete business response differs')
                observations['complete_response_equal_except_generation_time'] = True
                observations['complete_response_sha256'] = hashlib.sha256(
                    canonical(responses['baseline']).encode()).hexdigest()
                observations['generated_at'] = generated
                report['measurements'][name] = observations
                del responses
            report['native_samples_ms'] = {}
            for name, operation in operations.items():
                samples = {'baseline': [], 'prototype': []}
                for _ in range(3):
                    for label in ('baseline', 'prototype'):
                        select(label)
                        operation()
                for index in range(10):
                    order = ('baseline', 'prototype') if index % 2 == 0 else ('prototype', 'baseline')
                    for label in order:
                        select(label)
                        started = time.perf_counter()
                        result = operation()
                        elapsed = (time.perf_counter() - started) * 1000
                        if 'generated_at' in result.get('data', {}):
                            result['data']['generated_at'] = '<response generation time>'
                        require(hashlib.sha256(canonical(result).encode()).hexdigest()
                                == report['measurements'][name]['complete_response_sha256'],
                                name + ': pure native response differs')
                        samples[label].append(elapsed)
                report['native_samples_ms'][name] = samples
            report['after'] = check_state()
            check_source()
            for change in changes.values():
                require(file_hash(Path(change['path'])) == change['sha256'], 'Primary prototype changed')
            report['status'] = 'diagnostic_complete'
        except BaseException as error:
            report.update(status='diagnostic_failed', error_type=type(error).__name__, error=str(error))
            raise
        finally:
            select('baseline')
            json.dump(report, output, ensure_ascii=False, indent=2)
            output.write('\n')
            pool.close()
    print(json.dumps({'status': report['status'], 'browser_acceptance': False}, ensure_ascii=False))


if __name__ == '__main__':
    main()
'''
with target.open("x", encoding="utf-8", newline="\n") as output:
    output.write(prefix + body)
print(target)
