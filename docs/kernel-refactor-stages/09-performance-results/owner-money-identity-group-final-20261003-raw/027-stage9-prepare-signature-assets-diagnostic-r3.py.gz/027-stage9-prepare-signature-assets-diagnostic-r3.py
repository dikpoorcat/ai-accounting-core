"""Finish the unchanged group's report path and pure timing, not repeat five probes."""
import hashlib
from pathlib import Path

root = Path(__file__).resolve().parents[1]
old = root / ".tmp/stage9-signature-assets-main48-diagnostic-r2.py"
prior = root / ".tmp/stage9-signature-assets-main48-diagnostic-r2.json"
target = root / ".tmp/stage9-signature-assets-main48-diagnostic-r3.py"
text = old.read_text(encoding="utf-8").replace(
    "stage9-signature-assets-main48-diagnostic-r2", "stage9-signature-assets-main48-diagnostic-r3")
sha = hashlib.sha256(prior.read_bytes()).hexdigest()
needle = "            for name, operation in operations.items():\n                observations, responses, generated = {}, {}, {}"
replacement = f"""            prior_path = WORKSPACE / '.tmp/stage9-signature-assets-main48-diagnostic-r2.json'
            require(file_hash(prior_path) == '{sha}', 'Prior raw diagnostic changed')
            prior = json.loads(prior_path.read_text(encoding='utf-8'))
            require(prior['prototype_files'] == report['prototype_files']
                    and prior['source_sha256'] == report['source_sha256']
                    and prior['qualified_report_sha256'] == REPORT_SHA256
                    and prior['before'] == report['before'], 'Prior probes have different exact inputs')
            report['prior_work_probes'] = {{'path': str(prior_path), 'sha256': '{sha}'}}
            for name, operation in operations.items():
                if name in prior['measurements']:
                    report['measurements'][name] = prior['measurements'][name]
                    report['measurements'][name]['unchanged_prior_probe'] = True
                    continue
                observations, responses, generated = {{}}, {{}}, {{}}"""
assert text.count(needle) == 1
text = text.replace(needle, replacement)
text = text.replace(
    "                    if 'generated_at' in result:\n",
    "                    if name == 'quarterly_report':\n"
    "                        generated[label]['checked_at'] = result['checked_at']\n"
    "                        result['checked_at'] = '<response check time>'\n"
    "                    if 'generated_at' in result:\n", 1)
text = text.replace(
    "                        if 'generated_at' in result:\n",
    "                        if name == 'quarterly_report':\n"
    "                            result['checked_at'] = '<response check time>'\n"
    "                        if 'generated_at' in result:\n", 1)
with target.open("x", encoding="utf-8", newline="\n") as output:
    output.write(text)
print(target)
