"""Real posted expenses retain whole-month trust when saved anchors supply lines."""

import pytest
from stage9_metrics import measure_work
from test_cash import book as _cash_book
from test_integrity_content import damage
from test_reports import book as book  # noqa: F401

from ai_accounting.kernel import integrity
from ai_accounting.kernel.content_history_context import historical_content
from ai_accounting.kernel.contracts import KernelError
from ai_accounting.kernel.dashboard import Dashboard
from ai_accounting.kernel.dashboard_reads import Journal
from ai_accounting.kernel.query_reads import QueryReads

MONTH = "2026-01"
cash_book = _cash_book


def _expense(save, subject, amount, *, period=MONTH, revision=0):
    save("expense", subject, {
        "period": period, "counterparty_id": "supplier", "amount_fen": amount,
        "expense_class": "administration", "creditor_kind": "supplier",
    }, revision=revision)


def _posted(book, count=24):
    engine, save, publish, _ = book
    subjects = [f"cost-{index:03}" for index in range(count)]
    for index, subject in enumerate(subjects):
        _expense(save, subject, index + 1)
    publish(*subjects)
    return engine


def _brief(engine, period=MONTH):
    response = Dashboard(engine).brief(period, preparation="deferred")
    # Wall-clock generation metadata is the only varying response field;
    # retain all business fields, snapshot bindings and default voucher data.
    assert response["data"].pop("generated_at")
    return response


def _off_page(engine):
    with engine.store.connection(read_only=True) as connection:
        return dict(connection.execute(
            "SELECT v.id,v.calculation_id,p.id publication_id,c.outcome "
            "FROM voucher_current h JOIN voucher_version v ON v.id=h.version_id "
            "JOIN calculation c ON c.id=v.calculation_id "
            "JOIN calculation_publication p ON p.calculation_id=c.id "
            "WHERE c.subject_id='cost-023'"
        ).fetchone())


@pytest.mark.parametrize("count", [24, 100])
def test_real_whole_month_response_and_decodes_equal_fallback_with_unrelated_history(
    book, monkeypatch, count, record_property
):
    engine = _posted(book, count)

    def compare():
        work, actual = measure_work(engine, lambda: _brief(engine))
        with monkeypatch.context() as patch:
            patch.setattr(Journal, "_open_month_anchored_lines", lambda *_: {})
            old_work, expected = measure_work(engine, lambda: _brief(engine))
        assert actual == expected
        assert actual["data"]["position"]["month_expense_fen"] == count * (count + 1) // 2
        assert actual["data"]["collections"]["activity"]["page"]["total_count"] == count
        assert len(actual["data"]["collections"]["vouchers"]["items"]) == 20
        decoded = work["counters"].get("calculation_result_json_decodes", 0)
        old_decoded = old_work["counters"].get("calculation_result_json_decodes", 0)
        assert decoded < old_decoded, (work, old_work)
        record_property("anchored_result_decodes", decoded)
        record_property("fallback_result_decodes", old_decoded)
        return decoded

    before = compare()
    _, save, publish, _ = book
    others = [f"other-{index}" for index in range(40)]
    for subject in others:
        _expense(save, subject, 900, period="2026-03")
    publish(*others)
    for revision in range(1, 13):
        _expense(save, "cost-000", 1, revision=revision)
        publish("cost-000")
    # Equal-value reviews legitimately require this one voucher's fallback;
    # unrelated months and replaced versions must not add result decoding.
    assert compare() <= before + 2


@pytest.mark.parametrize("corruption", [
    "missing_last", "extra", "mismatch", "same_net", "body", "anchor", "source",
])
def test_off_page_damage_rejects_before_summary_publication(book, corruption):
    engine = _posted(book)
    _brief(engine)  # A successful earlier request does not bless the next snapshot.
    row = _off_page(engine)
    if corruption == "missing_last":
        damage(engine, "voucher_line", "DELETE FROM voucher_line WHERE version_id=? "
               "AND line_no=(SELECT max(line_no) FROM voucher_line WHERE version_id=?)",
               (row["id"], row["id"]))
    elif corruption == "extra":
        damage(engine, "voucher_line", "INSERT INTO voucher_line "
               "SELECT version_id,3,account,1,0,cashflow FROM voucher_line "
               "WHERE version_id=? AND line_no=1", (row["id"],))
    elif corruption == "mismatch":
        damage(engine, "voucher_line", "UPDATE voucher_line SET account='199999' "
               "WHERE version_id=? AND line_no=1", (row["id"],))
    elif corruption == "same_net":
        with engine.store.connection(read_only=True) as connection:
            sibling = connection.execute(
                "SELECT v.id FROM voucher_version v JOIN calculation c "
                "ON c.id=v.calculation_id WHERE c.subject_id='cost-022'"
            ).fetchone()[0]
        # Both vouchers remain balanced and whole-month debit/credit per
        # account are unchanged, while their independent source lines differ.
        damage(engine, "voucher_line", "UPDATE voucher_line SET "
               "debit=CASE WHEN debit>0 THEN debit+CASE WHEN version_id=? THEN 1 ELSE -1 END "
               "ELSE 0 END,credit=CASE WHEN credit>0 THEN credit+CASE WHEN version_id=? "
               "THEN 1 ELSE -1 END ELSE 0 END WHERE version_id IN (?,?)",
               (row["id"], row["id"], row["id"], sibling))
        damage(engine, "voucher_version", "UPDATE voucher_version SET "
               "total=total+CASE WHEN id=? THEN 1 ELSE -1 END WHERE id IN (?,?)",
               (row["id"], row["id"], sibling))
    elif corruption in {"body", "anchor"}:
        table = "report_open_contribution" + ("_anchor" if corruption == "anchor" else "")
        damage(engine, table, f"UPDATE {table} SET content_digest=zeroblob(32) "
               "WHERE publication_id=?", (row["publication_id"],))
    else:
        damage(engine, "calculation", "UPDATE calculation SET outcome='{}' WHERE id=?",
               (row["calculation_id"],))
    with Dashboard(engine)._snapshot(MONTH) as snap:
        with pytest.raises(KernelError) as failure:
            snap.month_journal.account_amounts()
        assert failure.value.code == "content_integrity_failed"
        assert snap.month_journal.verified_rows() is None
        assert not any(key[0] == "journal_summary" for key in snap.reads._report_snapshot_cache)
    with pytest.raises(KernelError):
        _brief(engine)


@pytest.mark.parametrize("fallback", ["missing_body", "noncanonical"])
def test_exceptional_saved_source_still_uses_original_decoder(book, monkeypatch, fallback):
    engine = _posted(book)
    expected = _brief(engine)
    row = _off_page(engine)
    if fallback == "missing_body":
        with engine.store.connection() as connection:
            connection.execute("DELETE FROM report_open_contribution WHERE publication_id=?",
                               (row["publication_id"],))
    else:
        damage(engine, "calculation", "UPDATE calculation SET outcome=' '||outcome WHERE id=?",
               (row["calculation_id"],))
    decoded = []
    original = integrity._object

    def observe(raw, component, ident):
        result = original(raw, component, ident)
        if component == "calculation":
            decoded.append(ident)
        return result

    monkeypatch.setattr(integrity, "_object", observe)
    assert _brief(engine) == expected
    assert row["calculation_id"] in decoded


@pytest.mark.parametrize("boundary", ["review", "closed", "fixed", "unowned", "filtered"])
def test_nonordinary_scopes_keep_original_complete_result_proof(book, monkeypatch, boundary):
    engine = _posted(book, 2)
    _, save, publish, close = book
    if boundary == "review":
        _expense(save, "cost-000", 1, revision=1)
        publish("cost-000")
    elif boundary == "closed":
        close(MONTH)
    with Dashboard(engine)._snapshot(MONTH) as snap:
        journal = snap.month_journal
        if boundary == "unowned":
            snap.reads = QueryReads(engine, snap.connection)
        elif boundary == "filtered":
            journal = journal.select(kinds={"expense"})
        rows = list(snap.connection.execute(*journal.sql()))
        if boundary == "fixed":
            # Actual fixed historical reader context must not consume current
            # anchor reuse, even while the current registry is installed.
            with historical_content(1):
                assert journal._open_month_anchored_lines(rows) == {}
            return
        anchored = {} if boundary == "closed" else journal._open_month_anchored_lines(rows)
        if boundary == "review":
            reviewed = next(row for row in rows if row["basis_subject_id"] == "cost-000")
            assert reviewed["voucher_calculation_id"] != reviewed["basis_calculation_id"]
            assert reviewed["voucher_calculation_id"] not in anchored
            assert len(anchored) == 1  # Ordinary sibling still uses its exact source.
        else:
            assert anchored == {}
        decoded = []
        original = integrity._object

        def observe(raw, component, ident):
            value = original(raw, component, ident)
            if component == "calculation":
                decoded.append(ident)
            return value

        monkeypatch.setattr(integrity, "_object", observe)
        amounts = journal.account_amounts()
        assert sum(value[0] for value in amounts.values()) == 3
        assert sum(value[1] for value in amounts.values()) == 3
        assert decoded  # Even an unowned reader must execute actual content proof.
        if boundary != "unowned":
            assert snap.reads._verified_source_contents


def test_mixed_closed_reversal_and_ordinary_sibling_equal_full_reader(book, monkeypatch):
    engine = _posted(book, 2)
    _, save, publish, close = book
    before = _brief(engine)
    close(MONTH)
    _expense(save, "cost-000", 7, revision=1)
    publish("cost-000", posting_period="2026-02")
    _expense(save, "ordinary", 11, period="2026-02")
    publish("ordinary")
    actual = _brief(engine, "2026-02")
    with monkeypatch.context() as patch:
        patch.setattr(Journal, "_open_month_anchored_lines", lambda *_: {})
        assert _brief(engine, "2026-02") == actual
    assert actual["data"]["position"]["month_expense_fen"] == 17
    assert _brief(engine)["data"]["position"] == before["data"]["position"]
    with Dashboard(engine)._snapshot("2026-02") as snap:
        rows = list(snap.connection.execute(*snap.month_journal.sql()))
        anchored = snap.month_journal._open_month_anchored_lines(rows)
        assert anchored
        original_ids = {
            snap.reads.voucher(row["reverses_id"])["calculation_id"]
            for row in rows if row["reverses_id"]
        }
        # A reversal and its replacement share the new calculation ID;
        # only the replacement's expected lines may use that anchor. The
        # independently frozen original still needs its own result proof.
        assert original_ids and original_ids.isdisjoint(anchored)
        snap.month_journal.account_amounts()
        assert original_ids <= snap.reads._verified_source_contents.keys()


def test_mixed_expense_and_actual_cash_bank_payments_keep_money_body_proof(
    cash_book, monkeypatch
):
    engine, save, publish, _ = cash_book
    period = "2026-09"
    _expense(save, "cost", 700, period=period)
    save("bank_opening", "bank-opening", {
        "period": period, "bank_account_id": "bank", "opening_fen": 0,
        "basis": "new_account",
    })
    subjects = ["cost", "bank-opening"]
    for channel, account in (("cash", "cashbox"), ("bank", "bank")):
        subject = channel + "-capital"
        save("cash_funding" if channel == "cash" else "funding", subject, {
            "period": period, "actual_date": period + "-01", "funding_kind": "capital",
            "owner_id": "owner", "amount_fen": 1000, channel + "_account_id": account,
        })
        subjects.append(subject)
    publish(*subjects)
    for channel, account, amount in (("cash", "cashbox", 300), ("bank", "bank", 400)):
        subject = channel + "-payment"
        save("cash_payment" if channel == "cash" else "payment", subject, {
            "period": period, "actual_date": period + "-10", "direction": "outflow",
            channel + "_account_id": account, "counterparty_id": "supplier",
            "amount_fen": amount, "allocations": [{
                "source_kind": "expense", "source_id": "cost", "obligation": "primary",
                "amount_fen": amount,
            }],
        })
        publish(subject)

    def compare_and_inspect():
        actual = _brief(engine, period)
        with monkeypatch.context() as patch:
            patch.setattr(Journal, "_open_month_anchored_lines", lambda *_: {})
            assert _brief(engine, period) == actual
        assert actual["data"]["position"]["month_expense_fen"] == 700
        assert actual["data"]["funds_overview"] == {
            "total_fen": 1300, "bank_fen": 600, "cash_fen": 700,
            "payment_platform_fen": 0, "inflow_fen": 2000, "outflow_fen": 700,
            "net_change_fen": 1300, "internal_transfer_fen": 0,
        }
        with Dashboard(engine)._snapshot(period) as snap:
            rows = list(snap.connection.execute(*snap.month_journal.sql()))
            lines = snap.reads.voucher_lines(row["id"] for row in rows)
            # Scope is established from actual posted accounts, never kind.
            money = {row["calculation_id"] for row in rows if any(
                line["account"] in {"1001", "1002", "1012", "1101"}
                for line in lines[row["id"]]
            )}
            ordinary = {row["calculation_id"] for row in rows} - money
            assert len(money) == 4 and len(ordinary) == 1
            anchored = snap.month_journal._open_month_anchored_lines(rows)
            assert set(anchored) == ordinary
            snap.month_journal.account_amounts()
            assert money <= snap.reads._verified_source_contents.keys()
            return money, ordinary, {row["id"] for row in snap.month_journal.verified_rows()}

    baseline = compare_and_inspect()
    unrelated = []
    for index in range(40):
        channel = "cash" if index % 2 else "bank"
        subject = f"other-month-money-{index}"
        save("cash_funding" if channel == "cash" else "funding", subject, {
            "period": "2026-11", "actual_date": "2026-11-01", "funding_kind": "capital",
            "owner_id": "owner", "amount_fen": 1,
            channel + "_account_id": "cashbox" if channel == "cash" else "bank",
        })
        unrelated.append(subject)
    publish(*unrelated)
    assert compare_and_inspect() == baseline
