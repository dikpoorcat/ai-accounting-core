"""Correct natural context timestamps without overwriting the initial failure."""
from pathlib import Path

root = Path(__file__).resolve().parents[1]
old = root / ".tmp/stage9-signature-assets-main48-diagnostic.py"
target = root / ".tmp/stage9-signature-assets-main48-diagnostic-r2.py"
text = old.read_text(encoding="utf-8").replace(
    "stage9-signature-assets-main48-diagnostic", "stage9-signature-assets-main48-diagnostic-r2")
text = text.replace(
    "generated[label] = result.get('data', {}).get('generated_at')",
    "generated[label] = {'root': result.get('generated_at'),\n"
    "                                        'data': result.get('data', {}).get('generated_at')}\n"
    "                    if 'generated_at' in result:\n"
    "                        result['generated_at'] = '<response generation time>'")
text = text.replace(
    "                        if 'generated_at' in result.get('data', {}):",
    "                        if 'generated_at' in result:\n"
    "                            result['generated_at'] = '<response generation time>'\n"
    "                        if 'generated_at' in result.get('data', {}):")
with target.open("x", encoding="utf-8", newline="\n") as output:
    output.write(text)
print(target)
