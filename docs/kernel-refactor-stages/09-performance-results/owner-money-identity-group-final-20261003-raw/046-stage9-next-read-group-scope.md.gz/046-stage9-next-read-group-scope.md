# 6688 后续读取组：静态范围与最小观察

本轮读取当前源码与既有 `.tmp/stage9-owner-main48-reference-group-native-work.json`。signature与资产消费过滤保留；窄own-line reader经r5交替native对照无净收益，已撤回，四个候选生产文件恢复精确6688原字节。候选源码和新增18项prototype-only测试原文保存在`.tmp/stage9-own-line-rejected-production-source-20261003`，不删除旧业务断言。下文own-line设计及fallback表仅是已撤回方案的历史边界，不能作为当前已实施功能。6688既有fresh qualification/full4coverage及browser150成功只绑定该旧固定候选，后续修改不继承验收。当前用户决定draft-only，正式交付延期。

当前 pure48 的 brief 超线 16→3、median 500.4→476.9ms；assets 5→1、457→417.3ms；reports 5→5、476.6→477.1ms。C4/C5 减少往返已见实际结果，但报表未净改善，不能仅凭 SQL 少称剩余问题已解决。

## 已测全贡献负结果；历史收窄方案（最终已撤回）

root 原件 `.tmp/stage9-owner-month-anchored-lines-prototype-main48-r2.json` 为同主48/2019-12、sealed6688 runtime 加局部 Journal prototype 的正常 brief 工作诊断；除 generated_at 外完整响应等价。全 eligible 贡献方案实际 SQL233→248、VM1136300→1592200、返回19904→25522行、字节10165621→约1450万；完整 outcome decode1015→534，但 result transfers1016→1537。它减少一次 JSON 集合，却增加整体返回/扫描/装载，不采纳全贡献方案，不能称页面加速。

实际重复消费来自 Funds.events→_verify_event_sources：后者确实需要约521个资金业务的完整 balances/values，并调用 verify_selected_content。原 Journal 先完整解码可共享此结果；全贡献先增加约3MB贡献与独立源字节，随后 Funds 仍完整解码这些业务。此负结果只排除该同源全贡献选择，不永久排除不同消费范围。

改进范围由真实 consumer 选择一致性约束：先用既有 reads.voucher_lines 取得原本 account_amounts 也必须读取的全部实际行，对任何出现 `1001/1002/1012/1101` 的当前普通凭证仍走原 outcome；仅未出现这些账户且满足下述 owner==basis/owned/open/unfiltered 条件的行尝试贡献。不得按 kind 猜纯确认，不从 balances/category 反推账户，也不裁凭证行或 fact/采用 proof。

`FundsRead.events` 默认四科目与其 `_verified_current_event_rows`、Journal.select(accounts=accounts) SQL 都按实际 voucher_line 的任何命中选整张凭证；故同一完整实际行过滤可确切排除默认当前 Funds._verify_event_sources 的这批消费者。共享常量可为 dashboard_funds 私有 frozenset，Journal 函数局部 import；仅替换 events 默认集合和 `_money_event_rows` 默认四科目等值 guard。投资专项 `{1101}`、caller 明确 accounts/subjects、opening/current=False、frozen/reversal 逻辑不改。

这个选择只证明“不进入默认当前资金 events”，不证明页上20条、其他 state、metadata 或贡献父源绝不再完整解码。root 随后实际 r3 对照仍多约1.79MB/+345kVM，完整响应相等、full decode1015→533；因此窄选择加完整 report reader 也不直接 seal。筛选用的实际行只作定位，后续 anchor 完整行匹配与 strict actual 检查必须成功；若删除/改坏资金科目使一行误入候选，完整行不一致必须拒绝，不能签发 journal headers 或让 Funds 过滤隐藏损坏。

### r3 后的职责收窄及 own-line reader

account_amounts 原 verify_selected_content 明确不核 parents、保存 input closure 或报表 party 关系；但完整 read_open_contributions 要物化 resolution、行第7列业务字段，查全部 parents/source_bindings 并核所有这些来源。将后者强加给纯分录摘要超出原 Journal 职责，不能因为它已是报告快路就认为金额路径也足够窄。

root 新候选是在 report_open_contribution 私有职责中提供 own 完整行 projection：同一候选 SELECT 取既有 formal publication/immutable anchor/body；先核 raw body checksum 对独立 anchor 和 body_digest，再用窄 SchemaValidator 取 format/pub/calc/result_digest/fact_id/source_bindings 与 rows 前6列。每行仍严格 JSON array 七列，第7列必须为 object，可用空 typed_dict(extra_ignore) 避免构造其大业务字典；any_schema 会物化内容，不能达到此目的。前6列 version、line_no、account、debit、credit、cashflow 类型和原顺序保留，不添加金额精度/上限、非空字符串或业务规则；完整数值规则仍由原 strict `_lines`/checked 处理。

自身认证保持 selected calculation 的 publication.subject/header、anchor calculation identity、content publication/calculation identity、唯一 own source binding，顶层 result_digest/fact_id 与 own binding 一致；只把这条 own binding 交现有 private _AnchoredSourceProof→_verify_anchored_source_bytes。该步骤仍核真实保存 outcome/fact 字节、fact 子序/seals/kind/period/identity，以及非canonical/duplicate fallback。只检查自身保存源，未签发 parents/input closure、任意 values、其他声明 binding 的语义或完整 dependency proof。

忽略 usable/parents/resolution/第7列语义符合原 Journal 金额职责；这些仍由 report consumers、close/fullverify/repair 的独立完整 checker核验。独立 anchor 精确 raw checksum 是忽略额外报告字段的前提，普通 source digest 或派生 body 自校验不能替代。Journal 仍逐 version 核完整有序 rows 与实际 strict lines 整集相等、原 total/采用/current/frozen/publication checks；窄 parser 不是金额 proof，不可直接求 body 的和。

认证 helper 只应提取两个真实消费者共有的 present-body/own-header/own-binding/source-bytes 检查，不统一 fallback政策：现 verify_published_source_bindings 缺 anchor 必须原错误、缺 body 原 read-only重建检查后要求 saved_input_identity；新 Journal 缺 anchor/body 留原 outcome。present 损坏不吞错，不扩成参数框架。所有本批 schema/自身绑定成功再做整批源字节 proof与返回，不能提前把未核 line projection 发到 shared cache；Journal summaries/verified_rows仍全部业务成功才发布。已有 independent publication/byte proofs可以保留其真实成功范围，不等于失败金额 proof。

新路径仅原 current-owned/open/unfiltered、普通 owner==basis、无默认资金科目的候选；review/reversal/closed/fixed-v1/unowned 等仍原 outcome。reader函数为 read_own_line_projections(reads, calculation_ids)，返回 dict[calcID, tuple[(version_id,line_no,account,debit,credit,cashflow),...]]；无current-owned资格返回{}，缺anchor/body省略ID，整批自身/schema/字节成功才返回，不存line/fullreport/decoded缓存。

root r4 原件 `.tmp/stage9-owner-month-anchored-lines-prototype-main48-r4.json` 绑定sealed6688 runtime和本轮 reader 文件SHA95b78ce8e484d0cc34f8b2cb2160caa2df38afe5dfa5fc325a0c9d72a2ac9de6；完整 brief响应相等（generated_at除外），result decode1015→533、peak25.7→22.1MB，但SQL233→240、VM1.136→1.481M、返回字节仍约+1.77MB。结果是局部内存/解码降低，不能称净页面收益或seal资格；完整贡献字节仍存在，诊断壁钟不作性能验收。

## 同组消费缺口：activity_classification 回退重跑完整 Journal 选择

### 实际根因与必要读取

位置为 dashboard._Snapshot.activity_classification，唯一分类producer。原快速分支需月 journal.verified_rows成功且全部 needed_basis已在 _verified_source_contents；needed_basis包含所有expense和所有非冲正ACTUAL_PAYMENT_KINDS。新own-line保存的只是精确anchor/source-byte proof，费用 outcome未完整decode，因此原条件不成立，转原SQL fallback。

r4 实际三条 fallback SQL重新包完整 Journal.sql：basis IDs898/88800VM、付款settlement.source IDs495/100200VM、分类1005 rows/153200VM。三条共约342200VM，与新增约345kVM一致；这些精确 ID/费用信用字段/直接付款来源仍必要，反复完整月 voucher selector 的定位成本则已有同snapshot完整成功headers可供替代。源码相似不是依据，该回退触发与实际SQL量已有root原件。

原先候选是四字段 json_each定位relation代替三条完整selector，技术上可以保持每row身份，但它仍需三次关系组装/扫描，没有必要为此添加Journal locator API。root后续提出的更窄 decoded-payment 分支符合真实消费职责，作为首选。

### 最窄改法

保留旧全部needed_basis已decode的分支。将集合拆成 payment_basis（ACTUAL_PAYMENT_KINDS且reverses_id is None）和 expense_basis（所有expense，含冲正）。仅要求全部payment_basis在成功contents中；对 missing expense IDs先 verify_sql_outcomes，再 exact-ID PK SELECT id,json_extract(outcome,'$.values.creditor_kind')，保留实际存储窄字段。该证明可精确复用own-line的 _anchored_source_bytes，不新增decoded缓存。

费用creditor映射包括每个expense basis：已有decoded费用继续原 values.get行为；缺decoded只消费窄SQL实际字段。必须核读回IDs等于missingexpense，不能遗漏来源后dict.get默认为None把真实费用静默归他类。按verified_rows逐凭证生成group/count，不把共享basis ID去重成一个凭证；同basis正向/冲正键保持 (basisID,reversal)。

原 payment slots读取/结构核验、全部直接source_calculation ID收集、verify_published_source_bindings及缺body时 saved_input_identity、verify_sql_outcomes、decoded来源种类/信用/退押金obligations以及未decode来源exact-ID窄SQL全部不删。不能先按source.kind过滤再证明，否则损坏kind可隐藏真实来源。payment reversal继续不展开settlements，expense reversal保留精确basis字段读取及correction组。

新增“费用未decode”的资格建议明确限 active current-owned connection/reader、exact unfiltered month且verified_rows成功；旧全decode分支历史行为不额外改。非decoded payment、无verified_rows、部分/其他月份或筛选journal、不满足current-owned/v1，保留原完整SQL fallback。直接测试fixture verified_rows=None仍走原分支。不得从kind猜付款必然decoded，真实contents membership必须满足。

### 全局同类范围

brief默认group/type_counts、_brief_activity_row、owner_voucher以及旧诊断voucher均消费同一个cached_property，公共CLI/MCP/HTTP经Dashboard同步受影响。活动按需/分页若未先完成整月 money proof，仍SQL fallback，不用当前20条rows冒充完整月。闭月成功完整proof的既有decoded快速行为不变；新的缺decode资格不越历史reader边界。

FundsRead.events已有同完整月 verified headers 的实际科目过滤，但其balances/values source proofs属于金额，不能用分类creditor字段替代。Funds.investment_events的settlement.source查询包含events/effects/current=False/opening范围及保存input身份职责，不能用本月分类集合裁它。dashboard_reads.metric_rows（员工/labor/capital/资产过滤journal）及资产consumption全through-period汇总也没有这份完整月相同scope证明；这轮不机械替换，未测收益不称排除或已修。reports不消费activity_classification，本调整不会减少其贡献解码。

close/fullverify/repair/backup/restore与fixed-v1独立源/依赖/冻结证明仍原路，不签发scope或外部already-verified参数。现有定向位置：test_brief_activity_reuse（当前/历史来源两页外损坏与成功reuse）、test_dashboard_activity_classification（supplier/employee/mixedbatch、闭月新draft、offpage/prior-month duplicate/digest）、test_dashboard_json_source_lookup（SQL窄fallback/无verifiedrows）。新missing-expense混合分支须对照旧完整分类，包含空月、多slot/同source、review/basis差异、reversal、缺ID与两次拒绝、无prefix/new snapshot/v1；由root统一验证，本 agent未执行。

该修改可明确减少三条重复月selector；实际返回/来源body额外读取仍须集中对照。r4约+1.77MB不能全归这三条定位SQL，不宣称消除所有新增字节或保证500ms。

### 真实工作与可行职责

`dashboard.py:_brief_amounts` 调 `dashboard_reads.py:Journal.account_amounts`。main48 brief 保存结果1016行、完整 outcome 解码1015；result_lines 调2010次，strict `_lines` 实际1006次。这不是同 outcome 的重复 strict 检查：`verify_selected_content` 只完成 JSON、封签、事实和身份核验；account_amounts 第一次检查完整分录。目标是为汇总换用已存在的独立完整行证明，不能删除第一次检查。

`report_open_contribution.prepare_open_contribution` 的 `_publication_rows` 读取该 calculation 拥有的全部非冲正 voucher_version 的全部行，按 version/line_no 排序，没有按 RECLASS、现金科目或可见行裁剪。`rows` 保存完整七字段行及报告语义，`source_bindings` 绑定 root 和实际加载的直接来源。`sync_open_contributions` 只为当前正式写事务新 publication 铸造 immutable anchor；旧缺失 anchor 不补权威。

因此 root 最新收窄方案有证明基础：current owned snapshot、current reader/non-v1、未冻结开放月、无 kinds/accounts/subjects filter；逐 row 仅普通非 reversal、`voucher_calculation_id == basis_calculation_id` 且完整实际行不含默认四个资金科目时尝试贡献。account_amounts 原 SQL exact selector、voucher adoption、publication original/current 关系、完整 current ID 集合必须先保留；原始冲正/frozen adopted 分支也不删。scope 判断不代替这些 checks。

完整 read_open_contributions 已核 publication、anchor/body checksum、shape、root binding、所有 declared bindings 的精确源 header/seals/事实/保存字节、精确直接 parents 与 source bindings 一致性；这是已测 r2/r3 的读取职责。新 own-line reader仅保留自身认证与完整行投影，不从完整 reader删检查，也不签发其他消费者需要的关系证明。

Journal 私有金额职责应将 content.rows 一次按精确 version 分组；对本 row 的全部 line_no/account/debit/credit/cashflow 收齐完整序列，检查重复、缺失、额外、顺序，与实际完整 voucher_line 集合相等。实际行仍走 `_lines` 全部 shape、非空 account/cashflow、strict int、非负/单边、signed64、每凭证平衡约束，及原 total/连续 line_no 检查；累计保留 `checked`/`sum_fen`。不调用 selected_open_line 对每行重新线性筛整份 rows，不直接从贡献 body 求和；逐行命中不证明完整集合。

原 outcome 字节仍由 `_verify_anchored_source_bytes` 读取并核验；退出的是不必要的完整 JSON 解码，源字节/事实/身份不退出。canonical bytes 与独立 anchor 的 result digest 精确匹配才快路；noncanonical 原字节继续 `_object` 与 canonical digest 比较，duplicate members 仍拒绝。普通 raw digest 单独匹配不具有该证明。

### fallback、兼容和失败边界

| 情形 | 决定 |
| --- | --- |
| missing anchor/body | existing read_open_contributions 省略该 ID；此 row owner/basis 留在原 verify_selected_content/result_lines。独立 fullverify 仍拒绝缺 anchor，汇总不重建。后续 activity/Funds 原本需要 own binding 的来源仍可能原样拒绝缺 anchor，fallback 不是整页免核验。 |
| anchor/body 存在但 checksum、自身身份/binding、完整行投影 shape 损坏 | 新 own-line reader须抛 content 错误，不吞错回旧 outcome；报告专属 parents/resolution语义仍由完整 reader承担。这扩大 Journal 对已存在自身投影的检查面，需明确验收；旧 Journal 独自不读 body，不能宣称所有坏body错误文本完全相同。 |
| 普通 version 缺行、重复/额外行、whole-line 不一致 | 拒绝，不能当可选显示投影成功。若正常 owner 有多个 version，逐 version 独立收齐，不能用单 version 假设裁掉其他 owner 行或 IDmap 覆盖重复。 |
| review_no_impact：旧 voucher/new basis | owner!=basis，owner、basis 完整 outcome 原路；新 basis 贡献 rows=[] 正常，不能代替旧凭证。 |
| reversal、closed、原始/frozen adopted | 原 outcome/原始凭证/冻结 adopted 对照全部保留。少量例外不必让整月全部 fallback。 |
| filtered/unowned/不同连接/new snapshot/fixed-v1 | 原路；仅存在 snapshot cache 不是 current-owned 资格。 |

只有全部账户/summary/完整 headers 成功后发布既有 journal_summary/count/verified_rows。完整报告贡献 body cache 是整组完整内容成功后发布，新 own-line reader不签发该缓存或 decoded outcome；independently completed anchored-byte proof可能早于最后 Journal whole-line失败完成，这不是 journal成功证明。失败测试须连续拒绝、无失败 line projection和 journal summary/headers；合法独立源 proof不得跳过下一次 whole-line检查，也不误称失败金额 proof。

### 公共范围与成本判断

直接候选为默认 brief 完整月 summary；CLI/MCP/HTTP 通过同 Dashboard 路由。凭证列表仍默认20、全部/焦点/分页语义不变；页上20条以及真实 values、asset members、字段来源消费者继续完整解码。Funds summary 原 verified compact effects 证明不能被贡献 rows 代替。activity_classification 已有 SQL 窄字段 fallback；verify_sql_outcomes 精确复用 `_anchored_source_bytes`，不会必然又为整月分类计数完整解码。

reports 已消费贡献，此改本身不减少1004次必要 contribution 解码。员工/资产默认不调用整月 account_amounts，不能声称直接提速。close/preview、独立 fullverify、repair、backup/restore/fixed-v1 不进入新路径；保留 `_check_sources`/`_outcome`/完整依赖、compare_open_contributions 独立重建和历史 reader。没有新端点、DDL、权威、共享 body cache 或跨请求缓存。

全贡献 r2 和无资金账户选择加完整 report reader 的 r3 均有实际负结果；新own-line reader r4诊断已完成但收益未获接受：完整响应except data.generated_at相等、result JSON解码1015→533、Python仪器峰值25741920→22140849B；SQL233→240、VM1136300→1480800、rows19904→22324、bytes10165621→11937428增长。instrumented6147.1518→6035.8811ms不是纯收益或browserpass，需要真实无插桩前后native对照。原件stage9-owner-month-anchored-lines-prototype-main48-r4.py/.json/.log保持原字节，不覆盖旧失败或manifest。report 两批贡献1004行/3322180返回字节、1004次贡献解码，anchored source header/outcome 仍约1237060字节；brief 原 source outcome 查询约1239867返回字节，result body994988字节，整页10165621字节不能全归 Journal。只给默认资金 events 不消费的行读取自身完整行 projection，仍需实际比较更大贡献正文与减少 outcome/分类解码、parent SQL/Python物化；不能仅 result_JSON_decode 下降称净省时。方案使用既有完整贡献/独立 source binding和 per-row fallback，不新造权威。

root负责Journal接线与统一测量。r5修窄classification后，完整响应except data.generated_at相等，VM1136300→1156100、bytes10165621→11756554、result JSON decode1015→533、仪器峰值25743997→22019957B；15次交替无插桩backend oldmedian/max483.7177/547.7141ms，new485.5747/557.0316ms，无净收益，全部raw/slow保留。这不是浏览器验收。stage9-withdraw-own-lines-candidate.py已撤回上述四文件及新增prototype-only测试；旧完整金额／来源／历史路径保留。此前line＋开发package定向39passed/1failed/2warnings/90.96s，失败为新增混合fixture调用不存在的bank_funding；修正后未重跑，不造完整通过。

## 同组已实施：重复 signature；返回组装仍不改

### 已证实的重复工作

位置：`query_reads.py:475 _verify_current_voucher_publication_rows`、`:597 _current_voucher_signature`；直接生产调用来自 `verify_current_voucher_publications`、`_verify_current_publication_voucher_heads` 的 owned scope-head 分支、`_selected_current_voucher_publications`。后者被 Journal.account_amounts 和 report_projection._authoritative_rows 使用。

冷 row 在函数入口生成六字段 `(id,voucher_id,calculation_id,reverses_id,period,subject_id)` signature。proof=None 时该值不留存；全部关系/记录核验成功后，owned cache producer 再对同一 row 生成一次 signature。下一次精确 selector 消费已有证明时再生成一次，这是必要的输入匹配。代码没有在这段验证中修改输入 row 的六字段。

现有 main48 计数：brief/report 各 `_verify_current_voucher_publication_rows=2`、signature=3015；funds/employees/assets 的 relationship-row verifier=1、signature=2010。report/brief 的 signature generator 产生 21105 次恢复（每六字段 tuple 有七次 generator 恢复），report cProfile 该 generator self≈87.78ms、signature cumulative≈92.48ms；两个 relationship-row verifier cumulative≈116.68ms。这些是插桩 profile 数，generator 会被 profiler 放大，不是可兑现页面净省时。精确 miss/hit/阶段 ID 集合本輪没有另采，3015/2010 不能被解释为额外 SQL/body 读取。

已保留入口 signature 的完整六字段访问，防止缺字段错误拖到 `cached.update(generator)` 留下成功前缀。在 owned/current 分支局部用 list 按行保留本批入口 signature，整批关系与 publication 全成功后 zip(strict=True) 按原顺序发布；命中仍逐行精确比较。六字段 generator 已改为同顺序直接 tuple，保持字段访问、缺字段顺序、值/容器完全相同。没有新 snapshot cache、DTO、外部 verified 参数或跨请求状态。

重复版本输入不可用 ID dict 静默覆盖，应按 row 顺序保留局部 signatures；不能把同 ID 不同内容误当相同 header。publication/subject/period/current head、original/head、review_no_impact、withdrawn/cleared、correction reversal 的原关系与 digest 校验全部保留；错误码/失败缓存规则不变。signature 只是 exact physical head identity，不能签发结果正文、分录或采用 proof。

### 同职责的小候选，收益未证

head verifier 调用 `_verify_current_voucher_publication_rows` 的返回 dictionary 被丢弃；report_projection._authoritative_rows 接收 `_selected_current_voucher_publications` 返回值也只判断是否 None，以决定 fallback，不消费 publication map。现函数在冷证明末端返回 `reusable | publications`，在全部命中时仍逐 row merge cached original/current pair。这是实际 caller 的未消费投影，不是可以省略 head proof。

当前 profile 的 dict.update cumulative≈93.71ms 包含内部 signature generator 成本，不能全归到 publication union/copy。未有单独净成本证据，不先造 proof-only 参数或改返回协议。若一组观察证实该投影成本可观，可以在同私有证明职责中只抑制这些明确 proof-only caller 的返回 map 构造，仍执行全部 signatures/关系/记录检查和成功缓存生产；Journal 真实需要 publication map 的调用及原 fallback 返回保持。该设计待 root 固定，不在本轮实现。

### 全局处理范围

| 范围 | 必要职责与影响 |
| --- | --- |
| 五页默认 | 共同 open-voucher scope 验证都到 head relationship proof，因而不仅报表/简报。现有 native 五页均有 2010 或 3015 个 signatures；应在共同 helper 收敛，不能仅改 report 调用点。源/正文/金额读取不减，主要是 Python 组装减量。 |
| 简报分页/焦点/活动，员工/资产按需，资金完整列表 | 各自选择范围与证据不变。只要经此公共 helper，owned/current 局部 signature 可复用；没有 shared proof 或不同 physical row 的分支仍完整核验。单项小集合收益尚未测，不按名字判热点。 |
| BusinessQueries 当前采用/资产 owner | 两处 verify_current_publication_voucher_heads 与同公共 reverse head verifier相连。forward proof 和 source selection 不省；不能凭成功 reverse signature 跳过另一方向的 missing/cleared/withdrawn 检查。 |
| CLI/MCP/HTTP | Service 路由到同 Dashboard/Reports/BusinessQueries，公共 helper 处理不依赖传输，不改 endpoint/响应/公司月份或分页语义。未逐命令测量。 |
| close/preview/fullverify/repair/backup/restore | 普通独立或写连接不满足 active owned/current guard，继续原源选择/核验；局部保留 signature 的方案限 owned/current。若机械改为直接 tuple，也必须保持全部六字段访问与异常顺序，不新增 proof reuse。完整验证的 `_outcome`/`_lines`、依赖/来源及冻结集合不得裁。 |
| fixed-v1 | historical_content/registry 与 current selector guard 排除 v1；固定 reader 没有本批 owned relationship cache生产。保留原路径/历史规则，不因 current signature 方案改固定 source wire 或金额/重复成员语义。 |

## 最大必要读取与本轮排除项

report 当前 SQL270、VM1022000、返回24896行/10688456字节；保存结果1007行、full result decode3、contribution decode1004。最大的两个 contribution candidate batches合计1004行/3322180字节，是互补的真实来源，此前同请求正文重复 ID 交集已测为0。不能重试 rawbody cache 或 native contribution decoder；后者已有等价但更慢原件。

report party beginning/end 的两个 cutoff 不同，`_party_balance_nets`/stored_month 已按快照 exact key 复用。read_report_flow 23 次调用实际只读12份 frozen flow（1605370字节），classification headers12批/4932行/784188字节、187600VM；已有精确 refs 样本0交集，不能改称重复。父请求的 source/period 与每月 adopted classification membership必须完整匹配，不能为了 summary只挑显示项；current contribution 的 parent/source binding/fact seal/typed voucher checks仍必要。readiness范围已经由C4批化，非重新忽略47个月来源。

brief SQL233、VM1136300、返回19904行/10165621字节，result_rows1016、result_JSON_decode1015。完整月金额、公示凭证集合与实际 voucher lines 必须保留；上节新候选仅将 eligible 普通行的证明来源改为已有完整贡献。verify_selected_content 不提供 strict-lines 证明；result_lines2010 实际_lines1006，已局部 memo。原 unused0、audit24、MATERIALIZED、旧 anchor/decoder、wide-prime 的负面条件不重试，不用源码相似重新宣称重复。

brief frozen settlement_root679077字节、1458ref/219006字节已有完整目录必要性与无同根重复证据；本轮不裁。_scope/_tail_rows的current/period边界不同，现有counterpart与tail缓存已复用可复用内容，profile出现两次调用本身不证明两批重复正文。资产最新owner替代历史member也仍缺独立完整性证明。

窗口/排序实验只适用于其当时条件：当前已恢复voucher20页用C2 verified_rows；report精确完整month的headers与lines分读保留duplicate rows及排序。现有 native 显示该selected header SQL137900VM/1005行、lines SQL49800VM/2292行，但没有当前计划或端到端重复排序证据。不把旧负面永久禁用，也不在没有新调用证据时再盲试窗口SQL。

## 已完成定向及下一次整组观察边界

signature 定向 `tests/kernel/test_open_publication_snapshot_work.py` 19 passed in 12.27s，原始日志 `.tmp/stage9-money-signature-boundary-tests.log`；两文件 ruff passed。新增测试证明冷 input 每行仅一次 signature 构造、命中精确重新比较、末行缺字段/同ID不同voucher身份连续两次失败且没有 relationship/publication proof 前缀。既有本文件同时覆盖 initial/review/replace、mixed hit/miss、晚失败、unowned/history/registry-v1、新 snapshot。没有单独 seal/browser/native 或大套，不能称净提速。

own-line方向已由r5无净收益终止，不继续该方案。当前收敛范围为signature、资产消费过滤与开发package；六文件114node组108passed/6failed/213.89s，原件stage9-signature-assets-development-package-group-corrected.log/.xml保留。六失败仅在metadata私有消费头与activation＋consumption完整事件比较；已修测试complete helper为先完整core核验再消费投影，保留core完整身份和unowned/v1完整fallback及全部源损坏／失败cache保护，修正后未运行。原计划test_owner_asset_activation_identity仍待核验。signature的profiler generator87ms不能估成净省87ms，当前候选未新固源／性能验收。

负面集中覆盖当前普通完整 lines、缺/重复/额外/错序/不平衡/overflow、anchor/body缺失 fallback 与存在损坏拒绝、duplicate/noncanonical源字节、review owner/current basis不同、冲正/冻结/无影响新basis、混合 eligible/fallback、两次失败无 journal prefix、unowned/另一连接/new snapshot/v1。运行与 pure timer/root其他 CPU 由 root 调度；本 agent 没有写新原型或执行这些汇总测试。
