# Money／identity r5后原件归档计划（尚未归档）

只列明确合成原件，不含DB、凭据、checkpoint；不修改旧manifest。执行新独占gzip与manifest须另调度，本文不代表归档完成。

| 范围 | 精确已存在文件 | 证据限制 |
| --- | --- | --- |
| r5诊断与交替native | stage9-owner-month-anchored-lines-prototype-main48-r5.py、.json、.log | 6688样本；完整响应仅生成时间例外，15次交替backend无净收益；不是浏览器／新资格。raw/slow数组保留原JSON。 |
| 撤回动作 | stage9-withdraw-own-lines-candidate.py | 四文件回到6688；不能将撤回helper当测试或新seal。 |
| 被拒候选原文 | stage9-own-line-rejected-production-source-20261003/dashboard.py、dashboard_reads.py、dashboard_funds.py、report_open_contribution.py、test_owner_month_anchored_lines.py | 当前候选源码／新增18项prototype-only测试；不是6688固定源码，混合fixture已修但未重跑。 |
| 初line＋package失败 | stage9-owner-lines-and-development-package-directed.log、.xml | 39pass/1fail/2warnings/90.96s；bank_funding不存在的新增fixture失败，不伪造修后全pass。 |
| 新signature／assets／package失败 | stage9-signature-assets-development-package-group-corrected.log、.xml | 六文件114node108pass/6fail213.89s；metadata旧私有口径，原activation identity文件尚待核验。 |

本轮仅静态修订test_owner_asset_metadata_scope.py的私有比较口径，修正后未测试；后续若归档该原文，应标current test-only，不能当固定6688源码。r4与更早失败原件及已有manifest维持原样，集中归档时按原组准确名单另列。
