# 请求生命周期：静态拥有关系与剩余观察边界

本轮只读主源码、固定6688对应实现和现有测试；没有运行DB、CPU、profile、GC实验或修改生产。root已报告r5完整响应相等但15次AB后端 old median483.72/max547.71ms、new485.57/max557.03ms，无净收益；own-lines/classification/四科目常量改动已撤回，仅保留signature及另一组资产过滤。本scope不重试own-lines。

## 结论

当前没有静态证据支持“请求Snapshot大环尚未释放”或“resident pool持有前请求proof”这个新根因。Snapshot确实构成环，但主源码与固定6688都已有边界释放；现有四页weakref测试检查请求返回后对象立即失效，不调用gc.collect。不能仅由400/500ms周期尾部推断泄漏或GC因果，也不能把正常可回收对象称永久泄漏。

目前不建议新增Weakref、再次清理已清缓存或改变GC设置。若后续实际观察发现存活对象，先找其外部拥有者/未断开的真实反向边，才能定窄生命周期修复。释放应在整个请求物化完成之后，不能为了少内存提前丢必要共享proof。

## 实际对象拥有关系

| 对象/边 | 活动期间的必要用途 | 退出处理与判断 |
| --- | --- | --- |
| Snapshot→Journal/month_journal/Calculations/ClosedPeriods/FrozenFacts→Snapshot | 同一完整请求的选择、分页、lazy calculation和冻结采用 | `_Snapshot.release` 清空Snapshot.__dict__，断开owner到所有helper的反向边；Dashboard._snapshot finally调用。初始化失败也release，release不依赖初始化到某一阶段。current与sealed6688都有，不能报告新未修环。 |
| Snapshot→calculation_cache→CalculationView→Snapshot；JournalRow→Snapshot | 页上实际业务、facts/outcome/lines延迟物化 | owner清空cache后无该环。JournalRow通常是局部returned batch，产品返回已物化owner dict而非lazy view。若外部直接保留私有view，它只持已清空Snapshot，不能按页面请求本身泄漏处理。 |
| Snapshot→DashboardMetadata/Records/ProfileCollection/Projection/Management/tax集合→Snapshot | 精确资料、历史/当前身份和字段来源 | release清owner全部metadata入口；Projection本身只持Records与无self捕获的lambda，未看到child之间形成独立互环。 |
| FundsRead→snap/connection、shared_pages/profiles/event_queries | 资金整scope证明、计算、页内共同结果 | FundsRead是_funds局部对象，不挂在Snapshot或pool上；数据集合不持FundsRead自身，现有return投影普通dict/list。不是跨request缓存。 |
| BusinessQueries→reads/engine/store | 共享本次source/关系读取 | 没有reads/engine/store到BusinessQueries的反向边；Snapshot释放该入口。独立caller保留BusinessQueries时可能保留自身reads，这是caller拥有期，不等同Service页面缓存泄漏。 |
| QueryReads→engine/store/connection、各proof/data cache | 活动snapshot的精确成功proof、正文、采用、headers | QueryReads.snapshot finally ContextVar.reset、_reset所有proof/data字典和snapshot token、authorizer(None)。_reset保留engine/store/connection绑定，但后者无回到该reads的边；不需清绑定才能结束proof有效期。 |
| _MaterialSqlOutcomeBatch/_OpenVoucherScopeHeads→reads/connection/token/rows | 活动scope的不可伪造内部携带对象 | 临时caller对象；QueryReads缓存不存这两个owner对象。结束token更新/active=false后不能继续签发proof。未见owner↔reads长期互环。 |
| Engine→Store→ResidentReadPool→idle entries→connection | 请求engine身份与受限SQLite页缓存 | Service.engine每次返回新Engine，pool不保存Engine/Store/QueryReads。idle entry只有path、file signature、connection。256MiB是每resident连接有界SQLite页缓存，不是前请求业务图，不能删作为优化。 |
| Store.validate_connection bound method→Store | 打开/复用连接时结构/身份校验 | runtime.connect/validate_reused_read_connection同步调用，未存入返回connection；当前Store使用类方法实现，没有历史self闭包反向边。观察wrapper若把bound method挂回Store会自行制造环。 |
| QueryReads.snapshot.keep_snapshot authorizer→无reads捕获 | 防COMMIT/BEGIN换事务冒用proof | 只读无捕获callback；退出移除。pool归还再次清authorizer/trace/progress callback并rollback；没有callback留着业务图的实际路径。 |
| service close_previews/active_close_previews | 精确owner批准与预览绑定 | ClosePreviewIntent只存身份/period/versions、签名/summary bytes，不存Engine/Snapshot/QueryReads。这是必要活动意图生命周期，不是待清的页面cache。 |

QueryReads关系解析的load_direct/self.calculation/self.parents只作为同步resolver参数；resolve_calculation_relations返回纯关系dict，未返回这些callbacks。source_records已用显式stack，collect不递归捕获自身；目前没有该局部闭包留下读图的证据。报告complete_references闭包不被返回或保存，cache保存的是已读data，非closure。

## 全局入口范围

五页中brief/funds/employees/assets都经Dashboard._snapshot；reports直接QueryReads.snapshot，Reports._report/closed_period_coverages共享其数据缓存，不创建Snapshothelper图。context也直接QueryReads.snapshot。页面按需、焦点、分页、失败/空月由相同contextmanager退出，必要proof在整个物化期间保留。

CLI/MCP/HTTP的Dashboard入口共用这些生命周期。Service.dispatch局部handler字典持bound methods，仅调用期使用，未保存到Service字段。owner-review bound callback虽指向Service，也无Service到Dashboard的持久反向边。

生产全局仅另一个直接Snapshot构造在close_review.build_owner_review的frozen-position分支，同样try/finally release。Periods/close、独立fullverify/repair、backup/restore等的QueryReads普通实例未启用owned共享proof；没有页面Snapshot环。它们的不可变来源/完整依赖/冻结集合必须保留；本scope不证明所有异常traceback或插件外部caller都不保留对象。固定v1走历史reader与同必要调用生命周期，未新增释放/金额规则。

## 已有证据与未验证范围

`tests/kernel/test_dashboard_bounded_reads.py`:

- test_dashboard_page_releases_snapshot_without_cyclic_collection参数brief/funds/employees/assets，捕获Snapshot及QueryReads的weakref，正常返回后断言None，未强制GC。
- test_dashboard_snapshot_releases_on_failure_and_nested_exit覆盖异常和嵌套请求；外层在内层退出后保持可用，最终weakref失效。
- read_probe读取统计在release前拷贝成独立只读值，没有为了检查而长期持有原Snapshot。

这些是阅读到的现有测试，未在本轮重跑，不能代替当前主48/120真实对象观察。reports、resident pool真正normal dispatch、独立fullverify/repair/backup异常路径、fixedv1对象存活情况本轮没有动态观察，标未验证。仅代码上未见持续反向拥有边。

## 如root统一安排，最小一次观察

用同源已qualified合成输入正常五页请求，捕获Snapshot/QueryReads/Journal/FundsRead/Engine/Store的weakref（支持weakref的类型才记录），在完整response物化、context退出并丢弃请求局部引用后记录存活ID与所属类型。observer不得保存对象、boundmethod、traceback或frame；SQLite connection不假定支持weakref，pool归还只记录idle数/事务状态及callback清理路径。诊断wrapper必须是无self捕获的独立函数，避免旧guard实验人为制造Store闭包环。

可以只观察自然GC callbacks和请求阶段关联，不disableGC、不调整阈值、不手动collect、无跨request业务cache。若周期尾部没有存活图证据，只能报告正常分配/自然GC相关性未证因果；若有存活图，先定位真正持有者，再在请求边界释放其local ownership或按既有业务边界使用Weakref，不先造生命周期框架。当前没有足够证据授权实现下一处清理。
