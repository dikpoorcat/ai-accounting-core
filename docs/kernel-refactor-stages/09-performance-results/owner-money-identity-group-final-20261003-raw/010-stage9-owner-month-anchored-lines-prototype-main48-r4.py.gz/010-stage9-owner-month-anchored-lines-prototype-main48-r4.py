"""Pinned, read-only instrumented diagnostic; this is never browser acceptance timing."""

from __future__ import annotations

import cProfile
import hashlib
import json
import pstats
import sys
from contextlib import contextmanager
from pathlib import Path

WORKSPACE = Path(__file__).resolve().parents[1]
SOURCE = WORKSPACE / ".tmp/stage9-build-source-owner-reference-group-20261003-release"
MANIFEST = SOURCE / "source-manifest.json"
import argparse

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--months', type=int, choices=(48,), required=True)
parser.add_argument('--book-report', type=Path, required=True)
parser.add_argument('--report-sha256', required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
BOOK_REPORT = args.book_report.resolve(strict=True)
OUTPUT = args.output.resolve()
assert BOOK_REPORT.is_relative_to(WORKSPACE / '.tmp')
assert OUTPUT.is_relative_to(WORKSPACE / '.tmp') and not OUTPUT.exists()
MANIFEST_FILE_SHA256 = '9de4a38ae2f93fc575d5a68898ad3cba334ab4dc5786c67731a6c1eead1d52b5'
SOURCE_SHA256 = '6688df6c46f5416ca03917def0d29a701cb20e8ae45b962c59df4a1290f8da62'
REPORT_SHA256 = '2ac7c29d02e920826d27bae8fdb2ff4deb740fa184e3a502aaa9e09521e804a3'
assert args.report_sha256 == REPORT_SHA256, "Only this pinned old-qualified main48 qualification is permitted"
assert BOOK_REPORT == (WORKSPACE / '.tmp/stage9-owner-main48-reference-group-qualified.json').resolve()
assert OUTPUT == (WORKSPACE / '.tmp/stage9-owner-month-anchored-lines-prototype-main48-r4.json').resolve()


def file_hash(path):
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def main():
    require(
        Path(sys.prefix).resolve() == (WORKSPACE / ".tmp-kernel-venv").resolve(),
        "Use the repository virtual environment",
    )
    require(not OUTPUT.exists(), "Diagnostic output must not exist")
    require(file_hash(MANIFEST) == MANIFEST_FILE_SHA256, "Pinned manifest bytes changed")
    require(file_hash(BOOK_REPORT) == REPORT_SHA256, "Pinned verified report bytes changed")
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    require(
        manifest["status"] == "complete"
        and manifest["sha256"] == SOURCE_SHA256
        and Path(manifest["target"]).resolve() == SOURCE.resolve(),
        "Wrong source manifest",
    )

    # Bootstrap only from the fixed candidate, before importing any accounting module.
    sys.path.insert(0, str(SOURCE / "scripts"))
    import stage9_source

    stage9_source.require_source_module(stage9_source, SOURCE, "scripts/stage9_source.py")
    stage9_source.configure_source(SOURCE, WORKSPACE)
    import benchmark_stage9_browser
    import snapshot_stage9_source
    import stage9_metrics

    from ai_accounting.kernel import catalog as catalog_module
    from ai_accounting.kernel import dashboard as dashboard_module
    from ai_accounting.kernel import engine as engine_module
    from ai_accounting.kernel import resident_reads, schema_bundle
    from ai_accounting.kernel.types import canonical
    from ai_accounting.kernel.versions import database_format

    for module, relative in (
        (snapshot_stage9_source, "scripts/snapshot_stage9_source.py"),
        (benchmark_stage9_browser, "scripts/benchmark_stage9_browser.py"),
        (stage9_metrics, "tests/kernel/stage9_metrics.py"),
        (catalog_module, "src/ai_accounting/kernel/catalog.py"),
        (dashboard_module, "src/ai_accounting/kernel/dashboard.py"),
        (engine_module, "src/ai_accounting/kernel/engine.py"),
        (resident_reads, "src/ai_accounting/kernel/resident_reads.py"),
        (schema_bundle, "src/ai_accounting/kernel/schema_bundle.py"),
    ):
        stage9_source.require_source_module(module, SOURCE, relative)

    def check_source():
        inventory = snapshot_stage9_source._inventory(SOURCE)
        require(
            inventory == manifest["files"]
            and snapshot_stage9_source._digest(inventory) == SOURCE_SHA256,
            "Fixed source bytes drifted",
        )
        require(
            file_hash(MANIFEST) == MANIFEST_FILE_SHA256 and file_hash(BOOK_REPORT) == REPORT_SHA256,
            "Pinned attestations drifted",
        )

    check_source()
    book = json.loads(BOOK_REPORT.read_text(encoding="utf-8"))
    OLD_SOURCE = WORKSPACE / ".tmp/stage9-build-source-owner-reference-group-20261003-release"
    old_manifest_path = OLD_SOURCE / "source-manifest.json"
    require(file_hash(old_manifest_path) == "9de4a38ae2f93fc575d5a68898ad3cba334ab4dc5786c67731a6c1eead1d52b5", "Old qualification source manifest changed")
    old_manifest = json.loads(old_manifest_path.read_text(encoding="utf-8"))
    contract_prefix = "src/ai_accounting/kernel/schema_contracts/"
    current_contracts = {k: v for k, v in manifest["files"].items() if k.startswith(contract_prefix)}
    old_contracts = {k: v for k, v in old_manifest["files"].items() if k.startswith(contract_prefix)}
    require(current_contracts and current_contracts == old_contracts, "Diagnostic requires identical manifest contracts")
    for relative, digest in current_contracts.items():
        require(file_hash(SOURCE / relative) == digest and file_hash(OLD_SOURCE / relative) == digest, "Contract bytes changed")
    benchmark_stage9_browser.require_report_source(book, OLD_SOURCE)
    period = benchmark_stage9_browser.validate_book_report(book, company_name="阶段九合成规模企业")
    require(
        book["requested_months"] == args.months
        and book["employee_count"] == 50
        and book["monthly_business_count"] == 1000
        and book["distribution"] == "mixed_cumulative",
        "Wrong main sample dimensions",
    )
    root = stage9_source.synthetic_path(Path(book["root"]), WORKSPACE)
    company = book["company"]
    checkpoint_path = root / "stage9-builder.json"
    checkpoint_hash = file_hash(checkpoint_path)
    require(checkpoint_hash == book["qualification"].get("checkpoint_sha256"), "Old qualified checkpoint changed")
    checkpoint = json.loads(checkpoint_path.read_text(encoding="utf-8"))
    preview = book["verified_open_preview"]
    require(
        checkpoint["company"] == company
        and checkpoint["snapshots"] == book["snapshots"]
        and checkpoint["epochs"] == preview["state"],
        "Checkpoint no longer matches proof",
    )
    expected_state = preview["state"]
    expected_identity = {
        "company_id": company["id"],
        "database_id": company["database_id"],
        "taxpayer_id": company["taxpayer_id"],
    }
    integrity_contract = book["integrity_contract"]
    del checkpoint, book
    require(
        (root / "catalog.sqlite").is_file() and Path(company["path"]).is_file(),
        "Existing databases are required",
    )

    class ReadOnlyCatalog(catalog_module.Catalog):
        @contextmanager
        def connection(self, *, read_only=False, _cross_thread=False):
            require(read_only, "Diagnostic forbids catalog writes")
            with super().connection(read_only=True, _cross_thread=_cross_thread) as connection:
                yield connection

        def recover_operations(self):
            # Never resume pending publications during a read diagnostic.
            with self.connection(read_only=True) as connection:
                count = connection.execute(
                    "SELECT count(*) FROM company_operation WHERE status!='succeeded'"
                ).fetchone()[0]
            require(
                count == 0, "Catalog has unfinished operations; diagnostic will not recover them"
            )

    bundle = schema_bundle.production_bundle()
    catalog = ReadOnlyCatalog(root, bundle)
    require(
        catalog.database_format()["status"] == "released"
        and catalog.database_format()["version"] == 1,
        "Wrong catalog contract",
    )
    companies = catalog.companies()
    require(
        [row for row in companies if row["id"] == company["id"]] == [company],
        "Catalog company identity changed",
    )
    with catalog.connection(read_only=True) as connection:
        catalog_identity = dict(connection.execute("SELECT * FROM catalog_identity").fetchone())

    pool = resident_reads.ResidentReadPool(maximum=4)
    store = catalog.bind(company["id"], read_pool=pool)
    original_connection = store.connection

    @contextmanager
    def read_only_connection(*, read_only=False):
        require(read_only, "Diagnostic forbids company writes")
        with original_connection(read_only=True) as connection:
            yield connection

    store.connection = read_only_connection
    engine = engine_module.Engine(store)
    dashboard = dashboard_module.Dashboard(
        engine, company_name=company["name"], companies=companies
    )
    year, month = map(int, period.split("-"))
    quarter = (month - 1) // 3 + 1

    def check_state():
        require(file_hash(old_manifest_path) == "9de4a38ae2f93fc575d5a68898ad3cba334ab4dc5786c67731a6c1eead1d52b5", "Old source manifest drifted")
        for relative, digest in old_contracts.items():
            require(file_hash(OLD_SOURCE / relative) == digest, "Old qualification contracts drifted")
        with store.connection(read_only=True) as connection:
            connection.execute("BEGIN")
            state = list(connection.execute("SELECT * FROM state WHERE id=1").fetchone())
            identity = dict(
                connection.execute(
                    "SELECT company_id,taxpayer_id,database_id FROM identity WHERE id=1"
                ).fetchone()
            )
            require(
                state == expected_state and identity == expected_identity,
                "Company identity, business state or repair revision changed",
            )
            require(
                database_format(connection, bundle=bundle) == integrity_contract,
                "Company format differs from verified source",
            )
        with catalog.connection(read_only=True) as connection:
            require(
                dict(connection.execute("SELECT * FROM catalog_identity").fetchone())
                == catalog_identity,
                "Catalog identity changed",
            )
        require(catalog.companies() == companies, "Catalog registration changed")
        require(file_hash(checkpoint_path) == checkpoint_hash, "Construction checkpoint changed")
        return {"state": state, "identity": identity, "catalog_identity": catalog_identity}

    import ast
    from ai_accounting.kernel import dashboard_reads

    prototype_path = WORKSPACE / 'src/ai_accounting/kernel/dashboard_reads.py'
    prototype_hash = file_hash(prototype_path)
    prototype_text = prototype_path.read_text(encoding='utf-8')
    tree = ast.parse(prototype_text)
    klass = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == 'Journal')
    methods = [node for node in klass.body if isinstance(node, ast.FunctionDef)
               and node.name in {'account_amounts', '_open_month_anchored_lines'}]
    require(len(methods) == 2, 'Both exact proposed methods are required')
    proposed = ast.Module(body=[ast.ClassDef(name='ProposedJournal', bases=[], keywords=[],
                                           body=methods, decorator_list=[])], type_ignores=[])
    namespace = dict(vars(dashboard_reads))
    exec(compile(ast.fix_missing_locations(proposed), str(prototype_path), 'exec'), namespace)
    prototype = namespace['ProposedJournal']
    from ai_accounting.kernel import dashboard_funds
    funds_path = WORKSPACE / 'src/ai_accounting/kernel/dashboard_funds.py'
    funds_hash = file_hash(funds_path)
    funds_tree = ast.parse(funds_path.read_text(encoding='utf-8'))
    definition = next(node for node in funds_tree.body if isinstance(node, ast.Assign)
                      and any(isinstance(target, ast.Name) and target.id == 'MONEY_EVENT_ACCOUNTS'
                              for target in node.targets))
    constant_namespace = {}
    exec(compile(ast.fix_missing_locations(ast.Module(body=[definition],type_ignores=[])),
                 str(funds_path),'exec'), constant_namespace)
    dashboard_funds.MONEY_EVENT_ACCOUNTS = constant_namespace['MONEY_EVENT_ACCOUNTS']
    require(dashboard_funds.MONEY_EVENT_ACCOUNTS == frozenset({'1001','1002','1012','1101'}), 'Default actual funds scope changed')
    import importlib.util
    from ai_accounting.kernel import report_open_contribution as old_contribution_module
    reader_path = WORKSPACE / 'src/ai_accounting/kernel/report_open_contribution.py'
    reader_hash = file_hash(reader_path)
    spec = importlib.util.spec_from_file_location(
        'ai_accounting.kernel._own_line_diagnostic', reader_path)
    candidate_reader = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = candidate_reader
    spec.loader.exec_module(candidate_reader)
    # The prototype must use the sealed runtime's private proof identity;
    # it adds a reader, never relaxes the original connection/proof checks.
    candidate_reader._AnchoredSourceProof = old_contribution_module._AnchoredSourceProof
    candidate_reader._SOURCE_PROOF_SEAL = old_contribution_module._SOURCE_PROOF_SEAL
    require(not hasattr(old_contribution_module, 'read_own_line_projections'),
            'Baseline must not already contain proposed reader')
    old_contribution_module.read_own_line_projections = candidate_reader.read_own_line_projections
    report = {
        'reader_file': str(reader_path), 'reader_file_sha256': reader_hash,
        'status': 'prototype_started',
        'scope': 'same_saved_sample_exact_owner_month_whole_line_anchor_diagnostic',
        'browser_acceptance': False, 'instrumented': True,
        'source': str(SOURCE), 'source_sha256': SOURCE_SHA256,
        'qualified_report': str(BOOK_REPORT), 'qualified_report_sha256': REPORT_SHA256,
        'qualification_reused_or_created': False,
        'primary_prototype_file': str(prototype_path), 'primary_prototype_sha256': prototype_hash,
        'script_sha256': file_hash(Path(__file__)),
        'exact_funds_constant_file': str(funds_path), 'exact_funds_constant_file_sha256': funds_hash,
        'candidate_scope': 'Only complete normal voucher rows outside the actual default funds accounts',
        'root': str(root), 'period': period,
        'default_page_limit': 20,
        'notes': [
            'Both paths use the same sealed 6688 runtime and ordinary page source checks.',
            'Prototype is exactly two current Journal methods; it is not a sealed release or qualification.',
            'Fresh 6688 qualification only binds the synthetic sample; no coverage is transferred.',
            'Work counters are not browser elapsed time. No timer or verifier is rerun.',
        ],
    }
    original_method = dashboard_reads.Journal.account_amounts
    had_helper = hasattr(dashboard_reads.Journal, '_open_month_anchored_lines')
    old_helper = getattr(dashboard_reads.Journal, '_open_month_anchored_lines', None)
    with OUTPUT.open('x', encoding='utf-8') as output:
        try:
            report['before'] = check_state()
            baseline_work, baseline = stage9_metrics.measure_work(
                engine, lambda: dashboard.brief(period, limit=20, preparation='deferred'))
            dashboard_reads.Journal.account_amounts = prototype.account_amounts
            dashboard_reads.Journal._open_month_anchored_lines = prototype._open_month_anchored_lines
            check_state()
            proposed_work, proposed_result = stage9_metrics.measure_work(
                engine, lambda: dashboard.brief(period, limit=20, preparation='deferred'))
            report['baseline'] = baseline_work
            report['prototype'] = proposed_work
            report['generated_at'] = {
                'baseline': baseline['data']['generated_at'],
                'prototype': proposed_result['data']['generated_at'],
            }
            baseline['data']['generated_at'] = '<naturally different response generation time>'
            proposed_result['data']['generated_at'] = baseline['data']['generated_at']
            if canonical(baseline) != canonical(proposed_result):
                def difference_paths(left, right, path=''):
                    if isinstance(left, dict) and isinstance(right, dict):
                        return [p for key in left.keys() | right.keys()
                                for p in difference_paths(left.get(key), right.get(key), path + '/' + key)]
                    if isinstance(left, list) and isinstance(right, list):
                        if len(left) != len(right): return [path + '/length']
                        return [p for i, (a,b) in enumerate(zip(left,right))
                                for p in difference_paths(a,b,path + '/' + str(i))]
                    return [] if left == right else [path]
                report['response_difference_paths'] = difference_paths(baseline, proposed_result)
                raise ValueError('Brief fields other than response generation time changed')
            report['complete_response_sha256_except_generation_time'] = hashlib.sha256(canonical(baseline).encode()).hexdigest()
            report['complete_response_equal_except_generation_time'] = True
            report['after'] = check_state()
            check_source()
            require(file_hash(prototype_path) == prototype_hash, 'Proposed methods changed during diagnostic')
            require(file_hash(funds_path) == funds_hash, 'Funds constant changed during diagnostic')
            require(file_hash(reader_path) == reader_hash, 'Own reader changed during diagnostic')
            report['status'] = 'diagnostic_complete'
        except BaseException as exc:
            report['status'] = 'diagnostic_failed'
            report['error_type'] = type(exc).__name__
            report['error'] = str(exc)
            raise
        finally:
            del old_contribution_module.read_own_line_projections
            dashboard_reads.Journal.account_amounts = original_method
            if had_helper:
                dashboard_reads.Journal._open_month_anchored_lines = old_helper
            else:
                delattr(dashboard_reads.Journal, '_open_month_anchored_lines')
            json.dump(report, output, ensure_ascii=False, indent=2)
            output.write('\n')
            pool.close()
    print(json.dumps({key: report[key] for key in ('status', 'source_sha256', 'complete_response_equal_except_generation_time')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
