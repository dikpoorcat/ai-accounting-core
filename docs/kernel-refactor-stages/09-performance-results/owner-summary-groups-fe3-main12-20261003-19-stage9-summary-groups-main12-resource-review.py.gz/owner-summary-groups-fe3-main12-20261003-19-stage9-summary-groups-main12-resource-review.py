"""Derive network/render statistics from completed synthetic browser JSON only."""
import hashlib
import json
import math
import statistics
from pathlib import Path

root = Path(__file__).resolve().parents[1]
source = root / ".tmp/stage9-owner-main12-summary-groups-browser.json"
output = root / ".tmp/stage9-summary-groups-main12-resource-review.json"
raw = source.read_bytes()
book = json.loads(raw)
assert book["status"] == "over_target" and book["sample_count"] == 30


def stats(values):
    ordered = sorted(values)
    return {"count": len(values), "median_ms": statistics.median(values),
            "p95_ms": ordered[math.ceil(len(values) * .95) - 1], "max_ms": max(values)}


pages = {}
for page, data in book["pages"].items():
    assert len(data["samples"]) == len(data["resource_samples"]) == 30
    context, main, tail, slow = [], [], [], []
    for index, (elapsed, sample) in enumerate(zip(data["samples"], data["resource_samples"], strict=True), 1):
        assert sample["diagnostics"] == []
        resources = sample["resources"]
        action = "quarterly-report" if page == "reports" else page
        assert len(resources["context"]) == len(resources[action]) == 1
        c, m = resources["context"][0], resources[action][0]
        assert c["responseStatus"] == m["responseStatus"] == 200
        last_response = max(c["responseEnd"], m["responseEnd"])
        actual_tail = sample["renderAt"] - last_response
        assert abs(actual_tail - sample["render_tail_ms"]) < .0001
        context.append(c["duration"])
        main.append(m["duration"])
        tail.append(actual_tail)
        if elapsed > 500:
            slow.append({
                "sample_number": index, "elapsed_ms": elapsed,
                "context_duration_ms": c["duration"], "main_duration_ms": m["duration"],
                "main_request_to_response_start_ms": m["responseStart"] - m["requestStart"],
                "click_to_last_response_ms": last_response - sample["clickStart"],
                "render_tail_ms": actual_tail,
            })
    assert len(slow) == data["over_500_ms"]
    pages[page] = {"context": stats(context), "main": stats(main), "render_tail": stats(tail),
                   "over_target_samples": slow}
value = {
    "status": "derived_from_completed_raw_browser_json",
    "input": str(source), "input_sha256": hashlib.sha256(raw).hexdigest(),
    "source": book["source"], "statistics": "median averages middle pair; p95 nearest rank",
    "attribution": "Resource durations include network/queue/request/response; tail includes processing/JSON/reactive DOM/two RAF. Neither identifies server CPU or isolated paint.",
    "pages": pages,
}
assert source.read_bytes() == raw
with output.open("x", encoding="utf-8") as handle:
    json.dump(value, handle, ensure_ascii=False, indent=2)
    handle.write("\n")
for page, result in pages.items():
    print(page, json.dumps(result))
