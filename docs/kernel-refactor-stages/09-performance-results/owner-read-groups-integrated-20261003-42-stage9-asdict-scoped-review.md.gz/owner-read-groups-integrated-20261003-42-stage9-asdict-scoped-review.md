# Read-only asdict scope review

Prepared on the current working tree; no production changes, CPU probes or new
timing measurements. Historical profile is a lead, not a current bottleneck proof.

## Historical evidence and its actual caller

`.tmp/stage9-owner-main48-final-ui-native-work.json` records source
8672404dd3fcb198f80d3583782b98590b8c8358e2c2e354fa3822b71fefa36b.
Its brief cProfile lists 538 asdict calls, cumulative 0.0820682 seconds,
538 primitive / 2690 total _asdict_inner calls. Nearby frames include
QueryReads.verify_saved_input_identity (3 calls), Journal.account_amounts and
dashboard funds processing. The JSON's separate funds measurement has no
cProfile field; do not present the 82ms as an independently profiled funds result.
Current Journal.account_amounts has no asdict call: result_lines uses checked
saved outcome dictionaries. The actual flat conversion candidate is the saved
Read identity payload, reached through participating funds/source bindings.

## Flat immutable inputs: potential narrow candidates, not measured current gains

| Location | Actual type and purpose | Read-only judgment |
| --- | --- | --- |
| query_reads.py:1850, verify_saved_input_identity | Read(source, kind, key, before_period); SQL string fields plus None or kernel YearMonth(str subclass). Used in canonical saved calculation identity payload after exact dependencies and result verification. | Four flat immutable fields need a fresh dictionary, not recursive copying. YearMonth is a str subtype, so generic deep-copy dispatch can reconstruct it. This is the only direct candidate tied to the historical dashboard profile. Current call count/time and benefit remain unverified. |
| engine.py:812, _prepare | Same current Read in trace.selections, included in the originally generated calculation ID. | Flat fields, but mutation/preview/write and hash-contract path; not ordinary five-page rendering. No current hotspot evidence. |
| integrity.py:363 | Current or version-scoped Read returned by read_type(), sealing every preserved calculation ID. | Flat fields but full verifier correctness path, not owner transport. No current timing evidence; any future change must preserve both historical digest variants and reader scope. |
| publication.py:485 / publication_v1.py:434 | Current Read for correction baseline; v1 fixed Read in fixed baseline verifier. | Flat fields; independent current/v1 publication proof. Not shown to dominate current requests. Keep v1 independent semantics; do not fold into a current-only optimization based on structural similarity. |
| domains/opening.py:567–568 | Line(account, debit, credit, cashflow) and BalanceEffect(key, amount, category), all strings/integers/None; opening member payload. | A fresh flat dictionary is enough for these leaf types. This happens during opening evaluation, not established page reads; no performance evidence. |

`contracts.Read` is frozen and has no nested mutable members. Current YearMonth
and historical _V1YearMonth both derive from str. Sorting remains `key=repr`
before conversion; source digest uses version-specific encoding. A candidate
must not drop None fields, rename keys, change sort order, or treat a flat
dictionary conversion as permission to skip saved input identity verification.
No generic serializer framework is warranted. Wait for current 48 pure browser
and new native evidence before deciding whether even this narrow change helps.

## Nested conversions with actual semantic work

| Location | Actual shape | Why a shallow replacement is not equivalent |
| --- | --- | --- |
| engine.py:690 _evaluate; identity_corrections.py:533/1584/1630/1675 | Outcome contains tuples of Line/BalanceEffect, opening lines, values: dict[str, Any], explanation: tuple[dict,...]. Opening-binding/basis reevaluation returns that Outcome shape. | Must convert nested dataclass leaves to persistent dictionaries and detach mutable values/explanations. Frozen Outcome does not freeze all its containers. Several identity-correction calls compare canonical bytes/digests with saved outcomes. |
| domains/payroll.py:104 _state_values | CumulativeTaxState has integer cumulative amounts plus payroll.types.YearMonth dataclass(year, month). | through_period initially recursively converts, then is explicitly replaced by its string. The intermediate month conversion is avoidable in principle, but it is a write/evaluation helper, absent from the cited owner profile. Not a fully flat dataclass. |
| domains/payroll.py:120 _tax_input_values | CumulativeTaxPeriodInput: integer amounts, two immutable date objects, optional integer deduction month. | Fields are flat immutable values; asdict date deepcopy is not required for sharing safety, but explicit ISO conversion is required and already follows. No current page hotspot evidence. |
| domains/payroll.py:138 _trace | TraceEntry(step: str, values: dict[str,str|int|bool]). | Frozen outer entry still contains a mutable dictionary. Fresh nested values are part of detachment; simply returning its field references changes aliasing. Evaluation/explanation path, not established owner request hotspot. |
| fixed_assets.py:357 fixed_asset_calculation_hash | Public hash accepts arbitrary dataclass-like results; current GroupedStraightLineDepreciationResult includes nested member_result. Other results are scalar amounts/bools or Decimal rates. | Recursive conversion is necessary for the grouped result's nested dataclass. Public object input is broader than flat result types; cannot assume every accepted input is flat. No kernel caller found by search. |
| intangible_assets.py:162 intangible_asset_calculation_hash | Current acquisition/amortization result types contain scalar integers/None/bool, but API accepts any dataclass-like object. | Known returned types are flat, but generic public accepted input remains broader. No kernel call site or owner hotspot found. |
| borrowings.py:147 borrowing_calculation_hash | Current SimpleInterestResult has integers, immutable Decimal values and dates; API accepts dataclass-like object. | Known result is flat, with Decimal/date canonical formatting handled separately. Broader accepted input and hashing semantics preclude blanket shallow replacement. No kernel call site or owner hotspot found. |

## Five pages, shared detail and non-page paths

Five-page rendering calls no direct asdict in dashboard/dashboard_reads/
dashboard_funds/reports/business_queries. Funds source-state/binding verification
calls verify_saved_input_identity at dashboard_funds.py:302/637/667/1519/1571;
shared dashboard payment/source bindings call it at dashboard.py:1199/1304.
Brief composes funds information, explaining the historical brief profile.
Employee, asset and report selectors mostly use verify_selected_content;
that operation verifies bytes and its presence alone does not imply asdict.
Shared detail source verification may reach the funds calls depending on the
selected object. No per-page current asdict count was measured here.

CLI/MCP usage follows the actual command: dashboard commands share those query
paths; preview/apply evaluates Outcome and Read traces through Engine._prepare;
direct business queries do not acquire an asdict hotspot merely by being a
shared query. This review does not establish timing for CLI/MCP commands.

Full integrity validates saved calculation identity reads in integrity.py.
verify_close_integrity also runs calculation/source integrity before close;
Periods close/readiness invokes that independent verifier. Maintenance verification
and pre/post repair invoke verify_integrity. Backup._verify_connection invokes
the registered company verifier; schema_bundle verifier calls verify_integrity;
restore_portable validates the unpacked company before publishing it. Thus the
flat Read conversion also exists on important independent correctness paths.
No full verify, repair, backup, restore or close timing was run for this review.

Fixed-v1 uses history_types_v1.Read and publication_v1 baseline logic, entered
through historical_content(1) / registered content_v1 verifier. Its stored
canonical identity is an immutable compatibility obligation. The current-query
candidate must not automatically change this path or use current YearMonth to
decode historical reads. Nested v1 identity-correction Outcome conversion must
also retain its saved fixed shape. These paths are inspected, not revalidated.

Decision: retain production unchanged. If current measurements reproduce a
significant verify_saved_input_identity/asdict share, consider only that exact
four-field current Read conversion, with canonical identity equivalence, bad
dependency/version rejection, cache atomicity and fixed-v1 exclusion tests.
No claim of present performance improvement or wider serializer cleanup.
