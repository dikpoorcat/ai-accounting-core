"""Read-only r63 resident page plan evidence; diagnostic work is not baseline."""
from pathlib import Path
import hashlib
import json
import sqlite3
import sys

w = Path(__file__).resolve().parents[1]
src = w / '.tmp/stage9-build-source-owner-r63-release'
sys.path.insert(0, str(src / 'scripts'))
from stage9_source import configure_source
configure_source(src, w)
from ai_accounting.kernel.catalog import Catalog
from ai_accounting.kernel.dashboard import Dashboard
from ai_accounting.kernel.engine import Engine
from ai_accounting.kernel.resident_reads import ResidentReadPool
import stage9_metrics

book = json.loads((w / '.tmp/stage9-owner-main48-r63-verified.json').read_text('utf-8'))
assert book['status'] == 'complete' and book['source'] == str(src)
assert book['integrity']['status'] == 'verified' and not book['integrity']['limitations']
root = Path(book['root'])
assert root.is_relative_to(w / '.tmp')
assert not (w / '.tmp/stage9-owner-plans-r64.json').exists()
catalog = Catalog(root)
pool = ResidentReadPool()
with catalog.connection(read_only=True) as connection:
    row = dict(connection.execute('SELECT * FROM company WHERE id=?',
                                  (book['company']['id'],)).fetchone())
    store = catalog._bound_store(row, read_pool=pool)
engine = Engine(store)
dash = Dashboard(engine, company_name=row['name'], companies=[row])
out = {'scope': 'r63_main48_actual_resident_bound_select_query_plans_r64_read_only',
       'source': str(src), 'root': str(root), 'sqlite_version': sqlite3.sqlite_version,
       'parameters_retained': False,
       'method': 'Three uninstrumented warmup calls, then the unchanged actual page call under '
                 'measure_work. The private execute wrapper issues EXPLAIN QUERY PLAN immediately '
                 'before the first unique SELECT SQL/parameter-count pair using actual parameters '
                 'and the original raw connection; original measurement execute still runs. '
                 'No row factory or connection ownership attributes are changed. '
                 'Only statement SQL/hash, parameter count, callers and planner output are retained.',
       'work_warning': 'EXPLAIN contributes additional VM work; diagnostic_with_explain is never '
                       'a baseline, page timing or acceptance measurement. explain_vm_sample_delta '
                       'is reported separately and sampled at 100 instructions, with boundary error.',
       'operations': {}}
operations = {'brief': lambda: dash.brief('2019-12', limit=20),
              'funds': lambda: dash.funds('2019-12', limit=20),
              'employees': lambda: dash.employees('2019-12', limit=20),
              'assets': lambda: dash.assets('2019-12', limit=20),
              'reports': lambda: dash.quarterly_report(2019, 4, preparation='deferred')}
original_execute = stage9_metrics._Connection.execute
active_records = {}
explain_vm = 0

def callers():
    selected = []
    frame = sys._getframe(2)
    while frame and len(selected) < 8:
        module = frame.f_globals.get('__name__', '')
        if module.startswith('ai_accounting.'):
            selected.append(module + ':' + frame.f_code.co_name)
        frame = frame.f_back
    return selected

def explained_execute(self, statement, parameters=()):
    global explain_vm
    normalized = ' '.join(statement.split())
    if normalized.upper().startswith(('SELECT ', 'WITH ')):
        key = (normalized, len(parameters))
        record = active_records.get(key)
        if record is None:
            before = self.counts['sqlite_vm_steps']
            plan = [dict(item) for item in self.connection.execute(
                'EXPLAIN QUERY PLAN ' + statement, parameters).fetchall()]
            delta = self.counts['sqlite_vm_steps'] - before
            explain_vm += delta
            record = active_records[key] = {
                'statement_hash': hashlib.sha256(normalized.encode()).hexdigest(),
                'statement': normalized, 'parameter_count': len(parameters),
                'calls': 0, 'callers': callers(), 'plan': plan,
                'explain_vm_sample_delta': delta}
        record['calls'] += 1
    return original_execute(self, statement, parameters)

try:
    for name, call in operations.items():
        for _ in range(3):
            call()
        active_records = {}
        explain_vm = 0
        stage9_metrics._Connection.execute = explained_execute
        try:
            work, result = stage9_metrics.measure_work(engine, call)
        finally:
            stage9_metrics._Connection.execute = original_execute
        plans = list(active_records.values())
        details = [r['detail'] for p in plans for r in p['plan']]
        scans = [detail for detail in details if detail.startswith('SCAN ')]
        searches = [detail for detail in details if detail.startswith('SEARCH ')]
        temporary = [detail for detail in details if 'TEMP B-TREE' in detail]
        out['operations'][name] = {
            'plans': plans, 'diagnostic_with_explain': work,
            'explain_vm_sample_delta': explain_vm,
            'plan_summary': {'unique_selects': len(plans), 'scan_nodes': scans,
                             'search_nodes': searches, 'temporary_btree_nodes': temporary}}
        print(json.dumps({'page': name, 'unique_selects': len(plans),
                          'scan_nodes': len(scans), 'search_nodes': len(searches),
                          'temporary_btree_nodes': len(temporary),
                          'explain_vm_sample_delta': explain_vm}), flush=True)
    with (w / '.tmp/stage9-owner-plans-r64.json').open('x', encoding='utf-8') as handle:
        json.dump(out, handle, ensure_ascii=False, indent=2)
    print('complete: .tmp/stage9-owner-plans-r64.json', flush=True)
finally:
    stage9_metrics._Connection.execute = original_execute
    pool.close()
