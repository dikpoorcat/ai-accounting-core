# r74首次公共开放guard私有模块ABBA

状态complete，精确terminal1006、relation缓存1005、摘要记录1007（含必要原发布／祖先），两边keys和值逐字段正规化相同；缓存记录数不是terminal数。每个调用新建对应模块QueryReads.snapshot，核shared ContextVar实际持有该module的QueryReads，入口前成功集合为空，退出重置；没有复用前次证明。

固定其余source为r73 released/1，旧A为固定query_reads，B仅私有alias加载当前query_reads SHA305924fa53da1b7696433efa8c2654bbe50baf69114ad87e390c9c0e8b0727ac。每次顺序重指canonical sys.modules及package.query_reads到该module，供动态相对导入分派，退出恢复；没有生产改动或持有A/B混合proof。真实main48r63已有r73完整核验报告只作来源引用，不生成新book验收。SQL只读，标准Catalog/Engine/ResidentReadPool，无服务／preview，无GC/freeze/collect/阈值调整。

每scope两边各warm3，ABBA三块每边实测6。native计时只含首次guard，不含snapshot入场和后续proof提取；CPU为process_time，Windows约15.625ms粒度，不夸大小差。小suite／agent可并行，尾部明显波动，不是纯延迟验收。

| scope | A→B wall median ms | A→B CPU median ms | A min–max／B min–max ms |
| --- | --- | --- | --- |
| month | 68.600→60.201 | 70.312→62.500 | 61.563–145.125／54.545–91.390 |
| through | 66.361→65.245 | 62.500→62.500 | 64.418–104.051／57.626–112.979 |

独立非计时measure_work每scope/side一次，含snapshot BEGIN、guard和proof提取。原始SQL/VM/row/value-byte仪器在实际connection级工作，因此私有alias不会漏掉这些SQL传输计数；命名kernel函数统计不保证覆盖所有alias，不能据该调用表声称全局函数成本。

| scope | SQL A→B | rows A→B | value bytes A→B | VM A→B | 必要结果／decode |
| --- | --- | --- | --- | --- | --- |
| month | 16→15 | 5050→3041 | 1434454→971808 | 195600→156300 | 双方1行／668B、1次result decode；typed decode0 |
| through | 16→15 | 5050→3041 | 1434454→971808 | 194600→155200 | 双方1行／668B、1次result decode；typed decode0 |

真实work减少：两scope均少1SQL、2009行、462646B；VM少39300／39400。必要结果装载／decode不变，摘要与relation完整等价。month中位净省8.399ms，through仅省1.117ms且ABBA一块B明显较慢；没有证据稳定负优化，也不能称整类时延稳定显著下降。工作量缩减真实，不把理论少SQL转换成500ms收益。五页完整版、最终固定r75完整核验及纯browser仍由root后续统一执行。

初版TypeError为sqlite3.Row证明序列化失败，repair1为将摘要缓存1007误当1006terminal断言失败；两者measured0且旧py/json/log/command保留，不是业务护栏失败。repair2独立目标通过，未重跑既有57＋1 tests。所有完整原始样本与工作量见repair2.json；加载override、模块SHA、已核book报告SHA已存。当前源结束仍同SHA，不冒充整个current固定候选。
