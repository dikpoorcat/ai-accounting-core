"""Prepared finite a5 recovery after a specific observer failure; no Q restarts."""
import argparse
from datetime import UTC, datetime
import hashlib
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys
import time

W = Path(__file__).resolve().parents[1]
T = W / '.tmp'
S = T / 'stage9-build-source-copy-retention-converged-20261005'
SOURCE_SHA = 'a5d4e1ac7d41814bb7a74d30410e0dbe45e6a691c85bd69f71deff10f57bd1d1'
MANIFEST_SHA = 'a95fce65d9fc6d5381f043d591caf2ab6562f1b08bba1ce24090c833e3639a0b'
PREPARED = T / 'stage9-a5-three-scale-recovery-preparation-20261005.json'
WORK_REVIEW = T / 'stage9-a5-recovery-work-v2-reviewed-20261005.json'
IDLE = T / 'stage9-a5-recovery-background-loads-stopped-20261005.json'
RECEIPT = T / 'stage9-a5-three-scale-recovery-controller-20261005.json'
INVENTORY = T / 'stage9-a5-recovery-process-inventory-v2-20261005.ps1'
WORK_HELPER = T / 'stage9-index-flow-five-page-work-v2-20261005.py'
WORK_HELPER_SHA = '25e2fceef9cf099dda8e29d2bad1f80ab45101aa0733a4e61b78ed8fbed1876a'
SHARED = T / 'stage9-verification-snapshot-three-scale-controller-20261005.py'
SHARED_SHA = '64589a961ea8219d11a89c1dc88c50bf8b69267e105284b224404c57dd557eac'
SCALES = ('main12', 'main48', 'main120')
PAGES = ('brief', 'funds', 'employees', 'assets', 'quarterly_report')
GUARDS = ('read_pool_closed', 'catalog_observer_closed', 'stable_guards_equal',
          'draft_history_unchanged', 'source_inventory_unchanged', 'existing_sessions_unchanged', 'new_session_logged_out')
WAIT_LIMIT = 86400

def now(): return datetime.now(UTC).isoformat()
def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()
def read(path): return json.loads(Path(path).read_text('utf-8'))
def exclusive(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
def save(value): RECEIPT.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', 'utf-8')
def paths(sample):
    prefix = str(T / f'stage9-copy-retention-converged-{sample}-browser-20261005')
    return {key: Path(prefix + suffix) for key, suffix in (
        ('ready', '-ready.json'), ('start', '-start.json'), ('runner', '-runner.json'),
        ('output', '.json'), ('qualified', '-qualified.json'), ('control', '-control.json'), ('log', '.log'))}
def wait_for(label, predicate):
    start = time.monotonic()
    while not predicate():
        if time.monotonic() - start > WAIT_LIMIT: raise TimeoutError(label)
        time.sleep(2)
def inventory():
    assert sha(INVENTORY) == inventory.expected_sha
    result = subprocess.run(['pwsh.exe', '-NoProfile', '-File', str(INVENTORY)],
                            cwd=W, capture_output=True, check=True, encoding='utf-8')
    rows = json.loads(result.stdout)
    assert isinstance(rows, list)
    return {row['id']: row for row in rows}
def frozen_files(index):
    for name, descriptor in index.items():
        path = T / name
        assert path.is_file() and path.stat().st_size == descriptor['bytes']
        assert sha(path) == descriptor['sha256'], name
def original_failure(prepared):
    frozen_files(prepared['immutable_first_failure_files'])
    old = read(T / 'stage9-converged-three-scale-controller-20261005.json')
    raw = read(T / 'stage9-index-flow-five-page-work-20261005-old.json')
    log = (T / 'stage9-index-flow-five-page-work-20261005-controller.log').read_text('utf-8')
    assert old['status'] == 'controller_failed' and old['source_sha256'] == SOURCE_SHA
    assert old['error']['type'] == 'CalledProcessError' and old['pure_timing_released'] == []
    assert old['work_helper_sha256'] == raw['helper_sha256'] == '2a45d8dc8a863251cf14616949af68fa175a05747324b1dba122b1add507a35c'
    assert "holder['entered'] == holder['exited'] == 1" in log
    assert raw['status'] == 'diagnostic_failed' and raw['observations'] == []
    assert raw['error']['type'] == 'AssertionError' and raw['all_guards_passed'] is True
    assert all(raw[key] is True for key in GUARDS)
    assert old['upgrade_receipt_sha256'] == raw['declared_upgrade_receipt_sha256'] == prepared['upgrade_sha256']
    upgrade = read(T / 'stage9-index-transition-main120-upgrade-20261005.json')
    assert upgrade['status'] == 'declared_upgrade_verified' and upgrade['source_inventory_unchanged']
    assert upgrade['source_sha256'] == 'ce54b17fda46c9596c06d96267f525efed3b5dbdd1380a8fec732b0e789d62a8'
    assert upgrade['target_database_sha256'] == '0d9f0f522eb4a69471217d16a26e290266e1ba02eb043b3f297d4beb3b58044a'
    assert upgrade['target_fingerprint'] == '52556e8ec6cbbb81ab9ad9a69bb87897401471dba9c693e7b7ebddd2a5b08bf4'

def require_work_review():
    reviewed = read(WORK_REVIEW)
    assert reviewed['status'] == 'reviewed_v2_work_complete'
    assert reviewed['new_source_sha256'] == SOURCE_SHA
    assert reviewed['real_pool_counting_review_passed'] is True
    helper = Path(reviewed['helper_path']).resolve()
    comparison_path = Path(reviewed['comparison_path']).resolve()
    assert helper.is_relative_to(T) and comparison_path.is_relative_to(T)
    assert sha(helper) == reviewed['helper_sha256']
    assert helper == WORK_HELPER and sha(helper) == WORK_HELPER_SHA
    assert comparison_path == T / 'stage9-index-flow-five-page-work-v2-20261005-comparison.json'
    assert sha(comparison_path) == reviewed['comparison_sha256']
    comparison = read(comparison_path)
    assert comparison['helper_sha256'] == reviewed['helper_sha256']
    assert comparison['status'] == 'diagnostic_complete' and comparison['all_business_responses_equal'] is True
    assert comparison['declared_upgrade_receipt_sha256'] == 'b771498027263fbd32e41bcc0e31a70d9a3e36f5422251752622c5a7ea2b6e18'
    # The SHA-bound module has definition-only top level; invoke only its pure
    # encoding/diff functions after real execution has produced raw receipts.
    pure = runpy.run_path(str(helper), run_name='_stage9_pure_v2_response_receipt_checks')
    expected_exclusions = {page: [('/read_context/read_version', ('read_context', 'read_version'))] for page in PAGES}
    expected_exclusions['brief'].append(('/data/generated_at', ('data', 'generated_at')))
    expected_exclusions['quarterly_report'].append(('/checked_at', ('checked_at',)))
    assert pure['PAGES'] == PAGES and pure['EXCLUDED_RESPONSE_PATHS'] == expected_exclusions
    assert [row['page'] for row in comparison['observations']] == list(PAGES)
    for row in comparison['observations']:
        assert row['business_response_equal'] is True and row['unknown_difference_paths'] == []
        assert 'raw_response_diff' in row and 'excluded_exact_metadata' in row
    raw_sides = {}
    for side, expected in (('old', 'ed96dfd296cd96d4279745eb0ac26a9422db450c10d3bb9f8e7def11e2f9d8c8'), ('new', SOURCE_SHA)):
        reference = comparison['raw_files'][side]
        path = Path(reference['path']).resolve()
        assert path.is_relative_to(T) and sha(path) == reference['sha256']
        assert path == T / f'stage9-index-flow-five-page-work-v2-20261005-{side}.json'
        raw = read(path)
        raw_sides[side] = raw
        assert raw['status'] == 'diagnostic_complete' and raw['source_sha256'] == expected
        assert raw['helper_sha256'] == reviewed['helper_sha256'] and raw['all_guards_passed'] is True
        assert all(raw[key] is True for key in GUARDS)
        assert [row['page'] for row in raw['observations']] == list(PAGES)
        for row in raw['observations']:
            assert row['measurement_error'] is None and row['snapshot_and_work_checks_passed'] is True
            assert row['command'] == 'dashboard_' + row['page']
            sql = row['work']['sql']
            assert sql and sum(item['calls'] for item in sql) > 0
            assert all(item['calls'] > 0 and item['statement'] for item in sql)
            counters = row['work']['counters']
            provider = row['snapshot_provider']
            assert all(provider[key] == 1 for key in ('calls', 'entered', 'exited', 'meter_entered', 'meter_exited'))
            assert provider['provider_restored'] is True and provider['first_sql_in_transaction'] is True
            assert provider['execute_calls'] == counters['sql_calls'] == sum(item['calls'] for item in sql) > 0
            assert counters['returned_rows'] > 0 and counters['sqlite_vm_steps'] > 0
            assert len(provider['snapshot_events']) == 1
            event = provider['snapshot_events'][0]
            assert all(event[key] is True for key in ('exact_owned_type', 'exact_guard_type', 'execute_restored', 'guard_unchanged'))
            assert event['transaction_before'] is False and event['transaction_after'] is False
            assert event['guard_permit_before'] is None and event['guard_permit_after'] is None
            reference = row['raw_receipt']
            page_path = Path(reference['path']).resolve()
            assert page_path == T / f"stage9-index-flow-five-page-work-v2-20261005-{side}-{row['page']}-raw.json"
            assert sha(page_path) == reference['sha256']
            page_raw = read(page_path)
            # This file is deliberately written before encoding/holder assertions.
            assert 'encoding_checks' not in page_raw and 'snapshot_and_work_checks_passed' not in page_raw
            for key in ('page', 'command', 'payload', 'response', 'work', 'snapshot_provider', 'measurement_error', 'timing_classification'):
                assert page_raw[key] == row[key]
            assert row['encoding_checks'] == pure['check_response_encoding'](
                row['page'], row['payload'], row['response'], raw['encoding_basis'], raw['program_build_id'])
            started, finished = (datetime.fromisoformat(raw[key]) for key in ('started_at', 'finished_at'))
            assert started.tzinfo is not None and finished.tzinfo is not None and started <= finished
            for pointer, parts in expected_exclusions[row['page']]:
                if pointer == '/read_context/read_version': continue
                value = row['response']
                for part in parts: value = value[part]
                clock = datetime.fromisoformat(value)
                assert clock.tzinfo is not None and started <= clock <= finished
    assert raw_sides['old']['period'] == raw_sides['new']['period']
    assert raw_sides['old']['encoding_basis'] == raw_sides['new']['encoding_basis']
    assert raw_sides['old']['fund_account_location']['selected_account'] == raw_sides['new']['fund_account_location']['selected_account']
    assert raw_sides['old']['collector_sha256'] == raw_sides['new']['collector_sha256']
    for old, new, compared in zip(raw_sides['old']['observations'], raw_sides['new']['observations'], comparison['observations'], strict=True):
        assert old['page'] == new['page'] == compared['page'] and old['payload'] == new['payload']
        a, removed_a = pure['business_response'](old['page'], old['response'])
        b, removed_b = pure['business_response'](new['page'], new['response'])
        differences = pure['raw_diff'](old['response'], new['response'])
        assert a == b and compared['raw_response_diff'] == differences
        assert compared['excluded_exact_metadata'] == {'old': removed_a, 'new': removed_b}
        assert compared['old_work'] == old['work'] and compared['new_work'] == new['work']
        allowed = {pointer for pointer, _ in expected_exclusions[old['page']]}
        assert all(row['path'] in allowed for row in differences)
    return {'review_sha256': sha(WORK_REVIEW), 'helper_sha256': sha(helper), 'comparison_sha256': sha(comparison_path)}

def validate_existing_ready(sample):
    selected = paths(sample)
    qualified = read(selected['qualified'])
    assert qualified['status'] == 'complete' and Path(qualified['source']).resolve() == S
    assert qualified['qualification']['source_manifest_sha256'] == MANIFEST_SHA
    assert qualified['integrity']['status'] == 'verified' and qualified['integrity']['limitations'] == []
    assert all(qualified['integrity']['coverage'].get(key) == 'verified' for key in (
        'sources', 'historical_adoption', 'projections', 'read_indexes'))
    assert Path(qualified['verified_open_preview']['source']).resolve() == S
    assert qualified['verified_open_preview']['digest'] and qualified['checkpoint_sha256']
    ready = read(selected['ready'])
    receipt = read(selected['runner'])
    assert ready['status'] == 'timing_ready' and receipt['status'] == 'running'
    assert receipt['source_sha256'] == SOURCE_SHA and receipt['source_manifest_sha256'] == MANIFEST_SHA
    assert receipt['helper_sha256'] == validate_existing_ready.expected[sample]['sha256']
    assert sha(T / validate_existing_ready.expected[sample]['path']) == receipt['helper_sha256']
    assert receipt['old_qualification_inherited'] is False
    assert not any(selected[key].exists() for key in ('start', 'control', 'output'))
    assert receipt['child_pid_private'] != ready['pid']
    return ready['pid'], receipt['child_pid_private']

def quiet_gate(active):
    declared = read(IDLE)
    assert declared['status'] == 'owned_background_loads_stopped' and declared['source_sha256'] == SOURCE_SHA
    assert declared['diagnostic_agent_stopped'] is True
    assert declared['other_owned_build_test_mcp_instrumentation_stopped'] is True
    def checked():
        rows = inventory()
        assert not any(row['old_controller'] or row['new_package'] for row in rows.values())
        owned = {os.getpid()}
        for sample, (pid, parent) in active.items():
            assert pid in rows and parent in rows and rows[pid]['parent'] == parent
            assert rows[pid]['is_native_worker'] is True and rows[parent]['is_venv_launcher'] is True
            for selected_pid in (pid, parent):
                assert rows[selected_pid]['a5_sample'] == sample and rows[selected_pid]['a5_source_command'] is True
                assert rows[selected_pid]['command_sha256'] == quiet_gate.expected_commands[selected_pid]
            owned.update((pid, parent))
        allowed = set(owned)
        while True:
            children = {pid for pid, row in rows.items() if row['parent'] in owned}
            if children.issubset(owned): break
            owned.update(children)
        allowed.update(owned)
        for pid in list(allowed):
            row = rows.get(pid)
            while row is not None:
                allowed.add(row['id'])
                row = rows.get(row['parent'])
        assert not [row for pid, row in rows.items() if row['related'] and pid not in allowed]
        return rows
    first = checked()
    time.sleep(3)
    second = checked()
    deltas = {pid: (second[pid]['cpu_100ns'] - first[pid]['cpu_100ns']) / 10_000_000 for pid, _ in active.values()}
    assert all(0 <= delta < 0.15 for delta in deltas.values())
    return {'operator_idle_sha256': sha(IDLE), 'observed_at': now(), 'idle_seconds': 3,
            'waiting_worker_cpu_delta_seconds': deltas, 'unexpected_owned_loads': [],
            'no_process_pause_kill': True}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    if not parser.parse_args().execute: parser.error('Prepared only; --execute required')
    assert Path(sys.prefix).resolve() == W / '.tmp-kernel-venv'
    prepared = read(PREPARED)
    assert sha(__file__) == prepared['recovery_controller_sha256']
    assert sha(S / 'source-manifest.json') == MANIFEST_SHA
    assert sha(SHARED) == SHARED_SHA
    shared = runpy.run_path(str(SHARED), run_name='_stage9_pure_receipt_checks')
    inventory.expected_sha = prepared['inventory_sha256']
    validate_existing_ready.expected = prepared['original_runner_sha256']
    original_failure(prepared)
    value = {'status': 'waiting_reviewed_v2_work', 'source_sha256': SOURCE_SHA,
             'source_manifest_sha256': MANIFEST_SHA, 'helper_sha256': sha(__file__),
             'started_at': now(), 'stages': [], 'pure_timing_released': [],
             'original_failure_preserved': True, 'original_failure_files': prepared['immutable_first_failure_files'],
             'qualification_restarted': False, 'migration_restarted': False, 'is_runner_parent': False}
    exclusive(RECEIPT, value)
    try:
        wait_for('v2 review absent', WORK_REVIEW.exists)
        value['work_v2'] = require_work_review()
        value['status'] = 'waiting_existing_three_a5_qualification_hosts'
        save(value)
        wait_for('existing main120 Q not ready', lambda: all(paths(sample)['ready'].exists() for sample in SCALES))
        rows = inventory()
        active = {}
        for sample in SCALES:
            pid, launcher = validate_existing_ready(sample)
            assert pid in rows and launcher in rows and rows[pid]['parent'] == launcher
            assert rows[pid]['is_native_worker'] is True and rows[launcher]['is_venv_launcher'] is True
            for selected_pid in (pid, launcher):
                assert rows[selected_pid]['a5_sample'] == sample and rows[selected_pid]['a5_source_command'] is True
                assert rows[selected_pid]['command_sha256']
            active[sample] = (pid, launcher)
        quiet_gate.expected_commands = {pid: rows[pid]['command_sha256'] for pair in active.values() for pid in pair}
        value['qualified_existing_hosts_private'] = {sample: {'worker': pid, 'parent': parent,
            'worker_command_sha256': rows[pid]['command_sha256'], 'launcher_command_sha256': rows[parent]['command_sha256'],
            'qualified_sha256': sha(paths(sample)['qualified'])} for sample, (pid, parent) in active.items()}
        wait_for('diagnostic agent load-stop declaration absent', IDLE.exists)
        value['status'] = 'serial_existing_a5_pure_whole_page_measurement'
        save(value)
        all_passed = True
        for sample in SCALES:
            original_failure(prepared)
            require_work_review()
            selected = paths(sample)
            gate = quiet_gate(active)
            gate.update(sample=sample, source_sha256=SOURCE_SHA, released_at=now(), recovery_controller_sha256=sha(__file__))
            exclusive(selected['control'], gate)
            exclusive(selected['start'], {'status': 'timing_released', 'sample': sample,
                                         'released_at': now(), 'control_sha256': sha(selected['control'])})
            value['pure_timing_released'].append(gate)
            save(value)
            wait_for(sample + ' runner receipt unfinished', lambda: read(selected['runner'])['status'] in ('finished', 'measurement_failed', 'runner_failed'))
            receipt = shared['validate_runner'](selected, SOURCE_SHA)
            pid, parent = active[sample]
            # These are externally launched workers: observe exit, never pretend wait().
            wait_for(sample + ' exact worker/parent still running', lambda: pid not in inventory() and parent not in inventory())
            passed = shared['validate_result'](read(selected['output']), S)
            assert receipt['exit_code'] == (0 if passed else 1)
            all_passed = all_passed and passed
            value['stages'].append({'sample': sample, 'status': 'passed' if passed else 'failed',
                'output_sha256': sha(selected['output']), 'runner_sha256': sha(selected['runner']),
                'actual_runner_exit_code': receipt['exit_code'], 'worker_and_parent_exit_observed': True,
                'not_a_parent_wait_receipt': True, 'finished_at': now()})
            del active[sample]
            save(value)
        value['all_three_runner_exit_receipts_verified'] = True
        value['status'] = 'measured_all_passed' if all_passed else 'measured_failures_preserved'
    except BaseException as error:
        value.update(status='controller_failed', error={'type': type(error).__name__, 'message': str(error)})
        raise
    finally:
        original_failure(prepared)
        value['finished_at'] = now()
        save(value)

if __name__ == '__main__': main()
