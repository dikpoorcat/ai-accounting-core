"""Pin the converged reference group in a separate released candidate."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

workspace = Path(__file__).resolve().parents[1]
assert Path(sys.prefix).resolve() == workspace / '.tmp-kernel-venv'
sys.dont_write_bytecode = True
sys.path.insert(0, str(workspace / 'scripts'))
from snapshot_stage9_source import _inventory, _digest, snapshot_source

candidate = workspace / '.tmp/stage9-build-candidate-owner-reference-group-20261003'
source = workspace / '.tmp/stage9-build-source-owner-reference-group-20261003-release'
assert not candidate.exists() and not source.exists()
before = _inventory(workspace)
candidate.mkdir()
for relative in before:
    destination = candidate / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    with (workspace / relative).open('rb') as original, destination.open('xb') as output:
        shutil.copyfileobj(original, output)
assert _inventory(workspace) == _inventory(candidate) == before
selector = candidate / 'src/ai_accounting/kernel/schema_bundle.py'
text = selector.read_text(encoding='utf-8')
assert text.count('STATUS = "draft"') == text.count('VERSION = 0') == 1
selector.write_text(text.replace('STATUS = "draft"', 'STATUS = "released"').replace('VERSION = 0', 'VERSION = 1'), encoding='utf-8', newline='\n')
bootstrap = "import pathlib,runpy,sys; root=pathlib.Path(sys.argv[1]).resolve(); sys.path.insert(0,str(root/'src')); sys.argv=[str(root/'scripts/export_kernel_schema_contracts.py'),*sys.argv[2:]]; runpy.run_path(sys.argv[0],run_name='__main__')"
for option in ('--freeze-v1', '--check'):
    subprocess.run([sys.executable, '-B', '-X', 'utf8', '-c', bootstrap, str(candidate), option], cwd=workspace, check=True)
sealed = snapshot_source(candidate, source, workspace=workspace)
assert _inventory(workspace) == before
contracts = {}
for relative in ('company/v1.json', 'catalog/v1.json', 'content-v1.json'):
    path = source / 'src/ai_accounting/kernel/schema_contracts' / relative
    contracts[relative] = {'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'fingerprint': json.loads(path.read_bytes())['sha256']}
report = {'status': 'isolated_candidate_sealed', 'repository_status': 'draft/0', 'original_source_sha256': _digest(before), 'source': str(source), 'source_sha256': sealed['sha256'], 'manifest_file_sha256': hashlib.sha256((source / 'source-manifest.json').read_bytes()).hexdigest(), 'contracts': contracts}
destination = workspace / '.tmp/stage9-close-reference-group-seal.json'
assert not destination.exists()
destination.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(report, ensure_ascii=False))
