"""One read-only actual brief/assets capture and private month-candidate A/B."""

from __future__ import annotations

from collections import Counter
import json
import os
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp/stage9-build-source-r37-release"
OUTPUT = ROOT / ".tmp/stage9-r37-kind-period-brief-assets-probe.json"
sys.path[:0] = [str(SOURCE / "src")]
os.environ["STAGE9_WORKSPACE_ROOT"] = str(ROOT)

OLD = (
    "scoped_vouchers AS (SELECT original.id FROM json_each(?) selected_kinds "
    "CROSS JOIN calculation sc INDEXED BY calculation_kind_period "
    "ON sc.kind=selected_kinds.value CROSS JOIN voucher_version original "
    "INDEXED BY voucher_calculation ON original.calculation_id=sc.id), "
)
GUARD = (
    "scoped_vouchers AS (SELECT original.id FROM "
    "(SELECT 1 FROM json_each(?) selected_kinds "
    "CROSS JOIN calculation sc INDEXED BY calculation_kind_period "
    "ON sc.kind=selected_kinds.value LIMIT 1) has_kind "
    "CROSS JOIN voucher_version original INDEXED BY voucher_period "
    "ON original.period=? "
    "CROSS JOIN calculation scoped_calc ON scoped_calc.id=original.calculation_id "
    "AND scoped_calc.kind IN (SELECT value FROM json_each(?))), "
)


def wire(row):
    return tuple(v.hex() if isinstance(v, bytes) else v for v in row)


def run(connection, statement, parameters):
    plan = [row[3] for row in connection.execute("EXPLAIN QUERY PLAN " + statement, parameters)]
    steps = 0

    def progress():
        nonlocal steps
        steps += 1
        return 0

    connection.set_progress_handler(progress, 1)
    try:
        rows = [wire(row) for row in connection.execute(statement, parameters)]
    finally:
        connection.set_progress_handler(None, 0)
    return rows, steps, plan


def main():
    assert Path(sys.prefix).resolve() == ROOT / ".tmp-kernel-venv"
    assert SOURCE.is_dir() and not OUTPUT.exists()
    from ai_accounting.kernel import runtime
    from ai_accounting.kernel.daemon import _prepare_static_runtime
    from ai_accounting.kernel.dashboard import Dashboard
    from ai_accounting.kernel.service import LocalService

    result = {"status": "private_read_only_diagnostic", "source": str(SOURCE), "samples": {}}
    for months, book, month in (
        (12, ".tmp/stage9-reseed-main-12-r36", "2016-12"),
        (48, ".tmp/stage9-reseed-main-48-r36.staging", "2019-12"),
    ):
        app = LocalService(
            ROOT / book, enable_read_pool=True, enable_parallel_brief=True,
            _static_runtime=_prepare_static_runtime(),
        )
        try:
            companies = app.catalog.companies()
            assert len(companies) == 1 and companies[0]["name"] == "阶段九合成规模企业"
            engine = app.engine(companies[0]["id"], dashboard_read=True)
            sample = {}
            for page in ("brief", "assets"):
                captured = []
                original_execute = runtime._PrivateConnection.execute

                def capture(self, statement, parameters=(), *args, **kwargs):
                    if OLD in statement and "AND v.period=?" in statement:
                        captured.append((statement, tuple(parameters)))
                    return original_execute(self, statement, parameters, *args, **kwargs)

                runtime._PrivateConnection.execute = capture
                try:
                    getattr(Dashboard(engine), page)(month, limit=100, preparation="deferred")
                finally:
                    runtime._PrivateConnection.execute = original_execute
                assert captured, (months, page)
                records = []
                with engine.store.connection(read_only=True) as connection:
                    connection.execute("BEGIN")
                    try:
                        for statement, params in captured:
                            assert statement.count(OLD) == 1
                            kind_index = statement[:statement.index(OLD)].count("?")
                            kinds = json.loads(params[kind_index])
                            assert isinstance(kinds, list)
                            month_ordinal = params[kind_index + 2]
                            assert month_ordinal == params[kind_index + 1]
                            candidate = statement.replace(OLD, GUARD)
                            candidate_params = (
                                params[:kind_index + 1]
                                + (month_ordinal, params[kind_index])
                                + params[kind_index + 1:]
                            )
                            before, before_steps, before_plan = run(connection, statement, params)
                            after, after_steps, after_plan = run(connection, candidate, candidate_params)
                            before_set = Counter(json.dumps(row, ensure_ascii=False) for row in before)
                            after_set = Counter(json.dumps(row, ensure_ascii=False) for row in after)
                            records.append({
                                "statement": statement,
                                "parameters": params,
                                "selected_kinds": kinds,
                                "target_posting_period_ordinal": month_ordinal,
                                "candidate_statement": candidate,
                                "candidate_parameters": candidate_params,
                                "original_vm_steps": before_steps,
                                "candidate_vm_steps": after_steps,
                                "same_order": before == after,
                                "same_row_multiset": before_set == after_set,
                                "original_rows": before,
                                "candidate_rows": after,
                                "original_plan": before_plan,
                                "candidate_plan": after_plan,
                            })
                    finally:
                        connection.rollback()
                sample[page] = records
            result["samples"][str(months)] = {"book": book, "period": month, "pages": sample}
        finally:
            app.close()
    OUTPUT.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    assert all(r["same_row_multiset"] for s in result["samples"].values()
               for entries in s["pages"].values() for r in entries)


if __name__ == "__main__":
    main()
