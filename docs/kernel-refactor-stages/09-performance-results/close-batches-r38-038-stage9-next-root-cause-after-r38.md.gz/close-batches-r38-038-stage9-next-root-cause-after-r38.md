# r38 后下一组性能根因的只读范围

固定候选为 `.tmp/stage9-build-source-r38-release`。本记录只读现有六份 48 月 cProfile、前序实测和第 9 阶段文档；没有改源码、跑测试、插桩或计时。r38 的 24 文件／366 项回归通过，完整核验已走完，真实预览仍在进行。后续 ABBA 是独占原生接口对照，不包含浏览器加载、响应校验和渲染，不是整页验收。下述 cProfile 与其他工作并行，均是包含子调用的采样耗时，不能相加或当作浏览器净时延。

## 唯一候选：季报往来余额的真实历史来源处理

r38 季报样本的 `quarterly_report` 累计 1.085 秒，`Reports._report` 0.984 秒；其中两个不同截止点的 `party_balance_rows` 合计 0.747 秒，本期期末 `_party_delta` 0.408 秒。其下 `read_open_contributions` 两次合计 0.229 秒、23 次 `read_report_flow` 合计 0.154 秒，均已包含在父函数里。相比之下，`browser_report_details` 技术计数为 0.070 秒；r33 覆盖索引及 r37 强制命中索引后，不能继续按旧的计数查询成本给它排序。`selected_open_line` 1,995 次累计仅 0.021 秒，也不足以单独成为下一轮优化目标。

这组成本的实际规模已有 r24 同类 48 月诊断：前一年期末与本期期末是不同截止点；本月往来核对首次要求 938 个精确计算 ID，随后报告其他行要求 1,003 个 ID，交集 937 个已在同一快照复用，合计只解码 1,004 份投影正文。12 个实际关账月的 flow 首次读取各一次，另外 11 次命中同快照缓存。故“重复加载共同 937 份来源”不是根因。有效的待证问题只在**这些非重复来源、依赖和 flow 的已验证原文处理里，是否还有可量化的重复工作**；当前资料尚未证明存在可安全删除的工作，更不能把 0.747 秒视作潜在节省。

本组比资产 owner 或简报准备更适合作为下一项窄排查，因为它在 r38 报表请求中占主要累计耗时，而 r32 最近一次独占纯浏览器 48 月报表中位 616.2 毫秒、30/30 超线。r38 的简报父路径仍有准备、资金和资产多条成本，资产页 r32 仅 2/30 超线；仅凭并行 profile 不能重新排列真实整页优先级。若即将完成的 r38 独占 ABBA 已使报表稳定达标，这一候选即暂停，不为凑优化而改动。

## 消费范围与边界

| 入口 | 与本候选的关系 |
| --- | --- |
| 五页季报 | `Dashboard.quarterly_report → Reports._report → party_balance_rows` 是本组直接消费者；本期期末开放来源与前一年期末闭期基线都需保留。`browser_report_details` 是同页另一条技术计数路径，不纳入本组。 |
| 简报 | reports worker 的 `check_report_readiness` 走相同报表准备／往来核对，但在自己的事务和进程；父请求与 worker 不共享来源证明。简报另外的准备、资金、资产工作不归入本组。 |
| 资金、员工、资产、上下文 | 当前六份 profile 不支持将这些页面的主要耗时归因于季报往来来源。资产及简报里的其他 `party_balance_rows` 调用应按实际命中和截止点再确认，不能因同名函数就计作本组收益；上下文在 r38 仅 0.072 秒。 |
| CLI／MCP／导出 | 调用公开 `report`、`preview_export`／`confirm_export` 或 `dashboard_quarterly_report` 的适配入口沿用相关报表读取；如果未来改公共投影，须保持完整来源 ID、计划摘要、错误及导出确认语义。 |
| 关账／完整核验／修复／备份／固定 v1 | 使用报表准备或公共当前投影的调用方需验证同一缺失、损坏、顺序和正式发布拒绝；完整核验及固定 `report_projection_v1` 的全范围、独立历史语义不能从当前普通页的快照命中推断或缩减。没有其相位实测时，不把 v1 记作当前性能缺陷。 |

## 最小判定及停点

先读 r38 独占 ABBA 原生接口对照，再以同源码的浏览器诊断确定实际整页瓶颈；原生接口低于 500 毫秒不能说明整页达标。若报表仍是实际瓶颈，才在同一固定源码、已核验的 48 月样本里对本组做一次窄归因：分别列出两个截止点的真实物理读取、`_party_delta` 的首次 938 个精确 ID、后续 66 个新 ID、12 个 flow 月的 SQL VM／行／字节、严格解析与摘要／绑定／凭证发布核验 CPU，确认 r24 的缓存命中形状仍成立。把真正重复处理的同一 ID／同一字节及其 CPU 从必要的首次核验中分离；若找不到足以影响整页阈值的重复工作，停止此组而非实施猜测。任何随后原型均须保持损坏来源、缺失／多余行、不同 cutoff、无 flow fallback、完成报告与准备检查的逐字段回应及错误顺序，并用隔离 ABBA 验证净收益。

不重试 audit24，也不重试逐行派生表或 SQL 往来聚合、跨请求／跨进程缓存、只读部分历史、资产 fully parsed owner 缓存、raw JSON 捷径、forced kind index、两阶段 header/body、rowid 排序等已有负面或不满足证明的路线。当前结论是**优先测这一组有无可消除的重复证据**，不是批准改动或声称 r38 未达标。

依据：`.tmp/stage9-remaining-profile-r38-48-{brief,reports,context,funds,employees,assets}.txt`、`docs/kernel-refactor-stages/09-performance-and-release.md`、`docs/kernel-refactor-stages/09-performance-results/exact-close-content-batches.md`、`grouped-report-party-overlap-r24.md`、`report-process-io-r30.md`、`.tmp/stage9-remaining-reports-r37-scope.md`。
