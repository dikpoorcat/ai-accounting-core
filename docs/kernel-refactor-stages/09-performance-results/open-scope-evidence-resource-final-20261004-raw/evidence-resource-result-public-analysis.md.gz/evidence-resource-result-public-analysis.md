> 明确去运行PID的公开分析；不是原字节结果文档。原始路径／SHA见manifest。

# 24b9证据规模与硬边界实测收口

固定源756文件，源SHA `24b9b8b65723cee8c6982b1f41235dce380e62788db33f100176f92c714571fc`、manifest文件SHA `9d81e82d7e2637637cc052cd42ff80946c6a0274264473d53f1d22a6f48fcef5`。240及1536MiB browser各唯一一次、顺序执行，无并行资格、建库、回归或另一个性能测试；独立MCP在其安全边界暂停。用户游戏／同步等背景不受控，不控制任何已有进程。只读环境前后snapshot另存；无窗口内连续OS CPU监测，不能声称稳定因果性能。测量窗口结束已立即通知主任务，随后root恢复MCP及main48准备不属于本次测量窗口。

两档原harness均status complete／exit0，source逐文件／manifest／完整额外文件清单及workspace schema_contracts前后守卫true；catalog/company/portable/restored均draft/0，身份、schema_history及结构指纹保留。均完成真实库内原件登记、完整verify_file、portable备份、restore及恢复后完整verify_file；恢复原件count／distinct digest／BLOB字节完全一致。foreground／RSS监控errors均为空。原harness和browser harness来自固定源，没有修订；没有重试、改样本、降低规模或再次边界执行。

| 项目 | 240MiB mixed | 1536MiB mixed |
|---|---:|---:|
| 实际独立原件／摘要 | 12／12 | 77／77 |
| 可压缩／不可压缩份数 | 6／6 | 39／38 |
| 可压缩原件B | 125829120 | 813694976 |
| 不可压缩原件B | 125829120 | 796917760 |
| 实际BLOB总B | 251658240 | 1610612736 |
| portable数据库B | 256184320 | 1616527360 |
| portable ZIP B | 126954163 | 801691921 |
| 恢复完整evidence数量（含8份fixture原件） | 20 | 85 |
| 全过程sampled RSS峰值B | 254685184 | 258252800 |

| 秒／resident sampled RSS MiB | 240MiB | 1536MiB |
|---|---:|---:|
| populate秒 | 17.296032 | 278.441099 |
| 完整verify秒／RSS MiB | 1.126284／239.309 | 8.028035／243.359 |
| portable backup秒／RSS MiB | 10.563032／241.633 | 70.250943／246.062 |
| restore秒／RSS MiB | 2.189602／242.719 | 12.292255／246.113 |
| restored verify秒／RSS MiB | 0.937461／242.281 | 5.564314／245.367 |

RSS每10ms采样实际resident进程（两档各自测量进程，运行PID仅保留于私有原件），后台四操作在同进程内运行；不包含Node／Edge进程。是采样值，不是分配量或严格内存上界。分阶段同点RSS记录及PID原值均保留于原report。

前台为真实browser默认20条／preparation deferred简报整页刷新，含HTTP及可见渲染。合成开放月仅2人／40业务，用于证据任务争用；不是主48的50人／每月1000业务，不替代五页每页30次整页500ms产品核验。短阶段样本数量由真实操作时长决定，样本按收到时phase归类，跨阶段边界需谨慎解释。

| 阶段 | 240样本数／max ms／≥500ms | 1536样本数／max ms／≥500ms |
|---|---:|---:|
| idle | 10／273.6／0 | 10／191.8／0 |
| verify | 2／236.0／0 | 24／195.6／0 |
| backup | 25／354.9／0 | 203／276.3／0 |
| restore | 5／316.1／0 | 33／275.1／0 |
| restored verify | 2／354.8／0 | 17／215.2／0 |

本次保存的所有前台样本均<500ms；这里只是限定场景实际观察。status complete仅代表四流程和监控完成，不自动代表500ms达标；不归纳成主五页或稳定性能PASS，也不与旧r14 limit100/complete或旧1536 HTTP-only合并。

240原report SHA `8750e8ff17c7f22be8d2d4a0d82c9c6bfd857db3a26baf9404f7e2a0b2bbe61b`；1536原report SHA `339912c958c3c73949eca3d6b2ebfcc0f587c1b6ca38dbec6512bbf9eb90a577`。各档`-browser-runner.json`、`-browser-report.json`、`-browser-run.log`、`-browser-summary-cleanup.json`与synthetic roots、ZIP、restored.sqlite原样保留。原件清单另存`-raw-manifest.json`。

每档测量子进程、server、browser完全退出后，owned cleanup通过公开SecurityService.login/change_password仅轮换自身新合成catalog凭据到不落盘的随机密码，全部session正常撤销。catalog/owner identity、schema_history和format不变；credential_version＋1及password/recovery/session/audit变化是明确预期。公司库SHA、公司identity/history/format及原report SHA均不变；无WindowsCredentialStore访问，没有真实root／负责人凭据／5173操作。清理不进入计时范围，所有审计保留。

硬边界已单独一次完成，详见`-boundaries-result.md`：20MiB／100000银行原行／5000typed facts接受，20MiB＋1／100001公开inspect／5001typed facts原子拒绝，最终evidence3／fact_revision5001／bank children100000／request8／audit8。与主48资格并行的59.5029s只属诊断。没有5000计算预览／发布、typed银行超界直接保存或十万行整页浏览器实证。post-run只读inspector首轮遗漏bundle的TypeError保留，新fix1读取通过；未重复业务harness。

本轮未冻结released合同、正式交付、切换运行入口、换库或提交。其余规模、主五页500ms和正式版状态由各自当前实证决定。
