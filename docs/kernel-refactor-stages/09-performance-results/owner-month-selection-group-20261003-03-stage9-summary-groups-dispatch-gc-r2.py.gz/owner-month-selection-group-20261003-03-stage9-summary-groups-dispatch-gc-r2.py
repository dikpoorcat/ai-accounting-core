"""Pinned, read-only instrumented diagnostic; this is never browser acceptance timing."""

from __future__ import annotations

import cProfile
import hashlib
import json
import pstats
import sys
from contextlib import contextmanager
from pathlib import Path

WORKSPACE = Path(__file__).resolve().parents[1]
SOURCE = WORKSPACE / ".tmp/stage9-build-source-owner-summary-groups-20261003-release"
MANIFEST = SOURCE / "source-manifest.json"
import argparse

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--months', type=int, choices=(12, 48, 120), required=True)
parser.add_argument('--book-report', type=Path, required=True)
parser.add_argument('--report-sha256', required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
BOOK_REPORT = args.book_report.resolve(strict=True)
OUTPUT = args.output.resolve()
assert BOOK_REPORT.is_relative_to(WORKSPACE / '.tmp')
assert OUTPUT.is_relative_to(WORKSPACE / '.tmp') and not OUTPUT.exists()
MANIFEST_FILE_SHA256 = '07b8a5b67a25d6d6df93fc60f7246b224f22a252fe3fe9b222744731a66ba463'
SOURCE_SHA256 = 'fe3a0ba43267bb05f3159bf38aeca13bf90f8cdc8c9b774882a6a560f27bc8f6'
REPORT_SHA256 = args.report_sha256


def file_hash(path):
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def main():
    require(
        Path(sys.prefix).resolve() == (WORKSPACE / ".tmp-kernel-venv").resolve(),
        "Use the repository virtual environment",
    )
    require(not OUTPUT.exists(), "Diagnostic output must not exist")
    require(file_hash(MANIFEST) == MANIFEST_FILE_SHA256, "Pinned manifest bytes changed")
    require(file_hash(BOOK_REPORT) == REPORT_SHA256, "Pinned verified report bytes changed")
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    require(
        manifest["status"] == "complete"
        and manifest["sha256"] == SOURCE_SHA256
        and Path(manifest["target"]).resolve() == SOURCE.resolve(),
        "Wrong source manifest",
    )

    # Bootstrap only from the fixed candidate, before importing any accounting module.
    sys.path.insert(0, str(SOURCE / "scripts"))
    import stage9_source

    stage9_source.require_source_module(stage9_source, SOURCE, "scripts/stage9_source.py")
    stage9_source.configure_source(SOURCE, WORKSPACE)
    import benchmark_stage9_browser
    import snapshot_stage9_source
    import stage9_metrics

    from ai_accounting.kernel import catalog as catalog_module
    from ai_accounting.kernel import dashboard as dashboard_module
    from ai_accounting.kernel import engine as engine_module
    from ai_accounting.kernel import resident_reads, schema_bundle
    from ai_accounting.kernel.types import canonical
    from ai_accounting.kernel.versions import database_format

    for module, relative in (
        (snapshot_stage9_source, "scripts/snapshot_stage9_source.py"),
        (benchmark_stage9_browser, "scripts/benchmark_stage9_browser.py"),
        (stage9_metrics, "tests/kernel/stage9_metrics.py"),
        (catalog_module, "src/ai_accounting/kernel/catalog.py"),
        (dashboard_module, "src/ai_accounting/kernel/dashboard.py"),
        (engine_module, "src/ai_accounting/kernel/engine.py"),
        (resident_reads, "src/ai_accounting/kernel/resident_reads.py"),
        (schema_bundle, "src/ai_accounting/kernel/schema_bundle.py"),
    ):
        stage9_source.require_source_module(module, SOURCE, relative)

    def check_source():
        inventory = snapshot_stage9_source._inventory(SOURCE)
        require(
            inventory == manifest["files"]
            and snapshot_stage9_source._digest(inventory) == SOURCE_SHA256,
            "Fixed source bytes drifted",
        )
        require(
            file_hash(MANIFEST) == MANIFEST_FILE_SHA256 and file_hash(BOOK_REPORT) == REPORT_SHA256,
            "Pinned attestations drifted",
        )

    check_source()
    book = json.loads(BOOK_REPORT.read_text(encoding="utf-8"))
    benchmark_stage9_browser.require_report_source(book, SOURCE)
    period = benchmark_stage9_browser.validate_book_report(book, company_name="阶段九合成规模企业")
    require(
        book["requested_months"] == args.months
        and book["employee_count"] == 50
        and book["monthly_business_count"] == 1000
        and book["distribution"] == "mixed_cumulative",
        "Wrong main sample dimensions",
    )
    root = stage9_source.synthetic_path(Path(book["root"]), WORKSPACE)
    company = book["company"]
    checkpoint_path = root / "stage9-builder.json"
    checkpoint_hash = file_hash(checkpoint_path)
    checkpoint = json.loads(checkpoint_path.read_text(encoding="utf-8"))
    preview = book["verified_open_preview"]
    require(
        checkpoint["company"] == company
        and checkpoint["snapshots"] == book["snapshots"]
        and checkpoint["epochs"] == preview["state"],
        "Checkpoint no longer matches proof",
    )
    expected_state = preview["state"]
    expected_identity = {
        "company_id": company["id"],
        "database_id": company["database_id"],
        "taxpayer_id": company["taxpayer_id"],
    }
    integrity_contract = book["integrity_contract"]
    del checkpoint, book
    require(
        (root / "catalog.sqlite").is_file() and Path(company["path"]).is_file(),
        "Existing databases are required",
    )

    class ReadOnlyCatalog(catalog_module.Catalog):
        @contextmanager
        def connection(self, *, read_only=False, _cross_thread=False):
            require(read_only, "Diagnostic forbids catalog writes")
            with super().connection(read_only=True, _cross_thread=_cross_thread) as connection:
                yield connection

        def recover_operations(self):
            # Never resume pending publications during a read diagnostic.
            with self.connection(read_only=True) as connection:
                count = connection.execute(
                    "SELECT count(*) FROM company_operation WHERE status!='succeeded'"
                ).fetchone()[0]
            require(
                count == 0, "Catalog has unfinished operations; diagnostic will not recover them"
            )

    bundle = schema_bundle.production_bundle()
    catalog = ReadOnlyCatalog(root, bundle)
    require(
        catalog.database_format()["status"] == "released"
        and catalog.database_format()["version"] == 1,
        "Wrong catalog contract",
    )
    companies = catalog.companies()
    require(
        [row for row in companies if row["id"] == company["id"]] == [company],
        "Catalog company identity changed",
    )
    with catalog.connection(read_only=True) as connection:
        catalog_identity = dict(connection.execute("SELECT * FROM catalog_identity").fetchone())

    pool = resident_reads.ResidentReadPool(maximum=4)
    store = catalog.bind(company["id"], read_pool=pool)
    original_connection = store.connection

    @contextmanager
    def read_only_connection(*, read_only=False):
        require(read_only, "Diagnostic forbids company writes")
        with original_connection(read_only=True) as connection:
            yield connection

    store.connection = read_only_connection
    engine = engine_module.Engine(store)
    dashboard = dashboard_module.Dashboard(
        engine, company_name=company["name"], companies=companies
    )
    year, month = map(int, period.split("-"))
    quarter = (month - 1) // 3 + 1

    def check_state():
        with store.connection(read_only=True) as connection:
            connection.execute("BEGIN")
            state = list(connection.execute("SELECT * FROM state WHERE id=1").fetchone())
            identity = dict(
                connection.execute(
                    "SELECT company_id,taxpayer_id,database_id FROM identity WHERE id=1"
                ).fetchone()
            )
            require(
                state == expected_state and identity == expected_identity,
                "Company identity, business state or repair revision changed",
            )
            require(
                database_format(connection, bundle=bundle) == integrity_contract,
                "Company format differs from verified source",
            )
        with catalog.connection(read_only=True) as connection:
            require(
                dict(connection.execute("SELECT * FROM catalog_identity").fetchone())
                == catalog_identity,
                "Catalog identity changed",
            )
        require(catalog.companies() == companies, "Catalog registration changed")
        require(file_hash(checkpoint_path) == checkpoint_hash, "Construction checkpoint changed")
        return {"state": state, "identity": identity, "catalog_identity": catalog_identity}

    from ai_accounting.kernel.service import LocalService
    from pydantic import SecretStr
    static_runtime, startup_ms = benchmark_stage9_browser.prepare_browser_static_runtime()
    app, preparation_ms = benchmark_stage9_browser.prepare_browser_service(root, static_runtime, startup_ms)
    # No provision, recovery, preview, or business write. Authenticate the existing synthetic owner.
    with app.catalog.connection(read_only=True) as connection:
        owners = [row[0] for row in connection.execute("SELECT login_name FROM security_owner")]
    require(owners == ["synthetic-stage9-owner"], "Only the existing synthetic benchmark owner is permitted")
    login = app.security.login("synthetic-stage9-owner", SecretStr("Synthetic-stage9-browser-only-2026"))
    token = login.session_token
    from ai_accounting.kernel.storage import Store
    original_connection_method = Store.connection
    @contextmanager
    def no_business_writes(selected, *, read_only=False):
        require(read_only, "Dispatch diagnostic forbids business writes")
        with original_connection_method(selected, read_only=True) as connection:
            yield connection
    # Class-level diagnostic guard captures no bound instance and creates no Store cycle.
    Store.connection = no_business_writes
    payloads = {
        "context": {},
        "brief": {"period": period, "limit": 20, "preparation": "deferred"},
        "funds": {"period": period, "limit": 20, "preparation": "deferred", "movement_account_selection": "first"},
        "employees": {"period": period, "limit": 20, "preparation": "deferred"},
        "assets": {"period": period, "limit": 20, "preparation": "deferred"},
        "quarterly_report": {"year": year, "quarter": quarter, "preparation": "deferred"},
    }
    import gc
    import time
    require(gc.isenabled(), "GC must remain enabled")
    report = {"status": "diagnostic_started", "scope": "instrumented_gc_authorized_dispatch",
              "browser_acceptance": False, "source_sha256": SOURCE_SHA256,
              "verified_report_sha256": REPORT_SHA256, "checkpoint_sha256": checkpoint_hash,
              "gc_threshold": gc.get_threshold(), "gc_enabled": gc.isenabled(), "measurements": {},
              "notes": ["GC stays enabled with unchanged thresholds; no collect, result cache, preview or HTTP server.",
                        "Wall time includes normal authorization/catalog/page/contracts; GC callback spans are diagnostic only.",
                        "No active preview in new service; owner prompt not reproduced. Background readonly activity may affect wall times."]}
    events = []
    pending = {}
    active = None
    def callback(phase, info):
        now = time.perf_counter_ns()
        generation = info["generation"]
        if phase == "start":
            pending[generation] = (now, active)
        elif generation in pending:
            started, request = pending.pop(generation)
            events.append({"generation": generation, "start_ns": started, "end_ns": now,
                           "pause_ms": (now-started)/1e6, "collected": info["collected"],
                           "uncollectable": info["uncollectable"], "request": request})
    with OUTPUT.open("x", encoding="utf-8") as output:
        try:
            report["before"] = check_state()
            gc.callbacks.append(callback)
            for name in ("brief", "quarterly_report"):
                samples = []
                report["measurements"][name] = samples
                for index in range(13):
                    phase = "warmup" if index < 3 else "sample"
                    active = {"page": name, "phase": phase, "index": index if index < 3 else index-3}
                    first_event = len(events)
                    started = time.perf_counter_ns()
                    wire = app.dispatch("dashboard_"+name, {"company_id": company["id"], **payloads[name]},
                        session_token=token, response_format="http_json")
                    ended = time.perf_counter_ns()
                    active = None
                    request_events = events[first_event:]
                    samples.append({"phase": phase, "index": index if index < 3 else index-3,
                                    "start_ns": started, "end_ns": ended, "wall_ms": (ended-started)/1e6,
                                    "response_bytes": len(wire), "gc_events": request_events,
                                    "gc_pause_ms": sum(event["pause_ms"] for event in request_events)})
                    del wire
                check_state()
            gc.callbacks.remove(callback)
            report["after"] = check_state()
            check_source()
            require(gc.isenabled() and gc.get_threshold() == tuple(report["gc_threshold"]), "GC configuration changed")
            report["status"] = "diagnostic_complete"
        except BaseException as error:
            report["status"] = "diagnostic_failed"
            report["error_type"] = type(error).__name__
            raise
        finally:
            if callback in gc.callbacks:
                gc.callbacks.remove(callback)
            app.security.logout(token)
            app.close()
            pool.close()
            json.dump(report, output, ensure_ascii=False, indent=2)
            output.write("\n")

if __name__ == "__main__":
    main()