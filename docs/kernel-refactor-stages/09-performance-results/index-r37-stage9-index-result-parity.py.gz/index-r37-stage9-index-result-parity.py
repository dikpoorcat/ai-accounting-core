from pathlib import Path
import hashlib
import json
import sqlite3

root = Path(__file__).resolve().parents[1]
output = root / '.tmp/stage9-index-result-parity.json'
assert not output.exists()
original = json.loads((root / '.tmp/stage9-index-material-probe.json').read_text('utf-8'))
records = []
for months in (12, 48):
    old_path = root / f'.tmp/stage9-release-main-{months}/91310000123456789S/company.sqlite'
    connection = sqlite3.connect(old_path.as_uri() + '?mode=ro', uri=True)
    try:
        connection.execute('BEGIN')
        for item in original['measurements']:
            if item['months'] != months or item.get('variant') != 'id_driven_candidate':
                continue
            table = 'fact_' + item['kind']
            ids = [row[0] for row in connection.execute(f'SELECT revision_id FROM {table} ORDER BY revision_id LIMIT ?', (item['requested'],))]
            # Use the original query on the intact source lacking the two indexes.
            sql = item['query'].replace('CROSS JOIN ', 'JOIN ')
            steps = [0]
            def tick():
                steps[0] += 1
                return int(steps[0] > 1_000_000)
            connection.set_progress_handler(tick, 1)
            try:
                rows = connection.execute(sql, (json.dumps(ids), item['kind'])).fetchall()
            finally:
                connection.set_progress_handler(None, 0)
            data = json.dumps(sorted(rows),ensure_ascii=False,separators=(',',':')).encode()
            result_hash = hashlib.sha256(data).hexdigest()
            assert result_hash == item['result_sha256'] and len(rows) == item['rows']
            records.append({'months':months,'kind':item['kind'],'requested':item['requested'],
                            'source_sql':sql,'source_vm_steps':steps[0],'rows':len(rows),
                            'result_sha256':result_hash,'candidate_matches':True})
    finally:
        connection.close()
output.write_text(json.dumps({'status':'passed','measurements':records},ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps({'status':'passed','comparisons':len(records),'max_old_source_vm':max(r['source_vm_steps'] for r in records)}))
