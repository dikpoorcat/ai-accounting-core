"""Physical index experiment on a new copy of an explicit synthetic file."""
from pathlib import Path
import ast
import inspect
import json
import sqlite3
import sys
import textwrap
import time

w = Path(__file__).resolve().parents[1]
src = w / '.tmp/stage9-build-source-owner-r66-release'
sys.path.insert(0, str(src / 'scripts'))
from stage9_source import configure_source
configure_source(src,w)
from ai_accounting.kernel.catalog import Catalog
from ai_accounting.kernel.permissions import ensure_private_file
from ai_accounting.kernel.query_reads import QueryReads
from ai_accounting.kernel.types import canonical, YearMonth

book = json.loads((w/'.tmp/stage9-owner-main48-r63-verified.json').read_text('utf-8'))
assert Path(book['root']).resolve() == (w/'.tmp/stage9-owner-main48-r63').resolve()
catalog = Catalog(Path(book['root']))
with catalog.connection(read_only=True) as c:
    row = dict(c.execute('SELECT * FROM company WHERE id=?',(book['company']['id'],)).fetchone())
    store = catalog._bound_store(row)
target = w/'.tmp/stage9-header-index-r67.sqlite'
if target.exists():
    raise FileExistsError(target)
ensure_private_file(target,create=True)
copy_start = time.perf_counter()
with store.connection(read_only=True) as origin, sqlite3.connect(target) as destination:
    origin.execute('BEGIN')
    origin.backup(destination,pages=2048)
    origin.rollback()
out = {'scope':'index_experiment_not_accepted_database_or_page_benchmark',
       'origin':str(store.path),'copy':str(target),'copy_seconds':time.perf_counter()-copy_start,
       'variants':{}}
tree = ast.parse(textwrap.dedent(inspect.getsource(QueryReads.calculation_identity_headers)))
sql = next(n.args[0].value for n in ast.walk(tree) if isinstance(n,ast.Call)
           and isinstance(n.func,ast.Attribute) and n.func.attr=='execute')
with sqlite3.connect(target) as connection:
    ids = [r[0] for r in connection.execute(
        "SELECT c.id FROM calculation_current h JOIN calculation c ON c.id=h.calculation_id "
        "JOIN subject s ON s.id=c.subject_id WHERE s.kind IN ('payroll','bounded_payroll') "
        "AND c.period<=?",(YearMonth('2019-12').ordinal,))]
params = (canonical(sorted(ids)),)
out['identity_count'] = len(ids)
for name in ('without_cover','with_cover'):
    if name=='with_cover':
        start = time.perf_counter()
        with sqlite3.connect(target) as connection:
            connection.execute('CREATE INDEX header_transport_experiment ON calculation('
                'id,subject_id,fact_id,kind,period,digest,program_version)')
        out['index_creation_seconds'] = time.perf_counter()-start
    samples=[]
    for attempt in range(5):
        with sqlite3.connect(target.as_uri()+'?mode=ro',uri=True) as connection:
            connection.row_factory=sqlite3.Row
            connection.execute('PRAGMA query_only=ON')
            connection.execute('PRAGMA cache_size=-65536')
            # Warm the file-system through previous samples, keep SQLite's own
            # page cache fresh to measure physical-record dependency.
            connection.execute('BEGIN')
            start=time.perf_counter()
            cursor=connection.execute(sql,params)
            begun=time.perf_counter()
            rows=cursor.fetchall()
            fetched=time.perf_counter()
            names=[v[0] for v in cursor.description]
            values=[dict(zip(names,r,strict=True)) for r in rows]
            finished=time.perf_counter()
            samples.append({'execute_ms':(begun-start)*1000,'fetch_ms':(fetched-begun)*1000,
                'convert_ms':(finished-fetched)*1000,'rows':len(values),
                'output_digest':__import__('hashlib').sha256(repr(values).encode()).hexdigest()})
            plan=[tuple(r) for r in connection.execute('EXPLAIN QUERY PLAN '+sql,params)]
            connection.rollback()
    out['variants'][name]={'plan':plan,'samples':samples}
with (w/'.tmp/stage9-header-index-r67.json').open('x',encoding='utf-8') as handle:
    json.dump(out,handle,ensure_ascii=False,indent=2)
print(json.dumps(out,ensure_ascii=False),flush=True)
