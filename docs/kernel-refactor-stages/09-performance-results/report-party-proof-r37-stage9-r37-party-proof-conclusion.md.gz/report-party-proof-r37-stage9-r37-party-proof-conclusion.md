# r37 季报往来证明路径：单次窄诊断结论

**没有发现足以实施的同根因重复验证缺陷。** r37 主 48 月季报 2019-Q4 的 `party_balance_rows` 确实占报表主要时间，但这次逐阶段工作量显示，大字节来自不同截止点、不同月份及首次命中的真实来源。已知重合贡献与 flow 在同一读取快照复用。应停止本组候选，不把“函数慢”或嵌套累计时间当作可删除工作。

本结论只读 `.tmp/stage9-r37-party-proof-work.json`／`.log`、固定 r37 源码和前序结果；本轮未再运行脚本或改源码。该诊断在合成书上对真实 `Dashboard.quarterly_report(2019, 4, preparation="deferred")` 运行一次，返回准备状态为 `ready`。`stage9_metrics` 全请求记录 635 SQL、26,961 行、10,953,779 B 返回值、约 1,235,700 VM 步。新 phase 标记与 metrics、`sys.setprofile`、`tracemalloc` 同行，会显著放大 CPU 和墙钟值；表中 VM 每 100 步采样，字节是返回 Python 的列值而非磁盘读取。phase 的父子计数重叠，不能相加或推出净时延。独占 ABBA 另见 `.tmp/stage9-native-close-batch-summary-r38.json`；r38 批读无整页净收益，已撤回，不把它纳入此候选。

| 精确路径 | 本次真实工作量 | 判断 |
| --- | --- | --- |
| 前一年末 cutoff `24215`、`source=closed` | 9 SQL、418 行、376,860 B、约 15,700 VM；所需闭月 flow 第一次读取约 376,844 B。 | 是不同截止点的比较基线，不是本期末重复计算。 |
| 本期期末 cutoff `24227`、`source=open` | 146 SQL、21,396 行、8,918,348 B、约 807,800 VM；其中 11 个闭月 flow 各首次读取，开放月另取权威行及往来贡献。 | 这是父调用总数；下列子项已经包含其中。 |
| 11 个闭月 flow | 第一次各约 187.2 KB；从 `report_period_flow` 取 `content` 总计 1,605,370 B，并逐月核对分类引用等原文。报告后续对相同 11 月再次调用均显示 `cache_hit_before=true`、0 SQL／0 返回字节。 | 没有二次物理读取；不同月内容与关账根不能互相替代。 |
| 本月开放权威行 | `_authoritative_rows` 6 SQL、5,306 行、1,545,832 B、约 307,400 VM；返回 2,292 条已选报表行。 | 包括凭证正式发布、当前版本及来源选择检查，不等同于下面的贡献正文。 |
| 第一次开放贡献 | 精确请求 938 ID、缓存命中 0；`read_open_contributions` 15 SQL、5,193 行、4,663,611 B、约 138,200 VM；938 份正文解码输入 2,807,995 B。内层锚定来源核验 13 SQL、3,261 行、1,478,652 B、约 101,100 VM；还读取精确计算依赖 155,232 B（两批合计）。 | 贡献、来源原文、依赖是不同证明材料，内层核验已包含在 4.66 MB 父项中。 |
| 报告后续 cash/profit 开放贡献 | 请求 1,003 ID，其中 937 个此前已请求并命中缓存，仅 66 个新 ID；19 SQL、506 行、426,226 B、约 11,700 VM；只解码 66 份、251,137 B。内层来源核验 17 SQL、258 行、133,773 B，且已认证 binding 可复用。全请求 1,004 唯一 ID、1,004 次贡献正文解码，输入 3,059,132 B。 | 未将共同 937 份正文再取或再解码；第二次的其余工作服务新 ID／依赖。 |

脚本对同一请求中每个 **≥256 B 的 SQL 返回列值**按长度与 SHA-256 区分首次／重复。`party_balance_rows` 的本期期末仅检测到 **3,733 B 重复大值**，归于 `_party_delta` 内 `SELECT * FROM period_close WHERE period<=? ORDER BY period DESC LIMIT 1`；开放贡献正文、锚定来源原文和月度 flow 无重复大值记录。这个 3.7 KB 的关账头重复既不在主要原文路径，也没有可证明影响 500 ms 整页门槛的 CPU 量；不能为此改证明合同。指纹仅识别字节完全相同且至少 256 B 的 SQL 值，不证明小列、不同编码或 Python 中间对象完全不重复。可采信的窄结论是：**没有观察到主要原文／依赖／flow 被二次装载或二次解码**，不是声称代码不存在任何重复运算。

r37 的非同次 cProfile 将两次 `party_balance_rows` 记为约 0.593 秒、`_party_delta` 约 0.329 秒、两次贡献读取约 0.195 秒、23 次 flow 调用约 0.115 秒，均为嵌套累计且带 profiler 成本。单次窄诊断的 phase CPU 被逐 SQL 行计数、哈希和全局 profile 放大到秒级，不可与该 cProfile 或独占浏览器约 725.6 ms 对比，更不能把 0.593 秒写成可节省时间。它只确认工作分布和是否发生了同值再次返回。

同根因消费者已核对：季度页面与公开 `Reports._report` 都经 `reports.py` 的两个 cutoff；`check_report_readiness` 经 `_report(..., _issues_only=True)`，简报 reports worker 在独立事务中调用，不能跨进程借用页面证明。公开 `report`、导出预览／确认，以及 CLI／MCP 的对应适配入口沿用当前报表路径；`Dashboard._position` 在自己的快照调用同一 `party_balance_rows`，仅同快照、同 cutoff 的成功结果可复用。关账准备若调用 `check_report_readiness`，仍需自己的完整核验。完整核验、修复、备份／恢复和固定 `report_projection_v1` 具有独立的全范围或历史核验职责；本次没有这些入口的同型重读证据，不能据当前季报缩减其来源或套用快照缓存。资金、员工、资产、上下文页也无本次证据表明共享了可删除的往来证明工作。

因此不提出生产改动，也不重试逐行派生表／SQL 聚合、跨事务缓存、缩小历史采用、typed 或 raw JSON 捷径、rowid 双阶段、forced index、asset owner 对象缓存以及已撤回的 r38 批读。若后续新的独占整页测量仍显示报表超线，需要新的**具体可删工作证据**再开组；当前根因排查至此停止。

证据：`.tmp/stage9-r37-party-proof-work.json`、`.tmp/stage9-r37-party-proof-work.log`、`.tmp/stage9-remaining-profile-r37-48-reports.txt`、`docs/kernel-refactor-stages/09-performance-results/grouped-report-party-overlap-r24.md`，固定源码 `report_projection.py`、`report_open_contribution.py`、`report_flow.py`、`query_reads.py`、`reports.py`。
