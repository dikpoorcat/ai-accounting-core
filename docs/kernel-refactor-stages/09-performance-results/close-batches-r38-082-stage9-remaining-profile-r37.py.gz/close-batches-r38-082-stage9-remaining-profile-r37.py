"""Current source, synthetic-only work diagnosis; not full-book or page acceptance."""
import cProfile
import json
import os
from pathlib import Path
import pstats
import sys

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / '.tmp/stage9-build-source-r37-release'
sys.path[:0] = [str(SOURCE / 'src'), str(SOURCE / 'tests/kernel')]
os.environ['STAGE9_WORKSPACE_ROOT'] = str(ROOT)

def main():
    assert Path(sys.prefix).resolve() == ROOT / '.tmp-kernel-venv'
    from ai_accounting.kernel.daemon import _prepare_static_runtime
    from ai_accounting.kernel.dashboard import Dashboard
    from ai_accounting.kernel.service import LocalService
    from stage9_metrics import measure_work
    result = {'source': str(SOURCE), 'status': 'diagnostic', 'samples': {}}
    output = ROOT / '.tmp/stage9-remaining-profile-r37.json'
    assert not output.exists()
    for months in (12, 48):
        root = ROOT / ('.tmp/stage9-reseed-main-12-r36' if months == 12
                       else '.tmp/stage9-reseed-main-48-r36.staging')
        app = LocalService(root, enable_read_pool=True, enable_parallel_brief=True,
                           _static_runtime=_prepare_static_runtime())
        try:
            companies = app.catalog.companies()
            assert len(companies) == 1 and companies[0]['name'] == '阶段九合成规模企业'
            engine = app.engine(companies[0]['id'], dashboard_read=True)
            page = Dashboard(engine)
            period = '2016-12' if months == 12 else '2019-12'
            operations = {
                'context': page.context,
                'brief': lambda: app._dashboard_brief(page, engine, {'period': period, 'limit': 100, 'preparation': 'complete'}),
                'funds': lambda: page.funds(period, limit=100, preparation='deferred'),
                'employees': lambda: page.employees(period, limit=100, preparation='deferred'),
                'assets': lambda: page.assets(period, limit=100, preparation='deferred'),
                'reports': lambda: page.quarterly_report(int(period[:4]), 4, preparation='deferred'),
            }
            sample = {'root': str(root), 'full_current_verification': months == 12, 'operations': {}}
            result['samples'][str(months)] = sample
            for name, operation in operations.items():
                operation()
                profiler = cProfile.Profile()
                response = profiler.runcall(operation)
                prefix = ROOT / f'.tmp/stage9-remaining-profile-r37-{months}-{name}'
                profiler.dump_stats(str(prefix.with_suffix('.pstats')))
                with prefix.with_suffix('.txt').open('x', encoding='utf-8') as stream:
                    stats = pstats.Stats(profiler, stream=stream).sort_stats('cumtime')
                    stats.print_stats(80)
                work, _ = measure_work(engine, operation)
                sample['operations'][name] = work
                prefix.with_suffix('.response.json').write_text(json.dumps(response, ensure_ascii=False), encoding='utf-8')
                output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
                print(months, name, 'done', flush=True)
        finally:
            app.close()

if __name__ == '__main__':
    main()
