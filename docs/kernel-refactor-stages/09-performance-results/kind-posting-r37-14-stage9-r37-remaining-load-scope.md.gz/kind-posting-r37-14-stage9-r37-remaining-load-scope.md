# r37 六入口剩余装载范围：当月按 kind 的凭证定位

只读复核固定 r37 源码、`.tmp/stage9-remaining-profile-r37.json` 的 12／48 月六入口记录，以及已有范围和负面结果；没有执行 SQL、EXPLAIN、测试或计时。r38 关账批读取 ABBA 原生接口没有五页净收益且已撤回；r37 季报 1,004 个唯一贡献来源只解码 1,004 次，因此两项都不再作为候选。原生 ABBA 和 cProfile 不能代替浏览器整页验收。

**只保留一个待证候选：`selected_voucher_sql(kinds=...)` 为取本月 50 份工资凭证，可能先枚举同 kind 的多年计算。** `query_reads.py:240–249` 的 `scoped_vouchers` 从 `json_each(selected_kinds)` 进入 `calculation sc INDEXED BY calculation_kind_period ON sc.kind=selected_kinds.value`，再按计算 ID 找 `voucher_version original`；本期 `v.period=?` 在后续 `candidates` 中。源码早段没有对 `sc.period` 的显式约束。尚无这条 SQL 的 r37 执行计划，不能把 SQL 形状直接定为实际过扫。

已有六入口工作量可把候选限定得很窄：brief 和 employees 的同一 `selected_kinds` SQL 族，三次 `SELECT DISTINCT basis_calculation_id` 合计均由主12月约 11.5k VM 增至主48月约 33.1k VM，返回都为 50 行／3,300 B；一次工资度量 `SELECT j.*,json_object(...)` 在 brief 为 17.5k→39.1k VM、employees 为 17.6k→39.2k VM，返回均为 50 行／99,660 B。每入口合计约 29k→72k VM，输出固定。这个增长相对 brief 全部 1.43M→1.69M VM、employees 全部 487k→1.02M VM 只是其中一段，尚无 CPU 或整页净收益证据；不能称为已找出主瓶颈。

同类比较排除了容易误选的更大行数：context 的真实期间 12→48 行、闭月头 11→47 个，本身就是导航范围；funds 的当月汇总／默认页主 SQL 260.5k→260.5k VM、101→101 行，清偿 122.8k→122.8k VM、101→101 行；employees 的工资采用头 600→2,400 行，供历史累计、人员身份和正式采用校验；assets 的成员 78→1,176 行及历史凭证 47→191 行，与真实历史成员和 owner 证明一起增长；reports 的公开计划分类计数 74k→296.2k VM 虽只返回一行，但需统计 12→48 月增长的精确计划 ID，已有覆盖索引。context 为判季度完整性从已认证 close 的 `readiness:financial_reports` 读每月来源块，虽最终只留少数 profile ID，不能从可修目录证明其它 profile 缺席。资产准备 1,428 个计算 ID 全唯一，不能再称重复装载。

影响面限定为 current `QueryReads` 的按 kind 凭证选择以及调用它的简报工资汇总、员工页默认结果；如同一公共函数在 CLI/MCP 详情、资金或其它页面以 `kinds` 和精确月份使用，需按实际参数和来源拒绝同类检查。固定 `report_projection_v1.selected_voucher_sql` 有镜像结构，但维持独立冻结读取合同，不能把 current 的推断直接写成 v1 缺陷。关账、完整核验、修复、备份不能用普通页定位结果替代自身的正式发布与凭证完整性证明。

最小下一验证只需在**相同 r37 索引环境、相同参数**下，对 profile 中上述两条 SQL 保存主12／48月 `EXPLAIN QUERY PLAN`，核对 `calculation_kind_period` 实际使用的是 `kind` 还是 `(kind,period)`，并数 kind 候选、目标月候选及最终 50 行。若期间过滤已经在早期生效或过读不存在，即关闭候选；若证实先遍历多年计算，才设计局部精确期间候选并对照冲正、闭期采用、当前发布、缺失/额外凭证及全部来源拒绝。此轮没有可实施改动，不重试资产 latest、结果全解码缓存、审查24、rowid、r38 批读或跨事务缓存。
