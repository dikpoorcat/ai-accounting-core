# r71 未消费展示读取：银行摘要范围

本组记录银行资金摘要的实现、工作量对照及随后银行相关84项通过；84项已包含原新增9项，不相加为93项。正式版本仍未冻结，不构成最终包、native、浏览器或500ms验收。资产专用metadata首轮新fixture失败，尚未通过且未纳入这84项；正式v1大组也未纳入。

## 同类问题、调用范围与处理

| 类型／位置与调用方 | 必要读取与修复 | 本批证明／缺口 |
| --- | --- | --- |
| 简报只消费金额，却构造银行对账展示：dashboard.brief → _funds(summary_only=True) → dashboard_funds.funds | FundsRead初始化、account_summary及完整资金来源／期初／零账户身份先成功，再早返回八个金额字段。跳过其后bank_summary、展示计数／风险／覆盖、空collections与未消费产品摘要。 | 相对固定r70生产diff只增加此早返回及注释；不修改普通资金分支、分类／来源scope／历史分派、模型／SQL合同／版本或缓存。 |
| 银行原行与已入账资金职责不同：普通资金页、FundsRead.bank_summary及核心匹配 | 普通资金页仍保留对账展示；原行999与实际资金1000分别表达，pending保留；核心匹配仍拒绝bank_match_difference。 | 新组显式核对这条边界，不能因简报退出展示而关闭真实匹配门禁。 |
| 汇总只看已显示账户，漏掉省略及零账户：FundsRead.account_summary | 摘要汇总account_rows与omitted_account_rows；余额／变动、当前及冻结资金事件、独立期初及不确定选择、退休账户归属继续核对。 | 普通资金页八金额及显式业务预期等价；未知closing_fen传播None，不把缺项补零。 |
| 资产及其他同名summary_only | 工资／资产／应收付／资料的同名选项不属于此资金摘要调用。 | 资产专用metadata首轮新fixture失败，尚未通过；本银行84项未包含资产，不以文件存在或银行组通过证明它完成。 |

当前八字段为total_fen、bank_fen、cash_fen、payment_platform_fen、inflow_fen、outflow_fen、net_change_fen、internal_transfer_fen。summary_only生产消费者为简报；普通资金页走完整分支。CLI／MCP／core／关账／fullverify／repair／backup没有直接消费此简报资金摘要，不据此修改它们的证明边界。

## 实际回执与工作量

实际一次新增窄组：9 passed、2 warnings、stdout16.31s；JUnit9项、0失败／错误／跳过，suite时间15.935s。两条warning是record_property与xunit2兼容提示；XML实际包含两条工作量属性，已读取核对。

实际命令：

    ./.tmp-kernel-venv/Scripts/python.exe -X utf8 -m pytest tests/kernel/test_owner_funds_summary_scope.py -q -ra --junitxml=.tmp/stage9-r71-owner-funds-summary.xml

author记录指定production／new-test两文件Ruff通过，只有tool stdout回执，没有独立ruff log，不补造。已有test_funds_bounded_reads两参数摘要断言更新为八金额，普通资金页及bank_summary未匹配断言保留；原9项命令没有测试这份文件，随后84项受影响组已包含它。

银行受影响组session59274 exit0：84 passed、4 record_property／xunit2 warnings、stdout480.21s；JUnit84项、0失败／错误／跳过，suite时间479.776s。七个文件／node分别为新增资金摘要9、资金有界读取6、银行身份见证21、历史账户身份20、老板简报金额25、期初位置2及简报默认有界单例1。84已包含新增9，不与首批或任何旧组相加。范围仅银行／资金及这些简报边界，资产和正式v1大组不在其中。

实际命令：

    .tmp-kernel-venv/Scripts/python.exe -X utf8 -m pytest tests/kernel/test_owner_funds_summary_scope.py tests/kernel/test_funds_bounded_reads.py tests/kernel/test_bank_identity_witness_scope.py tests/kernel/test_funds_historical_account_identities.py tests/kernel/test_owner_brief_amounts.py tests/kernel/test_dashboard_opening_position_scope.py tests/kernel/test_owner_brief_slim.py::test_brief_default_is_bounded_and_does_not_load_technical_payload -q -ra --junitxml=.tmp/stage9-r71-brief-funds-related.xml

原新增9项的独立16.31s回执和首批源码／工作量证据仍保留历史身份；84项是随后受影响组，不称当前全部修改或五页验收。


| 实际银行原行 | 旧 → 窄VM | SQL | 返回行 | 返回字节 | 必要结果加载／解码 |
| ---: | ---: | ---: | ---: | ---: | --- |
| 9 | 9,100 → 7,800 | 71 → 65 | 127 → 124 | 18,133 → 17,926 | 7 → 7／1377B不变 |
| 209 | 41,300 → 17,200 | 71 → 65 | 127 → 124 | 36,933 → 36,726 | 7 → 7／1381B不变 |

209原行的VM实际降低24,100，SQL少6次；返回只少3行／207B，不声称返回量显著下降。银行原行相关SQL3→2，窄路径两项必要来源读取仍在。七次计算结果加载与解码及1377／1381B保持严格相同，typed_fact_json_decodes均0；收益来自不再聚合未消费对账明细，不是弱化source／header／body身份证明。此为真实合成工作量对照，没有页面时延结论。

## 业务边界与未验证

新组覆盖bank／cash／platform合法转款与显式金额：total1700、bank900、cash200、platform600、internal100；普通资金页八金额相同。资金outcome重复键、fact seal、publication、零账户独立state损坏，在先前已读及重新读取情形均拒绝。

未知期初用真实严格source结果核验后的下游uncertainty替身检查None传播；它不是实际损坏fixture或工作量测量。银行相关受影响组已按上述84项实际通过；历史／固定v1完整矩阵、资产同类修复、后续最终合同及当前固定源码浏览器性能仍由root统一收口，本组不作它们的通过声明。r70原主48浏览器37／150失败不能转为r71通过。

原新增9项说明、stdout／XML、实现／新测试／更新断言及固定r70前版本、只读生成diff见[首批manifest](owner-display-read-scope-r71-manifest.json)。随后84项原stdout／XML、当前作者范围说明及本集中记录修订见[银行相关组manifest](owner-display-read-scope-r71-related-manifest.json)，引用首批而不覆盖旧证据。两批分别保存raw／gzip双SHA、bytes和mtime；生成diff无原文件mtime，明确来源双SHA。首批document_sha256保持当时版本，第二批记录当前修订。全部exclusive gzip解压逐字节一致。本次仅归档，无SQL、测试、service、browser、build或生产编辑。
