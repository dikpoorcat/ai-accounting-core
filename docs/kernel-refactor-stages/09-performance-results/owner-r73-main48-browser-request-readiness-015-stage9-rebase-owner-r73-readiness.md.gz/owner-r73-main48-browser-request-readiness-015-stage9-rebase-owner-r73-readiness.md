# r73 大样本合成构造准备

状态：`static_ready_runtime_guards_mandatory`。只完成准备与小源码guard负测；未复制业务库、构造、运行SQL、pytest、完整核验或preview。

固定 r73 snapshot `420ceb395fc5aec17ddaedf8914c7fc8de640da9f08cb35aded8a3a99a4eb7f4`；company `c9f9f7051bca67f1241ee5c89676fb9476bc819dc8f92c1a0c0bd1e940f459cb`、catalog `b484d315272bb64de3856b458f04d2d4881da05db7552250864260916c69a4ee`、content `8abdbad6e6dca035c948daaf8a254743282c72a2198fd28caa852d9593b895a1`。

包装器仅开放main120／independent48／independent120原CASE；固定r49执行器SHA，不修改原脚本。`RESUMABLE_STAGING=frozenset()`，不接受resume、dry-run、copy-only；输出log／report／command均用独占创建。

| CASE | 原状态 | report/checkpoint | 源码manifest | 原source JSON guard | 新目标 |
| --- | --- | --- | --- | --- | --- |
| main120 | built_not_verified | 原SHA均匹配 | 508文件逐SHA/aggregate通过 | not_reexecuted; exact 186767161-byte checkpoint SHA checked | `stage9-owner-main120-r73` |
| independent48 | built_not_verified | 原SHA均匹配 | 494文件逐SHA/aggregate通过 | original_JSON_guard_passed | `stage9-owner-independent48-r73` |
| independent120 | complete | 原SHA均匹配 | 534文件逐SHA/aggregate通过 | original_JSON_guard_passed | `stage9-owner-independent120-r73` |

原阻断原因是当前snapshot工具要求旧树补上后来新增的`frontend/local-api-proxy.ts`。旧r11/r22/r30的`_selected`没有选择该文件，原执行器只读取旧树合同/manifest；运行依赖使用当前/r73脚本和r73内核，未发现实际缺脚本。四个执行helper文件存在且与r73固定副本逐SHA相同。

经授权，仅包装器中的历史snapshot分派改为原manifest精确文件集合核验：固定CASE/来源标记/status/target/expected SHA、规范且限定范围的路径、普通文件/链接拒绝、size/mtime/inode稳定、逐文件SHA、原算法aggregate及完整eligible inventory。声明外的eligible文件亦拒绝；不补缺文件、不改旧manifest/源树。新r73保持原current完整snapshot guard。

实际guard：r22 508文件／15,709,749字节，r11 494文件／15,499,549字节，r30 534文件／15,992,385字节，以及current r73均通过。小fixture仅68,722字节，阳性通过；删声明文件、改单字节、错aggregate、路径逃逸均拒绝；unknown CASE dispatcher亦拒绝。原件为`.tmp/stage9-r73-historical-manifest-guard-probe.py`及`stage9-r73-historical-manifest-guard.log/json`和对应fixtures。

下列命令仅已准备，未启动；各自log／JSON／command及目标/staging当前均不存在，运行时再次拒绝既有路径。

```powershell
.tmp-kernel-venv/Scripts/python.exe -X utf8 .tmp/stage9-rebase-owner-r73.py --case main120
.tmp-kernel-venv/Scripts/python.exe -X utf8 .tmp/stage9-rebase-owner-r73.py --case independent48
.tmp-kernel-venv/Scripts/python.exe -X utf8 .tmp/stage9-rebase-owner-r73.py --case independent120
```

磁盘可用 137.89 GiB；三目标保守预算 91.35 GiB。按每目标3×源SQLite/WAL/SHM文件字节+2×report/checkpoint+512MiB；不是实测峰值。

两个独立来源原source JSON guard实际通过。main120 checkpoint为186,767,161字节，本次仅流式核对完整原SHA，未完整装载大JSON；实际构造仍先运行原guard，身份、50人/1000业务/月、snapshots、epochs、闭开状态均不放宽。main120和independent48保留built_not_verified来源状态。

原构造全流程不变：只读源；精确公司/目录合同与DDL对象差异；原样rowid/原始/冻结字节；FK关闭后事务保护及恢复；注册四范围完整内容核验；真实最后开放月preview；核验前后state/identity和源/目标摘要；成功后才注册及无覆盖发布。准备回执不证明这些重流程已通过。

readiness JSON保留initial_preflight_result原阻断，记录授权修法后的逐项结果。只有根节点统一安排才启动重流程。
