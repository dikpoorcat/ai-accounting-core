# r37 `selected_kinds`＋精确入账月候选审查（只读诊断）

结论：**不落地本次三个候选，生产选择器保持 r37。** `guard→voucher_period→scoped_calc` 虽能使 48 月简报工资 SQL 的 VM 不再随同类全历史增长，却使同路径资产页当月仅 1 行的两条 SQL 从不足 900 VM 升到约 13,600 VM；12 月工资 50 行也回退。两个 direct 变体没有改善这项权衡。原同类全历史候选增长问题仍在，不能记为已排除或已修复。未跑产品测试、全组回归、独立时延，也未新增索引或改业务规则。

## 原始证据与范围

- 原始 r37 12／48 月六入口工作量：`.tmp/stage9-remaining-profile-r37.json`；其中 `brief` 的 kind 月 SQL 约 11.5k／17.5k → 33.1k／39.1k VM，`assets` 的当月 asset kind 月 SQL 约 300／400 → 700／800 VM，说明同一 `selected_voucher_sql` 分支同时服务密集和稀疏类型。
- 员工真实调用及五条原 SQL、参数、计划、VM：`.tmp/stage9-r37-kind-period-probe.py`／`.json`；原文批比对：`.tmp/stage9-r37-kind-period-private-ab.py`／`.json`。
- 简报与资产页面各在两档库调用一次，捕获其真实 kind＋精确入账月 SQL、参数，再在只读事务里比较原文和 guard 候选：`.tmp/stage9-r37-kind-period-brief-assets-probe.py`／`.json`。JSON 保存每条完整 SQL、实参、计划、VM、原始与候选的逐列返回行；`DISTINCT` 未指定次序，以行多重集比较。
- 两个 direct 私有变体：`.tmp/stage9-r37-kind-period-direct-private-ab.py`／`.json` 与 `.tmp/stage9-r37-kind-period-direct-kind-first-private-ab.py`／`.json`。均仅对员工已捕获五条 SQL 比较；后一变体把 `vc.kind` 连接提前到凭证号连接之前。

| 真实入口／当月结果 | 12 月原文 → guard VM | 48 月原文 → guard VM | 行多重集 |
| --- | ---: | ---: | --- |
| 简报工资 basis，50 行 | 11,467 → 17,894 | 33,066 → 17,894 | 相同 |
| 简报工资 metric，50 行 | 17,624 → 24,051 | 39,223 → 24,051 | 相同 |
| 简报劳务／项目费用，0 行 | basis 49／45 → 56／52；metric 124／112 → 137／125 | 同左 | 相同 |
| 资产 basis，1 行 | 344 → 13,578 | 776 → 13,578 | 相同 |
| 资产 metric，1 行 | 462 → 13,696 | 894 → 13,696 | 相同 |

guard 候选先以 `calculation_kind_period(kind,period,id)` 作 `LIMIT 1` 存在性检查，再以 `voucher_period(period,voucher_id,id)` 找目标入账月所有 `voucher_version`，用该版本的 `calculation.kind` 筛选。对从未出现的劳务类型，guard 在扫描整月前中止；但资产类型在历史里存在、目标月仅 1 条，guard 仍放行整个月的其他类型。原文从 `calculation_kind_period` 按 kind 找计算，再由 `voucher_calculation(calculation_id)` 找其凭证版本，最后以 `v.period=?` 限定入账月。12 月工资全历史同类候选 600、目标月 50；48 月为 2,400、目标月仍 50。前者短历史上原文较省，后者历史增长导致原文多做工作。资产同类全历史本来很稀疏，改为整月驱动造成清楚的回退。

`voucher_period` 的一行是一条**凭证版本**，不是去重后的业务凭证；开放期替换会保留同一 `voucher_id` 的旧版本，闭期更正会有冲正与替换版本。后续 `voucher_current`／`period_close`／关账引用、`basis_calculation_id`、`reverses_id` 等选择规则决定可见行及其采用计算，不能用 `calculation.period` 裁掉跨月发布与冲正。简报的 basis SQL 用来取采用计算 ID，metric SQL 再取凭证与工资值；两条读取同一选择范围，但不同返回形态不是错误的重复凭证。资产同样先取 basis 再取 metric，一行结果不代表月索引只扫描一行。

直接以 `has_kind→voucher_period v→voucher n→calculation vc` 驱动的首变体，在 12／48 月工资 50 行均为 basis 40,135、metric 47,238 VM；把 `vc.kind` 移到凭证号前的最后一个 direct 变体仍为 38,225／44,373 VM。两者空类型行仍低 VM，返回行多重集相同，但非空路径均劣于原文。现有 `calculation_publication(posting_period,subject_id,id)` 能按发布月找记录，却不是凭证版本及冲正的覆盖索引；未证明它能作为不丢历史版本的等价入口。本次不再扩展 SQL 变体。

`query_reads.py` 中 `voucher_ids`、`subject_ids` 优先于 kinds；未指定精确 `posting_period` 的 kind 查询继续按原索引。固定 v1 选择器是独立历史语义。即便将来重新设计候选，也须保留原 `vc.kind IN`、关账／当前版本／冲正／发布证明及精确凭证入账月条件，并以真实稀疏类型与短历史同场比较。
