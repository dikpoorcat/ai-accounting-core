"""Small read-only live snapshot guards and isolated manifest rejection cases."""

import contextlib
import hashlib
import importlib.util
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / ".tmp" / "stage9-r73-historical-manifest-guard"
LOG = BASE.with_suffix(".log")
REPORT = BASE.with_suffix(".json")
FIXTURES = BASE.with_name(BASE.name + "-fixtures")
if any(path.exists() for path in (LOG, REPORT, FIXTURES)):
    raise RuntimeError("Exclusive guard probe output exists")
path = ROOT / ".tmp" / "stage9-rebase-owner-r73.py"
compile(path.read_bytes(), str(path), "exec")
spec = importlib.util.spec_from_file_location("r73_guard_probe_wrapper", path)
wrapper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(wrapper)
module = wrapper.executor()
result = {
    "scope": "source-file guards only; no SQLite, construction, verification or preview",
    "executable": sys.executable,
    "python": sys.version,
    "command": ".tmp-kernel-venv/Scripts/python.exe -X utf8 .tmp/stage9-r73-historical-manifest-guard-probe.py",
    "wrapper_compile": "passed",
    "live": [],
    "negative": [],
}


def fixture(name):
    tree = FIXTURES / name
    tree.mkdir()
    files = {}
    original = ROOT / ".tmp" / "stage9-build-source-r11-release"
    for relative in sorted(wrapper.HISTORICAL_TOP_FILES):
        target = tree / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        content = (original / relative).read_bytes()
        with target.open("xb") as handle:
            handle.write(content)
        files[relative] = hashlib.sha256(content).hexdigest()
    expected = wrapper._manifest_digest(files)
    manifest = {
        "status": "complete", "source": str(original), "target": str(tree),
        "sha256": expected, "file_count": len(files), "files": files,
    }
    return tree, original, manifest, expected


with LOG.open("x", encoding="utf-8", buffering=1) as log:
    with contextlib.redirect_stdout(log), contextlib.redirect_stderr(log):
        for selection, source_name in wrapper.APPROVED.items():
            case = module.CASES[source_name]
            tree = ROOT / ".tmp" / case["source_tree"]
            try:
                checked = module._require_snapshot(tree, case["source_snapshot"])
                item = {"selection": selection, "status": "passed", "proof": checked}
            except Exception as error:
                item = {"selection": selection, "status": "failed", "error": str(error)}
            result["live"].append(item)
            print(json.dumps(item))
        try:
            module._require_snapshot(ROOT / ".tmp" / wrapper.NEW_TREE, wrapper.NEW_SNAPSHOT)
            result["live"].append({"selection": "current_r73", "status": "passed"})
        except Exception as error:
            result["live"].append({"selection": "current_r73", "status": "failed", "error": str(error)})
        FIXTURES.mkdir()
        for name in ("healthy", "delete_declared_file", "change_byte", "wrong_aggregate", "path_escape"):
            tree, origin, manifest, expected = fixture(name)
            if name == "delete_declared_file":
                target = (tree / "pyproject.toml").resolve()
                assert target.is_relative_to(FIXTURES.resolve())
                target.unlink()
            elif name == "change_byte":
                target = tree / "pyproject.toml"
                target.write_bytes(target.read_bytes() + b"\n# isolated changed byte\n")
            elif name == "wrong_aggregate":
                manifest["sha256"] = "f" * 64
            elif name == "path_escape":
                manifest["files"]["../outside.py"] = "0" * 64
                manifest["file_count"] = len(manifest["files"])
                expected = wrapper._manifest_digest(manifest["files"])
                manifest["sha256"] = expected
            with (tree / "source-manifest.json").open("x", encoding="utf-8") as handle:
                json.dump(manifest, handle)
            try:
                proof = wrapper._verify_historical_manifest(tree, expected, origin=origin)
                item = {"case": name, "accepted": True, "proof": proof}
            except Exception as error:
                item = {"case": name, "accepted": False,
                        "error_type": type(error).__name__, "error": str(error)}
            item["expectation_met"] = item["accepted"] == (name == "healthy")
            result["negative"].append(item)
            print(json.dumps(item))
        try:
            module._require_snapshot(FIXTURES / "healthy", expected)
            result["unknown_case_dispatcher_rejected"] = False
        except ValueError:
            result["unknown_case_dispatcher_rejected"] = True
        result["status"] = "passed" if (
            all(item["status"] == "passed" for item in result["live"])
            and all(item["expectation_met"] for item in result["negative"])
            and result["unknown_case_dispatcher_rejected"]
        ) else "failed"
        print(json.dumps(result, indent=2))
with REPORT.open("x", encoding="utf-8") as handle:
    json.dump(result, handle, ensure_ascii=False, indent=2)
    handle.write("\n")
print(json.dumps(result, ensure_ascii=False))
raise SystemExit(0 if result["status"] == "passed" else 1)
