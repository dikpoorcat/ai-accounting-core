"""Build a Windows runtime from the already installed, controlled repository venv.

Only allowlisted application sources, public dependency distributions, standard
Python files and the built frontend are copied. No repository-wide copy occurs.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib
import importlib.metadata as metadata
import json
import os
import platform
import shutil
import sqlite3
import subprocess
import sys
import sysconfig
import zipfile
from datetime import UTC, datetime
from pathlib import Path

from packaging.requirements import Requirement
from packaging.utils import canonicalize_name

REPOSITORY = Path(__file__).resolve().parents[1]
ROOT_DEPENDENCIES = (
    "mcp",
    "pydantic",
    "argon2-cffi",
    "pypdf",
    "openpyxl",
    "xlwt",
    "xlrd",
    "jsonschema",
)


def sha256(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def verify_package_inventory(root: Path, manifest: dict, manifest_sha256: str) -> None:
    """Reject extra, absent or changed software before packaging or first execution."""
    expected = manifest["files"]
    names = set()
    if root.is_symlink() or root.is_junction():
        raise ValueError("Package root must not be a symbolic link or junction")
    for path in root.rglob("*"):
        if path.is_symlink() or path.is_junction():
            raise ValueError(f"Package contains a link or junction: {path.relative_to(root)}")
        if path.is_file():
            names.add(path.relative_to(root).as_posix())
        elif not path.is_dir():
            raise ValueError(f"Package contains an unsupported path: {path.relative_to(root)}")
    if names != set(expected) | {"manifest.json"}:
        raise ValueError("Package file inventory differs from its manifest")
    if sha256(root / "manifest.json") != manifest_sha256:
        raise ValueError("Package manifest changed after construction")
    for relative, recorded in expected.items():
        source = root / relative
        if source.stat().st_size != recorded["bytes"] or sha256(source) != recorded["sha256"]:
            raise ValueError(f"Package file changed: {relative}")


def copy_file(source: Path, target: Path):
    if source.is_symlink():
        raise ValueError(f"Symlinks are not included in the runtime: {source.name}")
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)


def dependency_closure():
    found = {}
    expanded_extras = {}
    pending = [Requirement(name) for name in ROOT_DEPENDENCIES]
    while pending:
        requested = pending.pop()
        name = canonicalize_name(requested.name)
        distribution = metadata.distribution(name)
        if requested.specifier and distribution.version not in requested.specifier:
            raise ValueError(f"Installed dependency does not satisfy {requested}")
        earlier_extras = expanded_extras.get(name)
        if earlier_extras is not None and requested.extras <= earlier_extras:
            continue
        active_extras = (earlier_extras or set()) | requested.extras
        expanded_extras[name] = active_extras
        found[name] = distribution
        for dependency in distribution.requires or ():
            requirement = Requirement(dependency)
            if requirement.marker is None or any(
                requirement.marker.evaluate({"extra": extra}) for extra in {"", *active_extras}
            ):
                pending.append(requirement)
    return found


def copy_runtime(output: Path):
    base = Path(sys.base_prefix).resolve()
    runtime = output / "runtime"
    runtime.mkdir()
    for source in base.iterdir():
        if source.is_file() and (
            source.suffix in {".exe", ".dll"} or source.name in {"BUILD", "LICENSE.txt"}
        ):
            copy_file(source, runtime / source.name)
    for directory in ("DLLs", "Lib", "tcl"):
        if not (base / directory).is_dir():
            raise ValueError(
                f"Controlled Python is missing required runtime directory: {directory}"
            )
        for source in (base / directory).rglob("*"):
            relative = source.relative_to(base)
            if source.is_file() and not {"site-packages", "__pycache__"} & set(relative.parts):
                copy_file(source, runtime / relative)
    # Windows' embedded-path mechanism ignores registry, PYTHONPATH, PYTHONHOME
    # and user site-packages. Every import path remains relative to this bundle.
    (runtime / "python312._pth").write_text(
        "python312.zip\nDLLs\nLib\nLib/site-packages\n"
        "Lib/site-packages/win32\nLib/site-packages/win32/lib\n"
        "Lib/site-packages/pythonwin\n../app\nimport site\n",
        encoding="ascii",
    )
    return runtime


def copy_dependencies(output: Path):
    installed = Path(sysconfig.get_path("purelib")).resolve()
    target = output / "runtime/Lib/site-packages"
    dependencies = dependency_closure()
    for distribution in dependencies.values():
        for member in distribution.files or ():
            source = Path(distribution.locate_file(member)).resolve()
            if not source.is_relative_to(installed) or not source.is_file():
                continue
            relative = source.relative_to(installed)
            if (
                "__pycache__" in relative.parts
                or source.suffix in {".pth", ".pyc", ".egg-link"}
                or source.name == "direct_url.json"
            ):
                continue
            copy_file(source, target / relative)
    # pywin32 normally installs search paths via executable .pth code. Keep
    # that code excluded: explicit _pth entries and local DLLs provide the
    # required MCP Windows process support without importing host locations.
    for source in (target / "pywin32_system32").glob("*.dll"):
        copy_file(source, output / "runtime" / source.name)
    return {name: distribution.version for name, distribution in sorted(dependencies.items())}


def selected_contract_files(bundle, directory: Path):
    """Copy the active draft or the declared released history, never stale drafts."""

    from ai_accounting.kernel.contract_files import contract_file_names, contract_files

    return contract_files(directory, contract_file_names(bundle))


def copy_application(output: Path):
    # Exercise all local public entry modules and generated schemas to discover
    # their shared pure imports. Optional dependency distributions are handled
    # separately above; legacy ORM/services are deliberately not imported.
    for name in ("cli", "http", "mcp", "exports", "reports", "workflow"):
        importlib.import_module("ai_accounting.kernel." + name)
    from ai_accounting.kernel.schema_bundle import production_bundle

    bundle = production_bundle()
    bundle.registry.schemas()
    source_package = REPOSITORY / "src/ai_accounting"
    selected = set((source_package / "kernel").rglob("*.py"))
    selected.discard(source_package / "kernel/security/legacy.py")
    selected.update((source_package / "payroll").rglob("*.py"))
    from ai_accounting.kernel.build import SHARED_SOURCE_FILES

    selected.update(source_package / name for name in SHARED_SOURCE_FILES)
    for name, module in tuple(sys.modules.items()):
        path = getattr(module, "__file__", None)
        if name.startswith("ai_accounting") and path:
            source = Path(path).resolve()
            if not source.is_relative_to(source_package) or source.suffix != ".py":
                raise ValueError("Application imports escaped the repository's source package")
            selected.add(source)
    if source_package / "kernel/security/legacy.py" in selected:
        raise ValueError("The installer-only identity importer entered the runtime import graph")
    if any(
        path.name in {"models.py", "database.py", "service.py"} and path.parent == source_package
        for path in selected
    ):
        raise ValueError("The local runtime unexpectedly imports legacy persistence")
    for source in sorted(selected):
        copy_file(source, output / "app/ai_accounting" / source.relative_to(source_package))
    contracts = source_package / "kernel/schema_contracts"
    for source in selected_contract_files(bundle, contracts):
        copy_file(source, output / "app/ai_accounting" / source.relative_to(source_package))
    from ai_accounting.financial_statement_template import TEMPLATE_FILE_NAME, _template_bytes

    _template_bytes()  # verifies the checked-in, blank report-template digest
    template = source_package / "templates/financial_reports" / TEMPLATE_FILE_NAME
    copy_file(
        template, output / "app/ai_accounting/templates/financial_reports" / TEMPLATE_FILE_NAME
    )
    frontend = source_package / "static/dashboard"
    if not all((frontend / name).is_file() for name in ("index.html", "local.html")):
        raise ValueError("Build the release frontend before packaging: npm run build:release")
    for source in frontend.rglob("*"):
        if source.is_file():
            copy_file(source, output / "frontend/dist" / source.relative_to(frontend))
    return sorted(path.relative_to(source_package).as_posix() for path in selected)


def bundle_manifest(output, dependencies, modules, *, source_build_id=None):
    from ai_accounting.kernel.build import calculator_build_id

    expected_build_id = source_build_id or calculator_build_id()
    probe = subprocess.run(
        [
            str(output / "runtime/python.exe"),
            "-I",
            "-B",
            "-X",
            "utf8",
            "-c",
            "import json,sqlite3,sys; from ai_accounting.kernel.build import calculator_build_id; "
            "from ai_accounting.kernel.schema_bundle import production_bundle; "
            "b=production_bundle(); "
            "formats={k:b.database_format(k) for k in ('catalog','company')}; "
            "print(json.dumps({'python':sys.version.split()[0],'sqlite':sqlite3.sqlite_version,"
            "'build_id':calculator_build_id(),'isolated':sys.flags.isolated,"
            "'database_formats':formats}))",
        ],
        cwd=output,
        check=True,
        capture_output=True,
        text=True,
        encoding="utf-8",
    )
    runtime = json.loads(probe.stdout)
    if runtime["build_id"] != expected_build_id or calculator_build_id() != expected_build_id:
        raise ValueError("Packaged build identity differs from its source build")
    if runtime["python"] != "3.12.13" or runtime["sqlite"] != "3.53.1" or runtime["isolated"] != 1:
        raise ValueError("Packaged interpreter does not match the controlled runtime")
    files = {
        path.relative_to(output).as_posix(): {"sha256": sha256(path), "bytes": path.stat().st_size}
        for path in sorted(output.rglob("*"))
        if path.is_file() and "__pycache__" not in path.parts
    }
    return {
        "format": "ai-accounting-local-runtime",
        "format_version": 1,
        "created_at": datetime.now(UTC).isoformat(),
        "platform": platform.platform(),
        "architecture": platform.machine(),
        "runtime": runtime,
        "source_build_id": expected_build_id,
        "dependencies": dependencies,
        "application_modules": modules,
        "files": files,
        "data_policy": "software only; company data and credentials are excluded",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--skip-validation", action="store_true")
    args = parser.parse_args()
    if (
        sys.platform != "win32"
        or sys.version_info[:3] != (3, 12, 13)
        or sqlite3.sqlite_version != "3.53.1"
    ):
        raise SystemExit("Use the controlled Windows Python 3.12.13 / SQLite 3.53.1 runtime")
    output = args.output.resolve()
    archive_path = output.with_name(output.name + ".zip")
    relocated = output.with_name(output.name + "-relocated")
    verification_path = output.with_name(output.name + "-verification.json")
    if any(path.exists() for path in (output, archive_path, relocated, verification_path)):
        raise SystemExit("Packaging targets must be absent; existing builds are never overwritten")
    from ai_accounting.kernel.build import calculator_build_id

    source_build_id = calculator_build_id()
    output.mkdir(parents=True)
    copy_runtime(output)
    dependencies = copy_dependencies(output)
    modules = copy_application(output)
    (output / "finance-local.cmd").write_text(
        "@echo off\nsetlocal\nif not defined FINANCE_DATA_ROOT "
        'set "FINANCE_DATA_ROOT=%~dp0data\\kernel-released"\n'
        '"%~dp0runtime\\python.exe" -I -X utf8 '
        "-m ai_accounting.kernel.cli %*\nexit /b %errorlevel%\n",
        encoding="ascii",
    )
    (output / "finance-local.ps1").write_text(
        "if (-not $env:FINANCE_DATA_ROOT) { "
        '$env:FINANCE_DATA_ROOT = Join-Path $PSScriptRoot "data/kernel-released" }\n'
        '& (Join-Path $PSScriptRoot "runtime/python.exe") -I -X utf8 '
        "-m ai_accounting.kernel.cli @args\nexit $LASTEXITCODE\n",
        encoding="utf-8",
    )
    copy_file(
        REPOSITORY / "scripts/verify_local_package.py", output / "tools/verify_local_package.py"
    )
    (output / "使用说明.txt").write_text(
        "本地会计内核运行包（Windows x64）\n\n"
        "不需要安装 Python、SQLite、PostgreSQL 或 Node.js。\n"
        "所有命令通过包内 finance-local.cmd 或 finance-local.ps1 运行。\n"
        "默认资料目录：包内 data\\kernel-released。\n"
        "示例：finance-local.cmd serve\n"
        "MCP：finance-local.cmd mcp\n"
        "另选资料目录：finance-local.cmd --root D:\\会计资料 serve\n"
        "命令说明：finance-local.cmd --help\n"
        "初始运行包中没有任何公司账务和登录凭据。\n"
        "不要直接复制活动 SQLite 文件作为备份，请使用内核 backup 命令。\n",
        encoding="utf-8",
    )
    manifest = bundle_manifest(output, dependencies, modules, source_build_id=source_build_id)
    (output / "manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    manifest_sha256 = sha256(output / "manifest.json")
    verify_package_inventory(output, manifest, manifest_sha256)
    with zipfile.ZipFile(
        archive_path, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6
    ) as archive:
        for path in sorted(output.rglob("*")):
            if path.is_file() and "__pycache__" not in path.parts:
                if path.suffix in {".sqlite", ".sqlite3", ".env"} or path.name == "pyvenv.cfg":
                    raise ValueError("A non-software file entered the package")
                archive.write(path, path.relative_to(output).as_posix())
    validation = None
    if not args.skip_validation:
        relocated.mkdir()
        with zipfile.ZipFile(archive_path) as archive:
            archive.extractall(relocated)  # own freshly generated, relative-only software archive
        verify_package_inventory(relocated, manifest, manifest_sha256)
        poisoned = dict(
            os.environ,
            PYTHONPATH=str(REPOSITORY / "not-an-import-path"),
            PYTHONHOME=str(REPOSITORY / "not-a-python-home"),
            PYTHONNOUSERSITE="1",
        )
        result = subprocess.run(
            [
                str(relocated / "runtime/python.exe"),
                "-I",
                "-B",
                "-X",
                "utf8",
                str(relocated / "tools/verify_local_package.py"),
            ],
            cwd=relocated,
            env=poisoned,
            capture_output=True,
            text=True,
            encoding="utf-8",
        )
        if result.returncode:
            raise RuntimeError("Relocated runtime verification failed:\n" + result.stderr)
        validation = json.loads(result.stdout)
        with verification_path.open("x", encoding="utf-8") as report:
            report.write(json.dumps(validation, ensure_ascii=False, indent=2))
    print(
        json.dumps(
            {
                "package": str(output),
                "archive": str(archive_path),
                "archive_bytes": archive_path.stat().st_size,
                "software_bytes": sum(item["bytes"] for item in manifest["files"].values()),
                "runtime": manifest["runtime"],
                "relocated": str(relocated) if validation else None,
                "validation": validation,
            },
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
