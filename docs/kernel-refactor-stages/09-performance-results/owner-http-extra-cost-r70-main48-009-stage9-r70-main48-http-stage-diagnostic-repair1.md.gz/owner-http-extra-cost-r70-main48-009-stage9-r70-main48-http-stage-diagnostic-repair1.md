# r70 主48 公共 HTTP 阶段及 bound 对照

主48固定 r70 release，50人、1000业务/月、48月、48000业务。只用已核验合成根 `.tmp/stage9-owner-main48-r63`，报告 `.tmp/stage9-owner-main48-r70-verified.json`。不是浏览器30轮或500 ms验收；没有更改生产、池配置、安全语义、业务库内容或构造 close preview。

repair1 exit0：36次真实HTTP预热、23次 measured 公共GET、6次同范围本地bound读取全部成功。两条实际物理公司连接，每条均六路各warm3；warm rendezvous仅在预热阶段强制两条连接同时占用，没有用于 measured。阶段、cProfile和五对context/main并发独立记录。root声明整个本轮无heavy job并行。

公共与bound完整响应归一后相等。仅归一源码明确的context顶层generated_at、brief.data.generated_at、quarterly-report顶层checked_at；read_context、业务快照、所有source/digest/金额/三张报表/20条集合字段全部保留。末尾实际catalog/company/state/identity重读及book报告精确guard通过，自己的session已logout，服务及pool已关闭。preview_close运行时tripwire触发0次；close-review只辅助读unprepared，无owner_review，Handler30.14 ms，不能当已准备浏览器close-review成本。

| 路由 | HTTP Handler ms | 线程CPU ms | 本地bound ms | bound线程CPU ms | authorize ms | bind ms | borrow enter ms | 同条HTTP/bound物理连接 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| context | 36.76 | 15.625 | 13.69 | 0.000 | 8.15 | 0.00 | 14.16 | 1 |
| brief | 404.21 | 390.625 | 403.38 | 406.250 | 11.32 | 10.00 | 11.72 | 2 |
| funds | 251.75 | 234.375 | 326.71 | 328.125 | 9.20 | 11.60 | 10.46 | 1 |
| employees | 196.54 | 171.875 | 188.44 | 187.500 | 8.36 | 10.98 | 11.56 | 2 |
| assets | 371.67 | 359.375 | 337.85 | 343.750 | 9.52 | 11.88 | 10.31 | 1 |
| quarterly-report | 379.03 | 375.000 | 375.40 | 375.000 | 9.63 | 10.60 | 9.65 | 2 |

顺序auth8.15–11.32 ms、main bind10.00–11.88 ms依旧是公共成本；context由Catalog.connection/_bound_store实现，未调用Catalog.bind。命令schema校验0.03–0.10 ms；response validate+dump最大约1.01 ms（assets），reply0.33–0.42 ms，不能解释额外百毫秒。pool检查也是bound必要路径，不能将其全部记为公共新增。单样本bound次序在六次HTTP之后；funds bound326.71高于HTTP251.75，brief两者约403–404，说明不能用这些单样本差值直接估计固定接口开销。

| 暖并发页 | 主Handler ms | 较顺序变化 ms | 主线程CPU ms | context Handler ms | context线程CPU ms | 主authorize ms | 主borrow enter ms | 主/context物理连接 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|
| brief | 451.66 | +47.45 | 437.500 | 41.32 | 31.250 | 11.97 | 14.33 | 2 / 1 |
| funds | 319.08 | +67.33 | 296.875 | 54.78 | 62.500 | 15.29 | 23.95 | 1 / 2 |
| employees | 213.07 | +16.53 | 187.500 | 56.27 | 31.250 | 12.68 | 14.90 | 2 / 1 |
| assets | 383.60 | +11.92 | 359.375 | 37.91 | 31.250 | 15.11 | 10.08 | 2 / 1 |
| quarterly-report | 450.47 | +71.43 | 390.625 | 104.69 | 15.625 | 31.46 | 10.24 | 1 / 2 |

全部measured _take 0.006–0.013 ms，creates_connection=False；同池Condition.wait wrapper没有记录到调用，不存在本轮连接容量等待。实际page_count873870，两条cache_size均-262144（256MiB预算）未变。页面预算不表示全部工作集驻留；并发期间轮转物理连接，因此report/assets比较仍有连接working-set差异，不当作严格GIL因果实验。

有实证的并发变化：brief主体_dispatch391.82→438.72 ms（+46.90）、authorize只+0.65；report主体368.29→418.10（+49.81）及authorize9.63→31.46（+21.84）。report main commit19.55 ms、context commit25.10 ms；context connect10.91、transaction enter31.47、authorize57.58、borrow27.53，总Handler104.69。Security._transaction持authorization_gate完成session核对/刷新及commit，与这个事务进入差值相符，但本轮没有独立量锁等待，不能将全部差值归GIL、SQLite锁或磁盘。assets并发主CPU与顺序同为359.375 ms、wall+11.92；brief/funds主CPU也上升，表明不仅是可直接相减的线程等待。Windows thread_time按15.625 ms量化，短阶段0 CPU不证明纯等待。

每个Handler实际开始/结束epoch、线程ID/CPU、连接ID及所有nested阶段均在JSON。cProfile属于单独带开销请求，不与阶段wall当作净收益比较。五页profile主要仍是各自业务读取；verify_schema每次4调用总6.33–8.42 ms，company validate5.26–7.32、两auth catalog合计0.52–0.76、bind catalog0.35–0.37。context prof另有异常跨调用记录urllib.client.getresponse43.90 ms，其caller require_local_database却0calls；保留原prof，不使用该条归因runtime/网络，其调用图有局部异常，阶段计时独立。

依据链：HTTP Handler→LocalService.dispatch→command validate/authorize→_dispatch→Catalog.bind或context catalog enumerate→Dashboard→QueryReads/pool。不同HTTP分别执行session认证与公司绑定、分别取业务snapshot；必要权限、idleexpiry/logout、事务身份/FK/schema、borrow前后文件替换护栏仍完整。主48公共并发会放大内部时延有实证，但不能宣称已解释r70浏览器全部超限或全部来自GIL。

若根决定下一窄架构项，可评估老板完整context+main在一个已授权公共请求内交付，减少第二套auth/catalog打开并消除二请求竞争；必须完整保留两部分合同、公司选择、期间导航、业务snapshot身份/读版本、独立错误语义及source证明，不通过缓存或跳过核验实现。当前仅建议，未改接口、前端或生产；brief-close-review已prepared竞争未在本轮复现，不能外推其净收益。

传输负面控制继续成立：此前176样本NODELAY0/1真实确认、响应bytes一致、fetch median2.7–3.8/max6.5 ms，没有40–100 ms改进。本轮不改NODELAY，也不把20 ms两帧阶梯归网络。

实际命令：

```powershell
& ./.tmp-kernel-venv/Scripts/python.exe -X utf8 .tmp/stage9-r70-main48-http-stage-diagnostic-repair1.py 2>&1 | Tee-Object -FilePath .tmp/stage9-r70-main48-http-stage-diagnostic-repair1.log
```

原件：exclusive repair1 `.py/.json/.log/-syntax.log`，六个 `-cprofile-{context,brief,funds,employees,assets,quarterly-report}.prof`。首次未归一展示时间在warm context退出，measured0，已logout；`.tmp/stage9-r70-main48-http-stage-diagnostic.py/.json/.log/-syntax.log`原样保留，没有改写为成功。

实测结束后再次只读622文件source inventory完全相等，SHA `402024802800938685bfb59983e6d717ae32fa55c555bad0a3ced3f3d8a8e404`；book SHA `17428bc02bfbc2a545041591b5b8134d27e25cbcd09fa159007cae2c95304647`亦不变。回执 `repair1-final-source-guard.json/-fixed-import.log`；首次此单独文件guard缺scripts导入路径的ModuleNotFoundError也保留在`repair1-final-source-guard.log`，它不涉及数据库或实测重跑。运行前后state `[1,2065,1164,152,48238,0]`及完整company/catalog/content发布合同严格一致。

没有启动浏览器/native大组、真实资料、preview服务或新的回归。整理完毕后停止工具。
