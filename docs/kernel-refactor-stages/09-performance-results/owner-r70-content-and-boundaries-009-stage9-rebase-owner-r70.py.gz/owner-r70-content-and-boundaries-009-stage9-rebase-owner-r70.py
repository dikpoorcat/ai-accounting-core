"""Explicit synthetic history copy to the fixed r70 candidate only.

Keep the original constructor's exact old-source contracts, deltas, identities,
report/checkpoint digests, raw row proof and registered target verification.
Never resumes staging, rebuilds business, or handles an existing real root.
"""
import importlib.util
from pathlib import Path

path = Path(__file__).with_name("stage9-rebase-owner-r49.py")
spec = importlib.util.spec_from_file_location("stage9_owner_r70_fixture", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.NEW_TREE = "stage9-build-source-owner-r70-release"
module.NEW_SNAPSHOT = "402024802800938685bfb59983e6d717ae32fa55c555bad0a3ced3f3d8a8e404"
module.RESUMABLE_STAGING = frozenset()

if __name__ == "__main__":
    module.main()
