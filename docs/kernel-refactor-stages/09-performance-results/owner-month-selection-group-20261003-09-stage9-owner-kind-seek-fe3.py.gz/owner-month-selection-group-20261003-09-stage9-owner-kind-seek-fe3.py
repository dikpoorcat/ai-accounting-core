"""Second bounded SQL-only probe; retain original first-round raw files."""
from pathlib import Path

base = Path(__file__).with_name('stage9-exact-scope-sql-fe3.py')
code = base.read_text(encoding='utf-8')
code = code.replace('stage9-exact-scope-sql-fe3.json', 'stage9-owner-kind-seek-fe3.json')
code = code.replace('stage9-exact-scope-sql-fe3.log', 'stage9-owner-kind-seek-fe3.log')
start = code.index("                for name, sql in [")
end = code.index("                require(list(c.execute('SELECT * FROM state", start)
code = code[:start] + '''                for name, sql in [
                    ('owner_pk_single_seek', owner.replace('JOIN subject s ON', 'JOIN subject s INDEXED BY sqlite_autoindex_subject_1 ON')),
                    ('owner_boolean_single_seek', owner.replace('AND s.kind IN(SELECT value FROM json_each(?))', 'AND (s.kind IN(SELECT value FROM json_each(?))) IS TRUE')),
                    ('owner_case_single_seek', owner.replace('AND s.kind IN(SELECT value FROM json_each(?))', 'AND CASE WHEN s.kind IN(SELECT value FROM json_each(?)) THEN 1 ELSE 0 END')),
                ]:
                    alternative = run(name, sql, (month, canonical(kinds)))
                    require(sorted(original) == sorted(alternative), 'Owner exact ID mismatch')
''' + code[end:]
code = code.replace("report['status'] = 'diagnostic_complete'", "report['probe_template_sha256'] = digest(base)\n        report['probe_wrapper_sha256'] = digest(Path(__file__))\n        report['status'] = 'diagnostic_complete'")
exec(compile(code, str(base), 'exec'), globals())
