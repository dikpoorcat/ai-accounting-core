"""Correct observer-retention bias; bounded aggregate counters only."""
from pathlib import Path

previous = Path(__file__).with_name('stage9-r74-preview-lifecycle.py')
source = previous.read_text(encoding='utf8')
replacements = {
    "'.tmp/stage9-r74-preview-lifecycle.json'": "'.tmp/stage9-r74-preview-lifecycle-bounded.json'",
    "args.update(quarter='2016-Q4', source='open')": "args.update(year=2016, quarter=4, preparation='deferred')",
    "assert parsed['company']['company_id'] == cid if 'company_id' in parsed['company'] else parsed['company']['id'] == cid": "assert parsed['read_context']['company_id'] == cid",
    "gc_events = []": "gc_events = {}",
    "first_event = len(gc_events)": "pass  # Aggregate keys are bounded by the 24 read phases.",
    "elapsed = (time.perf_counter() - started) * 1000\n                parsed = json.loads(result)": "elapsed = (time.perf_counter() - started) * 1000\n                read_phase = phase['name']\n                phase['name'] = 'outside_read'\n                pauses = {key: dict(value) for key, value in gc_events.get(read_phase, {}).items()}\n                parsed = json.loads(result)",
    "'gc_events': gc_events[first_event:]": "'gc_aggregates': pauses",
    "'gc_policy': 'unchanged_no_explicit_collection_no_threshold_change', 'reads': []": "'gc_policy': 'unchanged_no_explicit_collection_no_threshold_change',\n       'observer': 'bounded_phase_generation_aggregates_no_per_collection_records', 'reads': []",
}
for old, new in replacements.items():
    assert source.count(old) == 1, old
    source = source.replace(old, new)
old = """gc_events.append({'phase': start[1], 'generation': key,
                              'ms': (time.perf_counter() - start[0]) * 1000,
                              'collected': info['collected'], 'uncollectable': info['uncollectable']})"""
new = """values = gc_events.setdefault(start[1], {}).setdefault(key, {'count': 0, 'total_ms': 0.0, 'max_ms': 0.0, 'collected': 0, 'uncollectable': 0})
            duration = (time.perf_counter() - start[0]) * 1000
            values['count'] += 1
            values['total_ms'] += duration
            values['max_ms'] = max(values['max_ms'], duration)
            values['collected'] += info['collected']
            values['uncollectable'] += info['uncollectable']"""
assert source.count(old) == 1
source = source.replace(old, new)
exec(compile(source, str(previous), 'exec'))
