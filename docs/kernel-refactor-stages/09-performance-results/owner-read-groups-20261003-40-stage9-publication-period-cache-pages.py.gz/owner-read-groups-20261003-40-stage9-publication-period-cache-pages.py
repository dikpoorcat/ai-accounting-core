"""Small real mixed book: observe call order and tuple visits, not elapsed time."""
import json
import os
import runpy
import tempfile
from collections import Counter
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
probe = runpy.run_path(str(ROOT / ".tmp/stage9-publication-period-cache-scope.py"))
CountedRows = probe["CountedRows"]
from stage9_book import MixedBook
from ai_accounting.kernel import query_reads
from ai_accounting.kernel.dashboard import Dashboard

OUTPUT = ROOT / ".tmp/stage9-publication-period-cache-pages-fix1.json"
original = query_reads._verify_current_voucher_publication_rows
prime = query_reads.QueryReads.verify_publication_periods
report = {"status": "started", "scope": "small_actual_mixed_book_call_order_not_timing",
          "pages": {}, "errors": []}
current_page = []
visits = Counter()


def primed(reads, periods):
    periods = set(periods)
    result = prime(reads, periods)
    for period in periods:
        if period in reads._verified_publications and not isinstance(
            reads._verified_publications[period], CountedRows
        ):
            reads._verified_publications[period] = CountedRows(
                reads._verified_publications[period], visits
            )
    return result


def observed(connection, rows):
    reads = query_reads._active_fact_reads.get()
    row_count = len(rows)
    pending = sum(row["id"] not in reads._verified_current_voucher_publications for row in rows)
    periods = {row["period"] for row in rows}
    cached = {str(period): len(reads._verified_publications.get(period, ())) for period in periods}
    before = visits["period_tuple_rows_visited"]
    result = original(connection, rows)
    current_page.append({"requested_current_heads": row_count, "uncached_relationships": pending,
                         "period_cached_rows": cached,
                         "tuple_rows_visited": visits["period_tuple_rows_visited"] - before})
    return result


def main():
    os.environ["STAGE9_WORKSPACE_ROOT"] = str(ROOT)
    with OUTPUT.open("x", encoding="utf-8") as output:
        try:
            with tempfile.TemporaryDirectory(prefix="stage9-pub-pages-", dir=ROOT / ".tmp") as path:
                Path(path).rmdir()  # Builder requires this just-created empty root to be absent.
                book = MixedBook(Path(path), employees=1, businesses=26)
                book.add_month(0, close=True)
                book.add_month(1, close=False)
                dashboard = Dashboard(book.engine, company_name=book.company["name"])
                operations = {
                    "brief": lambda: dashboard.brief("2016-02", limit=20, preparation="deferred"),
                    "funds": lambda: dashboard.funds("2016-02", limit=20, preparation="deferred",
                                                      movement_account_selection="first"),
                    "employees": lambda: dashboard.employees("2016-02", limit=20,
                                                              preparation="deferred"),
                    "assets": lambda: dashboard.assets("2016-02", limit=20, preparation="deferred"),
                    "quarterly_report": lambda: dashboard.quarterly_report(2016, 1,
                                                                          preparation="deferred"),
                }
                with patch.object(query_reads.QueryReads, "verify_publication_periods", primed), \
                        patch.object(query_reads, "_verify_current_voucher_publication_rows", observed):
                    for name, operation in operations.items():
                        current_page.clear()
                        operation()
                        report["pages"][name] = list(current_page)
            report["status"] = "diagnostic_completed"
        except BaseException as exc:
            report["status"] = "failed"
            report["errors"].append({"type": type(exc).__name__, "message": str(exc)})
            raise
        finally:
            json.dump(report, output, ensure_ascii=False, indent=2)
            output.write("\n")
    print(json.dumps({"status": report["status"], "output": str(OUTPUT)}))


if __name__ == "__main__":
    main()
