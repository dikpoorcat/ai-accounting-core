"""Read-only implemented locator work, actual typed month; no native timing."""
import json
import sqlite3
import sys
from pathlib import Path
from types import SimpleNamespace

workspace = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(workspace / 'src'))
from ai_accounting.kernel.dashboard_reads import _payroll_identity_subjects, _payroll_roster_candidates, _payroll_roster_sql
from ai_accounting.kernel.types import YearMonth

profile = json.loads((workspace / '.tmp/stage9-resident-r69-main48-profile.json').read_text('utf-8'))
book = Path(profile['root']) / '91310000123456789S/company.sqlite'
assert book.is_relative_to(workspace / '.tmp')
connection = sqlite3.connect(book.as_uri() + '?mode=ro', uri=True)
connection.row_factory = sqlite3.Row
connection.execute('PRAGMA query_only=ON')
period = '2019-12'
month = YearMonth(period).ordinal
closes = list(connection.execute('SELECT * FROM period_close WHERE period<=?', (month,)))
reads = SimpleNamespace(
    authoritative_close_rows=lambda periods, through_period: [r for r in closes if r['period'] in periods],
    close_header=lambda row: SimpleNamespace(root=json.loads(row['manifest'])),
)
snapshot = SimpleNamespace(connection=connection, month=month, period=period, reads=reads, close=None)
kinds = {'annual_bonus', 'opening_payroll_payable', 'payroll', 'payroll_bounded'}
corrections = _payroll_identity_subjects(snapshot)
actual = max(profile['operations']['employees']['work']['sql'], key=lambda x: x['sqlite_vm_steps'])
full_sql, full_parameters = _payroll_roster_sql(snapshot, kinds, corrections)
assert full_sql == actual['statement']
records = []

class Measured:
    def execute(self, statement, parameters=()):
        list(connection.execute(statement, parameters))
        progress = [0]
        def visited():
            progress[0] += 100
            return 0
        connection.set_progress_handler(visited, 100)
        try:
            rows = list(connection.execute(statement, parameters))
        finally:
            connection.set_progress_handler(None, 0)
        plan = [list(row) for row in connection.execute('EXPLAIN QUERY PLAN ' + statement, parameters)]
        records.append({'statement': statement, 'parameters': parameters, 'vm': progress[0],
                        'rows': len(rows), 'plan': plan})
        print(json.dumps({'name': len(records), 'vm': progress[0], 'rows': len(rows)}), flush=True)
        return rows

baseline = [dict(row) for row in Measured().execute(full_sql, full_parameters)]
baseline_work = records.pop()
snapshot.connection = Measured()
candidates = _payroll_roster_candidates(snapshot, kinds, corrections)
assert candidates is not None
query, parameters = _payroll_roster_sql(snapshot, kinds, corrections, head_subjects=candidates[1])
after = [dict(row) for row in snapshot.connection.execute(query, parameters)]
assert candidates[0] == {row['roster_employee_id'] for row in after if row['roster_employee_id'] is not None}
order = lambda row: json.dumps(row, sort_keys=True, ensure_ascii=False)
assert sorted(map(order, baseline)) == sorted(map(order, after))
out = {
    'scope': 'read_only_fixed_synthetic_implemented_employee_locator_SQL_VM_not_native_or_business_proof',
    'database': str(book), 'period': period, 'ordinal_source': 'YearMonth(period).ordinal',
    'month': month, 'corrections': sorted(corrections),
    'objects': len(candidates[0]), 'subjects': len(candidates[1]),
    'all_fields_equal_as_multiset': True, 'all_fields_order_equal': baseline == after,
    'before_vm': baseline_work['vm'], 'after_vm_all_locator_phases': sum(r['vm'] for r in records),
    'baseline': baseline_work, 'after': records,
}
(workspace / '.tmp/stage9-r69-employee-scope-implemented.json').write_text(json.dumps(out, indent=2, ensure_ascii=False), 'utf-8')
print(json.dumps({k: v for k, v in out.items() if k not in {'baseline', 'after'}}), flush=True)
connection.close()
