"""Read-only private A/B for the complete brief's material/bank worker.

The input is an r32 independently verified synthetic book, read by the fixed
r33 candidate with unchanged schema/content contracts. This is instrumented
diagnosis, not r33 full verification or browser acceptance. The variant is an
in-memory patch of two private Python functions; fixed source and book stay
unchanged. Do not run alongside an exclusive browser measurement.
"""

from __future__ import annotations

import argparse
import hashlib
import inspect
import json
import os
import sys
import textwrap
import time
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _bank_issues(connection, month, reads, *, inspected_ids=None):
    """Exact existing Periods bank guard and two JSON1 selections."""
    from ai_accounting.kernel.stored_json import verify_sql_outcomes

    current_result_ids = {
        row[0]
        for row in connection.execute(
            "SELECT c.id FROM calculation_current a JOIN calculation c "
            "ON c.id=a.calculation_id WHERE c.period=?",
            (month,),
        )
    }
    if inspected_ids is not None:
        inspected_ids.update(current_result_ids)
    if reads is not None:
        reads.verify_sql_outcomes(current_result_ids)
    else:
        verify_sql_outcomes(connection, current_result_ids)
    bank_accounts = {
        row[0]
        for row in connection.execute(
            "SELECT DISTINCT json_extract(b.value,'$.key') FROM calculation_current a "
            "JOIN calculation c ON c.id=a.calculation_id,json_each(c.outcome,'$.balances') b "
            "WHERE c.period=? AND json_extract(b.value,'$.category')='bank'",
            (month,),
        )
    }
    reconciled = {
        row[0]
        for row in connection.execute(
            "SELECT "
            "json_extract(c.outcome,'$.values.bank_account_id') "
            "FROM calculation_current a "
            "JOIN calculation c ON c.id=a.calculation_id WHERE "
            "c.period=? AND c.kind='bank_reconciliation'",
            (month,),
        )
    }
    return [
        {
            "field": "bank_reconciliation",
            "work_area": "bank",
            "bank_account_id": account,
            "message": "银行账户尚未完成对账",
        }
        for account in sorted(bank_accounts - reconciled)
    ]


def _variant_worker(kind, binding, period, as_of, send_pipe=None):
    """Only materials differs; other two workers remain the fixed r33 code."""
    from ai_accounting.kernel import brief_parallel

    if kind != "materials":
        return brief_parallel._worker_read(kind, binding, period, as_of, send_pipe)
    from ai_accounting.kernel.engine import Engine
    from ai_accounting.kernel.materials import (
        _CompletenessInspectionCache,
        read_completeness_summary,
    )
    from ai_accounting.kernel.query_reads import QueryReads
    from ai_accounting.kernel.storage import Store
    from ai_accounting.kernel.types import YearMonth

    path, company_id, database_id, taxpayer_id = binding
    identity_before = brief_parallel._file_identity(path)
    started_wall, started_cpu = time.perf_counter(), time.process_time()
    stages = {}
    try:
        store = Store(
            path, brief_parallel._WORKER_BUNDLE, company_id, database_id,
            taxpayer_id=taxpayer_id, read_pool=brief_parallel._WORKER_POOL,
        )
        engine = Engine(store)
        with QueryReads.snapshot(engine) as reads:
            closed_through = reads.connection.execute(
                "SELECT max(period) FROM period_close"
            ).fetchone()[0]
            wall, cpu = time.perf_counter(), time.process_time()
            materials = read_completeness_summary(
                reads.connection, YearMonth(period).ordinal, store.registry,
                closed_through=closed_through,
                _inspection_cache=_CompletenessInspectionCache(reads.connection),
                _query_reads=reads,
            )
            stages["materials"] = {
                "wall_ms": (time.perf_counter() - wall) * 1000,
                "cpu_ms": (time.process_time() - cpu) * 1000,
            }
            material_ids = set(reads._verified_sql_outcomes)
            all_current_ids = set()
            wall, cpu = time.perf_counter(), time.process_time()
            bank = _bank_issues(
                reads.connection, YearMonth(period).ordinal, reads,
                inspected_ids=all_current_ids,
            )
            stages["bank"] = {
                "wall_ms": (time.perf_counter() - wall) * 1000,
                "cpu_ms": (time.process_time() - cpu) * 1000,
                "current_ids": len(all_current_ids),
                "material_proof_ids": len(material_ids),
                "proof_intersection": len(material_ids & all_current_ids),
                "new_bank_proof_ids": len(all_current_ids - material_ids),
            }
        result = {"ok": True, "value": {"materials": materials, "bank_issues": bank}}
    except Exception as exc:
        result = brief_parallel._error_packet(exc)
    try:
        identity_after = brief_parallel._file_identity(path)
    except OSError:
        identity_after = None
    return {
        **result,
        "identity_before": identity_before,
        "identity_after": identity_after,
        "ab_stages": stages,
        "ab_cpu_ms": (time.process_time() - started_cpu) * 1000,
        "ab_wall_ms": (time.perf_counter() - started_wall) * 1000,
    }


def _measured_worker(kind, binding, period, as_of, send_pipe=None, variant=False):
    """Measure the real worker body, including its SQLite calls and strict JSON."""
    from ai_accounting.kernel import brief_parallel, storage, stored_json
    from ai_accounting.kernel.engine import Engine
    from stage9_metrics import measure_work

    path, company_id, database_id, taxpayer_id = binding
    store = storage.Store(
        path, brief_parallel._WORKER_BUNDLE, company_id, database_id,
        taxpayer_id=taxpayer_id, read_pool=brief_parallel._WORKER_POOL,
    )
    engine = Engine(store)
    original_store = storage.Store
    original_verify = stored_json.verify_outcome_bytes
    strict_ids = Counter()
    strict_bytes = 0

    def counted_verify(raw, expected_digest, ident, **kwargs):
        nonlocal strict_bytes
        decoded = original_verify(raw, expected_digest, ident, **kwargs)
        strict_ids[ident] += 1
        strict_bytes += len(raw.encode("utf-8") if isinstance(raw, str) else raw)
        return decoded

    def operation():
        storage.Store = lambda *args, **kwargs: store
        stored_json.verify_outcome_bytes = counted_verify
        try:
            target = _variant_worker if variant and kind == "materials" else brief_parallel._worker_read
            return target(kind, binding, period, as_of, send_pipe)
        finally:
            stored_json.verify_outcome_bytes = original_verify
            storage.Store = original_store

    started_cpu = time.process_time()
    work, packet = measure_work(engine, operation)
    return {
        **packet,
        "diagnostic_pid": os.getpid(),
        "diagnostic_work": work,
        "strict_cpu_ms": (time.process_time() - started_cpu) * 1000,
        "strict_calls": sum(strict_ids.values()),
        "strict_unique_ids": len(strict_ids),
        "strict_repeat_calls": sum(strict_ids.values()) - len(strict_ids),
        "strict_input_bytes": strict_bytes,
        "strict_id_digest": hashlib.sha256(
            json.dumps(sorted(strict_ids), separators=(",", ":")).encode("utf-8")
        ).hexdigest(),
    }


def _native_variant_worker(kind, binding, period, as_of, send_pipe=None):
    """Uninstrumented material-then-bank body for the warm service A/B."""
    from ai_accounting.kernel import brief_parallel

    if kind != "materials":
        return brief_parallel._worker_read(kind, binding, period, as_of, send_pipe)
    from ai_accounting.kernel.engine import Engine
    from ai_accounting.kernel.materials import (
        _CompletenessInspectionCache,
        read_completeness_summary,
    )
    from ai_accounting.kernel.query_reads import QueryReads
    from ai_accounting.kernel.storage import Store
    from ai_accounting.kernel.types import YearMonth

    path, company_id, database_id, taxpayer_id = binding
    identity_before = brief_parallel._file_identity(path)
    try:
        store = Store(
            path, brief_parallel._WORKER_BUNDLE, company_id, database_id,
            taxpayer_id=taxpayer_id, read_pool=brief_parallel._WORKER_POOL,
        )
        engine = Engine(store)
        with QueryReads.snapshot(engine) as reads:
            closed_through = reads.connection.execute(
                "SELECT max(period) FROM period_close"
            ).fetchone()[0]
            materials = read_completeness_summary(
                reads.connection, YearMonth(period).ordinal, store.registry,
                closed_through=closed_through,
                _inspection_cache=_CompletenessInspectionCache(reads.connection),
                _query_reads=reads,
            )
            bank_issues = _bank_issues(reads.connection, YearMonth(period).ordinal, reads)
        result = {"ok": True, "value": {"materials": materials, "bank_issues": bank_issues}}
    except Exception as exc:
        result = brief_parallel._error_packet(exc)
    try:
        identity_after = brief_parallel._file_identity(path)
    except OSError:
        identity_after = None
    return {
        **result,
        "identity_before": identity_before,
        "identity_after": identity_after,
    }


def _install_variant():
    """Patch only this process's r33 private dispatch and readiness method."""
    from ai_accounting.kernel import brief_parallel, periods

    cls = brief_parallel._BriefParallelAttempt
    original = {
        "period_readiness": periods.Periods.collect_current_readiness,
        "material": cls.material,
        "finish": cls.finish,
        "bank_helper": getattr(periods, "_stage9_private_ab_bank_issues", None),
    }
    source = textwrap.dedent(inspect.getsource(original["period_readiness"]))
    begin = source.index("    from .stored_json import verify_sql_outcomes\n")
    end = source.index("    pending = (\n", begin)
    old = source[begin:end]
    required = (
        "current_result_ids", "bank_accounts", "reconciled",
        "snapshot_issues.append(issue)", "issues.append(issue)",
    )
    if not all(token in old for token in required):
        raise ValueError("r33 bank block changed; private A/B patch refused")
    replacement = (
        "    bank_issues = (\n"
        "        _parallel_checks.bank() if _parallel_checks is not None\n"
        "        else _stage9_private_ab_bank_issues(connection, month, _query_reads)\n"
        "    )\n"
        "    for issue in bank_issues:\n"
        "        snapshot_issues.append(issue)\n"
        "        issues.append(issue)\n"
    )
    namespace = {}
    periods._stage9_private_ab_bank_issues = _bank_issues
    exec(compile(source[:begin] + replacement + source[end:], "<stage9-bank-private-ab>", "exec"),
         periods.__dict__, namespace)
    periods.Periods.collect_current_readiness = namespace["collect_current_readiness"]

    def material(attempt):
        attempt._used.add("materials")
        return attempt._get("materials")["materials"]

    def bank(attempt):
        attempt._used.add("bank")
        return attempt._get("materials")["bank_issues"]

    def finish(attempt):
        if "bank" not in attempt._used:
            raise brief_parallel.ParallelBriefUnavailable("brief did not consume bank result")
        attempt._used.remove("bank")
        try:
            return original["finish"](attempt)
        finally:
            attempt._used.add("bank")

    cls.material = material
    cls.bank = bank
    cls.finish = finish

    def restore():
        periods.Periods.collect_current_readiness = original["period_readiness"]
        cls.material = original["material"]
        cls.finish = original["finish"]
        del cls.bank
        if original["bank_helper"] is None:
            del periods._stage9_private_ab_bank_issues
        else:
            periods._stage9_private_ab_bank_issues = original["bank_helper"]

    return restore


def _comparable(response):
    comparable = {**response, "data": {**response["data"]}}
    comparable["data"].pop("generated_at", None)
    return comparable


def _run_case(root, company_id, period, static_runtime, *, variant, preparation, expect_parallel):
    from ai_accounting.kernel import brief_parallel, stored_json
    from ai_accounting.kernel.dashboard import Dashboard
    from ai_accounting.kernel.service import LocalService
    from ai_accounting.kernel.types import canonical
    from stage9_metrics import measure_work

    service = LocalService(
        root, enable_read_pool=True, enable_parallel_brief=True,
        _static_runtime=static_runtime,
    )
    restore = None
    original_apply_async = None
    submitted = {}
    parent_segments = {}
    originals = {}
    strict_ids = Counter()
    strict_bytes = 0
    original_verify = stored_json.verify_outcome_bytes

    def counted_verify(raw, expected_digest, ident, **kwargs):
        nonlocal strict_bytes
        result = original_verify(raw, expected_digest, ident, **kwargs)
        strict_ids[ident] += 1
        strict_bytes += len(raw.encode("utf-8") if isinstance(raw, str) else raw)
        return result

    try:
        service.brief_parallel.timeout_seconds = 120.0
        engine = service.engine(company_id, dashboard_read=True)
        if variant:
            restore = _install_variant()
        pool = service.brief_parallel.pool
        original_apply_async = pool.apply_async

        def measured_apply_async(function, args=(), kwds=None, callback=None, error_callback=None):
            if function is not brief_parallel._worker_read:
                raise ValueError("Unexpected worker function in private A/B")
            kind = args[0]
            if kind in submitted:
                raise ValueError("Duplicate worker submission in private A/B")
            job = original_apply_async(
                _measured_worker, (*args, variant), kwds or {}, callback, error_callback
            )
            submitted[kind] = job
            return job

        pool.apply_async = measured_apply_async
        cls = brief_parallel._BriefParallelAttempt
        for name in ("material", "duplicates", "report", "position", "finish"):
            original = getattr(cls, name)
            originals[name] = original

            def observed(attempt, _name=name, _original=original):
                wall_started, cpu_started = time.perf_counter(), time.process_time()
                try:
                    return _original(attempt)
                finally:
                    parent_segments[_name] = {
                        "wall_ms": (time.perf_counter() - wall_started) * 1000,
                        "cpu_ms": (time.process_time() - cpu_started) * 1000,
                    }

            setattr(cls, name, observed)
        if variant:
            original = cls.bank
            originals["bank"] = original

            def observed_bank(attempt):
                wall_started, cpu_started = time.perf_counter(), time.process_time()
                try:
                    return original(attempt)
                finally:
                    parent_segments["bank"] = {
                        "wall_ms": (time.perf_counter() - wall_started) * 1000,
                        "cpu_ms": (time.process_time() - cpu_started) * 1000,
                    }

            cls.bank = observed_bank
        stored_json.verify_outcome_bytes = counted_verify
        data = {"period": period, "limit": 100, "preparation": preparation}
        wall, cpu = time.perf_counter(), time.process_time()
        work, response = measure_work(
            engine,
            lambda: service._dashboard_brief(Dashboard(engine), engine, data),
        )
        metrics = {
            "case": "variant" if variant else "baseline",
            "preparation": preparation,
            "response_sha256": hashlib.sha256(
                canonical(_comparable(response)).encode("utf-8")
            ).hexdigest(),
            "response_bytes": len(canonical(response).encode("utf-8")),
            "parent_wall_ms": (time.perf_counter() - wall) * 1000,
            "parent_cpu_ms": (time.process_time() - cpu) * 1000,
            "parent_work": work,
            "parent_strict_calls": sum(strict_ids.values()),
            "parent_strict_unique_ids": len(strict_ids),
            "parent_strict_input_bytes": strict_bytes,
            "parent_segments": parent_segments,
        }
        if expect_parallel and set(submitted) != {"materials", "duplicates", "reports"}:
            raise ValueError("Expected all three formal brief workers")
        if not expect_parallel and submitted:
            raise ValueError("Nonparallel control unexpectedly started workers")
        if submitted:
            metrics["workers"] = {}
            for kind in ("materials", "duplicates", "reports"):
                packet = submitted[kind].get(timeout=30)
                if not packet.get("ok") or "diagnostic_work" not in packet:
                    raise ValueError(f"{kind} worker failed: {packet!r}")
                metrics["workers"][kind] = {
                    "work": packet["diagnostic_work"],
                    "strict_calls": packet["strict_calls"],
                    "strict_unique_ids": packet["strict_unique_ids"],
                    "strict_repeat_calls": packet["strict_repeat_calls"],
                    "strict_input_bytes": packet["strict_input_bytes"],
                    "strict_id_digest": packet["strict_id_digest"],
                    "pid": packet["diagnostic_pid"],
                    "variant_stages": packet.get("ab_stages"),
                }
        return metrics
    finally:
        stored_json.verify_outcome_bytes = original_verify
        for name, original in originals.items():
            setattr(brief_parallel._BriefParallelAttempt, name, original)
        if original_apply_async is not None:
            service.brief_parallel.pool.apply_async = original_apply_async
        if restore is not None:
            restore()
        service.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--book-report", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--preparation", choices=("complete", "deferred"), default="complete")
    parser.add_argument("--closed-period", action="store_true")
    args = parser.parse_args()
    temporary = (ROOT / ".tmp").resolve()
    source, report, output = (
        value.resolve() for value in (args.source, args.book_report, args.output)
    )
    if source != temporary / "stage9-build-source-r33-release":
        parser.error("Only fixed r33 is accepted")
    if not report.is_relative_to(temporary) or not report.name.startswith("stage9-"):
        parser.error("Only a named Stage 9 synthetic report under .tmp is accepted")
    if not output.is_relative_to(temporary) or output.exists():
        parser.error("Choose a new .tmp output path")
    if Path(sys.prefix).resolve() != (ROOT / ".tmp-kernel-venv").resolve():
        parser.error("Use the repository virtual environment")
    book = json.loads(report.read_text(encoding="utf-8"))
    if book.get("status") != "complete":
        parser.error("Book must have completed independent full verification")
    recorded_source = Path(book.get("source", "")).resolve()
    if recorded_source != temporary / "stage9-build-source-r32-release":
        parser.error("This A/B accepts only the explicit r32 verified book")
    old_manifest = json.loads((recorded_source / "source-manifest.json").read_text(encoding="utf-8"))
    new_manifest = json.loads((source / "source-manifest.json").read_text(encoding="utf-8"))
    contracts = (
        "src/ai_accounting/kernel/schema.py",
        "src/ai_accounting/kernel/schema_contracts/catalog/v1.json",
        "src/ai_accounting/kernel/schema_contracts/company/v1.json",
        "src/ai_accounting/kernel/schema_contracts/content-v1.json",
        "src/ai_accounting/kernel/content_v1.py",
    )
    if any(old_manifest["files"][name] != new_manifest["files"][name] for name in contracts):
        parser.error("r32/r33 schema or fixed content contracts differ")
    root = Path(book.get("root", "")).resolve()
    if root.parent != temporary or not root.name.startswith("stage9-"):
        parser.error("Only a named Stage 9 synthetic root under .tmp is accepted")
    months = book.get("months", ())
    if len(months) != book.get("requested_months") or len(months) < 2:
        parser.error("Expected a complete multi-month verified book")
    period = months[-2 if args.closed_period else -1]["period"]

    sys.path.insert(0, str(ROOT / "scripts"))
    from stage9_source import configure_source, require_source_module

    configure_source(source, ROOT)
    import ai_accounting
    from ai_accounting.kernel.daemon import _prepare_static_runtime

    require_source_module(ai_accounting, source, "src/ai_accounting/__init__.py")
    runtime = _prepare_static_runtime()
    baseline = _run_case(
        root, book["company"]["id"], period, runtime,
        variant=False, preparation=args.preparation,
        expect_parallel=args.preparation == "complete" and not args.closed_period,
    )
    changed = _run_case(
        root, book["company"]["id"], period, runtime,
        variant=True, preparation=args.preparation,
        expect_parallel=args.preparation == "complete" and not args.closed_period,
    )
    if baseline["response_sha256"] != changed["response_sha256"]:
        raise ValueError("Complete brief business response differs")
    result = {
        "status": "diagnostic",
        "not_browser_acceptance": True,
        "book_verified_with": str(recorded_source),
        "candidate_read_source": str(source),
        "r33_independent_full_verification": False,
        "book_report": str(report),
        "period": period,
        "closed_period": args.closed_period,
        "preparation": args.preparation,
        "response_equal_excluding": ["data.generated_at"],
        "baseline": baseline,
        "variant": changed,
    }
    with output.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(output)


def native_main():
    """Warm ABBA with no SQL/profile/decoder hooks and production 15s timeout."""
    import datetime

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--book-report", type=Path, action="append", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    temporary = (ROOT / ".tmp").resolve()
    source = args.source.resolve()
    output = args.output.resolve()
    if source != temporary / "stage9-build-source-r33-release":
        parser.error("Only fixed r33 is accepted")
    if not output.is_relative_to(temporary) or output.exists():
        parser.error("Choose a new .tmp output path")
    if Path(sys.prefix).resolve() != (ROOT / ".tmp-kernel-venv").resolve():
        parser.error("Use the repository virtual environment")
    reports = []
    recorded_source = temporary / "stage9-build-source-r32-release"
    old_manifest = json.loads((recorded_source / "source-manifest.json").read_text(encoding="utf-8"))
    new_manifest = json.loads((source / "source-manifest.json").read_text(encoding="utf-8"))
    contracts = (
        "src/ai_accounting/kernel/schema.py",
        "src/ai_accounting/kernel/schema_contracts/catalog/v1.json",
        "src/ai_accounting/kernel/schema_contracts/company/v1.json",
        "src/ai_accounting/kernel/schema_contracts/content-v1.json",
        "src/ai_accounting/kernel/content_v1.py",
    )
    if any(old_manifest["files"][name] != new_manifest["files"][name] for name in contracts):
        parser.error("r32/r33 schema or fixed content contracts differ")
    for requested in args.book_report:
        report_path = requested.resolve()
        if not report_path.is_relative_to(temporary) or not report_path.name.startswith("stage9-"):
            parser.error("Only Stage 9 reports under .tmp are accepted")
        report = json.loads(report_path.read_text(encoding="utf-8"))
        root = Path(report.get("root", "")).resolve()
        if (
            report.get("status") != "complete"
            or Path(report.get("source", "")).resolve() != recorded_source
            or root.parent != temporary
            or len(report.get("months", ())) != report.get("requested_months")
        ):
            parser.error("Expected a complete r32-verified Stage 9 synthetic book")
        reports.append((report_path, report, root))

    sys.path.insert(0, str(ROOT / "scripts"))
    from stage9_source import configure_source, require_source_module

    configure_source(source, ROOT)
    import ai_accounting
    from ai_accounting.kernel import brief_parallel
    from ai_accounting.kernel.daemon import _prepare_static_runtime
    from ai_accounting.kernel.dashboard import Dashboard
    from ai_accounting.kernel.service import LocalService
    from ai_accounting.kernel.types import canonical

    require_source_module(ai_accounting, source, "src/ai_accounting/__init__.py")
    runtime = _prepare_static_runtime()
    results = []
    begun = datetime.datetime.now(datetime.UTC).isoformat()
    for report_path, report, root in reports:
        period = report["months"][-1]["period"]
        company_id = report["company"]["id"]
        baseline = LocalService(
            root, enable_read_pool=True, enable_parallel_brief=True,
            _static_runtime=runtime,
        )
        variant = LocalService(
            root, enable_read_pool=True, enable_parallel_brief=True,
            _static_runtime=runtime,
        )
        try:
            if baseline.brief_parallel.timeout_seconds != 15.0 or variant.brief_parallel.timeout_seconds != 15.0:
                raise ValueError("Expected the unchanged production 15-second timeout")
            entries = []

            def run_arm(which, warmup=False):
                service = baseline if which == "A" else variant
                engine = service.engine(company_id, dashboard_read=True)
                observed = {"submitted": set(), "accepted": False}
                pool = service.brief_parallel.pool
                original_apply_async = pool.apply_async
                attempt_cls = brief_parallel._BriefParallelAttempt
                restore_variant = _install_variant() if which == "B" else None
                original_finish = attempt_cls.finish

                def apply_async(function, args=(), kwds=None, callback=None, error_callback=None):
                    if function is not brief_parallel._worker_read:
                        raise ValueError("Unexpected worker submission")
                    observed["submitted"].add(args[0])
                    target = _native_variant_worker if which == "B" and args[0] == "materials" else function
                    return original_apply_async(target, args, kwds or {}, callback, error_callback)

                def finish(attempt):
                    result = original_finish(attempt)
                    observed["accepted"] = attempt.finished
                    return result

                pool.apply_async = apply_async
                attempt_cls.finish = finish
                data = {"period": period, "limit": 100, "preparation": "complete"}
                started = datetime.datetime.now(datetime.UTC).isoformat()
                wall, cpu = time.perf_counter(), time.process_time()
                try:
                    response = service._dashboard_brief(Dashboard(engine), engine, data)
                finally:
                    elapsed_wall = (time.perf_counter() - wall) * 1000
                    elapsed_cpu = (time.process_time() - cpu) * 1000
                    attempt_cls.finish = original_finish
                    pool.apply_async = original_apply_async
                    if restore_variant is not None:
                        restore_variant()
                if observed["submitted"] != {"materials", "duplicates", "reports"} or not observed["accepted"]:
                    raise ValueError("Formal guarded group was not accepted")
                entry = {
                    "arm": which,
                    "warmup": warmup,
                    "started_utc": started,
                    "wall_ms": elapsed_wall,
                    "parent_cpu_ms": elapsed_cpu,
                    "response_sha256": hashlib.sha256(
                        canonical(_comparable(response)).encode("utf-8")
                    ).hexdigest(),
                    "response_bytes": len(canonical(response).encode("utf-8")),
                    "guard_accepted": observed["accepted"],
                }
                entries.append(entry)

            run_arm("A", warmup=True)
            run_arm("B", warmup=True)
            for arm in ("A", "B", "B", "A"):
                run_arm(arm)
            if len({entry["response_sha256"] for entry in entries}) != 1:
                raise ValueError("Complete brief responses differ across warm ABBA")
            results.append({
                "book_report": str(report_path),
                "period": period,
                "response_equal_excluding": ["data.generated_at"],
                "samples": entries,
            })
        finally:
            variant.close()
            baseline.close()
    result = {
        "status": "diagnostic",
        "not_browser_acceptance": True,
        "source": str(source),
        "book_verified_with": str(recorded_source),
        "r33_independent_full_verification": False,
        "default_timeout_seconds": 15,
        "started_utc": begun,
        "ended_utc": datetime.datetime.now(datetime.UTC).isoformat(),
        "instrumentation": "perf_counter/process_time only; no SQL, JSON, tracemalloc or decoder hooks",
        "books": results,
    }
    with output.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(output)


if __name__ == "__main__":
    if "--native" in sys.argv:
        sys.argv.remove("--native")
        native_main()
    else:
        main()
