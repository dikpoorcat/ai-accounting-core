"""Prepare one grouped regression and source-bound read comparisons."""
import hashlib
import json
from pathlib import Path

W = Path(__file__).resolve().parents[1]
S = W / '.tmp/stage9-build-source-voucher-owner-converged-20261004'
OLD = W / '.tmp/stage9-build-source-frozen-member-guard-20261004'
P = 'stage9-voucher-owner-converged'

def sha(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()

m = json.loads((S / 'source-manifest.json').read_text('utf-8'))
old = json.loads((OLD / 'source-manifest.json').read_text('utf-8'))
assert m['status'] == old['status'] == 'complete'
changed = {name: {'baseline_sha256': value, 'current_sha256': m['files'][name]}
           for name, value in old['files'].items() if value != m['files'].get(name)}
added = {name: value for name, value in m['files'].items() if name not in old['files']}
assert {n for n in changed if n.startswith('src/')} == {
    'src/ai_accounting/kernel/' + name + '.py' for name in (
        'query_reads', 'close_storage', 'business_queries', 'asset_batches',
        'dashboard_funds', 'dashboard_reads', 'dashboard', 'integrity', 'entity_references',
    )
}
assert all(n.startswith(('tests/kernel/', 'src/ai_accounting/kernel/')) for n in changed)
assert len(added) == 4 and all(n.startswith('tests/kernel/') for n in added)
diff = {
    'baseline_source_sha256': old['sha256'], 'current_source_sha256': m['sha256'],
    'baseline_manifest_sha256': sha(OLD / 'source-manifest.json'),
    'current_manifest_sha256': sha(S / 'source-manifest.json'),
    'changed': changed, 'added': added,
    'unchanged_files': len(old['files']) - len(changed),
    'scope': 'fixed converged source; prior c3c3 qualification is input provenance only, '
             'not inherited as new-source browser qualification',
}
with (W / '.tmp' / (P + '-source-diff-20261004.json')).open('x', encoding='utf-8') as f:
    json.dump(diff, f, ensure_ascii=False, indent=2)

for suffix, source, manifest in (
    ('profile', S, m), ('native-current', S, m), ('native-baseline', OLD, old),
):
    template = W / '.tmp' / ('stage9-voucher-header-group-' +
                             ('profile' if suffix == 'profile' else 'native-current') +
                             '-20261004.py')
    content = template.read_text('utf-8')
    content = content.replace('.tmp/stage9-build-source-voucher-header-group-20261004',
                              source.relative_to(W).as_posix())
    content = content.replace('stage9-voucher-header-group-' +
                              ('profile' if suffix == 'profile' else 'native-current') + '-20261004',
                              P + '-' + suffix + '-20261004')
    content = content.replace('e39c5611ad8ce3a73bea4fd9f19de6cca25ba1a3fe0d893f0de78779807384c8',
                              manifest['sha256'])
    content = content.replace('45afd26b6b2bd9fb911e4af41102bb5c6865bf7fa46b0b2b0cb9d971f67810aa',
                              sha(source / 'source-manifest.json'))
    content = content.replace("m['file_count']==769", "m['file_count']==" + str(manifest['file_count']))
    content = content.replace("'source_files':766", "'source_files':m['file_count']")
    content = content.replace('stage9-voucher-header-group-source-diff-20261004',
                              P + '-source-diff-20261004')
    content = content.replace('new frozen-voucher binding and duplicate-read fixes',
                              'converged frozen-head binding, owner reuse and explicit entity type fixes')
    destination = W / '.tmp' / (P + '-' + suffix + '-20261004.py')
    with destination.open('x', encoding='utf-8') as f:
        f.write(content)

template = (W / '.tmp/run-voucher-header-group-20261004.py').read_text('utf-8')
template = template.replace('.tmp/stage9-build-source-voucher-header-group-20261004',
                            S.relative_to(W).as_posix())
template = template.replace('.tmp/stage9-voucher-header-group-regression-20261004',
                            '.tmp/' + P + '-regression-20261004')
template = template.replace("    'test_query_reads',", "    'test_integrity_entity_reference_types',\n"
    "    'test_source_verification_union', 'test_decoded_source_reuse',\n"
    "    'test_entity_reference_entity_only', 'test_business_subject_references',\n"
    "    'test_entity_role_bounded_reads', 'test_identity_native',\n"
    "    'test_identity_corrections', 'test_bank_identity_correction',\n"
    "    'test_foundation_backup', 'test_offline_upgrade_history_preservation',\n"
    "    'test_payroll_confirmation_presentation', 'test_payroll_reserve_payment',\n"
    "    'test_managed_reserve', 'test_accounting_candidate_integrity',\n"
    "    'test_query_reads',")
with (W / '.tmp' / ('run-voucher-owner-converged-20261004.py')).open('x', encoding='utf-8') as f:
    f.write(template)
print(json.dumps({'source_sha256': m['sha256'], 'manifest_sha256': diff['current_manifest_sha256'],
                  'files': m['file_count'], 'changed': list(changed), 'added': list(added)}))
