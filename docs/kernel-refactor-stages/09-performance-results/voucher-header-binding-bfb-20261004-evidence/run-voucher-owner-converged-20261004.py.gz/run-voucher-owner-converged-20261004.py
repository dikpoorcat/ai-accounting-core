"""One fixed-source regression group, never a timing or qualification run."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

W = Path(__file__).resolve().parents[1]
S = W / '.tmp/stage9-build-source-voucher-owner-converged-20261004'
OUT = W / '.tmp/stage9-voucher-owner-converged-regression-20261004'
EXTRA = (
    'test_integrity_entity_reference_types',
    'test_source_verification_union', 'test_decoded_source_reuse',
    'test_entity_reference_entity_only', 'test_business_subject_references',
    'test_entity_role_bounded_reads', 'test_identity_native',
    'test_identity_corrections', 'test_bank_identity_correction',
    'test_foundation_backup', 'test_offline_upgrade_history_preservation',
    'test_payroll_confirmation_presentation', 'test_payroll_reserve_payment',
    'test_managed_reserve', 'test_accounting_candidate_integrity',
    'test_query_reads', 'test_query_metadata_identity',
    'test_funds_summary_page', 'test_funds_source_integrity',
    'test_funds_verified_money_effects', 'test_funds_bounded_reads',
    'test_funds_historical_outcome_reuse', 'test_funds_historical_account_identities',
    'test_report_flow_integrity', 'test_report_flow_classification_scope',
    'test_report_header_reuse', 'test_read_repair_version',
    'test_runtime_backup', 'test_stage9_backup_upgrade_history',
    'test_asset_activation_current_guard', 'test_owner_asset_activation_identity',
    'test_frozen_voucher_header_binding', 'test_asset_owner_outcome_reuse',
    'test_journal_frozen_header_binding',
)


def sha(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def main():
    assert Path(sys.prefix).resolve() == W / '.tmp-kernel-venv'
    assert not any(Path(str(OUT) + suffix).exists() for suffix in ('.json', '.log', '.xml'))
    manifest_path = S / 'source-manifest.json'
    manifest = json.loads(manifest_path.read_text('utf-8'))
    assert manifest['status'] == 'complete'
    sys.path.insert(0, str(S / 'scripts'))
    import snapshot_stage9_source as snapshot
    assert snapshot._inventory(S) == manifest['files'] == snapshot._inventory(W)
    old = ET.parse(W / '.tmp/stage9-frozen-member-guard-group-regression-20261004.xml')
    files = {case.attrib['classname'].replace('.', '/') + '.py'
             for case in old.getroot().iter('testcase')}
    files.update('tests/kernel/' + name + '.py' for name in EXTRA)
    assert all((W / name).is_file() for name in files)
    command = [sys.executable, '-B', '-X', 'utf8', '-m', 'pytest', *sorted(files),
               '-q', '--junitxml=' + str(OUT) + '.xml']
    result = {
        'status': 'started', 'source_sha256': manifest['sha256'],
        'source_manifest_sha256': sha(manifest_path),
        'files': sorted(files), 'command': command,
        'scope': 'affected native readers, five-page projections, current/fixed-v1 history, '
                 'integrity, repair and backup synthetic regressions; no performance claim',
    }
    start = time.perf_counter()
    with Path(str(OUT) + '.log').open('xb') as log:
        run = subprocess.run(command, cwd=W, stdout=log, stderr=subprocess.STDOUT, check=False)
    result['elapsed_seconds'] = time.perf_counter() - start
    result['exit_code'] = run.returncode
    result['source_inventory_unchanged'] = (
        snapshot._inventory(W) == snapshot._inventory(S) == manifest['files']
    )
    for suffix in ('.log', '.xml'):
        path = Path(str(OUT) + suffix)
        if path.is_file():
            result[suffix[1:] + '_sha256'] = sha(path)
    if Path(str(OUT) + '.xml').is_file():
        suites = ET.parse(str(OUT) + '.xml').getroot()
        result['counts'] = {key: sum(int(s.attrib.get(key, 0)) for s in suites.iter('testsuite'))
                            for key in ('tests', 'failures', 'errors', 'skipped')}
    result['status'] = 'passed' if run.returncode == 0 and result['source_inventory_unchanged'] else 'failed'
    Path(str(OUT) + '.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), 'utf-8')
    print(json.dumps(result, ensure_ascii=False), flush=True)
    assert result['status'] == 'passed'


if __name__ == '__main__':
    main()
