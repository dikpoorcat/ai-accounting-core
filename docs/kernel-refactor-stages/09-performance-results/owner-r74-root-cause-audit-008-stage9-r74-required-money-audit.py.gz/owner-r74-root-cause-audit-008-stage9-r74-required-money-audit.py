"""Read-only exact-month SQL/work diagnosis, never acceptance timing."""
import hashlib
import json
from pathlib import Path
import sqlite3
import sys

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / '.tmp/stage9-build-source-owner-r73-release'
EXPECTED = '420ceb395fc5aec17ddaedf8914c7fc8de640da9f08cb35aded8a3a99a4eb7f4'
BOOK = ROOT / '.tmp/stage9-owner-main48-r73-verified.json'
OUT = Path(__file__).with_suffix('.json')
assert not OUT.exists(), 'exclusive output already exists'
book = json.loads(BOOK.read_text(encoding='utf-8'))
assert book['status'] == 'complete'
assert book['integrity']['status'] == 'verified' and not book['integrity']['limitations']
assert Path(book['source']) == SOURCE
assert Path(book['root']) == ROOT / '.tmp/stage9-owner-main48-r63'
assert book['company']['id'] == 'c73e4f4d144340c98ade475b8dd8c8b9'
assert book['company']['database_id'] == '6cc5f6cbe6cd402ebdfd072195398780'
manifest = json.loads((SOURCE / 'source-manifest.json').read_text(encoding='utf-8'))
assert manifest['status'] == 'complete' and manifest['sha256'] == EXPECTED
matched = {}
for name in ('query_reads.py', 'dashboard_reads.py', 'dashboard_funds.py',
             'report_projection.py', 'report_open_contribution.py', 'dashboard.py',
             'reports.py', 'integrity.py', 'publication.py', 'publication_v1.py'):
    relative = 'src/ai_accounting/kernel/' + name
    a, b = (SOURCE / relative).read_bytes(), (ROOT / relative).read_bytes()
    sha = hashlib.sha256(a).hexdigest()
    assert a == b and manifest['files'][relative] == sha
    matched[relative] = sha
sys.path.insert(0, str(SOURCE / 'src'))
from ai_accounting.kernel.query_reads import selected_voucher_sql
from ai_accounting.kernel.types import YearMonth, canonical

profile = json.loads((ROOT / '.tmp/stage9-resident-r73-main48-profile.json').read_text())
connection = sqlite3.connect(Path(book['company']['path']).as_uri() + '?mode=ro', uri=True)
connection.row_factory = sqlite3.Row
connection.execute('PRAGMA query_only=ON')
connection.execute('BEGIN')
result = {'scope': 'read_only_exact_month_sql_plan_vm_diagnostic_not_native_or_browser_acceptance',
          'source_snapshot_sha256': EXPECTED, 'verified_book_report': str(BOOK),
          'book_report_sha256': hashlib.sha256(BOOK.read_bytes()).hexdigest(),
          'root': book['root'], 'source_files_match': matched, 'queries': {}}

def query(name, sql, parameters):
    plan = [list(row) for row in connection.execute('EXPLAIN QUERY PLAN ' + sql, parameters)]
    vm = [0]
    def progress():
        vm[0] += 100
        return 0
    connection.set_progress_handler(progress, 100)
    try:
        rows = connection.execute(sql, parameters).fetchall()
    finally:
        connection.set_progress_handler(None, 0)
    def byte_count(value):
        return len(value.encode('utf-8')) if isinstance(value, str) else len(value) if isinstance(value, bytes) else 8 if value is not None else 0
    result['queries'][name] = {'sql': sql, 'parameters': list(parameters), 'plan': plan,
                             'vm_steps_floor_100': vm[0], 'rows': len(rows),
                             'returned_value_bytes': sum(byte_count(v) for r in rows for v in r)}
    print(json.dumps({'query': name, **{k: v for k, v in result['queries'][name].items()
                                     if k not in ('sql', 'parameters', 'plan')}}), flush=True)
    return rows

try:
    identity = dict(connection.execute('SELECT * FROM identity WHERE id=1').fetchone())
    assert identity['company_id'] == book['company']['id']
    assert identity['database_id'] == book['company']['database_id']
    result['identity'] = identity
    period = YearMonth('2019-12').ordinal
    closed = connection.execute('SELECT max(period) FROM period_close').fetchone()[0]
    assert closed == period - 1
    result['period'] = period
    result['closed_through'] = closed
    # These statements are exact recorded production SQL, with actual synthetic IDs.
    records = profile['operations']['brief']['work']['sql']
    terminal_sql = next(r['statement'] for r in records if r['statement'].startswith('SELECT p.*,a.calculation_id current_id'))
    terminals = query('open_terminal_source_headers', terminal_sql, (period, closed, period))
    active = [r for r in terminals if r['mode'] != 'withdrawn']
    ids = canonical(sorted(r['id'] for r in active))
    head_sql = next(r['statement'] for r in records if r['statement'].startswith('SELECT p.id,p.calculation_id,p.voucher_id,p.posting_period,h.version_id'))
    heads = query('forward_normal_physical_head_lookup', head_sql, (ids,))
    versions = canonical(sorted(r['version_id'] for r in heads if r['version_id'] is not None))
    id_sql = next(r['statement'] for r in records if r['statement'].startswith('SELECT ids.value requested_id,v.id'))
    physical = query('repeat_version_id_header_lookup', id_sql, (versions,))
    result['normal_head_id_equal_physical_id'] = {r['version_id'] for r in heads if r['version_id']} == {r['id'] for r in physical}
    selected, parameters = selected_voucher_sql(YearMonth('2019-12'), posting_period='2019-12', no_close_references=True)
    journal_sql = 'SELECT j.* FROM (' + selected + ') j WHERE 1=1 AND j.period=?'
    rows = query('whole_month_journal_money_selector', journal_sql, (*parameters, period))
    locator = ('SELECT v.id FROM voucher_version v INDEXED BY voucher_period '
               'WHERE v.period=? AND v.period<=? AND EXISTS(SELECT 1 FROM voucher_line l '
               'WHERE l.version_id=v.id AND l.account IN (SELECT value FROM json_each(?)))')
    candidates = query('funds_month_account_candidates', locator,
                       (period, period, canonical(['1001', '1002', '1012', '1101'])))
    result['funds_candidate_count'] = len(candidates)
    result['voucher_kind_counts'] = dict(connection.execute(
        'SELECT c.kind,count(*) FROM voucher_current h JOIN voucher_version v ON v.id=h.version_id '
        'JOIN calculation c ON c.id=v.calculation_id WHERE v.period=? GROUP BY c.kind', (period,)))
    result['terminal_mode_counts'] = {mode: sum(r['mode'] == mode for r in terminals)
                                      for mode in sorted({r['mode'] for r in terminals})}
    result['selector_matches_normal_heads'] = {r['id'] for r in rows} == {r['id'] for r in physical}
    # Plan-only preview of a single physical lookup join; not a new proof or candidate implementation.
    combined = terminal_sql.replace('a.calculation_id current_id,',
        'h.version_id forward_version_id,v.id forward_version_exists,v.voucher_id forward_version_voucher,'
        'v.period forward_version_period,v.reverses_id forward_reverses_id,'
        'v.calculation_id forward_version_calculation,a.calculation_id current_id,').replace(
        'WHERE p.posting_period<=?',
        'LEFT JOIN voucher_current h ON h.voucher_id=p.voucher_id '
        'LEFT JOIN voucher_version v ON v.id=h.version_id WHERE p.posting_period<=?')
    fused = query('diagnostic_combined_terminal_and_normal_heads', combined, (period, closed, period))
    result['combined_physical_headers_equal'] = {
        r['id']: (r['forward_version_id'], r['forward_version_exists'], r['forward_version_voucher'],
                  r['forward_version_period'], r['forward_reverses_id'], r['forward_version_calculation'])
        for r in fused if r['mode'] != 'withdrawn'
    } == {
        r['id']: (r['version_id'], r['version_exists'], r['version_voucher'],
                  r['version_period'], r['reverses_id'], r['version_calculation']) for r in heads
    }
    result['database_mutation'] = False
    result['limitations'] = ['Existing complete verification report checked; not rerun.',
        'Only current open month SQL; no damaged, review, correction, closed or fixed-v1 fixtures executed.',
        'VM is floor quantized by progress callback; bytes count SQLite returned values, not network bytes.',
        'Combined SQL is diagnostic equivalence of physical headers only, not a complete proof implementation.',
        'No native timing, browser timing, new library cache, schema/DDL or source changes.']
    result['status'] = 'passed'
finally:
    connection.rollback()
    connection.close()
    with OUT.open('x', encoding='utf-8') as handle:
        json.dump(result, handle, ensure_ascii=False, indent=2)
