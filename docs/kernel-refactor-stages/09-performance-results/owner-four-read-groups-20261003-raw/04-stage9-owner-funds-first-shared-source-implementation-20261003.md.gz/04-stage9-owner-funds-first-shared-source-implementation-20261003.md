# 首账户资金 source 同次重复构建：实现收口

2026-10-03。root 明确授权的 current default first 窄修复。修改固定为 `src/ai_accounting/kernel/dashboard_funds.py`、新增 `tests/kernel/test_owner_funds_first_shared_source.py`、既有 `tests/kernel/test_funds_first_account.py` 的一个单项。未改 dashboard.py、settlement、通用 `_sql_summary_page`、UI/response/version/合同/DDL 或历史模块。没有真实库、服务、owned main48 页面/profile、五页计时或大组测试。

## 根因与实际改变

4d 原工作诊断 first 首屏先执行 `account_summary()` 全 movements per-account 汇总（245,500 VM），完成真实账户目录后再执行 first page 的 `WITH source_rows AS MATERIALIZED`（230,400 VM）。第二条空 summary 没有重复 per-account GROUP BY，重复的是同一实际 journal/events/effects/money/transfers/source rows。原 event_queries 已共享来源证明与 SQL 文本，因此不增加 body cache 或 proof framework。

支持的 first 请求先运行原 balance_totals/balance_movements，调用提取出的 `_prepare_account_identities` 原样完整验证 state、冻结采用、no-voucher saved input、opening package 和 uncertain opening；同一个既有 `_sql_summary_page` 同时产生原九字段 per-account summary 与首账户页。其过滤子查询从 `summary_rows` 的所有活动账户 keys UNION 已准备的非活动 account_rows keys 按 category/key 排序选择。money 和 transfers 在筛选之前完整构建，全公司 summary 不受筛选影响。原 Python account_rows 更新、checked/None/attribution/negative/statement 状态与最终 sorted selection 仍执行；selected filters、页展示和 cursor seal 原样。

`_can_share_first_page` 只在 first 路径检查：owned active FactReads、snapshot transaction、current close/publication readers、registry 非 v1、无任何 identity_correction。prepared keys 非字符串或不能 UTF-8 编码时不采用组合 SQL。整类 identity correction 保留原 summary -> retired opening omission -> first page：退休条件依赖最终 movement_count/amount，不能提前选。historical v1、不支持上下文保留旧流程，不建立 current token。current closed 无 correction 的首屏可复用同一方案。

原 state/opening/unknown block 提取为同文件私有 helper；非 first 默认仍在原 summary 后调用一次。all、明确账户、movements/其他 section 原一次汇总与需要的 page 不变；summary_only/brief amounts 不进入 first guard。bank/investment source/详情读取继续独立，selected movement 后 prepare_calculation_items 仍完成事实与关系证明。full/close/repair/backup/copy 继续独立完整核验，不消费这张页面 summary 为权威。draft/0、5173 不切换。

## 首次与补测证据

首次：`.tmp/stage9-funds-first-shared-source-first-20261003.log/.xml`，13 collected，11 passed、2 failed，16.64s。失败发生在 fixture 准备：Unicode account ID 被正式 ASCII identifier 合同拒绝；Registry 非 dataclass，不能 dataclasses.replace。未为这些失败改生产行为；改为合法 case/prefix ID 排序和 scoped registry guard 设置。首次记录原样保留。

补测：`.tmp/stage9-funds-first-shared-source-corrected-20261003.log/.xml`，7 passed，10.85s。仅两项修正、新增非 first 四项及获准更新的旧首账户单项；没有重复已通过 11 项。合计 18 个唯一测试通过（新文件 17 + 旧单项 1）；小 Ruff 三文件通过。

已证明：

- 真实 48 个资金发布合成库 first 完整 response 等于原宽 SQL/Python 选择；实际 money source SQL 调用 2 -> 1、该 source 返回行与 VM 减少，完整 result body 加载数不增加；公司总数 48、首账户 filtered count 24，后续末页仍返回 22 行并正确终止。
- 零活动首账户、空 source、ASCII 大小写/前缀排序、unknown opening 保持 None 且保留身份；跨银行 transfer 保持完整双端判定，负支出、退款和 cash 类型仍在公司汇总中；真实闭期结果和下月冲正的 -1000 原收款反向行与 -300 公司净收款不变。
- 整类 identity correction guard 与真实纠错输出回退一致；unowned、v1 context、v1 registry guards 拒绝桥接。v1 用例在此只证明边界，不等于固定历史业务大组已执行。
- 非首账户 bank-b 的原 source 损坏仍拒绝；private arithmetic probe 保持 SQLite integer overflow（不是任意分录或新源认证）。
- all、明确账户、accounts section、brief amounts 四支不进入 first guard；SQL/VM/rows/value bytes/result body 加载与 decode counters 完全不增加。

既有首账户测试原来要求 private account_summary 无参、另有一次 `SELECT NULL unused WHERE 0` helper 调用；这些精确实现形状不再代表产品业务合同。现改为完整 response 与原宽法对照、真实 source 两次到一次/VM下降；原金额、selected account、explicit cursor 与 full-company all 查询断言均保留。

## 下一验证节点及限制

parent 统一组覆盖整个资金 first/filter/summary、state/historical outcome/source proof、identity correction、固定 v1、full/close/repair/backup/copy。此次没有跑这些大组，也没有改 4d 固定源或再次 qualification。18 个合成用例证明消费与边界，不证明主样本毫秒收益或 500ms 达标。

支持 first 的 state proof 提前执行；原两个独立非法条件同时存在时（例如损坏 state 与 SQL overflow），首次异常优先级可能随必要证明阶段前移而变化。各独立非法源仍拒绝，overflow 仍由 SQLite 报错；没有以 Python 大整数运算或未认证 locator 代替原检查。只读根因报告 `.tmp/stage9-owner-funds-first-account-repeated-movements-scope-20261003.md` 及所有 4d raw 证据保留。源码已固定，本代理停止 IO，交统一验证。
