# 清偿主体汇总开放尾段范围：只读 scope（2026-10-03）

## 结论与证据范围

存在真实“先装全部再按主体筛选”：`frozen_subject_summary` 先调用 `_scope`，后者 `_tail_rows` SELECT 所有开放 posting periods 的清偿 payload，并为所有非空 obligation_key 构造 overrides、groups/change-period-counts；随后 `_subject_proof` 才按目标主体提取 source keys/direct events。主体结果不用 scope.groups 或全局 scope.through。原始资料、发布和全期间 seals 的独立验证仍必要，不能把 period 验证范围改成 selected subjects。

已定位既有 `.tmp/stage9-owner-authority-read-groups-work-4d-20261003.json:48664` 的 native assets 条目：`_tail_rows` 1 call，self_profile_ms=104.1847、cumulative_profile_ms=118.6858；同前缀 assets.pstats 是原证据。self 包含 SQLite cursor step，不是纯 Python CPU 或可保证消除的耗时。未新 profile/页面/DB count/EXPLAIN。初始静态排查未测试；随后 root 明确授权独立修复及小合成库定向验证，结果见末节。旧 `read-groups-native-work` / `final-ui-native-work` 是其他 source 的诊断，不能代替该 4d 证据。

下表是修复前工作区行号，保留用于定位根因。静态时与固定 4d 比较：settlement_projection.py 字节一致；settlement_freeze.py 仅 hex 校验 helper 的已授权变动，`_tail_rows` 及后续固定源行号比工作区多 1；dashboard.py 有另组开放 asset owner SQL 收窄，资产 summary 调用未变，仅行号移动。实施后行号因新 helper 移动；只改 settlement_freeze.py 主体读取相关位置及自己的新 tests，保留 root 的 hex 修改。

## 实际消费决定表

| 消费者 | 必须消费的实际范围 | 本轮决定 |
| --- | --- | --- |
| 主体 summary `settlement_freeze.py:1266-1373` | cutoff 前所选主体 source keys 的最终义务、同 keys 的所有期间事件；所选主体 direct events（含空 key /其他 key）；当前 through 从这些状态与直接事件单独算 | 可研究独立主体 scope，仅装这些 payload/state。无需构造全局 groups、change_counts 或无关 key overrides。 |
| `_subject_proof:1147-1218` | 认证 subject_directory、选中 subject leaves/chunks；cutoff 前 source chunks；historical direct≤cutoff/current 所有 direct；source/direct 同月集合必须一致 | 保留存在/缺失、shape/digest、source events missing/mismatch；tail direct rows 不能仅挑 source。 |
| `_key_publications:1221-1263` | selected keys 的 frozen state previous_revision 链、所有 events/calculation digests、tail 对这些 keys 的 publications | include_history_counts=True 保留全选中历史链及 cycle/conflict 检查；不能只核当前 state。 |
| `include_history_counts=False:1324-1352` | 不读历史计数链，但仍对 selected key tail 和 direct events 的所有 publications 做正式来源验证，selected state source/kind/fact/digest 仍验证 | 无 business/movement_count 返回不代表这些 source 验证可省；direct unresolved 仍改变 complete/issues。 |
| followup `:1109-1144` | 所有 first_source_period≤cutoff groups 的 source/paid/other/remaining 与 unknown/unresolved/movement 数，以及 current 全局 through | 不适用 subject 收窄，保持全尾段对所有 relevant key 的覆盖。 |
| employee_net `:1452-1521` | 全局非工资 unknown/unresolved 决定能否安全归属；所有工资 cohort（含非 net 组件）unknown；员工 creditor 归属；period-paid keys | 不能仅 employee/wage subject/key 装尾段。非工资 unknown 时现有 fallback 必须保留；不使用此窄 scope。 |
| payroll period payments `:1376-1395` | 全局 included groups 的 bad_paid/bad_other 决定 fallback，再选工资支付 key | 保持全局前置判断，不能只按当月 changed keys 假设没有累积 unknown。 |
| 开放义务页 `frozen_dashboard_open:1734-1837` / `settlement_dashboard_open` | 全局 categories/count/unknown/status/through，再精确页 keys/after/limit；有 page_keys 也不是全部结果字段仅来自该页 | 不套主体 scope；仅显示页不授权丢全局数量/unknown。此处“open”不是 Reports 的 `read_open_contributions`，后者不走 settlement tail。 |

原路径位置：`_tail_rows:868-917`、`_scope:920-1099`、`_scope` 全尾段分组 `:1035-1086`，tail 第一次为 T 行 SQL→Python dict，所有 touched keys 旧 state 读取/复制/应用 O(T+K)，随后主体 proof 又扫描 T 行。某一主体只命中 Ts 行时，有缩小额外 hydration/reducer 到 Ts+目标 key rows 的空间；全 seals/authentication 仍覆盖 T，不承诺所有 T 相关工作消失。

## 不能丢的行与精确选择逻辑

1. 先认证 `_read_root` 与所选 subject chunks，取得 cutoff 前源 keys。开放段再以 `source_subject_id∈subjects AND change_kind='source' AND posting_period≤cutoff AND obligation_key IS NOT NULL` 补 keys。源 keys 是“曾经来自目标主体”的义务，不能看最终 state.source_subject_id 当前是谁来反推。
2. 在现有完整 period 范围内选 `source_subject_id∈subjects OR obligation_key∈selected_source_keys` 的 payload。所有 change kinds、符号和 resolved/unresolved 状态一律保留，仍按 posting_period/publication.sequence/item_no 的原序处理。合并可用去重 row identity `(publication_id,item_no)`，不能把多条同 key/sign 贡献当重复。
3. 相同 key 的付款可能 `source_subject_id=None`，另一个业务也可能清偿此 key；仅 subject 谓词丢付款。更正/撤去通过 baseline负贡献、新计算正贡献进入投影（`settlement_projection.py:211-257`），不能只取最新 publication、当前有效 calculation 或正金额。负付款/other 更正也必须应用。
4. 当前 cutoff 前所选源 keys 的 later source correction/reassignment 仍改变金额、最新 source metadata、last_change/current_cutoff。later 新建立的所选主体 source key 若 first_source_period>cutoff 不应成为该 cutoff 的义务，但其 direct event 在 current 模式仍参与 through/publication proof。
5. direct events 即使 key=None 或 key 不在 source_keys，仍计 movement、unresolved、publication/through；即使 include_history_counts=False，complete/issues 仍受其影响。未明确支付使 bad_paid/bad_other 累积，不能只挑 resolved。

这与无冻根的现有 SQL reducer独立选择规则一致：`settlement_projection.py:554-601` 选 subject source keys，再按同 keys 或 direct subjects 计算 current through；`:604-645` 对 scoped keys 的全部 contributions 汇总；`:923-945` direct movements/unresolved/业务 publication 也纳入。

## 必须独立保持的范围证明

- `_tail_rows:883-894` 的所有 sequence>冻结 highwater 且 posting_period≤冻结月的晚发布检测不能 subject 收窄：非 review_no_impact 一律拒；所有 late reviews predecessor、实际计算/AccountingBook meaning、涉及期间完整 seals 检查保留。
- `:897-903` posting periods 必须继续来自 calculation_publication、settlement_change、settlement_projection_seal 的 union（current 不加 maximum；historical through=cutoff）；不能由 selected tail rows 或 keys 决定认证范围，否则删除某个 selected key 的唯一行会隐藏晚期缺失。
- `verify_settlement_periods:502-551` 全范围 publication record、全部贡献 source_calculation_id→真实 calculation.digest 存在/匹配，以及 `_read_seals:324-365` 精确原 seal bytes/row_count 必须独立先完成。`_read_seals` 仍在 SQL 对全范围 rows 做 JSON 聚合并hash；本提案只减少随后第二次宽列读取/全局 reducer，不把已有 seal 当未核验的信任值。
- selected states 必须按 authenticated all directory 找到或证明无基线；`_read_states` payload/key/digest、subject source period/count、_verified_page_sources/_verified_event_sources/_verified_publication_sources 全部原样保留。

索引已有 `schema.py:154-157` `(posting_period,obligation_key)`、`(obligation_key,posting_period)`、`(source_subject_id,posting_period)`；selected rows 可使用两支精确范围 UNION/完整 key查询，无需新结构。未跑 EXPLAIN，不能声称 OR 自动用到两支索引或实际扫描已减少。

## 最小公共边界、范围变化与风险

已按 root 决定实施：把 tail 的“完整范围认证”与“payload hydration”拆为 `_tail_periods` / `_read_tail_rows`；仅 `frozen_subject_summary` 显式传 subject_ids 选择独立 `_subject_scope`，先 root/subject source proof+全 period auth，再按两支精确 SQL UNION hydrate direct-subject / exact-key rows、只构建目标 keys overrides/period amounts。UNION 保留每个真实 row identity，并避免两支命中重复应用。若本调用已有成功完整 scope直接取其 superset；不新增 cache/token/结构，也不改历史规则。general `_scope` 无 subject 参数的全局路径保持原算法。

**不能把窄结果写进现有通用 scope/tail maps。** `_scope` maps 按 `(period,current)`、tail map 按 `(base_period,root_digest)`，counterpart 还用 `all(row.posting_period≤cutoff)` 作范围等价证明。有限主体 rows 不证明没有无关未来行，污染后会改变 followup/employee/open 甚至 current/historical复用。只有完整覆盖对象可留在这些位置。

**普通失败集合有一个真实收窄点，需决定。** 当前 general scope 顺带读取所有 tail touched keys 的 frozen base state payload；独立主体 scope 会不再因未选中无关 state payload 损坏而失败。root/header 认证、所有 open period/source/seal损坏仍拒，selected state damage仍拒；未选中冻结状态全集损坏由 full/close/repair/backup保留检查。这符合模块所声明普通读取只hydrate selected states，但不能声称与旧实现所有 incidental failure完全相同。如要求任何 touched state损坏仍 ordinary 拒，就不能省其 payload读取。

生产普通资产入口 `dashboard.py:4460`（当前）传实际 acquisition/acceptance/project-source subjects、include_history_counts=False；员工fallback `:3710` 同主体接口，但 fast employee_net 仍全局。CLI/MCP 走 service 的同 Queries/Reports 入口，不应另加算法。完整核验/关账独立 reconstruct+all blocks/revisions/ref compare 不使用主体 helper；维修写前/写后、backup verifier 同完整路径不减。`settlement_freeze_v1.py` 没有 current `_scope/_tail_rows/frozen_subject_summary`，其历史 require/position独立；不混用当前 helper，历史普通路径保持现有选择。

既有回归依据仅阅读、留 root 统一执行：`test_settlement_freeze.py:209` historical/current对独立SQL输出，`:263` scoped current仍拒无关future period坏seal，`:317` 多冻根+tail，`:351` selectedsubject chunk缺失，`:421` identity重归属/空keydirect/空subject冲正/历史source damage，`:685` unusedref属于full且missingtail仍ordinary拒。

## 本组实施与定向验证

新增 `tests/kernel/test_settlement_subject_tail.py`；10 个唯一 cases 已在定向分轮全部覆盖成功，未重复大组：

- `.tmp/stage9-settlement-subject-tail-first-20261003.xml/.log`：5 passed /31.66s，真实 Company 发布+关账+开放支付+4 无关主体；两种 counts、两种 current、source与付款业务 subjects，每个完整输出同时对照原全局 scope 和独立 SQL reducer。工作量 JUnit property 实际 wide_tail_rows=6→selected=1、override_keys=6→1（减少 5/6=83.33% 此 fixture 的额外 rows/states，不是 VM/CPU/page 时间比例）。选中状态损坏普通/full拒；未选中受 tail 影响的历史状态损坏普通仍正确/full拒；两个场景 repair 后完整核验+普通结果恢复。无关 source digest/seal/缺 contribution 的 current主体读取均拒。
- `.tmp/stage9-settlement-subject-tail-boundaries-first-20261003.xml/.log`：4 passed /23.01s，1 个新 fixture 失败；通过项含 cutoff早于latest关账、多月份/双counts/双current 的独立三方内容一致、已成功 fullscope superset原对象复用，以及晚 review 的 mode/完整金融meaning/periodseal 三种必要拒绝。
- 唯一边界 fixture 首先误用了不存在的 amount_fen（正式字段 source_amount_fen）；修后 `.tmp/stage9-settlement-subject-tail-boundary-fixture-fix-20261003.xml/.log` 保留失败：真实开放源撤去会从 active tranches 移出，结果为空义务而不是零金额义务，原宽scope/独立SQL也都为空。只修这两个测试预期，不改生产或减少内容断言。
- `.tmp/stage9-settlement-subject-tail-boundary-fixture-fix2-20261003.xml/.log`：仅该 case 1 passed /6.85s；实际业务源首次发布24000、更正26000、撤去为空，每次双counts完整输出与两种独立期望一致。
- 小 SQL 语义 fixture 验证同key的 source_subject=None 付款与负冲正、跨subject源更正、unresolved other，以及所选subject keyless/other-key direct rows 全部保留，最终 source_amount=0/paid=0/remaining未知、最新来源owner正确；无关key未装载。这个工作量/选择 fixture不替代真实 period/source/root核验；上述真实 Company 测试承担这些证明。
- Ruff 范围为 settlement_freeze.py 与新 test 文件，通过。无 query_reads/v1/DDL/跨请求 cache 改动。尚无新固定候选 full/group/browser/CPU 结果；由 root 合组后统一回归，不能继承旧组通过数或保证五页时间收益。

### root/block 同快照复核修复

root 指出新 helper 直接 `_read_root` 与 grouped key `_lookup` 未传已有 loader，可能新增重复。新增独立风险 case `test_subject_tail_reuses_authenticated_root_and_selected_blocks`，真实全局 January followup 成功认证 root，再读 February selected summary（不存在 February fullscope）。修复前 `.tmp/stage9-settlement-subject-tail-root-block-before-20261003.xml/.log` 复现失败并保存 JUnit：additional_root_reads=1、selected_block_reads=2、unique_selected_blocks=1；真实金额700000和 limited scope/tail maps 未污染断言均通过。

只在 `_subject_scope` 补同 connection / active snapshot 的原 `_frozen_settlement_roots` 和 `_frozen_settlement_blocks` 读取职责：base/cutoff roots 用成功后入原 root map 的 read_root_once；grouped `_lookup` 用与随后 summary 相同 `(base_period,tuple(header))` block loader。它们均是完整已认证不可变 root/块，不是有限主体 scope或tail结果，没有新全局 proof set。

修复后仅新风险 case 定向复验 `.tmp/stage9-settlement-subject-tail-root-block-fix-20261003.xml/.log`：1 passed /9.78s，additional_root_reads=0、selected_block_reads=1、unique_selected_blocks=1；最终两文件 Ruff 通过。之前10个案例没有机械重复，仍需 root 对当前合组代码统一受影响回归；不能把前版定向通过数当当前组完整资格。
