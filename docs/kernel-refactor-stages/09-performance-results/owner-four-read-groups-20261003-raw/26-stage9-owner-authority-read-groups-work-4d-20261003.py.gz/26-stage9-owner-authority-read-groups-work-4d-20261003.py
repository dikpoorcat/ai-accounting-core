"""Pinned native read diagnostic. No implementation alternatives or proof shortcuts."""
from __future__ import annotations

import argparse
import cProfile
import pstats
from collections import Counter, defaultdict
from contextlib import contextmanager
import functools
import hashlib
import json
from pathlib import Path
import sys
import threading
import time

WORKSPACE = Path(__file__).resolve().parents[1]
SOURCE = WORKSPACE / '.tmp/stage9-build-source-owner-authority-read-groups-fixed-20261003'
SOURCE_SHA = '4d4c2f9bed660d5738ab9a5aea4d704525cb09207578a63679e70793163d11b5'
QUALIFIED = WORKSPACE / '.tmp/stage9-owner-authority-read-groups-main48-20261003-qualified.json'
BOOK = WORKSPACE / '.tmp/stage9-owner-main48-draft-period-group-construction-input.json'
BOOK_SHA = 'a73ded22688073e7aecb7a79d56a6e31d9d6be202e1083738b091d42d3671d93'
ROOT = WORKSPACE / '.tmp/stage9-draft-fixture-main48-20261003'


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--gate', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--qualification-sha256', required=True)
    args = parser.parse_args()
    require(Path(sys.prefix).resolve() == (WORKSPACE / '.tmp-kernel-venv').resolve(), 'Use repository venv')
    output = args.output.resolve()
    gate_path = args.gate.resolve(strict=True)
    require(output.parent == WORKSPACE / '.tmp' and output.name.startswith('stage9-owner-authority-read-groups-work-4d-') and not output.exists(), 'Require new isolated output')
    require(gate_path.parent == WORKSPACE / '.tmp', 'Require isolated root gate')
    qualification_hash = sha(QUALIFIED)
    require(qualification_hash == args.qualification_sha256 == '80b6f8d722cf3afcb9d86ce9e535bbb4cfa0c9f47e466dbe1177ba9851d75973' and sha(BOOK) == BOOK_SHA, 'Pinned qualification/construction drift')
    manifest_path = SOURCE / 'source-manifest.json'
    manifest_hash = sha(manifest_path)
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    qualified = json.loads(QUALIFIED.read_text(encoding='utf-8'))
    company, period = qualified['company'], qualified['verified_open_preview']['period']
    require(manifest['status'] == 'complete' and manifest['sha256'] == SOURCE_SHA and Path(manifest['target']).resolve() == SOURCE, 'Wrong source')
    require(Path(qualified['root']).resolve() == ROOT and qualified['requested_months'] == 48, 'Wrong sample')
    gate_hash = sha(gate_path)
    expected_gate = {'status': '4d_native_workload_and_two_profile_diagnostic_authorized',
                     'source_sha256': SOURCE_SHA, 'source_manifest_sha256': '9c04f6b1e7a9bca3d3acc6ff08d6468ec3cedf5b9d5c00b0e2d910f6ba2dd6c0',
                     'root': str(ROOT), 'output': str(output), 'qualification_sha256': qualification_hash,
                     'script_sha256': sha(__file__), 'construction_input_sha256': BOOK_SHA,
                     'checkpoint_sha256': 'f00aa0cf0a631a961707a6f74345cbdb5f53db2ff90ad60f8c594d03ca7cefbb',
                     'identity': {'company_id': 'c73e4f4d144340c98ade475b8dd8c8b9', 'database_id': '6cc5f6cbe6cd402ebdfd072195398780', 'taxpayer_id': '91310000123456789S'},
                     'state': [1,2065,1164,152,48238,0], 'repair_revision': 0,
                     'scope': 'six_entries_once_warm_once_work_and_funds_assets_once_profile',
                     'native_readonly_calls': 14, 'observer_installed': False, 'max_window_seconds': 240}
    require(json.loads(gate_path.read_text(encoding='utf-8')) == expected_gate, 'Root precise diagnostic gate mismatch')
    require(manifest_hash == expected_gate['source_manifest_sha256'], 'Source manifest guard mismatch')
    sys.path.insert(0, str(SOURCE / 'scripts'))
    import stage9_source
    stage9_source.require_source_module(stage9_source, SOURCE, 'scripts/stage9_source.py')
    stage9_source.configure_source(SOURCE, WORKSPACE)
    import snapshot_stage9_source
    import benchmark_stage9_browser
    from ai_accounting.kernel import catalog, dashboard, engine, resident_reads, schema_bundle, storage
    from ai_accounting.kernel import query_reads, integrity, report_open_contribution, settlement_freeze
    from ai_accounting.kernel import dashboard_owner, close_storage, report_flow
    from ai_accounting.kernel import reports, report_projection, business_queries
    from ai_accounting.kernel.versions import database_format
    from ai_accounting.kernel.read_state import repair_revision
    from ai_accounting.kernel.types import canonical
    modules = {m.__name__.rsplit('.', 1)[-1]: m for m in (catalog, dashboard, engine, resident_reads, schema_bundle, storage, query_reads, integrity, report_open_contribution, settlement_freeze, dashboard_owner, close_storage, report_flow, reports, report_projection, business_queries)}
    for name, module in modules.items():
        stage9_source.require_source_module(module, SOURCE, f'src/ai_accounting/kernel/{name}.py')
    stage9_source.require_source_module(snapshot_stage9_source, SOURCE, 'scripts/snapshot_stage9_source.py')
    stage9_source.require_source_module(benchmark_stage9_browser, SOURCE, 'scripts/benchmark_stage9_browser.py')
    benchmark_stage9_browser.require_report_source(qualified, SOURCE)
    require(benchmark_stage9_browser.validate_book_report(qualified, company_name=company['name']) == period, 'Qualification mismatch')
    checkpoint = ROOT / 'stage9-builder.json'
    checkpoint_hash = sha(checkpoint)
    require(checkpoint_hash == qualified['qualification']['checkpoint_sha256'], 'Checkpoint mismatch')
    expected_state = qualified['verified_open_preview']['state']
    expected_identity = {'company_id': company['id'], 'database_id': company['database_id'], 'taxpayer_id': company['taxpayer_id']}

    require(expected_state == expected_gate['state'] and expected_identity == expected_gate['identity'], 'Exact owned sample mismatch')
    require(checkpoint_hash == expected_gate['checkpoint_sha256'], 'Exact checkpoint mismatch')

    def check_source():
        inventory = snapshot_stage9_source._inventory(SOURCE)
        require(inventory == manifest['files'] and snapshot_stage9_source._digest(inventory) == SOURCE_SHA, 'Source inventory drift')
        require(sha(manifest_path) == manifest_hash and sha(QUALIFIED) == qualification_hash and sha(BOOK) == BOOK_SHA and sha(checkpoint) == checkpoint_hash and sha(gate_path) == gate_hash, 'Guard drift')
    check_source()

    class ReadOnlyCatalog(catalog.Catalog):
        @contextmanager
        def connection(self, *, read_only=False, _cross_thread=False):
            require(read_only, 'No catalog writes')
            with super().connection(read_only=True, _cross_thread=_cross_thread) as c:
                require(c.execute('PRAGMA query_only').fetchone()[0] == 1, 'Catalog is not query_only')
                yield c
        def recover_operations(self):
            with self.connection(read_only=True) as c:
                require(c.execute("SELECT count(*) FROM company_operation WHERE status!='succeeded'").fetchone()[0] == 0, 'No recovery during diagnostic')

    bundle = schema_bundle.production_bundle()
    require(bundle.status == 'draft' and dict(bundle.current_versions) == {'company': 0, 'catalog': 0}, 'Wrong draft factory')
    cat = ReadOnlyCatalog(ROOT, bundle)
    companies = cat.companies()
    require([r for r in companies if r['id'] == company['id']] == [company], 'Catalog company drift')
    with cat.connection(read_only=True) as c:
        catalog_identity = dict(c.execute('SELECT * FROM catalog_identity').fetchone())
    pool = resident_reads.ResidentReadPool(maximum=1)
    store = cat.bind(company['id'], read_pool=pool)
    normal_connection = store.connection
    @contextmanager
    def readonly(*, read_only=False):
        require(read_only, 'No company writes')
        with normal_connection(read_only=True) as c:
            require(c.execute('PRAGMA query_only').fetchone()[0] == 1, 'Company is not query_only')
            yield c
    store.connection = readonly
    core = engine.Engine(store)
    board = dashboard.Dashboard(core, company_name=company['name'], companies=companies)
    year, month = map(int, period.split('-'))
    operations = {'context': board.context,
                  'brief': lambda: board.brief(period, limit=20),
                  'funds': lambda: board.funds(period, limit=20, preparation='deferred', movement_account_selection='first'),
                  'employees': lambda: board.employees(period, limit=20, preparation='deferred'),
                  'assets': lambda: board.assets(period, limit=20, preparation='deferred'),
                  'quarterly_report': lambda: board.quarterly_report(year, (month-1)//3+1, preparation='deferred')}

    def check_state():
        with store.connection(read_only=True) as c:
            c.execute('BEGIN')
            state = list(c.execute('SELECT * FROM state WHERE id=1').fetchone())
            identity = dict(c.execute('SELECT company_id,database_id,taxpayer_id FROM identity WHERE id=1').fetchone())
            require(state == expected_state and identity == expected_identity, 'Company identity/state drift')
            value = {'state': state, 'identity': identity, 'repair_revision': repair_revision(c), 'format': database_format(c, bundle=bundle)}
            require(value['format'] == qualified['integrity_contract'] and value['repair_revision'] == 0, 'Company format/repair drift')
        with cat.connection(read_only=True) as c:
            require(dict(c.execute('SELECT * FROM catalog_identity').fetchone()) == catalog_identity, 'Catalog identity drift')
        require(cat.companies() == companies, 'Catalog registrations drift')
        return value

    def response_hash(result):
        # Only natural response clocks are removed; preserve complete business content.
        result = dict(result)
        for field in ('generated_at', 'checked_at'):
            if field in result:
                result[field] = '<response clock>'
        if isinstance(result.get('data'), dict):
            result['data'] = dict(result['data'])
            if 'generated_at' in result['data']:
                result['data']['generated_at'] = '<response clock>'
        return hashlib.sha256(canonical(result).encode()).hexdigest()

    report = {'status': 'diagnostic_started', 'diagnostic_only': True, 'browser_acceptance': False,
              'source': str(SOURCE), 'source_sha256': SOURCE_SHA, 'source_manifest_sha256': manifest_hash,
              'qualification_guard': {'path': str(QUALIFIED), 'sha256': qualification_hash},
              'qualification_reused_or_created': False, 'qualification_is_original_sample_guard_only': True, 'fresh_current_qualification': True, 'construction_input_sha256': BOOK_SHA,
              'checkpoint_sha256': checkpoint_hash, 'script_sha256': sha(__file__), 'gate_sha256': gate_hash,
              'root': str(ROOT), 'period': period, 'default_page_limit': 20, 'observations': [],
              'runtime_path_memo': {'browser': 'Native Dashboard methods only; no HTTP/auth/serialize or active owner_review_request callback measurement. UI/context/deferred/section/default20 retained.',
                                    'csv_cli_mcp': 'No export/CLI/MCP work executed. Same kernel shared helpers; complete integrity, close, repair, backup and fixed-v1 retain independent paths.',
                                    'qualification': 'New 4d qualification pins existing synthetic sample; diagnostic is separate from pure timing acceptance.'}}
    with output.open('x', encoding='utf-8') as stream:
        try:
            report['before'] = check_state()
            started = time.perf_counter()
            responses = {name: operation() for name, operation in operations.items()}
            report['warmup_responses'] = responses
            baseline = {name: response_hash(result) for name, result in responses.items()}
            sys.path.insert(0, str(SOURCE / 'tests/kernel'))
            import stage9_metrics
            stage9_source.require_source_module(stage9_metrics, SOURCE, 'tests/kernel/stage9_metrics.py')
            for name, operation in operations.items():
                require(time.perf_counter() - started < 230, 'Native workload window exceeded')
                work, result = stage9_metrics.measure_work(core, operation)
                digest = response_hash(result)
                require(digest == baseline[name], f'{name}: complete response drift')
                report['observations'].append({'page': name, 'repeat': 0, 'actual_work': work,
                                               'complete_response_sha256': digest,
                                               'equal_to_uninstrumented_warmup': True})
                print(json.dumps({'status': 'workload_page_complete', 'page': name}), flush=True)
            report['work'] = {'scope': 'one actual instrumented read per six entries; no Observer; not latency acceptance'}
            report['profiles'] = []
            for name in ('funds', 'assets'):
                require(time.perf_counter() - started < 230, 'Profile window exceeded')
                profiler = cProfile.Profile(timer=time.perf_counter)
                result = profiler.runcall(operations[name])
                digest = response_hash(result)
                require(digest == baseline[name], f'{name}: profile response drift')
                profile_path = output.with_name(output.stem + '-' + name + '.pstats')
                require(not profile_path.exists(), 'Preserve first profile')
                profiler.dump_stats(profile_path)
                stats = pstats.Stats(profiler)
                rows = [{'file': key[0], 'line': key[1], 'function': key[2],
                         'primitive_calls': value[0], 'calls': value[1],
                         'self_profile_ms': value[2] * 1000,
                         'cumulative_profile_ms': value[3] * 1000,
                         'callers': [{'file': caller[0], 'line': caller[1], 'function': caller[2],
                                      'stats': list(counts) if isinstance(counts, tuple) else counts}
                                     for caller, counts in value[4].items()]}
                        for key, value in stats.stats.items()]
                report['profiles'].append({'page': name, 'pstats': str(profile_path),
                                           'total_profiled_ms': stats.total_tt * 1000,
                                           'complete_response_sha256': digest,
                                           'functions': rows,
                                           'caveat': 'High-resolution wall profile includes callbacks and concurrent scheduling; not 500ms acceptance or potential savings.'})
                print(json.dumps({'status': 'profile_complete', 'page': name}), flush=True)
            report['after'] = check_state()
            require(report['before'] == report['after'], 'Snapshot state drift')
            check_source()
            report['status'] = 'diagnostic_complete'
        except BaseException as error:
            report.update(status='diagnostic_failed', error_type=type(error).__name__, error=str(error))
            raise
        finally:
            store.connection = normal_connection
            pool.close()
            json.dump(report, stream, ensure_ascii=False, indent=2)
            stream.write('\n')
    print(json.dumps({'status': report['status'], 'output': str(output), 'diagnostic_only': True}))


if __name__ == '__main__':
    main()
