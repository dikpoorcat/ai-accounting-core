# 摘要格式校验：同类排查范围

本轮问题是已认证冻结目录的 64 字符摘要格式检查逐字符进入 Python。4d 主48资产原生诊断只执行一次，`_read_root` 1次、`_validate_directory` 3次对应 all/open/subject 三个必要目录，不是重复根核验；字符生成器146,965次。插桩65.643ms包括 profiler 开销，不是页面可节省的纯时延。

| current位置 | 实际消费及决定 |
| --- | --- |
| settlement_freeze._validate_directory | 普通资金关系/人员/资产/报表/简报及只读CLI/MCP；保留全部目录条目、排序、范围、类型及摘要核验，仅替换逐字符ASCII判断。full、close、repair仍独立重建和比较全部内容。 |
| close_storage.verified_header | 同一格式检查用于preview_digest和derived_roots；保留身份、原始字节SHA、独立封签与采用语义，复用同一窄字符串规则。 |
| period_balance_freeze.read_frozen_balances | 各余额bucket摘要同型；保留精确类别/对象桶、顺序、重复与数量检查，替换字符判断。 |
| business_queries._frozen_asset_owner_discovery | 已采用资产批次membership_digest同型；保留精确拥有者、成员摘要与来源，替换字符判断。 |
| report_classification_directory、close_contract、backup、exports、schema_bundle、security | 64字符摘要已用C正则，或32字符身份；不存在此64次Python字符循环，无需改实现。branch单字符路由、小集合遍历是必要且有界，保留。 |
| *_v1独立读取 | 冻结版本实现不改，不将current性能收益推广到v1。历史语义及保护仍由既有版本测试验证。 |

在既有types集中窄职责的ASCII小写SHA256文本规则。保留isinstance/type原有区别、恰好64字符、拒绝大写/空白/换行/Unicode替代/非法字符；不重新摘要，不增加缓存，不省略未显示目录，不改存储合同/DDL/响应/UI。

修改收敛后验证合法/非法格式的原规则等价及真实目录校验保护，工作量检查统计完整调用边界Python函数调用，限制64倍逐字符调度退化；不匹配某个函数名，不以profiler耗时当500ms验收。五页、full/close/repair/backup、固定历史读取与SQL组统一验证，收益尚未测。
