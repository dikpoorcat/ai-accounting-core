"""Exact owned synthetic root/ref counts and query plans; no page, full verify or timing."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sqlite3
import sys

WORKSPACE = Path(__file__).resolve().parents[1]
SOURCE = WORKSPACE / '.tmp/stage9-build-source-owner-authority-read-groups-fixed-20261003'
ROOT = WORKSPACE / '.tmp/stage9-draft-fixture-main48-20261003'
QUALIFIED = WORKSPACE / '.tmp/stage9-owner-authority-read-groups-main48-20261003-qualified.json'
BOOK = WORKSPACE / '.tmp/stage9-owner-main48-draft-period-group-construction-input.json'
PRIOR = WORKSPACE / '.tmp/stage9-owner-authority-read-groups-work-4d-20261003.json'
PREFIX = WORKSPACE / '.tmp/stage9-owner-asset-open-owner-ranges-4d-20261003'
SOURCE_SHA = '4d4c2f9bed660d5738ab9a5aea4d704525cb09207578a63679e70793163d11b5'
QUALIFIED_SHA = '80b6f8d722cf3afcb9d86ce9e535bbb4cfa0c9f47e466dbe1177ba9851d75973'
MANIFEST_SHA = '9c04f6b1e7a9bca3d3acc6ff08d6468ec3cedf5b9d5c00b0e2d910f6ba2dd6c0'
BOOK_SHA = 'a73ded22688073e7aecb7a79d56a6e31d9d6be202e1083738b091d42d3671d93'
CHECKPOINT_SHA = 'f00aa0cf0a631a961707a6f74345cbdb5f53db2ff90ad60f8c594d03ca7cefbb'
IDENTITY = {'company_id': 'c73e4f4d144340c98ade475b8dd8c8b9',
            'database_id': '6cc5f6cbe6cd402ebdfd072195398780',
            'taxpayer_id': '91310000123456789S'}
STATE = [1, 2065, 1164, 152, 48238, 0]
QUERY = ('SELECT r.ordinal,r.first_key,r.last_key,r.row_count,r.block_digest,'
         'b.digest FROM settlement_freeze_ref r '
         'LEFT JOIN settlement_freeze_block b ON b.digest=r.block_digest '
         'WHERE r.period=? AND r.kind=? ORDER BY r.ordinal')

def require(value, message):
    if not value:
        raise ValueError(message)

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def main():
    require(Path(sys.prefix).resolve() == WORKSPACE / '.tmp-kernel-venv', 'Use repo venv')
    output = PREFIX.with_suffix('.json')
    require(not output.exists(), 'Preserve first diagnostic')
    gate_path = PREFIX.with_suffix('.gate.json')
    expected_gate = {
        'status': 'asset_open_owner_ranges_readonly_authorized',
        'source_sha256': SOURCE_SHA, 'root': str(ROOT),
        'qualification_sha256': QUALIFIED_SHA, 'source_manifest_sha256': MANIFEST_SHA,
        'checkpoint_sha256': CHECKPOINT_SHA, 'construction_input_sha256': BOOK_SHA,
        'identity': IDENTITY, 'state': STATE, 'repair_revision': 0,
        'script_sha256': sha(__file__), 'output_prefix': str(PREFIX),
        'scope': 'three_owner_query_ranges_exact_explain_and_vm_only',
        'native_page_calls': 0, 'profile_calls': 0, 'full_integrity_calls': 0,
    }
    require(json.loads(gate_path.read_text(encoding='utf-8')) == expected_gate, 'Gate mismatch')
    gate_sha = sha(gate_path)
    qualified = json.loads(QUALIFIED.read_text(encoding='utf-8'))
    manifest_path = SOURCE / 'source-manifest.json'
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    prior = json.loads(PRIOR.read_text(encoding='utf-8'))
    require(prior['status'] == 'diagnostic_complete' and prior['source_sha256'] == SOURCE_SHA, 'Prior source mismatch')
    require(Path(qualified['root']).resolve() == ROOT and Path(qualified['source']).resolve() == SOURCE
            and qualified['requested_months'] == 48, 'Wrong qualified root')
    company = qualified['company']
    require(company['id'] == IDENTITY['company_id'] and company['database_id'] == IDENTITY['database_id']
            and company['taxpayer_id'] == IDENTITY['taxpayer_id'], 'Qualified identity mismatch')
    db = ROOT / IDENTITY['taxpayer_id'] / 'company.sqlite'
    require(Path(company['path']).resolve() == db, 'Wrong DB path')
    require(manifest['status'] == 'complete' and manifest['sha256'] == SOURCE_SHA
            and Path(manifest['target']).resolve() == SOURCE, 'Wrong source manifest')
    sys.path.insert(0, str(SOURCE / 'scripts'))
    import stage9_source
    stage9_source.require_source_module(stage9_source, SOURCE, 'scripts/stage9_source.py')
    stage9_source.configure_source(SOURCE, WORKSPACE)
    import snapshot_stage9_source
    from ai_accounting.kernel import close_storage, schema_bundle
    from ai_accounting.kernel.read_state import repair_revision
    from ai_accounting.kernel.types import YearMonth
    from ai_accounting.kernel.versions import database_format
    for module in (close_storage, schema_bundle):
        stage9_source.require_source_module(module, SOURCE, f'src/ai_accounting/kernel/{module.__name__.rsplit(".", 1)[-1]}.py')
    def check_files():
        inventory = snapshot_stage9_source._inventory(SOURCE)
        require(inventory == manifest['files'] and snapshot_stage9_source._digest(inventory) == SOURCE_SHA,
                'Source inventory drift')
        require(sha(QUALIFIED) == QUALIFIED_SHA and sha(manifest_path) == MANIFEST_SHA
                and sha(BOOK) == BOOK_SHA and sha(ROOT / 'stage9-builder.json') == CHECKPOINT_SHA
                and sha(gate_path) == gate_sha, 'Evidence drift')
    check_files()
    bundle = schema_bundle.production_bundle()
    def check_state(connection):
        state = list(connection.execute('SELECT * FROM state WHERE id=1').fetchone())
        identity = dict(connection.execute('SELECT company_id,database_id,taxpayer_id FROM identity WHERE id=1').fetchone())
        require(state == STATE and identity == IDENTITY, 'State/identity drift')
        result = {'state': state, 'identity': identity, 'repair_revision': repair_revision(connection),
                  'format': database_format(connection, bundle=bundle)}
        require(result == prior['after'] and result['format'] == qualified['integrity_contract']
                and result['repair_revision'] == 0, 'Prior format/repair drift')
        return result
    report = {'status': 'started', 'diagnostic_only': True, 'performance_acceptance': False,
              'gate': expected_gate, 'gate_sha256': gate_sha}
    try:
        with sqlite3.connect(db.as_uri() + '?mode=ro', uri=True) as connection:
            connection.row_factory = sqlite3.Row
            connection.execute('PRAGMA query_only=ON')
            require(connection.execute('PRAGMA query_only').fetchone()[0] == 1, 'Readonly guard')
            connection.execute('BEGIN')
            report['before'] = check_state(connection)
            cutoff = YearMonth(qualified['verified_open_preview']['period']).ordinal
            closed = connection.execute('SELECT max(period) FROM period_close WHERE period<=?', (cutoff,)).fetchone()[0]
            require((cutoff, closed) == (24227, 24226), 'Exact qualified tail drift')
            observation = next(row for row in prior['observations'] if row['page'] == 'assets')
            actual_query = next(row['statement'] for row in observation['actual_work']['sql']
                                if row['statement'].startswith('SELECT c.id FROM calculation_publication p JOIN calculation c '))
            require(actual_query.count("c.kind='asset_consumption_month'") == 2, 'Wrong actual query')
            scope = 'p.posting_period<=?' if closed is None else 'p.posting_period>? AND p.posting_period<=?'
            scope_params = (cutoff,) if closed is None else (closed, cutoff)
            range_query = ' UNION '.join(
                'SELECT c.id FROM calculation_publication p JOIN calculation c '
                f'ON c.id=p.{column} WHERE {scope} AND c.kind=\'asset_consumption_month\''
                for column in ('calculation_id', 'baseline_calculation_id'))
            exact_query = ' UNION '.join(
                'SELECT c.id FROM json_each(?) months CROSS JOIN calculation_publication p '
                'INDEXED BY publication_posting ON p.posting_period=months.value '
                f'JOIN calculation c ON c.id=p.{column} WHERE c.kind=\'asset_consumption_month\''
                for column in ('calculation_id', 'baseline_calculation_id'))
            from ai_accounting.kernel.posting_period_reads import posting_periods
            probes = []
            def run(name, sql, parameters):
                steps = 0
                def progress():
                    nonlocal steps
                    steps += 100
                    return 0
                plan = [list(row) for row in connection.execute('EXPLAIN QUERY PLAN ' + sql, parameters)]
                connection.set_progress_handler(progress, 100)
                try:
                    rows = [row[0] for row in connection.execute(sql, parameters)]
                finally:
                    connection.set_progress_handler(None, 0)
                value = {'variant': name, 'query': sql, 'parameters': list(parameters),
                         'plan': plan, 'sqlite_vm_steps_sampled_100': steps,
                         'returned_ids': sorted(rows), 'returned_rows': len(rows)}
                probes.append(value)
                return set(rows)
            expected = run('actual_nullable_tail', actual_query, (cutoff, closed, closed) * 2)
            require(run('direct_known_after_range', range_query, scope_params * 2) == expected,
                    'Direct range owners differ')
            locator_steps = 0
            def locator_progress():
                nonlocal locator_steps
                locator_steps += 100
                return 0
            connection.set_progress_handler(locator_progress, 100)
            try:
                periods = posting_periods(connection, ('calculation_publication',), after=closed, through=cutoff)
            finally:
                connection.set_progress_handler(None, 0)
            periods_json = json.dumps(sorted(periods))
            require(run('exact_posting_months', exact_query, (periods_json,) * 2) == expected,
                    'Exact month owners differ')
            report['scope'] = {'cutoff': cutoff, 'closed': closed, 'actual_periods': sorted(periods),
                               'period_locator_vm_steps_sampled_100': locator_steps}
            report['probes'] = probes
            report['after'] = check_state(connection)
            require(report['before'] == report['after'], 'Snapshot drift')
            connection.rollback()
            connection.execute('BEGIN')
            report['after_fresh_snapshot'] = check_state(connection)
            require(report['before'] == report['after_fresh_snapshot'], 'Fresh snapshot drift')
        check_files()
        report['status'] = 'complete'
    except BaseException as error:
        report.update(status='failed', error_type=type(error).__name__, error=str(error))
        raise
    finally:
        with output.open('x', encoding='utf-8') as stream:
            json.dump(report, stream, ensure_ascii=False, indent=2)
            stream.write('\n')
    print(json.dumps({'status': report['status'], 'scope': report['scope'], 'probes': report['probes']}))

if __name__ == '__main__':
    main()
