import ast
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

root = Path(__file__).resolve().parents[1]
prefix = root / '.tmp/stage9-four-read-groups-regression-20261003'
files = '''test_sha256_format_work.py
test_close_header_batch.py
test_period_balance_freeze.py
test_asset_batch_invariants_review.py
test_asset_batch_reads.py
test_owner_asset_open_owner_ranges.py
test_settlement_subject_tail.py
test_settlement_freeze.py
test_settlement_period_scopes.py
test_settlement_late_reviews.py
test_owner_funds_first_shared_source.py
test_funds_first_account.py
test_funds_summary_page.py
test_funds_source_integrity.py
test_dashboard_projection.py
test_integrity_content.py
test_v1_stored_json_isolation.py
test_settlement_freeze_v1.py'''.splitlines()
nodes = '''test_owner_asset_consumption_identity_scope.py::test_many_activation_owners_keep_full_cards_and_consumption_history
test_owner_asset_consumption_identity_scope.py::test_closed_consumption_directory_remains_required_by_public_detail_and_integrity
test_owner_asset_payment_summary.py::test_asset_dashboard_rejects_removed_payment_collection_and_keeps_ai_read
test_employee_frozen_cohort_reads.py::test_cohorts_preserve_actual_closed_correction_and_complete_public_totals
test_employee_frozen_cohort_reads.py::test_cohort_projection_keeps_fixed_v1_on_the_complete_reader
test_employee_frozen_cohort_reads.py::test_frozen_net_cohorts_include_employee_beyond_default_page
test_employee_frozen_cohort_reads.py::test_mixed_closed_month_locates_only_wage_payment_states_and_rejects_missing_key
test_dashboard_funds_alignment.py::test_account_filter_covers_movements_beyond_the_first_500
test_dashboard_funds_alignment.py::test_movement_filter_requires_matching_account_type_and_identifier
test_dashboard_funds_alignment.py::test_funds_cursor_cannot_cross_filters_sections_or_periods
test_dashboard_funds_alignment.py::test_http_fund_filters_and_cursors_are_company_scoped
test_dashboard_funds_alignment.py::test_owner_funds_defaults_to_twenty_rows_with_full_company_summary
test_funds_historical_account_identities.py::test_public_historical_zero_accounts_match_complete_scope_with_less_source_payload
test_funds_historical_account_identities.py::test_fixed_v1_keeps_complete_historical_source_reader
test_dashboard_reports_adapter.py::test_owner_report_keeps_authoritative_source_integrity_boundaries
test_dashboard_reports_adapter.py::test_closed_owner_report_export_uses_the_exact_preview
test_dashboard_transport.py::test_browser_money_strings_do_not_change_private_cli_and_mcp_results
test_maintenance.py::test_index_repair_restores_missing_close_marker_without_waiving_frozen_roots
test_maintenance.py::test_index_repair_with_missing_marker_still_rejects_damaged_close_root
test_maintenance.py::test_source_damage_cannot_be_repaired_or_disguised
test_runtime_backup.py::test_online_backup_includes_committed_wal_and_is_standalone
test_runtime_backup.py::test_initial_portable_round_trip_and_rollover_are_verified
test_runtime_backup.py::test_portable_creation_rejects_stable_source_damage_and_corrupt_replay
test_runtime_backup.py::test_portable_creation_rejects_tampered_snapshot_and_zip
test_runtime_backup.py::test_foreign_key_corruption_is_detected
test_runtime_backup.py::test_close_manifest_corruption_is_detected
test_offline_upgrade.py::test_nonempty_v1_frozen_adoption_survives_changed_v2_current_model
test_offline_upgrade.py::test_v1_identity_correction_is_verified_after_current_expense_model_changes
test_offline_upgrade.py::test_v1_frozen_opening_and_cumulative_identity_survive_changed_v2_methods_and_helpers'''.splitlines()
selection = ['tests/kernel/' + x for x in files + nodes]
assert len(selection) == len(set(selection))
for node in nodes:
    filename, name = node.split('::')
    tree = ast.parse((root / 'tests/kernel' / filename).read_text(encoding='utf-8'))
    assert any(isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == name
               for n in tree.body), node
for filename in files:
    assert (root / 'tests/kernel' / filename).is_file(), filename
paths = {x.split('::')[0] for x in selection}
hashes = {p: hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sorted(paths)}
command = [sys.executable, '-X', 'utf8', '-m', 'pytest', '-q', *selection,
           '--junitxml=' + str(prefix.with_suffix('.xml'))]
for suffix in ('.xml', '.log', '.json'):
    assert not prefix.with_suffix(suffix).exists(), suffix
started = time.time()
print(json.dumps({'status': 'starting', 'files': len(files), 'nodes': len(nodes),
                  'log': str(prefix.with_suffix('.log'))}), flush=True)
with prefix.with_suffix('.log').open('x', encoding='utf-8') as log:
    child = subprocess.Popen(command, cwd=root, stdout=log, stderr=subprocess.STDOUT)
    print(json.dumps({'child_pid': child.pid}), flush=True)
    result = child.wait()
record = {'started_unix': started, 'elapsed_seconds': time.time()-started,
          'exit_code': result, 'command': command, 'files_before': hashes,
          'files_unchanged': all(hashlib.sha256((root/p).read_bytes()).hexdigest() == h
                                 for p, h in hashes.items())}
prefix.with_suffix('.json').write_text(json.dumps(record, ensure_ascii=False, indent=2)+'\n',
                                     encoding='utf-8')
print(json.dumps({k: v for k, v in record.items() if k not in {'command', 'files_before'}}),
      flush=True)
sys.exit(result)
