# 资金首账户重复 movements：只读 scope

2026-10-03。仅阅读当前代码、既有 4d actual work/profile 与测试。未改生产、未运行新 profile/页面/测试或打开业务数据库。准确类型名是 `FundsRead`，本仓库没有本链的 `FundSource`。

## 已证实触发与重复范围

4d native 脚本入口明确使用 `board.funds(period, limit=20, preparation='deferred', movement_account_selection='first')`。当前 `dashboard_funds.funds` 因 first 不建立 movements page_request，先调用 `read.account_summary()`：

1. 读取/验证完整 closing balance 与当期 balance_movements，建立账户 opening。
2. `events(current=True)` 完整证明所用 publication/voucher/source/frozen adoption/result/close_reference；若已有 request 范围 money headers/body 可消费则使用，否则原 SQL 路。
3. `_verified_money_summary()` 不适用时，`movements()` 创建 journal/events/effects，再从 money 计算每事件 transfers，执行 per-account GROUP BY。真实 top SQL `abaa46...` 为这一完整汇总，245,500 VM。
4. 补完整零活动 state/opening/unknown identities、冻结原来源，计算 closing/unknown/checked 与 retired identities，得到真实 visible account_rows。
5. funds first 从 `sorted(account_rows)` 选首账户，再 `read.movements()`；`_sql_summary_page` 采用 `SELECT NULL unused WHERE 0` 空汇总，仅产生筛选页与全 scope total_count。真实 `f655...` 为此，230,400 VM。

第二次确实重新执行同一资金 source 的 journal/events/effects JSON 展开、money 行号及 transfers 聚合、source_rows 全范围 materialization/count。第二次没有重复 per-account GROUP BY：其 summary 已明确为空。两 SQL 的时长由旧工作诊断约 35/40ms 得到，含插桩，不能作节省承诺。`event_queries` 缓存的是 query/parameters 和成功的 sources proof；不会物化 SQL effects。第二次 `events(current=True)` hit 相同 key，不重新执行第一轮完整 sources proof，所以本问题是物理消费重复，不能再增加同类证明缓存。

## 已共享与必须保留的差别

|入口|现行为|本问题|
|---|---|---|
|公开默认 all 首屏|movements page_request -> account_summary -> 一次 _sql_summary_page：全 per-account summary + page|已经共享，不能再报同一候选|
|指定账户、section=movements、后续 cursor|同上；summary 未筛选，page 在完整 source 后筛选|已经共享；不能让 filter 限制全公司 summary 或 transfer 判定|
|first 首屏|先 summary，真实 visible first 完成后再次物化 page|唯一已证实重复触发|
|accounts/statements/investment section|仍需全公司 money summary，未产生 movements page|没有第二次 movements page|
|brief summary_only/amounts_only|summary 后立即返回；无 page。amounts_only guards 不合格则保留完整 state route|无此重复；不应为本候选加载结果以使 fastpath 合格|
|CLI/MCP/service dashboard_funds|command_schema/service 均分派 Dashboard.funds；默认 selection=all，明确 first 才进入重复|同一个调用边界，无新接口|
|movement_item/业务详情|页确定后 prepare_calculation_items 只加载 selected calculations、relations/facts/展示资料|无法从九字段 summary 重建完整 movement rows/party/detail，原展示来源核验保留|

movements 范围是本月实际 voucher，非所有历史。`events(current=False)` 加 opening_ids、采用 through-period 范围，银行/investment 另有独立来源，不能合并。money 包含 bank/cash/platform 的非零 effects，short_term_investment 不进入此 money；transfer 是全事件多个 category+key 且 sum(amount)=0，并限定三种 transfer kind。必须在账户筛选前判定，不能从单个账户页面推断。reversal 以原 effect sign 产生 signed_amount：公司 inflow/outflow/internal 仍用原 sign 反向修正；movement_count 包括逆向行，不能改成净额或仅 count selected page。

per-account 九字段可完整供 account_summary 消费；全公司 external inflow/outflow/internal/movement_count 来自该 summary，不能改用页小计。opening/closing/unknown/attribution adjustment/retired 状态来自独立余额与身份路线，九字段不够。first 可以是显式建立但本月零流水的账户；未知 opening 仍要保留账户且金额 None；开放期 `_omit_retired_opening_accounts` 检查已证明 opening binding/witness，并依赖最终 movement_count 与金额决定删除。因此不能直接选 summary_rows 的第一个活动账户，也不能先从 page 的第一个 row 选账户。

## 最窄可评估方案

优先复用现有 `_sql_summary_page`，不增加跨 request 缓存、临时业务表、全部 effects/body 重载或通用框架。仅 current first 分支考虑一次 SQL：

1. 让 account_summary 的原 closing/current balance + state/opening/unknown 身份准备先完成，形成非 movement 的候选 account_rows keys；所有原 source/frozen/state/unknown checks 原样执行，不把原文未经证明的 ID 当权威。
2. 调用原 `_sql_summary_page` 的真实 per-account summary；filtered_rows 的 where 可引用已经存在的 `summary_rows` CTE，首账户从 `summary_rows(category,balance_key) UNION prepared account_rows keys`，按原 category/key 排序取一个。这包含零活动账户，不需要改 helper 签名或返回产品结构。返回完整九字段 summaries、所选页与 total/filtered counts。
3. 原 account_summary 完成所有更新、checked/unknown/closing 等；funds 按最终原 Python visible account_rows 设置 filters/selected_movement_account，并核对 SQL 选择一致，后续 seal_collections/cursor/display 原样。
4. 开放期存在 identity_correction 时先保留原两查询。其 retired 条件依赖最终 summary，提前删除会错；若日后要覆盖必须独立证明完整条件，无需为本候选复制该规则进 SQL。current closed 无 omission，本身可评估；historical v1 context/registry.content_version=1 保留原路，不混用 current proof。

当前不能声称“默认资金已产生的 per-account summary 可直接用于第二次 account_summary”：account_summary 先发生，第二 SQL 没有 per-account summary，而且需要真实第一账户才能执行。可行方向是把相同 SQL 的 summary/page 同时产出，并以完整候选目录选择，不能只换调用顺序。

阶段移动风险必须测试：原资金 summary SQL 的 integer overflow 在后面的 state validation 之前；把 state proof 提前可能改变 simultaneous corrupted-state + overflow 时首先返回的错误。所有非法源仍须拒绝，不能把 Python 无界 sum 替代 SQLite error。若要求异常优先级完全不变，此方案尚未证明满足，应保留该组合原路或进一步独立设计。未运行新 probe，未知实际 main48 correction guard 是否合格，收益与最终 SQL plan 均未验证。

## 未来最小必要验证与边界

既有 `test_funds_first_account` 证明 explicit first、零流水首账户、空账户、cursor/API；首个测试绑定了旧空-summary implementation，应改为真实行为和 source 构建次数，不能只换 mock 断言。需比较 first 与 all/显式首账户完整公司 totals/page/selected/cursor；追加跨账户 transfer、reversal、未知 opening、零余额、retired correction fallback、current/closed、非 ASCII key 排序、整数 overflow、非选中源损坏仍拒。以同 actual SQL source 计数/VM 证明两次变一次，不能仅统计 Python account_summary 调用。普通 all/filter/section/brief 不扩大查询/解码；不为资格加载结果。

完整核验、close、repair、backup/copy 并不消费该页面 summary/page 作为权威，继续其独立完整源重建及拒绝路径。v1 content reader 各历史模块仍独立，ordinary Dashboard 可在 historical context 下运行，所以候选必须明确排除该上下文，不能只判断 snap.close。没有修改这些模块或其检查。
