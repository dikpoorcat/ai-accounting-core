# 4d 实际工作量与资产开放期 owner 范围修正

2026-10-03；仅本组 owned 合成 main48，未访问真实资料或服务。一次 native 工作量诊断、funds/assets 各一次 profile、一次范围探针已经收口；没有重跑页面纯计时。此次实现仅修正资产候选 owner 查询的下界表达，不改变凭证、业务规则、响应、DDL 或 v1。

## 固定源与诊断边界

- 源：`.tmp/stage9-build-source-owner-authority-read-groups-fixed-20261003`，SHA `4d4c2f9bed660d5738ab9a5aea4d704525cb09207578a63679e70793163d11b5`；manifest SHA `9c04f6b1e7a9bca3d3acc6ff08d6468ec3cedf5b9d5c00b0e2d910f6ba2dd6c0`。
- qualified SHA `80b6f8d722cf3afcb9d86ce9e535bbb4cfa0c9f47e466dbe1177ba9851d75973`；owned root `.tmp/stage9-draft-fixture-main48-20261003`；book SHA `a73ded22688073e7aecb7a79d56a6e31d9d6be202e1083738b091d42d3671d93`。
- company `c73e4f4d144340c98ade475b8dd8c8b9`、database `6cc5f6cbe6cd402ebdfd072195398780`、state `[1,2065,1164,152,48238,0]`、repair 0、company draft/0；请求 2019-12/24227，最新闭期 2019-11/24226。before/after/fresh source、身份、合同与状态守卫一致。
- native 脚本 `.tmp/stage9-owner-authority-read-groups-work-4d-20261003.py`，SHA `1c017f7f19d95331ad0b58528c4c4acb5c57a4f1d29e77484ef263fc10b8a1a9`。6 入口各 warm 一次、measure_work 一次，funds/assets 各 profile 一次，总 14 次只读 native 调用；无 Observer、全库 SQL trace、preview、完整核验或备份。各 instrumentation/profile 完整业务响应 hash 等于本入口 warm。
- 范围脚本 `.tmp/stage9-owner-asset-open-owner-ranges-4d-20261003.py`，SHA `b0f978c6cbc807eb2a7ed61b36e47d9be80fae35ababd6e49563114539a9df95`。仅三个 exact owner SELECT、其 EXPLAIN 和 posting_periods 定位，不执行页面/profile/full。两组首次 `.gate.json/.json/.log`、funds/assets `.pstats` 和离线 comparison JSON 全部保留。

## 实际工作量与归因

|4d 入口|SQL|VM（100 步采样）|返回行|值字节|stdlib loads|typed facts|result decode|contribution decode|
|---|---:|---:|---:|---:|---:|---:|---:|---:|
|context|4|10,900|96|850|0|0|0|0|
|brief|193|869,700|16,338|7,507,561|1,395|121|1,008|0|
|funds|171|1,438,300|11,372|3,432,830|773|35|542|0|
|employees|98|782,300|6,975|4,227,716|395|0|101|0|
|assets|258|920,600|9,663|6,563,498|1,137|40|197|0|
|quarterly_report|255|948,100|24,869|10,684,375|224|417|3|1,004|

相比 148d，brief/assets 各减少 2 次镜像 ref 查询、1,458 行、219,006 字节；decode 数不变。funds 与 reports 上述工作量不变。context 保持 4 SQL/10,900 VM，不能从 HTTP 等待推断其内核慢。

assets profile 中 `_asset_card_sources` inclusive 218.623ms，settlement summary 241.358ms；`_tail_rows` inclusive 118.686ms/self 104.185ms，包含 Python cursor 迭代等工作，不能把 self 全部解释成结构校验。`_read_root` 仅一次 inclusive 76.112ms；`_validate_directory` 3 次 inclusive 65.643ms，其中旧逐字符 hex generator 146,965 次/self 27.935ms。parent 正处理严格等价 hex 检查，本组不编辑 settlement/types。这些有 profiler callback/并发调度成本，不能作可节省耗时或 500ms 验收。

funds profile 总 373.018ms；account_summary inclusive 213.014ms，events 5 次 inclusive 136.723ms，runtime execute 189 次 self 137.702ms；raw_decode 773 次 self 7.647ms，不能据 loads 数认 JSON 是主要成本。top VM 包括全钱款关系 summary 245,500、首账户页 230,400、银行来源窗口 154,500、月 publication heads 85,800。已有 `_verified_current_event_rows`/money effects/summary 消费路径：本次 profile 函数各耗时极小后进入 SQL fallback；Journal.verified_rows 只取已成功 whole-scope account_amounts 发布的 request cache，native funds 未预先形成该证明。不能再提“增加相同缓存”或直接删除来源核验；若未来改变消费条件，需要同时核对整月真实 lines、采用 headers、所有资金账户及页面选择职责。本组不改 funds，也未测任何该方向收益。

资产 all_items 在分页前承担全部卡片的排序、filter total_count、fixed/intangible/registered 数量与账面/本月金额摘要，20 条展示不是缩窄必要来源证明的依据。原 acquisition/activation 身份、原 posting-close 采用、selected/current member、publication 与余额证明保留。开放 tail 的完整性检查同样保留。

## 已证实的 SQL 范围缺陷及最窄修复

旧资产 open_owners 两 UNION 分支均使用 `posting_period<=? AND (? IS NULL OR posting_period>?)`。已知闭期时 baseline 分支实际 plan 仅 `publication_posting (posting_period<?)`，扫描所有闭期历史再过滤，返回一个 owner 仍花 298,600 VM。

同库同参数范围探针：

|查询|VM|owner 集合|baseline plan|
|---|---:|---|---|
|原 nullable 下界|298,600|完全相同，1 个|仅上界 `posting_period<?`|
|明确已知下界|5,500|完全相同，1 个|`posting_period>? AND posting_period<?`|
|posting_periods + JSON IN exact months|14,400，locator 小于 100|完全相同，1 个|各月 equality|

采用第二项：`dashboard._asset_open_batch_owners(connection, through, after)`。after=None 只保留 `posting_period<=?`；after 已知则真实 `posting_period>? AND posting_period<=?`。两种都 UNION primary calculation_id 与 baseline_calculation_id，仍按 owner.kind 过滤，随后调用原 `reads.asset_members_many(open_owners)`。owner 原核算期可在闭期内：只按采用 publication 的 posting_period 定位，跨月更正、撤去、baseline-only 都保留。不新增索引、period lookup、token 或跨 request 缓存。

同类 current nullable OR 全局排查仅发现该处两个 UNION 分支。period_balances/settlement_freeze/settlement_projection 既有 posting_periods 分别承担源、余额/变化投影及 seal 的独立 orphan 范围证明，不能统一删掉；其他已知下界路径已有明确范围。fixed-v1 不改。

## 调用范围与保护边界

调用链为 `Dashboard.assets -> _assets -> fast_assets -> verify_selected_balances -> max(period_close<=month) -> _asset_open_batch_owners -> reads.asset_members_many`。仅 locator SQL 改写；fast_assets 为空时不进入。assets 列表、filter/section/detail 经该入口时享有同一修正。service 的 dashboard_assets、当前 CLI/MCP command schema 仍分派该入口，不改变产品合同。brief 使用 `_long_term_assets`，funds/employees/reports 各自路径，本次 locator 不参与。

standalone AI asset 查询、full integrity、正式 close、repair、backup/source_copy 各自源及 adopted/member 验证没有改动，也没有从该 locator 得到认证 token。draft/0 不冻结、不切换 5173；current 内容历史 reader 选择仍原样，v1 decoder/module 不改。ordinary 源/root/amount/unknown/reverse/member 完整性职责没有减少，范围集合在 None 和 knownclose 都与原查询等价；区别是 SQL planner 可看到 lower bound。

## 首轮定向结果与后续节点

修改固定为 `src/ai_accounting/kernel/dashboard.py` 与新增 `tests/kernel/test_owner_asset_open_owner_ranges.py`。小 Ruff 两文件通过。首次 pytest `.tmp/stage9-asset-open-owner-range-first-20261003.log/.xml`：6 passed in 7.03s，未重跑。

- 新 3 项：无 close/已知 close 的结果等于原 SQL 与明确业务 owner 集合；跨期替换、撤去、baseline-only、未来 publication 排除；4,000 无关闭期 publication 增长后新 VM 保持有界，原 SQL VM 增长。
- 原真实 engine 测试 3 项：fast balance 与完整 member history 的完整资产响应一致；较早 member 损坏拒绝；owner 原文解码失败拒绝且不发布成功 proof。

这 6 项不等于完整 unknown/current/late 所有业务及 v1 回归已经通过。parent 统一组应包含现有资产 identity/open month/closed correction/unknown summaries/selected source+member damage，以及完整核验、close、repair、backup/copy 和 v1。无需本代理再跑大组。尚未在新源测 native 工作量或页面纯计时；5,500 VM 是同库范围探针，不承诺页面总收益或 500ms 达标。
