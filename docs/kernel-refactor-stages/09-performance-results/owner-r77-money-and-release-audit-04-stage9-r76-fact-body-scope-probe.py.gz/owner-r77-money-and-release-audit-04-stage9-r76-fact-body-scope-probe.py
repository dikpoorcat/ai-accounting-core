from pathlib import Path
import sys,json,hashlib,traceback
w=Path(__file__).resolve().parents[1]; src=w/'.tmp/stage9-build-source-owner-r76-release'
sys.path.insert(0,str(src/'scripts'))
from stage9_source import configure_source
configure_source(src,w)
from ai_accounting.kernel.catalog import Catalog
from ai_accounting.kernel.dashboard import Dashboard
from ai_accounting.kernel.engine import Engine
from ai_accounting.kernel.resident_reads import ResidentReadPool
from ai_accounting.kernel import query_reads,storage,integrity
import stage9_metrics as metrics
book=json.loads((w/'.tmp/stage9-owner-main12-r76-verified.json').read_text('utf-8'))
assert book['status']=='complete' and book['integrity']['status']=='verified' and not book['integrity']['limitations']
root=Path(book['root']); assert root==w/'.tmp/stage9-owner-main12-r43'
assert Path(book['source'])==src
pool=ResidentReadPool();catalog=Catalog(root)
with catalog.connection(read_only=True) as c: row=dict(c.execute('SELECT * FROM company WHERE id=?',(book['company']['id'],)).fetchone())
store=catalog._bound_store(row,read_pool=pool);engine=Engine(store);dash=Dashboard(engine,company_name=row['name'],companies=[row])
load=json.loads; out={'scope':'fixed_r76_main12_single_native_each_page_instrumented_not_acceptance','source':str(src),'root':str(root),'prior_verification_source':book['source'],'verified_input_sha256':hashlib.sha256((w/'.tmp/stage9-owner-main12-r76-verified.json').read_bytes()).hexdigest(),'loaded_modules':{},'operations':{}}
for m in [query_reads,storage,integrity]:out['loaded_modules'][m.__name__]={'file':m.__file__,'sha256':hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest()}
originals=[];state={};active=[];allstages=[];sqls=[];page=None
def patch(obj,name,fn):originals.append((obj,name,getattr(obj,name)));setattr(obj,name,fn)
def caller():return [f'{Path(x.filename).name}:{x.lineno}:{x.name}' for x in traceback.extract_stack(limit=9)[:-2]]
body=query_reads.QueryReads._verify_selected_fact_bodies
def wrapped_body(reads,headers):
 headers=tuple(headers);token=id(reads);prior=state.setdefault(token,{})
 bindings={h['fact_id']:(h['fact_kind'],h['fact_period'],h['fact_digest'].hex()) for h in headers}
 repeated={i for i,b in bindings.items() if prior.get(i)==b}
 ev={'snapshot_token':token,'caller':caller(),'headers':[{'calculation_id':h['id'],'fact_id':h['fact_id'],'kind':h['fact_kind'],'period':h['fact_period'],'digest':h['fact_digest'].hex()} for h in headers],'distinct_facts':len(bindings),'same_binding_prior_helper_success_ids':sorted(repeated),'same_id_different_binding_ids':sorted(i for i,b in bindings.items() if i in prior and prior[i]!=b),'stages':[],'sql':[],'success':False}
 out['operations'][page]['body_batches'].append(ev);active.append(ev)
 try:
  result=body(reads,headers);ev['success']=True;prior.update(bindings);return result
 except BaseException as e:ev['error']={'type':type(e).__name__,'message':str(e)};raise
 finally:active.pop()
patch(query_reads.QueryReads,'_verify_selected_fact_bodies',wrapped_body)
for module,name in [(integrity,'verify_fact_child_order'),(storage,'_scalar_fact_hashes'),(storage,'_snapshot_fact_hashes')]:
 original=getattr(module,name)
 def make(original,name):
  def wrapper(*args,**kwargs):
   request=args[2];ids=sorted(set().union(*request.values())) if isinstance(request,dict) else sorted(set(request))
   e={'name':name,'input_ids':ids,'caller':caller(),'success':False};allstages.append(e)
   if active:active[-1]['stages'].append(e)
   try:
    result=original(*args,**kwargs);e['success']=True
    if isinstance(result,dict):e['returned_ids']=sorted(result)
    return result
   except BaseException as err:e['error']={'type':type(err).__name__,'message':str(err)};raise
  return wrapper
 patch(module,name,make(original,name))
execute=metrics._Connection.execute
rowfn=metrics._Cursor._row
def wrapped_execute(conn,statement,parameters=()):
 cursor=execute(conn,statement,parameters)
 if active:
  ids=[]
  for value in parameters:
   if isinstance(value,str) and value.startswith('['):
    try:
     vals=load(value)
     if isinstance(vals,list) and all(isinstance(x,str) for x in vals):ids.extend(vals)
    except ValueError:pass
  repeat=set(active[-1]['same_binding_prior_helper_success_ids'])
  event={'statement':' '.join(statement.split()),'input_ids':sorted(set(ids)),'repeat_input_ids':sorted(set(ids)&repeat),'returned_rows':0,'returned_value_bytes':0,'repeat_returned_rows':0,'repeat_returned_value_bytes':0,'vm_steps_at_execute_start':conn.counts['sqlite_vm_steps']}
  active[-1]['sql'].append(event);cursor._probe_event=event;cursor._probe_repeat=repeat;cursor._probe_conn=conn
 return cursor
def wrapped_row(cursor,row):
 result=rowfn(cursor,row)
 e=getattr(cursor,'_probe_event',None)
 if e is not None:
  e['vm_steps_through_last_fetch']=cursor._probe_conn.counts['sqlite_vm_steps']-e['vm_steps_at_execute_start']
  if row is not None:
   size=sum(metrics._value_bytes(x) for x in row);e['returned_rows']+=1;e['returned_value_bytes']+=size
   if row[0] in cursor._probe_repeat:e['repeat_returned_rows']+=1;e['repeat_returned_value_bytes']+=size
 return result
patch(metrics._Connection,'execute',wrapped_execute);patch(metrics._Cursor,'_row',wrapped_row)
operations={'brief':lambda:dash.brief('2016-12',limit=20),'funds':lambda:dash.funds('2016-12',limit=20),'employees':lambda:dash.employees('2016-12',limit=20),'assets':lambda:dash.assets('2016-12',limit=20),'reports':lambda:dash.quarterly_report(2016,4,preparation='deferred')}
try:
 for page,call in operations.items():
  state.clear();allstages=[];out['operations'][page]={'body_batches':[]}
  try:
   work,result=metrics.measure_work(engine,call);out['operations'][page].update({'status':'success','work':work,'response_schema_version':result.get('schema_version')})
  except BaseException as e:out['operations'][page].update({'status':'failed','error':{'type':type(e).__name__,'message':str(e)},'traceback':traceback.format_exc()})
  out['operations'][page]['all_fact_stages']=allstages
  print(json.dumps({'page':page,'status':out['operations'][page]['status'],'body_batches':len(out['operations'][page]['body_batches']),'repeated_fact_checks':sum(len(x['same_binding_prior_helper_success_ids']) for x in out['operations'][page]['body_batches'])}),flush=True)
finally:
 for obj,name,original in reversed(originals):setattr(obj,name,original)
 pool.close();out['cleanup']='wrappers_restored_read_pool_closed'
 with (w/'.tmp/stage9-r76-fact-body-scope-probe.json').open('x',encoding='utf-8') as f:json.dump(out,f,ensure_ascii=False,indent=2)
