# r36 reseed 只读复核

范围：`scripts/reseed_stage9_book.py`、`tests/kernel/test_reseed_stage9_book.py`、`scripts/stage9_verified_open_preview.py`；未执行测试或复制。r35 的失败 staging 与原始库保持不动。

- `Store.create` 初始行的五表分类与实际新建公司一致：`identity/schema_meta/schema_history` 由目标保留，其中 identity 与源核对；`state/source_change_head` 先核对精确默认值，再在一个目标事务中更新为源全列。任何其他初始非空表拒绝。原 r35 主键冲突已由这一分支覆盖。
- 公司表清单、可插入列、DDL 原文只容许两项指定新索引。每个非元数据表的源/目标行数及含 rowid、存储生成列、SQLite 值类型的摘要逐一相等；目标外键、SQLite 完整性、恢复后的 trigger 和结构再检查。失败时回滚目标事务；真实 Store 测试在 journal 头已更新后注入故障，检查整表回滚。
- 指定源公司仅以只读连接及事务读取；目录和公司结构、身份、checkpoint epochs、已关账摘要、任务及批准路径均有门禁。目标先在新 staging 建库，完成登记的版本内容完整核验与实际开放月 preview，核对无 limitations 后才写 finished/report 并同父目录 rename 发布；已有目标或 staging 均拒绝覆盖。
- 未发现会必然阻断 r36 main12/main48 复制的新增静态缺陷。限制：新增真实测试只直接覆盖 `_copy_rows`，未模拟整个 `reseed()` 的目录绑定、完整核验和发布；这些由即将运行的固定 r36 12/48 实际 reseed 验证。源读事务保护行复制快照，但对外部进程在事务结束后继续修改原合成库或报告并无锁定承诺；本次命名源应保持静止。
