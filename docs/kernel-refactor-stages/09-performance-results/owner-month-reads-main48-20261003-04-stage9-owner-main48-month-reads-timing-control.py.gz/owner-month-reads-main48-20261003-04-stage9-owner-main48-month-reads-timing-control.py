"""Gate one pinned browser run; suspend only the explicitly owned independent120 copy."""
import ctypes
from ctypes import wintypes
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

WORKSPACE = Path(__file__).resolve().parents[1]
SOURCE = WORKSPACE / '.tmp/stage9-build-source-owner-month-reads-20261003-release'
PREFIX = WORKSPACE / '.tmp/stage9-owner-main48-month-reads'
READY = Path(str(PREFIX) + '-timing-ready.json')
START = Path(str(PREFIX) + '-timing-start.json')
REPORT = Path(str(PREFIX) + '-browser.json')
CONTROL = Path(str(PREFIX) + '-timing-control.json')
COPY_TARGET = WORKSPACE / '.tmp/stage9-independent120-month-reads-candidate-20261003'
BROWSER_PID, BROWSER_PARENT = 23192, 55504
COPY_PID, COPY_PARENT = 52844, 32836
DEMO_PID = 48684
WAIT_OBJECT_0, WAIT_TIMEOUT = 0, 258
QUERY_SYNCHRONIZE = 0x0400 | 0x00100000
SUSPEND_RESUME = 0x0800


def require(value, message):
    if not value:
        raise RuntimeError(message)


def process_snapshot():
    command = 'Get-CimInstance Win32_Process | Select-Object ProcessId,ParentProcessId,CommandLine,CreationDate | ConvertTo-Json -Compress'
    result = subprocess.run(['powershell', '-NoProfile', '-Command', command],
                            capture_output=True, text=True, check=True)
    rows = json.loads(result.stdout) if result.stdout.strip() else []
    return rows if isinstance(rows, list) else [rows]


def row_for(rows, pid):
    return next((row for row in rows if row['ProcessId'] == pid), None)


def arguments(command):
    count = ctypes.c_int()
    shell = ctypes.WinDLL('shell32', use_last_error=True)
    shell.CommandLineToArgvW.argtypes = [wintypes.LPCWSTR, ctypes.POINTER(ctypes.c_int)]
    shell.CommandLineToArgvW.restype = ctypes.POINTER(wintypes.LPWSTR)
    memory = shell.CommandLineToArgvW(command, ctypes.byref(count))
    require(bool(memory), 'Cannot parse process command line')
    try:
        return [memory[i] for i in range(count.value)]
    finally:
        kernel.LocalFree.argtypes = [ctypes.c_void_p]
        kernel.LocalFree.restype = ctypes.c_void_p
        kernel.LocalFree(memory)


def option(args, name):
    if name in args:
        index = args.index(name)
        require(args.count(name) == 1 and index + 1 < len(args), 'Ambiguous process option')
        return args[index + 1]
    values = [arg[len(name)+1:] for arg in args if arg.startswith(name + '=')]
    require(len(values) == 1, 'Required process option missing or repeated')
    return values[0]


def absolute(value):
    selected = Path(value)
    return (selected if selected.is_absolute() else WORKSPACE / selected).resolve()


def validate_browser(row):
    require(row is not None and row['ParentProcessId'] == BROWSER_PARENT, 'Unexpected browser PID/parent')
    args = arguments(row['CommandLine'])
    require(any(absolute(arg) == WORKSPACE / 'scripts/benchmark_stage9_browser.py'
                for arg in args[1:] if not arg.startswith('-')), 'Unexpected browser script')
    for name, path in [('--source', SOURCE), ('--output', REPORT),
                       ('--timing-ready-file', READY), ('--timing-start-file', START)]:
        require(absolute(option(args, name)) == path, 'Unexpected browser source/output/gate binding')
    return row


def validate_copy(row):
    if row is None:
        return None
    require(row['ParentProcessId'] == COPY_PARENT, 'Copy PID has unexpected parent; do not touch it')
    args = arguments(row['CommandLine'])
    require(any(absolute(arg) == WORKSPACE / '.tmp/stage9-prepare-independent-month-reads.py'
                for arg in args[1:] if not arg.startswith('-')), 'Copy PID has unexpected script; do not touch it')
    require(option(args, '--case') == 'independent120'
            and absolute(option(args, '--target-root')) == COPY_TARGET,
            'Copy PID has unexpected synthetic case/target; do not touch it')
    return row


def confirm_no_owned_cpu_jobs(rows):
    blocked = []
    for row in rows:
        if row['ProcessId'] in {BROWSER_PID, COPY_PID, DEMO_PID, os_pid}:
            continue
        command = (row.get('CommandLine') or '').replace('\\', '/').lower()
        # Only our explicit accounting test/diagnostic families, not unrelated
        # system processes or all-process zero-CPU requirements.
        owned = str(WORKSPACE).replace('\\', '/').lower() in command or '.tmp/stage9-' in command
        compute = ' -m pytest' in command or 'release-core-group.py' in command or (
            'stage9-' in command and any(term in command for term in
            ('native-work.py', 'decoder-probe', 'dispatch-profile', 'dispatch-gc', '-prototype.py', '-probe.py')))
        if owned and compute:
            blocked.append({'pid': row['ProcessId'], 'parent_pid': row['ParentProcessId']})
    require(not blocked, 'Owned test/decoder/native/prototype job still active: ' + json.dumps(blocked))
    core = json.loads((WORKSPACE / '.tmp/stage9-month-reads-release-core-group.json').read_text(encoding='utf-8'))
    native = json.loads((WORKSPACE / '.tmp/stage9-owner-main12-month-reads-native-work.json').read_text(encoding='utf-8'))
    require(core['status'] == 'passed' and core['pid'] == 54748 and core['exitcode'] == 0
            and core['source_inventory_equal'] is True, 'Core group has not finished successfully')
    require(native['status'] == 'diagnostic_complete', 'Main12 native diagnostic has not finished')
    return {'core': {'pid': core['pid'], 'status': core['status'], 'counts': core['counts']},
            'main12_native_status': native['status'], 'owned_active_compute_jobs': blocked}


kernel = ctypes.WinDLL('kernel32', use_last_error=True)
nt = ctypes.WinDLL('ntdll')
kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
kernel.OpenProcess.restype = wintypes.HANDLE
kernel.CloseHandle.argtypes = [wintypes.HANDLE]
kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
kernel.WaitForSingleObject.restype = wintypes.DWORD
nt.NtSuspendProcess.argtypes = [wintypes.HANDLE]
nt.NtSuspendProcess.restype = ctypes.c_long
nt.NtResumeProcess.argtypes = [wintypes.HANDLE]
nt.NtResumeProcess.restype = ctypes.c_long


class FILETIME(ctypes.Structure):
    _fields_ = [('low', wintypes.DWORD), ('high', wintypes.DWORD)]


kernel.GetProcessTimes.argtypes = [wintypes.HANDLE, *([ctypes.POINTER(FILETIME)] * 4)]
kernel.GetProcessTimes.restype = wintypes.BOOL


def times(handle):
    values = [FILETIME() for _ in range(4)]
    require(kernel.GetProcessTimes(handle, *[ctypes.byref(value) for value in values]),
            'Cannot read process CPU times')
    return dict(zip(('creation', 'exit', 'kernel', 'user'),
                    [value.high * 2**32 + value.low for value in values]))


def active(handle):
    status = kernel.WaitForSingleObject(handle, 0)
    require(status in (WAIT_OBJECT_0, WAIT_TIMEOUT), 'Cannot inspect process state')
    return status == WAIT_TIMEOUT


def delta(before, after):
    return sum(after[key] - before[key] for key in ('kernel', 'user')) / 10_000_000


def main():
    require(Path(sys.prefix).resolve() == WORKSPACE / '.tmp-kernel-venv', 'Use repository venv')
    require(not START.exists() and not CONTROL.exists(), 'Gate/control outputs must be new')
    handles = {}
    suspended = False
    state = {'status': 'waiting_for_qualified_ready', 'browser_pid': BROWSER_PID,
             'copy_pid': COPY_PID, 'existing_demo_pid': DEMO_PID,
             'scope': 'only_explicit_owned_synthetic_copy_may_be_suspended',
             'existing_demo_modified': False, 'started_epoch': time.time()}
    with CONTROL.open('x', encoding='utf-8') as output:
        try:
            manifest = json.loads((SOURCE / 'source-manifest.json').read_text(encoding='utf-8'))
            require(manifest['sha256'] == '1c37c576cb0026b0b39c199b74672a60890c43a7d9e2b944416179fe2bf398e9'
                    and Path(manifest['target']).resolve() == SOURCE, 'Unexpected fixed source')
            state['source_sha256'] = manifest['sha256']
            rows = process_snapshot()
            browser = validate_browser(row_for(rows, BROWSER_PID))
            handles['browser'] = kernel.OpenProcess(QUERY_SYNCHRONIZE, False, BROWSER_PID)
            require(handles['browser'], 'Cannot open pinned browser process')
            state['browser_creation_times'] = times(handles['browser'])
            state['browser_parent_pid'] = browser['ParentProcessId']
            state['browser_command_line'] = browser['CommandLine']
            deadline = time.monotonic() + 3600
            while not READY.is_file():
                require(active(handles['browser']), 'Browser exited before actual ready signal')
                require(time.monotonic() < deadline, 'Ready wait timed out')
                time.sleep(1)
            signal = json.loads(READY.read_text(encoding='utf-8'))
            require(signal['status'] == 'timing_ready' and signal['pid'] == BROWSER_PID
                    and Path(signal['output']).resolve() == REPORT, 'Unexpected ready signal')
            state['ready_signal'] = signal
            state['ready_sha256'] = hashlib.sha256(READY.read_bytes()).hexdigest()
            rows = process_snapshot()
            require(validate_browser(row_for(rows, BROWSER_PID)) == browser, 'Browser identity changed')
            state['finished_work_checks'] = confirm_no_owned_cpu_jobs(rows)
            copy = validate_copy(row_for(rows, COPY_PID))
            if copy is not None:
                handles['copy'] = kernel.OpenProcess(QUERY_SYNCHRONIZE | SUSPEND_RESUME, False, COPY_PID)
                require(handles['copy'], 'Cannot open explicitly owned copy')
                require(validate_copy(row_for(process_snapshot(), COPY_PID)) == copy, 'Copy identity changed')
                state['copy_command_line'] = copy['CommandLine']
                state['copy_parent_pid'] = copy['ParentProcessId']
                if active(handles['copy']):
                    status = nt.NtSuspendProcess(handles['copy'])
                    if status != 0 and not active(handles['copy']):
                        state['copy_already_finished'] = True
                    else:
                        require(status == 0, 'Unable to suspend owned synthetic copy')
                        suspended = True
                        state['copy_suspended_epoch'] = time.time()
                        state['copy_after_suspend'] = times(handles['copy'])
                else:
                    state['copy_already_finished'] = True
            else:
                state['copy_already_finished'] = True
            demo = row_for(rows, DEMO_PID)
            if demo is not None:
                handles['demo'] = kernel.OpenProcess(QUERY_SYNCHRONIZE, False, DEMO_PID)
                require(handles['demo'], 'Cannot observe baseline demo')
                state['demo_before_quiet'] = times(handles['demo'])
            else:
                state['demo_observation'] = 'PID absent; no action'
            time.sleep(10)
            require(active(handles['browser']), 'Browser exited during quiet interval')
            if suspended:
                state['copy_before_timing'] = times(handles['copy'])
                require(delta(state['copy_after_suspend'], state['copy_before_timing']) == 0,
                        'Suspended copy consumed CPU during quiet interval')
            if 'demo' in handles:
                state['demo_before_timing'] = times(handles['demo'])
                state['demo_quiet_cpu_seconds'] = delta(state['demo_before_quiet'], state['demo_before_timing'])
            state['environment_note'] = 'Existing demo remains as baseline; demo CPU is observed, never a release gate or suspension target.'
            with START.open('x', encoding='utf-8') as release:
                json.dump({'status': 'pure_timing_released', 'epoch': time.time(),
                           'synthetic_copy_paused': suspended, 'controller_pid': os_pid}, release)
            state['timing_released_epoch'] = time.time()
            print(json.dumps({'status': 'timing_released', 'copy_paused': suspended}), flush=True)
            require(kernel.WaitForSingleObject(handles['browser'], 600_000) == WAIT_OBJECT_0,
                    'Browser did not exit within ten-minute timing window')
            require(REPORT.is_file(), 'Browser exited without report')
            timing = json.loads(REPORT.read_text(encoding='utf-8'))
            state['browser_status'] = timing['status']
            state['browser_report_sha256'] = hashlib.sha256(REPORT.read_bytes()).hexdigest()
            if suspended:
                state['copy_after_timing'] = times(handles['copy'])
                state['copy_timing_cpu_seconds'] = delta(state['copy_before_timing'], state['copy_after_timing'])
                require(state['copy_timing_cpu_seconds'] == 0, 'Suspended copy consumed CPU during timing')
            if 'demo' in handles:
                state['demo_after_timing'] = times(handles['demo'])
                state['demo_timing_cpu_seconds'] = delta(state['demo_before_timing'], state['demo_after_timing'])
            state['status'] = 'timing_finished'
        except BaseException as exc:
            state['status'] = 'control_failed'
            state['error'] = {'type': type(exc).__name__, 'message': str(exc)}
            raise
        finally:
            if suspended:
                state['resume_status'] = nt.NtResumeProcess(handles['copy'])
                state['copy_resumed_epoch'] = time.time()
                if state['resume_status'] != 0:
                    state['status'] = 'resume_failed'
                try:
                    state['copy_after_resume'] = times(handles['copy'])
                    state['copy_active_after_resume'] = active(handles['copy'])
                except BaseException as error:
                    # Resume has already been attempted; preserve its status and
                    # every original browser/control failure even if observation fails.
                    state['resume_observation_error'] = {
                        'type': type(error).__name__, 'message': str(error)}
            for handle in handles.values():
                if handle:
                    kernel.CloseHandle(handle)
            state['finished_epoch'] = time.time()
            json.dump(state, output, ensure_ascii=False, indent=2)
            output.write('\n')
            output.flush()
            print(json.dumps({'status': state['status'], 'control': str(CONTROL)}), flush=True)
            require(state.get('resume_status', 0) == 0, 'Owned copy resume failed; explicit intervention required')


if __name__ == '__main__':
    import os
    os_pid = os.getpid()
    main()
