"""Release one guarded synthetic browser run; pause only our four idle MCP hosts."""
import argparse
import ctypes
from ctypes import wintypes
import hashlib
import json
from pathlib import Path
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('--pid', type=int, required=True)
parser.add_argument('--parent', type=int, required=True)
parser.add_argument('--prefix', type=Path, required=True)
args = parser.parse_args()
workspace = Path(__file__).resolve().parents[1]
prefix = args.prefix.resolve()
assert prefix.parent == workspace / '.tmp' and prefix.name.startswith('stage9-')
ready, start, report, receipt = (Path(str(prefix) + suffix) for suffix in
    ('-timing.ready.json', '-timing.start.json', '-browser.json', '-pure-control.json'))
assert ready.is_file() and not start.exists() and not report.exists() and not receipt.exists()
signal = json.loads(ready.read_text(encoding='utf-8'))
assert signal['pid'] == args.pid and Path(signal['output']).resolve() == report

kernel = ctypes.WinDLL('kernel32', use_last_error=True)
nt = ctypes.WinDLL('ntdll')
kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
kernel.OpenProcess.restype = wintypes.HANDLE
kernel.CloseHandle.argtypes = [wintypes.HANDLE]
kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
kernel.WaitForSingleObject.restype = wintypes.DWORD
nt.NtSuspendProcess.argtypes = [wintypes.HANDLE]
nt.NtSuspendProcess.restype = ctypes.c_long
nt.NtResumeProcess.argtypes = [wintypes.HANDLE]
nt.NtResumeProcess.restype = ctypes.c_long

class FileTime(ctypes.Structure):
    _fields_ = [('low', wintypes.DWORD), ('high', wintypes.DWORD)]

kernel.GetProcessTimes.argtypes = [wintypes.HANDLE, *([ctypes.POINTER(FileTime)] * 4)]

def process_times(handle):
    values = [FileTime() for _ in range(4)]
    assert kernel.GetProcessTimes(handle, *[ctypes.byref(value) for value in values])
    return dict(zip(('creation', 'exit', 'kernel', 'user'),
        [value.high * 2**32 + value.low for value in values]))

def processes():
    command = 'Get-CimInstance Win32_Process | Select-Object ProcessId,ParentProcessId,CommandLine | ConvertTo-Json -Compress'
    value = subprocess.run(['powershell', '-NoProfile', '-Command', command],
        capture_output=True, text=True, check=True)
    return {item['ProcessId']: item for item in json.loads(value.stdout)}

hosts = {
    51132: (58128, 'stage9_package_agent_harness.py', 'stage9-final-draft-agent-fix1-20261003'),
    27232: (52292, 'stage9_restore_agent_harness.py', 'stage9-final-draft-agent-restore-20261003'),
    39716: (23008, 'stage9_restore_agent_harness.py', 'stage9-final-draft-agent-current-runtime-20261003'),
    5244: (46856, 'stage9_restore_agent_harness.py', 'stage9-final-draft-agent-current-runtime-published-20261003'),
}
state = {'status': 'started', 'scope': 'exact_owned_idle_synthetic_mcp_hosts_only',
    'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'started_epoch': time.time(), 'targets': {}, 'browser_pid': args.pid}
handles, paused = {}, []
browser = None
try:
    inventory = processes()
    item = inventory[args.pid]
    assert item['ParentProcessId'] == args.parent
    assert 'benchmark_stage9_browser.py' in item['CommandLine'] and prefix.name in item['CommandLine']
    for pid, (parent, script, marker) in hosts.items():
        item = inventory[pid]
        assert item['ParentProcessId'] == parent and script in item['CommandLine'] and marker in item['CommandLine']
    children = [pid for pid, item in inventory.items() if item['ParentProcessId'] in hosts]
    for pid in children:
        command = inventory[pid]['CommandLine'] or ''
        parent = inventory[pid]['ParentProcessId']
        marker = hosts[parent][2]
        assert (
            command.lower() == '\\??\\c:\\windows\\system32\\conhost.exe 0x4'
            or ('python.exe' in command.lower() and 'ai_accounting.kernel.cli' in command
                and marker in command and command.endswith('data mcp'))
        )
    for pid in [*hosts, *children]:
        handle = kernel.OpenProcess(0x0800 | 0x0400 | 0x00100000, False, pid)
        assert handle and kernel.WaitForSingleObject(handle, 0) == 258
        handles[pid] = handle
        state['targets'][str(pid)] = {'before': process_times(handle),
            'parent': inventory[pid]['ParentProcessId']}
        assert nt.NtSuspendProcess(handle) == 0
        paused.append(pid)
    browser = kernel.OpenProcess(0x0400 | 0x00100000, False, args.pid)
    assert browser and kernel.WaitForSingleObject(browser, 0) == 258
    time.sleep(3)
    state['window_started_epoch'] = time.time()
    with start.open('x', encoding='utf-8') as handle:
        json.dump({'status': 'pure_timing_released', 'owned_idle_synthetic_paused': paused,
            'epoch': time.time()}, handle)
    print(json.dumps({'status': 'pure_browser_started', 'pid': args.pid}), flush=True)
    deadline = time.monotonic() + 600
    while kernel.WaitForSingleObject(browser, 1000) == 258:
        assert time.monotonic() < deadline, 'Owned browser timeout'
    result = json.loads(report.read_text(encoding='utf-8'))
    state.update(window_finished_epoch=time.time(), result_status=result['status'])
    for pid in paused:
        record = state['targets'][str(pid)]
        record['after'] = process_times(handles[pid])
        record['cpu_unchanged'] = all(record['before'][key] == record['after'][key]
            for key in ('kernel', 'user'))
        assert record['cpu_unchanged']
    state['status'] = 'timing_finished'
except BaseException as error:
    state.update(status='control_failed', error={'type': type(error).__name__, 'message': str(error)})
    raise
finally:
    for pid in reversed(paused):
        state['targets'][str(pid)]['resume_status'] = nt.NtResumeProcess(handles[pid])
    if browser:
        kernel.CloseHandle(browser)
    for handle in handles.values():
        kernel.CloseHandle(handle)
    state['finished_epoch'] = time.time()
    with receipt.open('x', encoding='utf-8') as handle:
        json.dump(state, handle, indent=2)
    print(json.dumps({'status': state['status'], 'output': str(receipt)}), flush=True)
    assert all(state['targets'][str(pid)]['resume_status'] == 0 for pid in paused)
