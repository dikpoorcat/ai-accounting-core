from pathlib import Path
import hashlib
import json
import statistics
import sys
import time

w = Path(__file__).resolve().parents[1]
src = w / '.tmp/stage9-build-source-owner-r76-release'
sys.path.insert(0, str(src / 'scripts'))
from stage9_source import configure_source
configure_source(src, w)
from ai_accounting.kernel.catalog import Catalog
from ai_accounting.kernel.dashboard import Dashboard
from ai_accounting.kernel.dashboard_funds import FundsRead
from ai_accounting.kernel.daemon import _prepare_static_runtime
from ai_accounting.kernel.engine import Engine
from ai_accounting.kernel.resident_reads import ResidentReadPool
from ai_accounting.kernel.types import canonical

def effects(read):
    if read.snap.close is not None:
        return None
    headers = read._verified_current_event_rows(current=True,
        accounts={'1001', '1002', '1012', '1101'}, subjects=None)
    if headers is None:
        return None
    bodies = read.snap.reads._verified_source_contents
    rows = []
    for header in headers:
        ident = header['basis_calculation_id']
        if ident not in bodies:
            return None
        outcome = bodies[ident]
        balances, values = outcome.get('balances'), outcome.get('values')
        if type(balances) is not list or type(values) is not dict:
            return None
        actual_date = values.get('actual_date')
        if actual_date is not None and type(actual_date) is not str:
            return None
        for index, balance in enumerate(balances):
            if (type(balance) is not dict or type(balance.get('category')) is not str
                or type(balance.get('key')) is not str or type(balance.get('amount')) is not int
                or not -(1 << 63) <= balance['amount'] < (1 << 63)):
                return None
            if balance['category'] in {'bank', 'cash', 'platform'} and balance['amount'] != 0:
                rows.append([header['period'], header['id'], header['number'], ident,
                    header['basis_kind'], -1 if header['reverses_id'] is not None else 1,
                    index, balance['category'], balance['key'], balance['amount'], actual_date])
    return rows

columns = ('period','event_id','number','calculation_id','kind','sign','effect_index',
           'category','balance_key','amount','actual_date')
prefix = 'WITH effects AS (SELECT ' + ','.join(
    f"json_extract(value,'$[{i}]') {column}" for i,column in enumerate(columns)
) + ' FROM json_each(?)) '
old_movements = FundsRead.movements
def candidate(read):
    rows = effects(read)
    source, parameters = old_movements(read)
    if rows is None:
        return source, parameters
    suffix = source[source.index(', money AS'):]
    return prefix + suffix.replace("json_extract(m.outcome,'$.values.actual_date')", 'm.actual_date'), [canonical(rows)]

book = json.loads((w / '.tmp/stage9-owner-main48-r73-verified.json').read_text('utf-8'))
assert book['status'] == 'complete' and book['integrity']['status'] == 'verified'
root = Path(book['root'])
assert root == w / '.tmp/stage9-owner-main48-r63'
_prepare_static_runtime()
catalog = Catalog(root)
pool = ResidentReadPool()
with catalog.connection(read_only=True) as connection:
    row = dict(connection.execute('SELECT * FROM company WHERE id=?', (book['company']['id'],)).fetchone())
    store = catalog._bound_store(row, read_pool=pool)
engine = Engine(store)
dashboard = Dashboard(engine, company_name=row['name'], companies=[row])
out = {'source':str(src),'source_sha256':hashlib.sha256((src/'src/ai_accounting/kernel/dashboard_funds.py').read_bytes()).hexdigest(),
       'root':str(root),'current_full_integrity':'not_run','experiment':str(Path(__file__)), 'runs':[]}
try:
    with dashboard._snapshot('2019-12') as snap:
        snap.month_journal.account_amounts()
        read = FundsRead(snap)
        data = effects(read)
        out['closed'] = snap.close is not None
        out['input_rows'] = None if data is None else len(data)
        out['input_json_bytes'] = None if data is None else len(canonical(data).encode())
        out['verified_basis_json_bytes'] = sum(len(canonical(snap.reads._verified_source_contents[h['basis_calculation_id']]).encode())
            for h in read._verified_current_event_rows(current=True, accounts={'1001','1002','1012','1101'}, subjects=None))
        for name, operation in [('sql_original',old_movements),('candidate',candidate)]:
            source, params = operation(read)
            out[name+'_sql'] = source
            vm=[0]
            def progress(): vm[0]+=100; return 0
            snap.connection.set_progress_handler(progress,100)
            start=time.perf_counter()
            result=[dict(r) for r in snap.connection.execute(source,params)]
            elapsed=(time.perf_counter()-start)*1000
            snap.connection.set_progress_handler(None,0)
            out[name+'_execution']={'vm':vm[0],'ms':elapsed,'rows':len(result),'bytes':len(canonical(result).encode())}
            if name=='sql_original': expected=result
            else: assert result==expected
    for i in range(8):
        for name, method in ([('candidate',candidate),('sql_original',old_movements)] if i%2 else [('sql_original',old_movements),('candidate',candidate)]):
            FundsRead.movements=method
            start=time.perf_counter()
            response=dashboard.brief('2019-12',limit=20)
            elapsed=(time.perf_counter()-start)*1000
            out['runs'].append({'name':name,'ms':elapsed})
            response['generated_at'] = None
            normalized=canonical(response)
            if 'response' not in out: out['response']=hashlib.sha256(normalized.encode()).hexdigest()
            assert out['response']==hashlib.sha256(normalized.encode()).hexdigest()
    out['median_ms']={name:statistics.median(x['ms'] for x in out['runs'] if x['name']==name) for name in ('sql_original','candidate')}
    out['status']='complete'
except BaseException as error:
    out['status']='failed';out['error']=repr(error)
    raise
finally:
    FundsRead.movements=old_movements
    pool.close()
    (w/'.tmp/stage9-r77-verified-money-native.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in out.items() if k in ('status','input_rows','input_json_bytes','verified_basis_json_bytes','median_ms','sql_original_execution','candidate_execution','error')},ensure_ascii=False),flush=True)

