# Read-only final regression plan, month-reads source

Candidate .tmp/stage9-build-source-owner-month-reads-20261003-release SHA1c37c576cb0026b0b39c199b74672a60890c43a7d9e2b944416179fe2bf398e9; production remains primary draft, sealed source selects released1. A fixed-source group proves its own implementation/fixture behavior, not completion of the stage, package or other scales. No fixture rewrite, source mutation, real-root access or proof transfer.

The12 core files in stage9-month-reads-release-core-group.py cover contract export/selection/registered verifiers, exact SQL and migration ancestry, copied CLI startup rejection, offline fault/retry/history preservation, old ZIP restore, fixed-v1 saved JSON isolation and warm-cache semantics, and identity/recovery. Explicit synthetic draft fixtures do not imply the primary factory must be draft: schema_fixture builds test-family draft0; draft_bundle_fixture independently builds typed draft contracts; exporter temporarily patches selector and __file__ to a tmp root. Offline tests explicitly declare synthetic released1→2 and verifier mappings. Active factory assertions adapt to the selected status/version. CLI rejection fixture freezes its own copied source, so those receipts are not the sealed source's original contract publication. These facts are from static inspection; actual group failures must remain and be classified without replacing fixtures.

Implementation regression may separately run from primarydraft with source=test/fixture paths all primary and expected=draft. Sealed group uses1c37 kernel/tests/fixtures and expected=released. Never mix selected released kernel with primary tests silently or add two run counts together. The executed runner source and command are preserved in .tmp/stage9-month-reads-release-core-group.py; repo venv invocation is:

```powershell
.tmp-kernel-venv/Scripts/python.exe -B -u .tmp/stage9-month-reads-release-core-group.py
```

This target is must-new and cannot be reused for another run. It clears inherited FINANCE_DATA_ROOT, selects sealed source before accounting/pytest imports, asserts factory released1+verifier1, records actual module paths, uses sealed pytest config/tests with source-backed fixtures, disables sealed pyc/.pytest_cache, puts temp/XML/log/metadata outside sealed source, and compares the complete source file inventory and manifest bytes before/after. The runner does not start browser timing, a scale builder or evidence tasks; individual core tests execute their original isolated CLI/daemon rejection and synthetic database fixtures.

Already existing main12-month-reads-qualified complete proves registered verifier nonempty released1 content:30225 facts/12413 calculations/12309 vouchers/11 closes/85 evidence,4coverage verified andlimitations[]. This is not future synthetic-v2 production support, and does not cover final package upgrade/daemon-lock/MCP/AI approval or all remaining scales. The four package helper/mock files are a separate group; actual full released packaging remains required without skip-validation.

Evidence commands are prepared only, not executed:

```powershell
$releaseSource = (Resolve-Path .tmp/stage9-build-source-owner-month-reads-20261003-release).Path
.tmp-kernel-venv/Scripts/python.exe scripts/benchmark_stage9_evidence.py --workspace . --source $releaseSource --root .tmp/stage9-month-reads-evidence-240-mixed-root --output .tmp/stage9-month-reads-evidence-240-mixed.json --size-mib 240 --profile mixed --seed 9 --foreground http
.tmp-kernel-venv/Scripts/python.exe scripts/benchmark_stage9_evidence.py --workspace . --source $releaseSource --root .tmp/stage9-month-reads-evidence-1536-mixed-root --output .tmp/stage9-month-reads-evidence-1536-mixed.json --size-mib 1536 --profile mixed --seed 9 --foreground http
```

Root/output must be absent direct stage9-prefixed children of workspace.tmp. chunk20MiB is function default, not a CLI flag. Actual preflight checks free temporary DISK: mixed/incompressible4×size+512MiB, so240 requires1472MiB and1536 requires6656MiB(6.5GiB); compressible3×size+512MiB. No equivalent free-RAM preflight exists. RSS samples same-time resident/background process sums each10ms, excludes browser process, and never adds independent historical peaks. This corrects the one inaccurate RAM sentence in release-remaining-gates.md.

Old240/1536 reports complete underdraft0 and lack current source binding. r14-240 is old released source, old limit100/preparationcomplete foreground. Neither covers1c37 default20/deferred final evidence. Need both actual scale verify/backup/restore/restored_verify, unique evidence bytes/digests/ZIP summaries, source checks, same-time RSS and samples during every operation. HTTP default foreground is not500ms whole-browser proof. Browser option requires --foreground browser --node <actual> --playwright-module <actual> --browser-channel msedge. No evidence/package/scale CPU work is scheduled during root-controlled pure-timing gate.
Authorized core group result: 12 unchanged sealed test files, 119 passed in235.14s, exit0, PID54748/session25814 ended. Complete source inventory before/after and manifest bytes matched1c37; nine actual production module paths recorded in group.json. No fixture edits or repeat run. This is the core group outcome only, not stage/package/evidence completion.
