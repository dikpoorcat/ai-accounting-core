# 请求发表证明缓存的只读核对

确认存在 P3 同根因的遗漏，但不证明整页提速，也不按月份数推断增长。

`query_reads._verify_current_voucher_publication_rows`先检查每个version的原／当前关系缓存；空输入或全部关系成功命中时，在tuple comprehension前返回。首次未命中的请求才读取实际current头及publication行，再遍历请求period对应的全部 `_verified_publications[period]` tuple制造ID集合，之后另按本次 `publications.values()` 的ID及精确posting_period查询 `_verified_publication_ids`。因此增长轴是同月缓存发表行数，不是其他月份的缓存键数。

## 实际访问证据及边界

- `.tmp/stage9-publication-period-cache-scope-fix2.json`：通过真实登记／发布入口构造同月12、48、120条；先成功verify_publication_periods，再请求一个实际current voucher。旧tuple访问12／48／120；临时id→精确posting_period原型访问tuple 0，membership和period lookup各1次，返回相同。再次请求原关系均新增0次。数字是发表行数，不是12／48／120月公司验收。
- 同报告：只调用verify_publication_records自然形成ids-only缓存时，旧／原型均成功且不遍历tuple。unowned、historical-v1、registry-v1原／候选返回一致且period／relation缓存均为空；没有更改这些条件或固定v1算法。
- 人为清除id缓存、保留已通过tuple，再注入“必须digest检查失败”的故障时：旧tuple路径仍跳过该检查；id-only原型重新核验并拒绝。这个差异说明原型不会从孤立tuple恢复弱证明，但不能宣称任意私有cache篡改都完全等价。这不是数据库真实损坏或接口输入案例。
- 第一轮scope探针误查voucher_current.subject_id，失败报告及脚本分别保留为scope-first.json／scope-first.py；修正实际join后另存fix1、fix2。没有覆盖失败。

## 五页及接口调用范围

已存主12及主48真实native报告中，helper调用次数均为：简报2、资金1、员工1、资产1、季度报表2。这些原报告没有独立tuple访问计数，不能直接将其helper调用次数等同于tuple遍历次数。

`.tmp/stage9-publication-period-cache-pages-fix1.json`使用1人、26业务×2月的实际MixedBook观察调用顺序：

| 页 | 第一次关系请求 | tuple缓存／实际遍历 | 后续关系命中 |
| --- | ---: | ---: | --- |
| 简报 | 31 heads | 0／0 | 第二次31均命中，早退 |
| 资金 | 31 heads | 34／34 | 无额外调用 |
| 员工 | 31 heads | 34／34 | 无额外调用 |
| 资产 | 31 heads | 0／0 | 无额外调用 |
| 报表 | 31 heads | 0／0 | 第二次31均命中；空月输入早退 |

资金的balance_totals、员工的settlement_summary会先通过完整period publication核验，随后journal完整开放范围验证才核对当前关系；简报先account_amounts，资产先journal／分类源，报表自身没有verify_publication_periods调用。主12／48已存报告的前四页有period verification调用，报表没有；小fixture支持同条调用顺序，但未重新插桩大样本逐tuple计数。资金／员工当前主路径通常请求整个开放月当前凭证，因此多数tuple成员亦在必要请求中；这仍是重复集合装配，但不是“默认20所以只请求20”的依据。无影响复核／无凭证发表使完整tuple与当前凭证集合不完全相同。

CLI／MCP消费者通过Service和Reports、BusinessQueries进入相同journal／report_projection或verify_open_voucher_scope链。Reports独立入口可拥有QueryReads.snapshot；普通BusinessQueries(connection)只构造未owned的QueryReads，缓存不启用。不能以协议名称断言都受益；要看事务是否owned、是否先有period成功缓存、当前关系是否未命中。固定v1独立reader／非owned条件保持原样。

pages-first.json及pages-first.py保留首次失败：TemporaryDirectory预创建空根，不符合MixedBook must-new；仅删该刚创建空目录后让真实builder创建，成功结果另存fix1。

## 正确性前提与最小方案

唯一自然tuple producer是QueryReads.verify_publication_periods：`list(_verified_period_headers)`完整成功后，同一同步调用先登记period tuple，再登记每个id→posting_period。中途异常不登记；无await或对外暴露的中间阶段。退出snapshot清除两缓存。既有proof不会被失败head批次撤销；该批次只撤回新增、原来不存在的ID。

id缓存有独立成功producer：verify_publication_records、_verify_current_voucher_publication_rows、settlement_freeze._verified_publication_sources。它们逐ID严格digest／期间核验并在整个所选批次成功后登记；ids-only成功不代表完整period覆盖。period_balances／settlement_projection仍须独立执行完整period identity/sequence/header coverage，绝不能拿ID缓存推导period完成。

最小可行调整仅删当前关系helper的period tuple ID集合装配，保留本次实际publication ID命中且posting_period完全相等的复用；未命中仍verify_record。继续执行current/original subject、period、head/successor、voucher/correction/no-impact、signature全部检查，保持成功后关系／ID登记及失败隔离。保留现有active connection/transaction守卫，不将本组扩大为proof范围优化，不动完整period验证、完整源算法、历史固定v1或typed合同。

本轮只增加`.tmp`诊断原件，没有修改production、tests或docs，没有执行工具组回归、真实浏览器或大样本计时。
