"""Preserve rejected private query experiments and prove runtime stayed at r37."""
from pathlib import Path
import gzip
import hashlib
import json
import sys

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root / "scripts"))
from snapshot_stage9_source import _digest, _inventory

provenance = json.loads((root / ".tmp/stage9-release-candidate-work-r37/candidate-provenance.json").read_text("utf-8"))
inventory = _inventory(root)
assert inventory == provenance["repository_inventory"], "Runtime/test source is not r37"
paths = sorted((root / ".tmp").glob("stage9-r37-kind-period*"))
paths += [root / ".tmp/stage9-r37-growth-scope.md", root / ".tmp/stage9-r37-remaining-load-scope.md"]
paths.append(Path(__file__))
assert all(path.is_file() for path in paths)
out = root / "docs/kernel-refactor-stages/09-performance-results"
manifest = out / "kind-posting-r37-manifest.json"
assert not manifest.exists()
records = []
for index, path in enumerate(paths, 1):
    target = out / f"kind-posting-r37-{index:02}-{path.name}.gz"
    assert not target.exists()
    raw = path.read_bytes()
    packed = gzip.compress(raw, mtime=0)
    with target.open("xb") as handle:
        handle.write(packed)
    assert gzip.decompress(target.read_bytes()) == raw
    records.append({"source": str(path.relative_to(root)), "archive": target.name,
                    "raw_bytes": len(raw), "archive_bytes": len(packed),
                    "raw_sha256": hashlib.sha256(raw).hexdigest(),
                    "archive_sha256": hashlib.sha256(packed).hexdigest()})
result = {"status": "private_candidates_rejected_original_growth_unresolved",
          "decision": "do_not_force_month_driver_for_all_kind_scopes",
          "repository_source_sha256": _digest(inventory),
          "candidate_source_sha256": provenance["snapshot_sha256"],
          "runtime_and_tests_match_r37": True,
          "new_production_change": False, "new_test_run": False,
          "measurement": "VM work and result parity only; not page latency acceptance",
          "files": records}
manifest.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", "utf-8")
print(json.dumps({"archives": len(records), "source_unchanged": True,
                  "compressed_bytes": sum(row["archive_bytes"] for row in records)}))
