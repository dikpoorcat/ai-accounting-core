from pathlib import Path
import sys,json,hashlib,sqlite3
from collections import Counter
W=Path.cwd(); S=W/'.tmp/stage9-build-source-surviving-read-consumers-fixed-20261003'; Q=W/'.tmp/stage9-surviving-read-main48-20261003-qualified.json'; B=W/'.tmp/stage9-owner-main48-draft-period-group-construction-input.json'
assert Path(sys.prefix).resolve()==(W/'.tmp-kernel-venv').resolve()
q=json.loads(Q.read_text(encoding='utf-8')); m=json.loads((S/'source-manifest.json').read_text(encoding='utf-8')); c=q['company']; root=Path(q['root']); db=Path(c['path'])
assert q['status']=='complete' and m['sha256']=='dd8601e985cb6bed14f9bc0746bb5b387a20f9355ecd69e1e5ebae729b746a96' and m['file_count']==753
assert root.resolve()==(W/'.tmp/stage9-draft-fixture-main48-20261003').resolve() and q['requested_months']==48 and q['business_count']==48000
assert hashlib.sha256(B.read_bytes()).hexdigest()=='a73ded22688073e7aecb7a79d56a6e31d9d6be202e1083738b091d42d3671d93'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def guard():
 out={'files':{str(p):sha(p) if p.exists() else None for p in [Q,B,S/'source-manifest.json',root/'stage9-builder.json',root/'catalog.sqlite',db,Path(str(db)+'-wal')]}}
 for name,p in [('company',db),('catalog',root/'catalog.sqlite')]:
  con=sqlite3.connect(p.as_uri()+'?mode=ro',uri=True);con.execute('PRAGMA query_only=ON');con.execute('BEGIN')
  out[name]={}
  for table in (['identity','state','schema_history','read_repair_state'] if name=='company' else ['catalog_identity','security_owner','schema_history']):
   if con.execute('SELECT 1 FROM sqlite_master WHERE type=\'table\' AND name=?',(table,)).fetchone():out[name][table]=hashlib.sha256(repr(con.execute('SELECT * FROM '+table).fetchall()).encode()).hexdigest()
  if name=='company': assert con.execute('SELECT company_id,database_id,taxpayer_id FROM identity').fetchone()==(c['id'],c['database_id'],c['taxpayer_id']); assert list(con.execute('SELECT * FROM state WHERE id=1').fetchone())==[1,2065,1164,152,48238,0]
  con.rollback();con.close()
 return out
before=guard();assert before['files'][str(S/'source-manifest.json')]==q['qualification']['source_manifest_sha256'];assert before['files'][str(root/'stage9-builder.json')]==q['qualification']['checkpoint_sha256']
sys.path.insert(0,str(S/'scripts'));import stage9_source;stage9_source.configure_source(S,W)
from ai_accounting.kernel.schema_bundle import production_bundle
from ai_accounting.kernel.storage import Store
from ai_accounting.kernel.engine import Engine
from ai_accounting.kernel.dashboard import Dashboard
from ai_accounting.kernel.reports import Reports
from ai_accounting.kernel.query_reads import QueryReads
from ai_accounting.kernel.read_state import repair_revision
from ai_accounting.kernel import report_open_contribution as roc,integrity
bundle=production_bundle();assert bundle.status=='draft' and dict(bundle.current_versions)=={'company':0,'catalog':0}
store=Store(db,bundle,c['id'],c['database_id'],taxpayer_id=c['taxpayer_id']);engine=Engine(store)
with store.connection(read_only=True) as con: assert con.execute('PRAGMA query_only').fetchone()[0]==1 and repair_revision(con)==0
phase='';result={'diagnostic_only':True,'acceptance':False,'service_started':False,'source':str(S),'source_sha256':m['sha256'],'source_files':753,'calls':{}}
counts={}; decoded=Counter();lookups=Counter();sizes=Counter();scan_work=Counter();content_calls=[]
old_decode=roc._decode;old_line=roc.selected_open_line;old_object=integrity._object;old_content=QueryReads.verify_selected_content
objects=Counter()
def dec(raw,pub):decoded[(phase,pub)]+=1;return old_decode(raw,pub)
def line(content,row):
 key=(phase,content['publication_id'],row.get('reverses_id') or row['version_id'],row['line_no'],bool(row.get('reverses_id')))
 lookups[key]+=1;sizes[len(content['rows'])]+=1;scan_work[phase]+=len(content['rows']);return old_line(content,row)
def obj(raw,component,ident):objects[(phase,component,ident)]+=1;return old_object(raw,component,ident)
def content(self,ids):
 ids=set(ids);content_calls.append({'phase':phase,'requested':len(ids),'missing':len(ids-self._verified_source_contents.keys())});return old_content(self,ids)
roc._decode=dec;roc.selected_open_line=line;integrity._object=obj;QueryReads.verify_selected_content=content
try:
 phase='brief'; brief=Dashboard(engine,company_name=c['name']).brief('2019-12')
 phase='reports'; report=Reports(engine).report(2019,4,source='open')
finally:
 roc._decode=old_decode;roc.selected_open_line=old_line;integrity._object=old_object;QueryReads.verify_selected_content=old_content
for name,module in tuple(sys.modules.items()):
 if name=='ai_accounting' or name.startswith('ai_accounting.'):
  assert not getattr(module,'__file__',None) or Path(module.__file__).resolve().is_relative_to(S/'src')
after=guard();assert before==after
result.update(guards_equal=True,guards=before,content_calls=content_calls,object_decodes={'calls':sum(objects.values()),'repeat_ids_in_same_page':[list(k)+[v] for k,v in objects.items() if v>1]},contribution_decodes={'calls':sum(decoded.values()),'unique_ids':len(decoded),'repeat_ids':[list(k)+[v] for k,v in decoded.items() if v>1]},line_lookup={'calls':sum(lookups.values()),'unique_full_keys':len(lookups),'repeat_calls':sum(v-1 for v in lookups.values()),'rows_length_frequency':dict(sizes),'rows_scanned':dict(scan_work),'repeat_key_rows_scanned':sum((v-1)*next(n for n in [0]) for k,v in [])},response_types=[brief.get('projection'),report.get('projection')])
O=W/'.tmp/stage9-owner-money-party-read-group-boundedprobe-20261004.json';O.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in result.items() if k!='guards'},ensure_ascii=False,indent=2))
