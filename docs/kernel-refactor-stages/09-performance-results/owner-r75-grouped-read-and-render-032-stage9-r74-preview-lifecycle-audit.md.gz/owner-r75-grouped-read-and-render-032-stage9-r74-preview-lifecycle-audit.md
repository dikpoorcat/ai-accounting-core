# r74 preview生命周期只读审计

实际GC暂停仅解释部分上涨，不能确认preview保留对象是全部延迟根因。原件为stage9-r74-preview-lifecycle-attempt2.json，固定r73、main12、同LocalService／root；真实preview67,623.14ms，三页各前后4次（第0预热）。被动GC回调，无collect／阈值修改；并行小任务存在，不是纯计时或浏览器验收。

## 先看GC实际归因边界

| 页面 | wall median前→后／增量ms | GC暂停median前→后／增量ms | 各样本wall减实际GC后median前→后／增量ms |
| --- | --- | --- | --- |
| 简报 | 369.930→501.649／+131.720 | 7.429→34.443／+27.013 | 362.672→467.207／+104.535 |
| 资产 | 196.847→237.074／+40.226 | 4.577→5.228／+0.651 | 192.271→225.923／+33.652 |
| 报表 | 363.983→409.170／+45.187 | 16.422→31.071／+14.649 | 341.526→377.238／+35.712 |

GC median差不是与wall median同一个样本，不能直接把两差相减当因果分解。JSON逐个保存24次read的实际暂停总量、三代次数／总量／最长pause；未复制13,911 callback原列表。post测量brief gen2为26.657和20.953ms，assets一次19.405ms，report为17.362和17.325ms（post预热32.330ms另列）。GC是实测成本，但去除已记录暂停后的各样本仍整体变慢，不能据此宣称全部131.7／40.2／45.2ms由GC导致。SQL／调度／CPU缓存等剩余原因未测，不由RSS替代归因。

RSS241,889,280→672,915,456B，tracked1,922→26,640；列表178→12,270、dict129→12,233。现存kernel类型未出现QueryReads／InspectionCache，正常常驻连接3、service／pool各1。没有逐对象referrer／独占内存图，且诊断本身持有callback记录，不能把全部新增对象或RSS都归于preview。startup已有静态gc.freeze机制保持不动，不建议freeze业务对象。

5,278,127B是脚本json.dumps返回preview响应（含review_locator）的编码长度；不是close_previews真实heap字节，也不是各section编码量。原件没有保存完整preview或分字段大小，本次不启动服务／数据库获取它，因而无法精确宣称5MB中各类占比。

## 全局持有与消费者

| 位置与职责 | 实际持有／读取范围 | 紧凑持有的适当边界 |
| --- | --- | --- |
| LocalService._remember_close_preview，service.py381–417 | 缓存浅拷贝完整result（digest、epochs、manifest）及owner_confirmation；manifest含vouchers、adopted_results、readiness、management_snapshot、材料覆盖、trial_balance、资产采用、owner_review及detail目录。插入前在authorization_gate下核epochs＋repair revision。 | 可把已完整构造／验证的内容改为私有不可变字节或固定section块，长期仅保留小身份／版本包络，不能裁剪原manifest或改摘要。 |
| require_active_close_preview及close提交前置 | 核company/database/digest活动键、period；authorize_close只要求活动存在后消费密码approval。 | 身份／period／digest／epochs／read_version必须独立可读，不能每次把5MB整树解码。返回可变dict的内部约定需要统一调整，不能只换cache值。 |
| 原生密码窗口，daemon333–399/native298/window44 | inspect读取epochs、owner_review；UI最终调用public_owner_review只显示固定摘要。issue在BEGIN IMMEDIATE下用owner_confirmation重建整个manifest，再核原preview_digest／epochs，包括repair revision。 | 摘要可在首次完整构造成功后从同一review原子生成不可变public-summary bytes；不能改成实时重算金额。签发仍重建全manifest并核摘要，不以缓存summary替代密码前置或批准。 |
| DashboardCloseReview.read，close_review1491–1594 | 开放期读active preview的manifest.period/read_version及owner_review，再投影公共摘要；section/cursor当前明确拒绝。闭期从period_close经verified_header/read_section读取真实冻结review。 | 开放摘要只decode紧凑摘要；闭期历史不借runtime缓存。不得新增用户已取消的详情入口。现有read_collection只是独立helper，不是本路径实际分页调用。 |
| Periods.preview_close／close，periods680–734 | preview完整构造后返回manifest及按现有公式digest；close独立重建manifest、完整核摘要再写冻结。 | 外部preview完整响应及冻结必需字段不删除，保持旧公式；仅改变服务私有长期表示。完整树只在实际完整响应／构造／关账需要时短期存在。 |
| 冻结存储及完整历史核验，close_storage331–401等 | 真实adopted/voucher/management及owner_review目录按固定块／section持久化，verify_owner_review_integrity重新核语义；closed_report从SQLitedecode真实冻结。 | 不修改冻结合同／已存字节，不复用runtime摘要证明历史完整内容。若借现有分块思路作内存表示，不能直接调用write_close或把预览注册为关账。 |
| 更换／过期／服务退出 | 新digest替换active键，旧entry仍在128全局FIFO预算内；读review核epochs/repair stale，native签发重新构造；成功close删除对应active及缓存，失败保留。logout未见清空，LocalService.close只关pool／observer，没有明确清preview map。 | 保留同gate、旧密码请求失效及128预算；表示修改不是任意删除active／冻结或新TTL授权。显式退出释放可作为独立生命周期修正候选，未测。 |
| replay_close_previews | 独立intent/boundary/preview_scope缓存，由replay_close操作消费，非本close_previews fullmanifest。 | 不因同名把它一起压缩或改语义。 |

## 技术取舍与待验证

按完整daemon332–400调用与CloseReview当前精简职责，优先方案应是**专用活动关账intent**，不应继续长期保存完整5MBmanifest或owner_review.collections。CLI／MCP的preview_close完整manifest返回保持；活动定位缓存不是该公开返回合同，也不是冻结库。正式签发／提交仍在写事务中重新_manifest并核原digest／epochs／repair，不能变成信任缓存摘要直接批准。

专用intent只保留company_id／database_id／period／preview_digest、epochs及含read_repair_revision的read_version、owner_confirmation，以及从同份已require_close_contract核验manifest的owner_review原子投出的PublicOwnerReview摘要。摘要包含period、全部OwnerReviewAmounts（整数分及None）、businesses、materials、status、followup_count；native窗口和CloseReview消费同一份固定摘要，不现场重算旧业务值。窗口当前本就public_owner_review投影后展示，collections不被消费；CloseReview当前明确拒绝section/cursor，不新增命中页入口或runtime目录块方案。

为减少长期可追踪对象，摘要可以用未经压缩的既有确定性JSON编码bytes持有，加小不可变身份／版本包络；摘要大小原件未保存，需在实施时记录，不能假设就是若干KB或推算净收益。这里只是一个专用intent表示，不新增通用缓存。完整manifest／directory继续在preview返回和冻结构造／核验中保留，完全不改冻结合同；不为“未来可能读明细”在active cache重新留大树或拆旧冻结directories。

摘要完整性不能因精简而取消：仅由已核preview原子建立immutable intent，public摘要按现有严格PublicOwnerReview合同验证；同一company/database/period/digest/read_version绑定，保存原始摘要内容摘要并在实际读取／窗口展示前核bytes与绑定，不接受外部任意摘要／aliases或仅schema合法即可信。测试cachedowner损坏须迁移成真实intent摘要／绑定损坏、交换其他intent等负例，仍应在展示／批准前拒绝；现有测试通过require_active返回manifest.owner_review修改，是内部注入方式，不是业务保持完整dict缓存的兼容义务。若摘要和校验值能被同时任意改写而读仍接受，则绑定设计未完成；不能靠删除旧负例通过。

整个签发digest依旧由完整重建manifest与epochs按现有公式生成；intent额外摘要绑定不能冒充该完整preview_digest，不能改变approve规则或冻结身份。128预算、active替换、并发密码请求与成功close删除按既有gate保留。完整内容无需runtime保留的结论来自实际消费者职责，理论对象量下降并不证明延迟根因全部消失或500ms通过。

必须验证：完整preview返回／digest与旧实现逐字段或确定字节等价；公共review及native窗口精确金额／None／followups相同；密码等待期间替换、epoch或repair变化拒绝；跨公司／数据库／period／digest混用与篡改字节／摘要拒绝；关账签发和提交重建完整manifest、approval消费与失败原子性；成功删除／失败保留、并发活动更换／FIFO淘汰／退出释放；闭期及fixed-v1完整历史从真实冻结读、不走新缓存；当前section/cursor仍拒绝。失效header／summary绑定不能被trusted私有record名称绕过。

随后才用固定源、相同preview前后工作量和被动GC对照验证保留量／跟踪对象是否减少，以及纯browser30次实际收益。需要补各section编码量／实际持有图，不能用RSS下降、无显式GC、native3次小样本宣称500ms。当前main12r73仍5／150慢、main48r73仍79／150慢，正式draft0未完成。本次不修改源码／测试／GC，不启动服务、preview、SQL或计时，不重复归档前批。
