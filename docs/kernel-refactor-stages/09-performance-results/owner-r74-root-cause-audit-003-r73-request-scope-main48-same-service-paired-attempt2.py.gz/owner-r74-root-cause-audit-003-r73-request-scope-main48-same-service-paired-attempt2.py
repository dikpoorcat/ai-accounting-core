"""Same-service paired reads, synthetic current r73; diagnostic only."""
from pathlib import Path
import sys,json,time,gc,statistics,ctypes,os,cProfile,pstats
w=Path(__file__).resolve().parents[1]; src=w/'.tmp/stage9-build-source-owner-r73-release'
sys.path.insert(0,str(src/'scripts'))
from stage9_source import configure_source
configure_source(src,w)
from ai_accounting.kernel.daemon import _prepare_static_runtime
from ai_accounting.kernel.service import LocalService
from ai_accounting.kernel.dashboard import Dashboard
from ai_accounting.kernel.response_contracts import RESPONSE_ADAPTERS,validate_response
from ai_accounting.kernel import runtime
from pydantic import SecretStr
book=json.loads((w/'.tmp/stage9-owner-main48-r73-verified.json').read_text('utf8'))
assert book['status']=='complete' and book['integrity']['status']=='verified' and not book['integrity']['limitations']
assert Path(book['source'])==src
root=Path(book['root']); assert root==w/'.tmp/stage9-owner-main48-r63'
output=w/'.tmp/r73-request-scope-main48-same-service-paired-attempt2.json'
assert not output.exists()
class Mem(ctypes.Structure):
    _fields_=[('cb',ctypes.c_ulong),('PageFaultCount',ctypes.c_ulong),('PeakWorkingSetSize',ctypes.c_size_t),('WorkingSetSize',ctypes.c_size_t),('QuotaPeakPagedPoolUsage',ctypes.c_size_t),('QuotaPagedPoolUsage',ctypes.c_size_t),('QuotaPeakNonPagedPoolUsage',ctypes.c_size_t),('QuotaNonPagedPoolUsage',ctypes.c_size_t),('PagefileUsage',ctypes.c_size_t),('PeakPagefileUsage',ctypes.c_size_t)]
def memory():
    m=Mem();m.cb=ctypes.sizeof(m)
    kernel=ctypes.windll.kernel32;kernel.GetCurrentProcess.restype=ctypes.c_void_p
    ctypes.windll.psapi.GetProcessMemoryInfo(ctypes.c_void_p(kernel.GetCurrentProcess()),ctypes.byref(m),m.cb)
    return {'pid':os.getpid(),'rss':m.WorkingSetSize,'peak_rss':m.PeakWorkingSetSize,'spawned_descendants':0}
state={'phase':None,'sql':0}
execute=runtime._PrivateConnection.execute
def tracked(self,*args,**kwargs):
    if state['phase'] is not None: state['sql']+=1
    return execute(self,*args,**kwargs)
runtime._PrivateConnection.execute=tracked
out={'scope':'same_service_same_process_paired_diagnostic_not_acceptance','source':str(src),'root':str(root),'warmup_pairs':3,'samples':[],'loaded_modules':{},'gc_before':gc.get_stats(),'memory_before':memory()}
app=None;token=None
try:
    app=LocalService(root,enable_read_pool=True,_static_runtime=_prepare_static_runtime())
    with app.catalog.connection(read_only=True) as conn:
        owners=[r[0] for r in conn.execute('SELECT login_name FROM security_owner')]
    assert owners==['synthetic-stage9-owner'], 'Unexpected synthetic owner'
    token=app.security.login(owners[0],SecretStr('Synthetic-stage9-browser-only-2026')).session_token
    cid=book['company']['id'];kwargs={'period':'2019-12','limit':20,'preparation':'deferred'}
    engine=app.engine(cid,dashboard_read=True);dashboard=Dashboard(engine)
    direct=lambda:dashboard.brief(**kwargs)
    dispatched=lambda:app.dispatch('dashboard_brief',{'company_id':cid,**kwargs},session_token=token,response_format='http_json')
    def normal(value):
        if isinstance(value,bytes): return json.loads(value)
        return json.loads(RESPONSE_ADAPTERS['dashboard_brief'].dump_json(validate_response('dashboard_brief',value)))
    def stable(value):
        if isinstance(value,dict): return {k:stable(v) for k,v in value.items() if k not in {'generated_at','checked_at'}}
        if isinstance(value,list): return [stable(v) for v in value]
        return value
    out['semantic_comparison_excludes']=['generated_at','checked_at']
    for i in range(3):
        a=direct(); b=dispatched(); assert stable(normal(a))==stable(normal(b))
    for i in range(3):
        results={}; pair=[]
        for name,call in ([('direct',direct),('dispatch',dispatched)] if i%2==0 else [('dispatch',dispatched),('direct',direct)]):
            state.update(phase=name,sql=0);before_gc=gc.get_count(); cpu=time.process_time();wall=time.perf_counter()
            value=call();elapsed=(time.perf_counter()-wall)*1000;cpu_ms=(time.process_time()-cpu)*1000
            state['phase']=None
            pair.append({'kind':name,'wall_ms':elapsed,'cpu_ms':cpu_ms,'sql_execute_calls':state['sql'],'result_type':type(value).__name__,'gc_count_before':before_gc,'gc_count_after':gc.get_count(),'memory':memory()})
            results[name]=stable(normal(value))
        out['samples'].append({'pair':i,'semantic_equal':results['direct']==results['dispatch'],'observations':pair})
    medians={k:statistics.median(o['wall_ms'] for p in out['samples'] for o in p['observations'] if o['kind']==k) for k in ['direct','dispatch']}
    out['wall_medians_ms']=medians
    out['dispatch_delta_ms']=medians['dispatch']-medians['direct']
    if out['dispatch_delta_ms']>25 and medians['dispatch']>medians['direct']*1.15:
        profile=cProfile.Profile();profile.runcall(dispatched)
        out['dispatch_profile']=[{'function':str(Path(k[0]).name)+':'+str(k[1])+':'+k[2],'calls':v[1],'own_ms':v[2]*1000,'inclusive_ms':v[3]*1000} for k,v in sorted(pstats.Stats(profile).stats.items(),key=lambda p:p[1][3],reverse=True)[:60]]
    for name,module in sys.modules.copy().items():
        if name in ['ai_accounting.kernel.service','ai_accounting.kernel.dashboard','ai_accounting.kernel.query_reads','ai_accounting.kernel.runtime','ai_accounting.kernel.resident_reads']:
            out['loaded_modules'][name]=module.__file__
    assert all(str(Path(path)).startswith(str(src)) for path in out['loaded_modules'].values())
    out['status']='complete'
except BaseException as exc:
    out['status']='failed';out['error_type']=type(exc).__name__;raise
finally:
    state['phase']=None
    if app is not None:
        if token is not None: app.security.logout(token);out['synthetic_session_revoked']=True
        app.close();out['app_closed']=True
    runtime._PrivateConnection.execute=execute
    out['gc_after']=gc.get_stats();out['memory_after']=memory()
    with output.open('x',encoding='utf8') as handle:json.dump(out,handle,ensure_ascii=False,indent=2)
print(json.dumps({'status':out['status'],'medians':out.get('wall_medians_ms'),'delta':out.get('dispatch_delta_ms'),'samples':out['samples'],'output':str(output)},ensure_ascii=False))