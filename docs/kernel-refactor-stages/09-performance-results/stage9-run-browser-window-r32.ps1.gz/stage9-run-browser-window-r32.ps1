$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'D:/GitHub/ai-accounting-core'
$stage9Release = '.tmp/stage9-r32-browser-window.release'
$stage9Window = '.tmp/stage9-r32-browser-window.json'
if (Test-Path -LiteralPath $stage9Window) { throw 'Preserve earlier timing window' }
$stage9Record = @{source='r32'; status='waiting_for_explicit_release'; queued=(Get-Date).ToString('o'); runs=@()}
$stage9Record | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $stage9Window -Encoding utf8
while (-not (Test-Path -LiteralPath $stage9Release)) { Start-Sleep -Seconds 2 }
$stage9Old = Get-CimInstance Win32_Process -Filter 'ProcessId=39312'
if ($stage9Old -and $stage9Old.CommandLine.Contains('stage9-release-independent-120-verified-r30.json')) { throw 'Independent verification still running' }
$stage9Record.status='running'; $stage9Record.started=(Get-Date).ToString('o')
$stage9Record | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $stage9Window -Encoding utf8
try {
    foreach ($stage9Months in @(12,48)) {
        $stage9Output = ".tmp/stage9-release-main-$stage9Months-browser-pure-r32.json"
        if (Test-Path -LiteralPath $stage9Output) { throw 'Preserve earlier browser report' }
        $stage9Args = @('-X','utf8','scripts/benchmark_stage9_browser.py','--source','.tmp/stage9-build-source-r32-release','--workspace','.','--book-report',".tmp/stage9-release-main-$stage9Months-verified-r32.json",'--output',$stage9Output,'--node','D:/Program Files/nodejs/node.exe','--playwright-module','D:/Develop/nodejs/node_global/node_modules/@playwright/cli/node_modules/playwright','--warmups','3','--repeats','30')
        if ($stage9Months -eq 12) { $stage9Args += @('--switch-book-report','.tmp/stage9-release-main-12-switch-verified-r32.json') }
        $stage9Run = @{months=$stage9Months; started=(Get-Date).ToString('o')}
        & ./.tmp-kernel-venv/Scripts/python.exe @stage9Args *> ".tmp/stage9-release-main-$stage9Months-browser-pure-r32.log"
        $stage9Run.exit_code=$LASTEXITCODE; $stage9Run.ended=(Get-Date).ToString('o')
        $stage9Run | ConvertTo-Json | Set-Content -LiteralPath ".tmp/stage9-release-main-$stage9Months-browser-pure-r32-exit.json" -Encoding utf8
        $stage9Record.runs += $stage9Run
        $stage9Record | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $stage9Window -Encoding utf8
    }
    $stage9Record.status='finished'
} catch {
    $stage9Record.status='driver_failed'; $stage9Record.error=$_.Exception.Message
    throw
} finally {
    $stage9Record.ended=(Get-Date).ToString('o')
    $stage9Record | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $stage9Window -Encoding utf8
}
