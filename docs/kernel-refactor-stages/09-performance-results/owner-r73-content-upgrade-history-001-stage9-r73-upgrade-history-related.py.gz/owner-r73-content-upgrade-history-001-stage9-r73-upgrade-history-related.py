"""Run only the authorized six-file isolated upgrade/history regression once."""

from __future__ import annotations

import datetime as dt
import json
import platform
import sqlite3
import subprocess
import sys
import time
import traceback
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import snapshot_stage9_source as snapshot  # noqa: E402

FILES = (
    "test_offline_upgrade.py",
    "test_offline_upgrade_history_preservation.py",
    "test_stage9_backup_upgrade_history.py",
    "test_v1_stored_json_isolation.py",
    "test_history_reads_v1_warm_cache.py",
    "test_versions_recovery.py",
)
EXPECTED_SOURCE = "6a9086e066bd09df5834781fe49da6d4fb7e3333ba6b5569241193a33925f75a"
BASE = ROOT / ".tmp" / "stage9-r73-upgrade-history-related"
LOG = BASE.with_suffix(".log")
XML = BASE.with_suffix(".xml")
REPORT = BASE.with_suffix(".json")
COMMAND = BASE.with_name(BASE.name + "-command.txt")
TEMP = BASE.with_name(BASE.name + "-fixtures")


def utc():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def junit():
    if not XML.is_file():
        return None
    root = ET.parse(XML).getroot()
    cases = list(root.iter("testcase"))
    per_file = {}
    failed = []
    for case in cases:
        module = case.get("classname", "")
        counts = per_file.setdefault(module, {
            "tests": 0, "passed": 0, "failures": 0, "errors": 0, "skipped": 0,
        })
        counts["tests"] += 1
        outcome = "passed"
        for tag, label in (("failure", "failures"), ("error", "errors"), ("skipped", "skipped")):
            if case.find(tag) is not None:
                outcome = label
                break
        counts[outcome] += 1
        if outcome in {"failures", "errors"}:
            failed.append({"module": module, "name": case.get("name"), "outcome": outcome})
    totals = {key: sum(item[key] for item in per_file.values())
              for key in ("tests", "passed", "failures", "errors", "skipped")}
    return {
        "totals": totals,
        "per_file": per_file,
        "failed_cases": failed,
        "suites": [dict(suite.attrib) for suite in root.iter("testsuite")],
    }


def main():
    outputs = (LOG, XML, REPORT, COMMAND, TEMP)
    if any(path.exists() for path in outputs):
        raise RuntimeError("Exclusive output or fixture target already exists")
    expected_python = ROOT / ".tmp-kernel-venv" / "Scripts" / "python.exe"
    if Path(sys.executable).resolve() != expected_python.resolve():
        raise RuntimeError("Repository virtual environment is required")
    argv = [str(expected_python), "-X", "utf8", "-m", "pytest", "-q", "-ra"]
    argv += ["tests/kernel/" + name for name in FILES]
    argv += ["--junitxml=" + str(XML), "--basetemp=" + str(TEMP)]
    command = subprocess.list2cmdline(argv)
    with COMMAND.open("x", encoding="utf-8", newline="\n") as handle:
        handle.write(command + "\n")
    before = snapshot._inventory(ROOT)
    before_sha = snapshot._digest(before)
    result = {
        "scope": "isolated six-file upgrade/history regression; not performance or package acceptance",
        "files": list(FILES), "command": command, "argv": argv, "cwd": str(ROOT),
        "started_at": utc(), "expected_before_sha256": EXPECTED_SOURCE,
        "before_sha256": before_sha, "before_files": before,
        "environment": {"executable": sys.executable, "python": platform.python_version(),
                        "sqlite": sqlite3.sqlite_version, "platform": platform.platform()},
        "log": str(LOG), "xml": str(XML), "fixture_root": str(TEMP),
    }
    start = time.perf_counter()
    code = 1
    with LOG.open("xb") as log:
        try:
            if before_sha != EXPECTED_SOURCE:
                raise RuntimeError("Source digest differs from the authorized regression source")
            print(json.dumps({"started_at": result["started_at"], "source_sha256": before_sha,
                              "command": command}, ensure_ascii=False), flush=True)
            process = subprocess.run(argv, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
            code = process.returncode
            result["returncode"] = code
        except Exception as exc:
            result["runner_error"] = {"type": type(exc).__name__, "message": str(exc)}
            log.write(traceback.format_exc().encode("utf-8"))
        finally:
            result["finished_at"] = utc()
            result["elapsed_seconds"] = time.perf_counter() - start
            after = snapshot._inventory(ROOT)
            result["after_sha256"] = snapshot._digest(after)
            result["after_files"] = after
            result["source_unchanged"] = before == after
            result["junit"] = junit()
            if not result["source_unchanged"]:
                code = 1
            result["status"] = "passed" if code == 0 else "failed"
            with REPORT.open("x", encoding="utf-8", newline="\n") as handle:
                json.dump(result, handle, ensure_ascii=False, indent=2)
                handle.write("\n")
    print(json.dumps({key: result.get(key) for key in (
        "status", "returncode", "elapsed_seconds", "before_sha256", "after_sha256",
        "source_unchanged", "junit", "runner_error",
    )}, ensure_ascii=False), flush=True)
    return code


if __name__ == "__main__":
    raise SystemExit(main())
