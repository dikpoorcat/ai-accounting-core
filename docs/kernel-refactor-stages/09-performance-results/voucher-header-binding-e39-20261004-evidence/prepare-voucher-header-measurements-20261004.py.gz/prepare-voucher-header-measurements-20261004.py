"""Bind before/after read diagnostics to preserved source snapshots."""
import hashlib
import json
from pathlib import Path

W = Path(__file__).resolve().parents[1]
OLD = W / '.tmp/stage9-build-source-frozen-member-guard-20261004'
NEW = W / '.tmp/stage9-build-source-voucher-header-group-20261004'
P = '.tmp/stage9-voucher-header-group'


def sha(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


old = json.loads((OLD / 'source-manifest.json').read_text('utf-8'))
new = json.loads((NEW / 'source-manifest.json').read_text('utf-8'))
assert old['status'] == new['status'] == 'complete'
changed = {name: {'baseline_sha256': value, 'current_sha256': new['files'][name]}
           for name, value in old['files'].items() if value != new['files'].get(name)}
added = {name: value for name, value in new['files'].items() if name not in old['files']}
assert set(changed) == {'src/ai_accounting/kernel/' + name + '.py' for name in (
    'query_reads', 'close_storage', 'business_queries', 'asset_batches',
    'dashboard_funds', 'dashboard_reads',
)}
assert len(added) == 3 and all(name.startswith('tests/kernel/') for name in added)
diff = {
    'baseline_source_sha256': old['sha256'], 'current_source_sha256': new['sha256'],
    'baseline_manifest_sha256': sha(OLD / 'source-manifest.json'),
    'current_manifest_sha256': sha(NEW / 'source-manifest.json'),
    'changed': changed, 'added': added, 'unchanged_files': len(old['files']) - len(changed),
    'scope': 'fixed e39 source diagnostic comparison; full c3c3 qualification remains '
             'input provenance only, not inherited as new-source browser qualification',
}
with (W / (P + '-source-diff-20261004.json')).open('x', encoding='utf-8') as handle:
    json.dump(diff, handle, ensure_ascii=False, indent=2)
for template, suffix, source, record in (
    ('stage9-frozen-member-guard-profile-20261004.py', 'profile', NEW, new),
    ('stage9-frozen-member-guard-native-current-20261004.py', 'native-current', NEW, new),
    ('stage9-frozen-member-guard-native-current-20261004.py', 'native-baseline', OLD, old),
):
    content = (W / '.tmp' / template).read_text('utf-8')
    content = content.replace('.tmp/stage9-build-source-frozen-member-guard-20261004',
                              source.relative_to(W).as_posix())
    old_output = ('profile' if suffix == 'profile' else 'native-current')
    content = content.replace('stage9-frozen-member-guard-' + old_output + '-20261004',
                              'stage9-voucher-header-group-' + suffix + '-20261004')
    content = content.replace(old['sha256'], record['sha256'])
    content = content.replace(sha(OLD / 'source-manifest.json'), sha(source / 'source-manifest.json'))
    content = content.replace("m['file_count']==766", "m['file_count']==" + str(record['file_count']))
    content = content.replace('stage9-frozen-member-guard-source-diff-20261004',
                              'stage9-voucher-header-group-source-diff-20261004')
    content = content.replace('current member guard read changes are diagnostic only and not newly qualified',
                              'new frozen-voucher binding and duplicate-read fixes are diagnostic only and not newly qualified')
    destination = W / (P + '-' + suffix + '-20261004.py')
    with destination.open('x', encoding='utf-8') as handle:
        handle.write(content)
print(json.dumps({'source_sha256': new['sha256'],
                  'manifest_sha256': diff['current_manifest_sha256'],
                  'files': new['file_count'], 'changed': list(changed),
                  'added': list(added)}, ensure_ascii=False))
