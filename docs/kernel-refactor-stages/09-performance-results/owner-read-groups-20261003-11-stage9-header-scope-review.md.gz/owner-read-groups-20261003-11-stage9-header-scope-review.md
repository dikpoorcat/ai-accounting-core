# Header batching scope and evidence

This is a diagnostic record, not browser performance or release acceptance.

## Implemented scope

`close_storage.verified_headers` groups storage-root and close-marker support in
one exact-period SQL, then reads actual company/database identity once. Each row
still passes the factored original root SHA, logical digest, marker, identity,
encoding, source-change contract/highwater, preview and root-shape checks.
No family SQL batching was implemented. Raw support lives only within the call.

Eligibility uses existing `_owns_current_selector_snapshot`: active QueryReads
owner in `_active_fact_reads`, the exact same connection, active transaction,
registry content version other than 1, current close and publication readers.
QueryReads.snapshot denies transaction/savepoint changes until scope exit.
Ordinary authoritative_close_rows and current accounting/adopted-many header
misses use this helper. Accounting headers publish only after the original
complete family/adoption/voucher batch succeeds; errors publish no new header,
slice, verified-part or position prefix. Authority rows publish only after all
headers validate. Existing successful cached rows retain their previous scope.

Dashboard._snapshot and other dashboard QueryReads.snapshot entry points cover
five owner pages/shared detail selectors. BusinessQueries uses authoritative
close rows and accounting-many through its supplied reads. Reports has its own
QueryReads.snapshot entry points. CLI/MCP calls benefit only when their actual
entry point owns such a snapshot; direct independent transactions do not.

## Independent and historical paths: code inspection, not complete validation

* `content_history_context.close_reader` chooses close_storage_v1 within
  historical_content(1); `_close_accounting_many` retains the v1 per-row branch,
  read_indexes retains its independent marker/identity/header branch, and the
  helper falls back to that reader's verified_header. The narrow fixed-v1
  header fallback and existing filter/history reader test passed. Fixed-v1
  complete company verification, repair, backup and restore were not run here.
* integrity._closes selects `close_reader().decode_close`; both current and v1
  decode_close directly call their independent verified_header, not the new
  helper. verify_integrity and verify_close_integrity use independent caller
  connections and verified_source_lease, not QueryReads.snapshot ownership.
  Complete integrity was not rerun as part of this change.
* Maintenance.verify_integrity opens independent read-only BEGIN;
  Maintenance._repair verifies before/after repair in its write transaction.
  Neither installs the QueryReads owner; incidental independent selectors
  therefore retain fallback. Repair was not executed here.
* backup._verify_connection invokes the registered bundle-version verifier;
  schema_bundle.verify_company_with_registry builds Engine/Store over the
  verifier's connection and calls verify_integrity. content_v1.verify_v1_company
  explicitly enters historical_content(1). restore_portable calls
  _unpack_verified before publishing an absent target. These complete backup,
  upgrade and restore paths were inspected but not executed here.
* Periods close checking calls verify_close_integrity, retaining the independent
  full-close decode path before readiness checks. Targeted fixtures did close
  synthetic months; no separate full close workflow suite was run here.

## Recorded work and correctness

The production tests request exactly two closed months, seed 12/48/120 unrelated
cached months, and prohibit cache iteration. Both authority and accounting
routes issue one combined root/marker SQL plus one identity SQL (2 total);
independent per-header support is 6 total. Repeated same-snapshot selection is
0 support SQL. These are request-work counts, not a 12/48/120 business workload
or pure timing result.

Real synthetic damage tests cover the last root digest, marker digest and
accounting-family digest; two failed attempts leave all new caches empty,
restoring original bytes permits a fresh successful retry. Re-sealed last roots
with another company identity or bool source highwater still fail with no
authority/header prefix. Cross-connection, transaction-change rejection,
unowned BEGIN, nontransaction, historical-reader fallback and cutoff were tested.

First accounting/filter scope group: 31 passed (tool session 31897).
First QueryReads/read_indexes/new-header group: 65 passed, 1 failed (session
59052). The failure expected unknown_calculation after deleting the exact fact
revision referenced by a published calculation. An actual run using fixed P3
source 19ae7d824077e8e988ffe254120f7d8ee7ed42708c5fdf8fb6eff2ffb3e49941
reproduced it before modifying the test: content_integrity_failed,
message 核算元数据与来源事实身份不一致, details {}. The old source query_reads.py
SHA 98f5c13855a1d8e5e1b0ffaa9e91babf99f05901a35e8bbd175fccd75426146d
was verified against its source manifest. This was an existing test/semantic
mismatch, not a header-batching regression. The approved test correction keeps
rejection and strengthens message/cache assertions. Final corrected single test
plus 13 header tests: 14 passed. Root then restored both original unowned and
new owned scopes via parametrization: 2 passed in its separate log. Ruff passed.

## Raw SQL prototype provenance

The initial support prototype failed with KeyError 0 due to its proxy shape;
its diagnostic_failed JSON is retained. The corrected r2 uses fixed source
8672404dd3fcb198f80d3583782b98590b8c8358e2c2e354fa3822b71fefa36b,
main12 report SHA 2195134f3ca8fefe5945d8928f78cb09fa99cef62383ed0f66f36201d68db2ab,
main48 report SHA 3889368a3656259b0155f3c6e2091286ae8b96d220305fda45e0f48d37376554.
Source/identity/state/checkpoint were unchanged. No pure wall timing was recorded.
Header SQL 33 to 2 / VM 363 to 326 for 11 closes; SQL 141 to 2 / VM 1551 to
1298 for 47 closes. Family SQL 11 to 1 / VM 176 to 314 and 47 to 1 / VM 752
to 1286, with unchanged bytes 436593 / 1868298: negative, not implemented.
Five proxy faults tested missing last root/marker/family, wrong identity and
bad last family digest; these supplement rather than replace real damage tests.

The single-header VM +1.2% and initial production fallback extra-work experiments
were not produced by this agent; collect their provenance from root/owner.
