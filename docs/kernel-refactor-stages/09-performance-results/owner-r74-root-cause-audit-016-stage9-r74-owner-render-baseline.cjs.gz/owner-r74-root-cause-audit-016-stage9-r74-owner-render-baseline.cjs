const { chromium } = require(process.env.STAGE9_PLAYWRIGHT_MODULE);
const fs = require('node:fs');
(async () => {
 const cfg=JSON.parse(fs.readFileSync(0,'utf8'));
 const browser=await chromium.launch({channel:'msedge',headless:true});
 const page=await browser.newPage({viewport:{width:1440,height:1000}});
 const failures=[];page.on('pageerror',e=>failures.push(e.name));
 const observations=[];
 try {
  const launch=new URL(cfg.ticket_url);launch.searchParams.set('company_id',cfg.company_id);launch.searchParams.set('period',cfg.period);
  await page.goto(launch.href);
  await page.waitForFunction(()=>document.querySelector('#overview')?.getClientRects().length && document.querySelector('.module-header')?.getAttribute('aria-busy')==='false');
  const specs=[['brief','/','brief','#overview'],['funds','/funds','funds','#funds-overview'],['employees','/employees','employees','#employees-overview'],['assets','/assets','assets','#assets-overview'],['reports','/reports','quarterly-report','#report-overview']];
  for(const [name,path,action,selector] of specs){
   const url=new URL(path,cfg.origin);url.searchParams.set('company_id',cfg.company_id);url.searchParams.set('period',cfg.period);if(name==='reports')url.searchParams.set('quarter','2019-Q4');
   await page.goto(url.href);
   await page.waitForFunction(sel=>document.querySelector(sel)?.getClientRects().length && document.querySelector('.module-header')?.getAttribute('aria-busy')==='false',selector);
   await page.evaluate(sel=>{
    const root=document.querySelector(sel); window.__oldRoot=root;
    window.__oldNodes=[root,...document.querySelectorAll('tbody tr, .close-review, .kpi, .summary-grid')];
    window.__renderMutation={added:0,removed:0};
    window.__renderObserver=new MutationObserver(events=>{for(const event of events){window.__renderMutation.added+=event.addedNodes.length;window.__renderMutation.removed+=event.removedNodes.length;}});
    window.__renderObserver.observe(document.body,{childList:true,subtree:true});window.__renderStart=performance.now();
   },selector);
   const reply=page.waitForResponse(r=>new URL(r.url()).pathname===`/api/dashboard/${action}`);
   await page.locator('.module-header button.refresh').click();
   await page.waitForFunction(()=>document.querySelector('.module-header')?.getAttribute('aria-busy')==='true');
   const loading=await page.evaluate(()=>({root_connected:window.__oldRoot.isConnected,root_visible:!!window.__oldRoot.getClientRects().length,old_connected:window.__oldNodes.filter(n=>n.isConnected).length,old_node_count:window.__oldNodes.length}));
   const response=await reply;await response.json();
   await page.waitForFunction(sel=>document.querySelector(sel)?.getClientRects().length && document.querySelector('.module-header')?.getAttribute('aria-busy')==='false',selector);
   const completed=await page.evaluate(async ({sel,action})=>{
    await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));
    const resource=performance.getEntriesByType('resource').filter(r=>new URL(r.name).pathname===`/api/dashboard/${action}`).at(-1);
    window.__renderObserver.disconnect();
    return {same_root:window.__oldRoot===document.querySelector(sel),old_connected:window.__oldNodes.filter(n=>n.isConnected).length,mutations:window.__renderMutation,response_end_to_two_raf_ms:performance.now()-resource.responseEnd,refresh_to_two_raf_ms:performance.now()-window.__renderStart};
   },{sel:selector,action});
   observations.push({page:name,http_status:response.status(),loading,completed});
  }
  process.stdout.write(JSON.stringify({status:failures.length?'failed':'complete',scope:'actual_synthetic_release_dom_identity_diagnostic_not_acceptance',observations,failures}));
 }catch(e){process.stdout.write(JSON.stringify({status:'failed',error_name:e.name,observations,failures}));process.exitCode=1;}
 finally{await browser.close();}
})();
