import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
prefix = ROOT / '.tmp/stage9-r75-owner-frontend'
validation = json.loads(Path(str(prefix) + '-validation.json').read_text(encoding='utf-8'))
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
receipts=[]
for p in sorted((ROOT / '.tmp').glob('stage9-r74-owner-render-*.json')):
    data=json.loads(p.read_text(encoding='utf-8'))
    receipts.append({'path': str(p.relative_to(ROOT)).replace('\\','/'), 'sha256': digest(p),
                     'status': data.get('status'), 'scope': data.get('scope'),
                     'source_provenance': 'fixed r73 release/main12 synthetic' if 'baseline' in p.name else 'live frontend Vue/generated synthetic fixture'})
release = ROOT / '.tmp/stage9-build-source-owner-r73-release'
source = {str(p.relative_to(release)).replace('\\','/'): digest(p) for p in sorted((release / 'frontend/src/views').glob('*.vue'))}
current = {p: h for p,h in validation['before'].items() if p.startswith('frontend/src/views/')}
result={'receipts':receipts,'baseline_fixed_source':str(release),
        'baseline_source_sha256_from_parent':'420ceb395fc5aec17ddaedf8914c7fc8de640da9f08cb35aded8a3a99a4eb7f4',
        'baseline_five_view_sha256':source,'current_five_view_sha256':current,
        'provenance_limit':'Old receipts did not record contemporaneous full Vue source hashes; per-file hashes here are recorded retrospectively. Baseline source is fixed release; fixture final used live frontend and precedes this unchanged validation capture. Failed/early fixtures are not performance or final-source acceptance.',
        'targeted_tests_overlap':{'dashboard-context-v2.test.mjs':19,'dashboard-render-v2.test.mjs':5,'brief-close-review-prefetch.test.mjs':4,
                                 'total':28,'all_in_full_test':True,'add_to_full_test_count':False},
        'full_tests':{'total':150,'pass':148,'fail':2},
        'failure_classification':[
          {'file':'frontend/tests/funds-filters.test.mjs','assertion_line':134,'finding':'Old null assertion conflicts with retained hidden same-selection refresh. Must assert old projection identity + loading + new data gated until fresh context.'},
          {'file':'frontend/tests/funds-filters.test.mjs','assertion_line':255,'finding':'Snapshot-change recovery now retains known-stale data through refresh. Clear funds/snapshotVersion/responsePeriod explicitly on dashboard_snapshot_changed before refresh; retain manual refresh behavior.'}],
        'build':{'contracts_check':True,'type_check':True,'release_mode':True,'exit_code':0},
        'tracked_validation_hashes_unchanged':not validation['changed_files'],
        'static_release_outputs':{str(p.relative_to(ROOT)).replace('\\','/'):digest(p) for p in sorted((ROOT/'src/ai_accounting/static/dashboard').rglob('*')) if p.is_file()}}
path=Path(str(prefix)+'-receipts.json');assert not path.exists()
path.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
report=Path(str(prefix)+'-report.md');assert not report.exists()
report.write_text('''# r75 前端统一验收回执

使用 Node v24.19.0 和仓库 Python venv，执行一次 npm test，随后一次 npm run build:release。没有重跑全测试，也没有另行重复 contracts:check 或类型检查；正式 build 本身依次执行两者及 vite --mode release。

测试 150 项，148 通过、2 失败。失败 stdout 全保留在 stage9-r75-owner-frontend-test.log。资金页 hot refresh 的旧 null 断言与同选择保留隐藏设计不符；已知 snapshot_changed 的恢复则应立即清除失效投影和版本，再刷新。当前验收任务未修改这两处，需要主任务收敛修复和验证。

contracts:check、vue-tsc、正式 release build 均通过，完整 stdout 在 stage9-r75-owner-frontend-build.log。五 View、全部测试、生成合同及捕获的配置/约定文件 before/after SHA256 无变化。正式构建按仓库配置更新 src/ai_accounting/static/dashboard 输出，回执保存最终输出哈希；没有改源码或代理/配置/AGENTS。

此前 28 项定向测试全部属于本次 150 项：dashboard-context-v2 19、dashboard-render-v2 5、brief-close-review-prefetch 4，不能加总为178。此轮包含新移除期间测试。

DOM最终及所有失败/early JSON 的路径、结果、文件SHA256列于 stage9-r75-owner-frontend-receipts.json。基线使用固定r73 release及main12合成根；修复后DOM使用live Vue与生成合同合成样例。旧DOM回执未保存当时完整源码hash，本次按固定release/当前未变化源码回溯记录各View hash，不将早期失败声称为最终源码验收。没有复制archives，没有HTTP/preview/大性能或浏览器达标结论。
''',encoding='utf-8')
print('receipt/report saved')
