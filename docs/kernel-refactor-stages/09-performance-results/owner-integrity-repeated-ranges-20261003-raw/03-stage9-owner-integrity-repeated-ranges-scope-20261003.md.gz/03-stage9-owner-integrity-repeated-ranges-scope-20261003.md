# 第 9 阶段完整资格：重复输入范围与同次调用边界

2026-10-03。先按只读静态排查执行，随后主代理授权仅编辑 current settlement 和 classification 两项窄范围及独立测试文件。编辑期没有运行测试、资格、计时、profile、插桩、建库、SQLite 查询或业务程序。收到主代理“纯窗口结束，可测”后，才执行一次新增范围测试及三个归属文件Ruff；仅使用测试临时合成库，没有访问真实公司库、服务、构建或生产资源。当前保持 draft / 0。main48/main120 的耗时观察来自主代理，不是本报告测量；不能把静态规模推为本次耗时占比。已回退 sharedQueryReads prototype（主代理记录 VM 收益 0.34%、RAM 75→217 MB）不作为候选；不重试已排除的 24 等工作。

最有直接证据且能够独立收窄的组是：当前 settlement 按期过滤全 publication，以及 classification 完整重建重复枚举已经进入 expected_nodes 的子树。另查到旧报告未具体展开的第三处累计输入：`report_flow._refs_from_ids` 在 full 已复用 report/semantics 时，仍逐月编码、连接整组累计分类 ID。它与 report party prefix 证明共享输入，但输出职责不相同，不能直接用一方结果替代另一方。

## 1. 当前 settlement：相同全集反复筛选，不是相同历史结果反复核验

`settlement_freeze.py:1877` 的 `_authoritative_freezes` 是完整 frozen 核验和显式维修的权威重建边界。`1910–1915` 一次装载全 `calculation_publication` 为 ID 字典；`1920–1931` 已按 posting_period 对 expected settlement 行分组。但 `1949` 每个 close 又在 `1957–1960` 遍历全部 publication，筛选 `posting_period == period && sequence > highwater`。

- 输入重复：每个 close 的候选 publication 全集严格相同，且在同一连接/事务内没有修改；只有 period/highwater 谓词改变。若 P 是全 publication 行数、M 是 close 月数，额外谓词次数 Θ(MP)，即便 late 为空也执行。
- 必要范围：各月 close highwater、late publication 的 mode、`1964` 的 `_verify_late_reviews`、`1967–1983` 对 late 月份在原 highwater 下重新算 settlement，以及 `1994` 原 root 对照均有独立职责。不能把原冻结根改成当前结果或跳过 late source 核验。
- 可成组收窄：就在 `_authoritative_freezes` 的 `1910` 装载边界，一次将同一 row 引用按 posting_period 分桶；逐 close 只对其桶过滤 sequence。工作量变为 Θ(P + ΣP_period)，闭期唯一时 ΣP_period≤P。保留 ID 字典供 `1923/1975` 使用，分桶不复制 row/body；本次调用返回后释放，不做跨请求 cache。
- full `integrity.py:1367`、close `1662`、维修 `maintenance.py:67` 经同一当前函数受益。close 仍核所有现存 frozen settlement（没有 through_period 参数），不能借这次优化擅自缩小权威集合。
- 固定 v1 明确不同：`settlement_freeze_v1.py:703` 也装载 publication，但 `743–751` 直接消费 by_period，没有 late 全全集过滤。因此这个 M×P 候选只属于当前实现，不能修改 v1 来“同步”一个不存在的问题。

## 2. 分类目录：每期 root 不同，共享子树内容和完整遍历证明相同

`report_classification_directory.py:584` 在一次 compare 内创建空 overlay 的 `_Nodes`，所有 close 共用。`600–610` 已用 `_previous_keys` 和 `collect_nodes=False`，避免重新 `_tree_keys` 与 prepare 内枚举。真正重复在 `619–620`：每期 `_reachable_new_nodes`（`276–288`）的 found 重新为空，而 overlay 保留以前全部月份的写入；`expected_nodes` 在 `588/619` 已保存历月最终可达节点。

- 输入重叠：T_i 是第 i 个月最终 root 从 overlay 可达的节点数，当前枚举 Θ(ΣT_i)。旧的未变子树具有同一 digest、同一 payload、同一 child 列表；先前已完整遍历的子树，又被当前 root 再次枚举。节点生成和每月 root 内容不同，不可整体复用 root。
- 最小现有边界：`compare_classification_directory` 的本次 expected_nodes 就是“已从某个最终历史 root 完整展开”的集合。给 reachable collector 一个本次已展开集合，遇到已完整展开 digest 停止向下枚举；只在首次完成其子树展开后才登记。可直接复用 expected_nodes 的键，避免另建大缓存。并保留本月 found 去重，正确处理同月共享子树。
- 必要证明不删：`613` 每月 authoritative_root_mismatch；`624–648` 全部实际 root 和全部实际 node payload 与重建期望精确集合对照。只跳过本次自主生成且已完整展开的同一 payload 子树，不信任数据库中的自报 digest。额外插入的中间节点不应因出现在 overlay 就登记为已展开；`78` overlay 中含 copy-on-write 插入中间结果，必须以最终 root 可达为准。
- 收窄后 collector 可达枚举为 O(U+各月新边触达数)，U 为全部历史最终 root 可达节点并集；仍有插入、root 输出、key_filter/hash、全 payload 最后对照成本。`258–272` 每期累计 key_filter 是现有合同输出，不在此组删除。
- full、close、维修共用当前 compare，维修传 `_expected_flows` 已避免另做 flow compare。普通新 close 的 prepare 用一个新 `_Nodes`（`393/407`），旧节点通常不在 overlay，`432` 本来只收新节点，不是同型跨月扩大；不能把 compare 的 visited 语义随意带入写入 prepare。
- 固定 v1 已逐行确认同型：`report_classification_directory_v1.py:547` 共用 overlay；`551` expected_nodes；`583` 每期重新调用 collector（`263`）。可在独立 v1 模块实施相同内部枚举策略，但须保留 v1 独立字段/根合同；不将其改为当前版 reader。

## 3. 累计分类头：party prefix 与 flow 选择共享输入，证明不能互相代替

`report_projection.compare_report_projection:1172/1181` 从闭期 readiness 不断累计唯一分类 ID。每个有 RECLASS 行的月，`_party_delta:433–450` 编码 sorted 全 prefix、连接 typed header/voucher、检查整个 prefix 的重复 voucher key 和 typed period/voucher period 一致，然后才挑当月 source_vouchers。没有 RECLASS 行时 `368–370` 提前返回；不能无条件把每月都算进这段。

另一个实际完整调用：`report_flow.compare_report_flow:468/474` 维护同样累计 refs；即便 `477–480` 消费已核 report/semantics，`522` 仍调用 `_refs_from_ids:108–125`。它先编码 sorted 全 prefix（`123`），再连接 fact_revision/subject/typed classification（`116–121`），只在 WHERE 筛 `voucher key 属本月现金/利润 source_vouchers OR fact period == 本月`。因此已复用报告并没有消除全部累计分类头工作。

令 C_i 为第 i 个 close 的累计唯一分类数：party 的 SQL 输入为 Σ有RECLASS月份 C_i，flow 为 Σ全部closed月份 C_i；均匀增长时可能二次。两者 ID prefix 相同，但不是完全相同的 SQL/输出：party 要全 prefix 重复 key/期间冲突证明；flow 要 fact kind/digest/period，以及现金/利润范围，且包含“本月 fact、凭证不属于本月报表来源”的 refs。directory `_adopted_classifications:374–388` 又读取本 close readiness 全 facts，它需要 digest、voucher binding 和该月 flow 的 certified flag，范围亦不能与当月 party selection 合并。

可成组实现的边界有两个层次，建议与前两项分组：

1. 在一次 `compare_report_projection` 内保留一个很窄的 prefix header state：新加入 ID 的 typed header/voucher period 读取一次，维护 revision→header、voucher-key→revision 集合与累计冲突状态；每月仍只取该月 source_vouchers。不要把每月缺少 relevant 行的状态提前报错：累计 refs 可以加入 pending，新输入到首次有 relevant 的月才做等价证明；未来加入新 ID 引起的冲突不能倒灌到过去 root。
2. 若跨 report→flow 共用，应放在现有 `verified_source_lease`/`_VerifiedReports` 边界（`report_projection.py:113/1368`、`integrity.py:1373–1397`、close `1670–1706`），携带完整有来源的窄头信息及按首次采用月的增量/集合标识，而非摘要。flow仍独立按 `f.period` 和现金/利润 voucher 范围选择、排序并生成原 refs；directory仍核 readiness 所点名全部来源和每月 certified flag。fact id/kind/digest/period 与 typed/voucher身份也要先实际核验，单纯 party 现有 header 行不足以担任 flow 来源。

这一桥接需要设计新的窄状态身份/前缀范围检查，不能现在称为已有完成证明。若当前 _check_sources 的已验 fact 数据可复用（`integrity.py:300/519–525`），只能用 lease 限定本次输入；不能新建共享 QueryReads 来持有所有事实、关系、凭证和祖先闭包。调用 standalone compare 没有共享 proof 时仍从实际来源独立构建窄状态。

v1 也独立确认存在 prefix 查询：`report_projection_v1.py:238/601/610/620` 与 `report_flow_v1.py:98–115`。但是 v1 使用 V1Reads、旧关系算法和独立 source fields；复用边界必须按 v1 实際合同检查。不能混用当前 token 类或当前事实计算。

## 4. owner review 财务位置：全 party keys 相同；历史 membership、absence 与异常范围不同

full `_check_closes:1172` 每月调 `close_review.verify_owner_review_integrity:1322`，其 `1329–1331` 在 verify_financial_position 时传 None，`build_owner_review:1048–1052` 建一个新 snapshot 并重建 `_position`。`dashboard.py:2629–2636` 全表查含 counterparty 子行的所有 voucher key，没有时间过滤。之后 `2662` 把这个全 K key 集合与当月 open_keys 并集传该月最新 close 的 classification_directory_scope。

- 至少 M 次全 counterparty→typed scan；同一 snapshot 中全 party-key 查询结果严格相同。分类目录 `533–536` 还对全部 K 排序、key_filter 检查、建 membership 字典（含未来 key 的空 tuple），实际 tree lookup 只在 filter 可能命中时发生。因此不能把 Θ(MK) 说成 K 次真实节点查询全都命中。
- 可以最小搬移的是 party_keys 候选全集：在 `_check_closes` 本次调用入口加载一次，通过一个私有、同 connection/lease 的窄参数传给 owner review→snapshot→position；本月 open_rows/keys、历史 membership/absence、conflict/unsafe和 position金额重建仍独立。这个改法减少重复 scan，仍有 Θ(MK) 每月 membership处理，且会保留原来对未来 key 的 absence 输入。若要进一步只传已采用party keys，应从已核 close 的 readiness前缀增量建立，不能直接用typed period截止条件作无证明替换。
- 必须保留 `2641–2659` 每个实际开放 fact period 的 current heads，profit-only新增分类与历史分类冲突；`2678–2679` 全 missing adopted typed heads，因为冻结树无法反查删除 typed 行；目录的 `537–540` 异常全覆盖不局限于party_keys。不能只用“当月有余额的key”来删历史缺失或冲突。
- full 通常 verify_financial_position 为 `include_projections && include_indexes`（`1317`）。维修前 `maintenance.py:46–48` 两项 false；维修后 `100–104` 只有一个 true，所以这两次都不重建财务位置。该候选不是 repair 每次的 owner-position 瓶颈。close `_check_closes:1626` 默认重建历史位置，也可用同调用窄参数；普通 close 的新 manifest `periods.py:398–403` 仍需在自己的写事务重建当前位置。
- 固定 v1 已有专用已验 close 前缀路径 `integrity.py:1145–1170`，交 `position_v1`。当前 dashboard 全 party keys 结论不适用于它。勿替换或移除该前缀证明。

## 5. report manifest rows：full/close 同范围读两次，可直接用已有report token桥接

full 的 report `report_projection.py:1184` 与 semantics `report_semantics.py:513` 在同次 verify、同连接/事务、同 VerifiedCloseArchive 的每个 period，均调用 `_manifest_rows:254`。查询和选取范围完全相同：精确 manifest.vouchers、v.period、每条实际voucher line、原凭证basis calculation和publication。函数仍核 voucher_id/calculation_id/reverses_id/total/number与冻结manifest一致及covered exactness（`280–308`）。重复量为两次 ΣL_i，是线性重复而非 M 次全库扫描。

已存在最短边界：report require 返回 `_VerifiedReports`，每月 PreparedReport.rows 已持有所需17字段（`113/1368`）。在 `integrity.py:1379` 与 close `1683` 调 semantics 时，再传该 token；semantics用 report_flow 已有 `416–449` 同样的连接、lease、close精确集合、period/close_digest校验后直接消费对应 rows。原 semantics _verified_source计算/关系及semantic/root核验仍保留。source tuple不应改为从report_line_source表读，因为那是待比较的可维修派生目标。

新 close 已正确复用：`periods.py:753–754` 给 `prepare_report_semantics` 传 prepared_report.rows，其契约 `report_semantics.py:299–307` 明示同close事务。不能以“修full两次读取”为由改变新close或多加一次验证。

维修的情况更广但不等同于一次纯verify：`maintenance.py:70/76/79` 顺序repair report、semantic、flow；各自compare独立，flow `589–590` 没拿tokens，因此 `482` 第三次读manifest rows并重建report/semantic。这些源在repair中通常未修改，但中间fault hooks及派生写入使原lease/状态边界必须明确；可在未来repair组内只对不可变authority打窄proof并每步检查本身actual派生目标，最终verify仍不能删。这不是当前full的“三次manifest”问题：full已经给flow配对tokens，实际为两次。

固定v1同型两次读取在 `report_projection_v1.py:613` 与 `report_semantics_v1.py:515`，但必须传它独立 `_VerifiedReports`，不能直接使用当前版token。

## 6. 公共边界与不可合并范围

full经维护只读BEGIN（`maintenance.py:15–17`）进入 `integrity.verify_integrity`。backup `_verify_connection:166–173` 根据数据库版本派发同公共verifier；当前和fixedv1必须各走其content reader。backup因此可以自动获得上述当前算法优化，不需要绕过内容verifier或改变便携包规则。

backup `690` 来源snapshot核验与 `695` 复制后verify_file，restore/upgrade `975/981` 来源/目标核验，是不同连接/实际字节及迁移前后状态。不能跨它们复用token或删除后一轮。维修 `46` 权威先核、各repair、`100` 结果后核也不能省成一次；同个连接不等于同个已验内容状态。close按 through_period核report/semantics/flow/directory（`1673/1686/1694/1704`）与full全scope不同，不能拿完整集合和前缀集合相互冒充。

本报告仅把“相同输入的重复选取/已展开子树”提到同次已有边界；所有历史root、source/body、required coverage、原子失败职责不减少。全源 `_check_sources` 已一次装载和认证、图依赖环有completed集合，未查到此处每月无条件重新全源核算，不纳入新组。

本组已仅编辑 current settlement：一次装载时以posting_period分桶，桶内保留同一publication row引用；分类collector新增expanded参数，compare传本次expected_nodes，在此前已完整展开子树处止步。writer原调用默认不变，所有当月root和最后全实际payload/set比较保留。固定v1只排查而未修改：settlement无该late全集过滤，classification虽同型但本组不推广current helper；其历史reader与token独立性仍属于回归风险范围。

新增 `tests/kernel/test_stage9_integrity_range_work.py` 的验证设计：三个月真实合成业务关闭后增加两个无关开放月与16主体，对比全重建roots/blocks/revisions；独立旧全publication扫描表达式计数与实际行字段访问比较。两次真实无影响review核其原highwater输出及精确late源。六个小树月份用独立JSON图枚举，覆盖增长、共享子树、未变root和不应纳入的copy-on-write中间节点；真实三月classification compare用原collector默认全遍历作on/off对照，比较完整输出及实际展开次数；分别损坏缺失、变更、多余node payload和root，仍应拒绝。

首轮 `.tmp/stage9-integrity-range-work-first-20261003.xml/.log` 保留，8项中7通过、1失败，27.93s。失败是新增16主体fixture用了同日期同金额资金事实，被真实重复业务规则阻止，尚未到settlement工作量断言；已区分各项实际日期和金额，未绕过规则。首轮成功项没有输出精确计数；补JUnit user_properties供集中回归输出old/new计数，未单独第二次运行完整8项。三归属文件Ruff修正一行101字符后通过。

主代理授权固定四个生产文件整组回归后，执行一次如下范围：新增range-work、verified-report-rows两个文件；report projection/semantics/flow/flow-integrity；current classification、current settlement、late reviews；独立v1 settlement/classification/verified-close-prefix；integrity-content/maintenance；runtime-backup中online WAL snapshot、初始便携包恢复及滚动、source damage/corrupt replay、tampered snapshot/ZIP、FK corruption、close manifest corruption六项；foundation-backup中released source→target再核及缺失source verifier原子失败两项。没有运行前端、build、浏览器、profile或120月完整公司造库。`.tmp/stage9-repeated-source-group-regression-first-20261003.xml/.log` 记录 **176通过、0跳过、0失败，366.89秒**；生产代码在该轮保持固定，fixture修正已跑到全部工作量和业务断言。

该次JUnit记录的实际计数：

| 独立旧/新对照 | 旧次数 | 新次数 | 此fixture减少 | 原业务/内容证明 |
| --- | ---: | ---: | ---: | --- |
| settlement全publication候选的period字段访问：22行、3closed月，额外2个open月16主体 | 66 | 22 | 66.67%（3倍） | 与添加无关业务前完整prepared roots/blocks/revisions一致，且与全部实际freeze集合比较不变 |
| 6个月小树旧collector逐月全展开 vs 本次union增量collector | 327 | 58 | 82.26%（5.64倍） | 每月独立JSON遍历期望一致，完整历史最终root节点并集58个；52个不可达插入中间节点仍排除 |
| 真实3月classification compare旧collector默认全遍历 vs 本次expanded | 2 | 1 | 50%（2倍） | 完整compare输出、roots、actual node payload/set一致，全部1个实际node仍核验；4类损坏拒绝 |

上述计数来自实际测试字段访问或collector对同图读取，旧路径为独立原候选过滤表达式/原collector默认参数；不是实现字符串匹配，也不是计时百分比。真实late reviews原highwater/source核验、row租约/原凭证损坏、full/close/维修/backup前后及独立v1关联回归均通过。这些fixture不是固定main120的规模或结构，不能把次数比例推为该资格或页面耗时收益。

未改善和未覆盖量：classification每月root/filter构造及hash、插入生成、最终全实际node payload/set核验全部保留；publication仍一次装载全表，额外分桶为O(P)行引用列表，未测RSS；若相邻root没有共享子树则visited枚举收益可以为零，单closed月publication减少也可以为零。v1 classification同型代码本组未优化；v1 settlement没有当前late全集过滤。没有测本组对页面时延的作用，也没有重跑固定120月资格。

后续组才考虑exact report rows桥接及prefix窄状态；owner party-key候选读一次需要明确私有proof传递且只减scan，收益不在这里推测。不宣称本组为main120当前耗时根因，也不根据静态复杂度给出资格时延或RSS改善幅度。
