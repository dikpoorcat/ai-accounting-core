# r75 前端统一验收回执

使用 Node v24.19.0 和仓库 Python venv，执行一次 npm test，随后一次 npm run build:release。没有重跑全测试，也没有另行重复 contracts:check 或类型检查；正式 build 本身依次执行两者及 vite --mode release。

测试 150 项，148 通过、2 失败。失败 stdout 全保留在 stage9-r75-owner-frontend-test.log。资金页 hot refresh 的旧 null 断言与同选择保留隐藏设计不符；已知 snapshot_changed 的恢复则应立即清除失效投影和版本，再刷新。当前验收任务未修改这两处，需要主任务收敛修复和验证。

contracts:check、vue-tsc、正式 release build 均通过，完整 stdout 在 stage9-r75-owner-frontend-build.log。五 View、全部测试、生成合同及捕获的配置/约定文件 before/after SHA256 无变化。正式构建按仓库配置更新 src/ai_accounting/static/dashboard 输出，回执保存最终输出哈希；没有改源码或代理/配置/AGENTS。

此前 28 项定向测试全部属于本次 150 项：dashboard-context-v2 19、dashboard-render-v2 5、brief-close-review-prefetch 4，不能加总为178。此轮包含新移除期间测试。

DOM最终及所有失败/early JSON 的路径、结果、文件SHA256列于 stage9-r75-owner-frontend-receipts.json。基线使用固定r73 release及main12合成根；修复后DOM使用live Vue与生成合同合成样例。旧DOM回执未保存当时完整源码hash，本次按固定release/当前未变化源码回溯记录各View hash，不将早期失败声称为最终源码验收。没有复制archives，没有HTTP/preview/大性能或浏览器达标结论。
