$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'D:/GitHub/ai-accounting-core'
$stage9Window = '.tmp/stage9-native-close-batch-ab-window-r38.json'
if (Test-Path -LiteralPath $stage9Window) { throw 'Preserve existing timing record.' }
$stage9Group = Get-Content -LiteralPath '.tmp/stage9-group-r38/result.json' -Raw | ConvertFrom-Json
$stage9Book = Get-Content -LiteralPath '.tmp/stage9-main48-verification-r38.json' -Raw | ConvertFrom-Json
if ($stage9Group.status -ne 'passed' -or -not $stage9Group.source_unchanged -or $stage9Book.status -ne 'complete') { throw 'Fixed group and full verification must finish before timing.' }
function Assert-NoCompetingStage9Work {
    $stage9Competing = @(Get-CimInstance Win32_Process | Where-Object {
        $_.Name -match '^(python.*|node)\.exe$' -and $_.CommandLine -and
        $_.CommandLine -match '(pytest|benchmark_stage9\.py|benchmark_stage9_browser\.py|stage9-remaining-profile-r38\.py|reseed_stage9_book\.py|build_local_package\.py)'
    })
    if ($stage9Competing.Count) { throw "Timing blocked by active work: $($stage9Competing.ProcessId -join ',')" }
}
Assert-NoCompetingStage9Work
$stage9Record = @{status='running'; mode='native_diagnostic_not_page_acceptance'; started=(Get-Date).ToString('o'); runs=@()}
$stage9Record | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $stage9Window -Encoding utf8
try {
    foreach ($stage9RunName in @('r37-A','r38-A','r38-B','r37-B')) {
        Assert-NoCompetingStage9Work
        $stage9Revision = $stage9RunName.Substring(0,3)
        $stage9Output = ".tmp/stage9-native-close-batch-$stage9RunName.json"
        if (Test-Path -LiteralPath $stage9Output) { throw 'Preserve earlier native results.' }
        $stage9Run = @{name=$stage9RunName; started=(Get-Date).ToString('o')}
        & ./.tmp-kernel-venv/Scripts/python.exe -X utf8 .tmp/stage9-native-close-batch-ab.py --source ".tmp/stage9-build-source-$stage9Revision-release" --output $stage9Output *> ".tmp/stage9-native-close-batch-$stage9RunName.log"
        $stage9Run.exit_code = $LASTEXITCODE
        $stage9Run.ended = (Get-Date).ToString('o')
        $stage9Record.runs += $stage9Run
        $stage9Record | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $stage9Window -Encoding utf8
        if ($LASTEXITCODE -ne 0) { throw "Native diagnostic failed: $stage9RunName" }
    }
    $stage9Record.status='finished'
} catch {
    $stage9Record.status='failed'
    $stage9Record.error=$_.Exception.Message
    throw
} finally {
    $stage9Record.ended=(Get-Date).ToString('o')
    $stage9Record | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $stage9Window -Encoding utf8
}
