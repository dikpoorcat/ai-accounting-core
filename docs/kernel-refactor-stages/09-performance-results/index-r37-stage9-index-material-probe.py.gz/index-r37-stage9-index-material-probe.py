"""Bounded read-only diagnosis of exact-ID material lookup plans."""
from pathlib import Path
import hashlib
import json
import sqlite3
import time

root = Path(__file__).resolve().parents[1]
destination = root / '.tmp/stage9-index-material-probe.json'
assert not destination.exists()
kinds = [('material_source_v2','fact_material_source_v2'),
         ('material_period_allocation','fact_material_period_allocation'),
         ('material_resolution_v2','fact_material_resolution_v2'),
         ('material_group_resolution','fact_material_group_resolution')]
reports = []
for months, leaf in [(12,'stage9-reseed-main-12-r36'),(48,'stage9-reseed-main-48-r36.staging')]:
    path = root / '.tmp' / leaf / '91310000123456789S/company.sqlite'
    with sqlite3.connect(path.as_uri()+'?mode=ro', uri=True) as connection:
        connection.execute('BEGIN')
        for kind, table in kinds:
            ids = [row[0] for row in connection.execute(f'SELECT revision_id FROM {table} ORDER BY revision_id LIMIT 100')]
            if not ids:
                reports.append({'months':months,'kind':kind,'status':'empty_unmeasured'})
                continue
            if kind == 'material_source_v2':
                query = ('SELECT f.subject_id,ids.value FROM json_each(?) ids '
                         'JOIN fact_revision f ON f.id=ids.value '
                         'JOIN fact_seal seal ON seal.fact_id=f.id '
                         'JOIN subject s ON s.id=f.subject_id AND s.kind=? '
                         f'JOIN {table} t ON t.revision_id=f.id')
            else:
                query = (f'SELECT t.source_id,ids.value FROM json_each(?) ids JOIN {table} t '
                         'ON t.revision_id=ids.value JOIN fact_revision f ON f.id=t.revision_id '
                         'JOIN fact_seal seal ON seal.fact_id=f.id '
                         'JOIN subject s ON s.id=f.subject_id AND s.kind=?')
            for size in (1, min(100,len(ids))):
                for label, sql in [('before',query),('id_driven_candidate',query.replace('JOIN ', 'CROSS JOIN '))]:
                    parameters=(json.dumps(ids[:size]),kind)
                    steps=[0]
                    def progress():
                        steps[0] += 100
                        return int(steps[0] > 3_000_000)
                    plan=list(connection.execute('EXPLAIN QUERY PLAN '+sql,parameters))
                    connection.set_progress_handler(progress,100)
                    rows=[]
                    error=None
                    started=time.perf_counter()
                    try:
                        rows=connection.execute(sql,parameters).fetchall()
                    except sqlite3.OperationalError as exc:
                        if str(exc) != 'interrupted': raise
                        error='vm_budget_exceeded'
                    finally:
                        elapsed=(time.perf_counter()-started)*1000
                        connection.set_progress_handler(None,0)
                    data=json.dumps(sorted(rows),ensure_ascii=False,separators=(',',':')).encode()
                    result={'months':months,'kind':kind,'requested':size,'variant':label,'query':sql,
                            'status':error or 'complete','vm_steps_rounded_100':steps[0],
                            'rows':len(rows),'result_bytes':len(data),'result_sha256':hashlib.sha256(data).hexdigest(),
                            'elapsed_ms_diagnostic_only':elapsed,'plan':plan}
                    reports.append(result)
                    print(json.dumps({key:result[key] for key in ('months','kind','requested','variant','status','vm_steps_rounded_100','rows')},ensure_ascii=False),flush=True)
        connection.rollback()
destination.write_text(json.dumps({'scope':'synthetic read-only; 48 month copy lacks completed full verifier; not page timing','measurements':reports},ensure_ascii=False,indent=2)+'\n','utf-8')
