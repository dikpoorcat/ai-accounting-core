"""Consumer and independent boundary regression on the pinned reference group."""
import contextlib
import importlib
import json
from pathlib import Path
import os
import sys
import time

workspace = Path(__file__).resolve().parents[1]
source = workspace / '.tmp/stage9-build-source-owner-reference-group-20261003-release'
prefix = workspace / '.tmp/stage9-reference-group-regression'
paths = {kind: Path(str(prefix) + suffix) for kind, suffix in [('log', '.log'), ('xml', '.xml'), ('metadata', '.json'), ('temp', '-temp')]}
assert all(not path.exists() for path in paths.values())
assert Path(sys.prefix).resolve() == workspace / '.tmp-kernel-venv'
os.environ.pop('FINANCE_DATA_ROOT', None)
sys.dont_write_bytecode = True
sys.path[:0] = [str(source / 'scripts')]
import stage9_source
stage9_source.configure_source(source, workspace)
import snapshot_stage9_source

manifest_bytes = (source / 'source-manifest.json').read_bytes()
manifest = json.loads(manifest_bytes)
assert manifest['sha256'] == '6688df6c46f5416ca03917def0d29a701cb20e8ae45b962c59df4a1290f8da62'
before = snapshot_stage9_source._inventory(source)
assert before == manifest['files']
modules = {}
for name in ('close_storage', 'read_indexes', 'query_reads', 'reports', 'content_v1', 'history_reads_v1', 'close_storage_v1', 'backup', 'schema_bundle'):
    module = importlib.import_module('ai_accounting.kernel.' + name)
    path = Path(module.__file__).resolve()
    assert path.is_relative_to(source / 'src')
    modules[name] = str(path)
from ai_accounting.kernel.schema_bundle import production_bundle
bundle = production_bundle()
assert bundle.status == 'released' and dict(bundle.current_versions) == {'company': 1, 'catalog': 1}
files = [
    'test_close_accounting_filter.py', 'test_full_accounting_period_scopes.py',
    'test_report_flow.py', 'test_report_flow_header_aggregate.py',
    'test_report_flow_integrity.py', 'test_report_projection.py', 'test_period_readiness.py',
    'test_stage9_production_verifier_coverage.py', 'test_v1_verified_close_prefix.py',
    'test_report_classification_v1.py', 'test_stage9_backup_upgrade_history.py',
    'test_stored_json_repair_boundary.py',
    'test_read_repair_version.py::test_actual_repair_invalidates_pages_and_deferred_checks_but_noop_does_not',
    'test_runtime_backup.py::test_close_manifest_corruption_is_detected',
    'test_runtime_backup.py::test_initial_portable_round_trip_and_rollover_are_verified',
]
report = {'status': 'running', 'pid': os.getpid(), 'source': str(source), 'source_sha256': manifest['sha256'], 'source_inventory_before': before, 'production_module_paths': modules, 'test_files': files, 'fixture_mode': 'unchanged pinned source tests and production factories', 'contract': {'status': bundle.status, 'versions': dict(bundle.current_versions)}, 'stage_complete': False}
class Record:
    def pytest_sessionfinish(self, session, exitstatus):
        terminal = session.config.pluginmanager.getplugin('terminalreporter')
        report['counts'] = {key: len(value) for key, value in terminal.stats.items() if key in ('passed', 'failed', 'error', 'skipped', 'xfailed', 'xpassed')}
import pytest
os.chdir(source)
started = time.perf_counter()
exitcode = 1
print('PID', os.getpid(), 'LOG', paths['log'], flush=True)
with paths['log'].open('x', encoding='utf-8') as log:
    with contextlib.redirect_stdout(log), contextlib.redirect_stderr(log):
        try:
            exitcode = pytest.main(['-c', str(source / 'pyproject.toml'), '-p', 'no:cacheprovider', '--basetemp', str(paths['temp']), '--junitxml', str(paths['xml']), '-q', *[str(source / 'tests/kernel' / item) for item in files]], plugins=[Record()])
            after = snapshot_stage9_source._inventory(source)
            assert after == before and (source / 'source-manifest.json').read_bytes() == manifest_bytes
            report['source_inventory_equal'] = True
            report['status'] = 'passed' if exitcode == 0 else 'failed'
        except BaseException as error:
            report['status'] = 'runner_failed'
            report['error_type'] = type(error).__name__
            raise
        finally:
            report['exitcode'] = int(exitcode)
            report['seconds'] = time.perf_counter() - started
            with paths['metadata'].open('x', encoding='utf-8') as output:
                json.dump(report, output, ensure_ascii=False, indent=2)
                output.write('\n')
print('DONE', report['status'], report.get('counts'), flush=True)
raise SystemExit(exitcode)
