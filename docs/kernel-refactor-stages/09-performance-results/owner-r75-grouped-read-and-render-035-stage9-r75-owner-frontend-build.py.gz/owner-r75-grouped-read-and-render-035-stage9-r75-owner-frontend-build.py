import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]
PREFIX = ROOT / '.tmp/stage9-r75-owner-frontend'
output = Path(str(PREFIX) + '-validation.json')
result = json.loads(output.read_text(encoding='utf-8'))
node = Path(result['node'])
env = os.environ.copy()
env['PATH'] = str(node.parent) + os.pathsep + str(ROOT / '.tmp-kernel-venv/Scripts') + os.pathsep + env.get('PATH', '')
env['PYTHON'] = result['python']
env.pop('NODE_ENV', None)
log = Path(str(PREFIX) + '-build.log')
assert not log.exists()
argv = [str(node), result['npm_cli'], 'run', 'build:release']
started = time.time()
with log.open('w', encoding='utf-8') as stream:
    completed = subprocess.run(argv, cwd=ROOT / 'frontend', env=env, stdout=stream, stderr=subprocess.STDOUT, text=True)
command = {'name': 'build', 'argv': argv, 'exit_code': completed.returncode,
           'elapsed_seconds': round(time.time()-started, 3), 'log': str(log.relative_to(ROOT))}
result['commands'].append(command)
after = {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in result['before'] if (ROOT / p).is_file()}
result.update(after=after, after_group_sha256=hashlib.sha256(json.dumps(after, sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
              changed_files=[p for p in sorted(set(result['before']) | set(after)) if result['before'].get(p) != after.get(p)],
              checks_executed=True, complete=all(c['exit_code'] == 0 for c in result['commands']))
output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(command), flush=True)
print(json.dumps({'complete': result['complete'], 'changed_files': result['changed_files']}), flush=True)
