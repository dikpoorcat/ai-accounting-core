# r76 经营金额与既有贡献证明只读审计

## 决定与证据范围

现贡献可作为精确正常凭证行的锚定投影依据候选，但现有 API 不能直接替代 `Journal.account_amounts` 的整月来源及完整行证明。本轮不改生产、不执行 SQL/EXPLAIN、测试、核验、服务或计时。未重试逐行报表表、aggregate-authority、JSON decoder、close_rows24 等已退出方案。

当前触发来自 `.tmp/stage9-owner-main12-browser-r76.json`：150 次成功，brief 4 次 >=500ms（median457/max576.6），reports 3 次（median450.6/max516.9）。没有 r76 新主48金额路径测量。下面工作量引用已存在的 `.tmp/stage9-r74-required-money-audit.md` 中 r73 主48证据，不能标成 r76 实测：brief `account_amounts` 246.72ms、`verify_selected_content` 74.37ms、整页约1015次结果 decode/995KB；reports 1004 个贡献 decode/3,059,132 字节，`read_open_contributions` 108.27ms、anchored-source bytes 44.03ms。当前根节点“约260ms”属于其提供的线索。

## 实际消费与必要证明

`dashboard._brief_amounts`（2506）唯一调用 `Journal.account_amounts`（dashboard_reads 1233）。它消费所有 account 的 debit/credit，核对 `monthly_account` 完整非零双边金额，然后按 `PROFIT_ACCOUNTS` 得收入、费用、结果；还消费月末 `snap.accounts` 的未知非零账户和独立 `opening_selection` 的未建立状态。不能只选利润科目、前20项、资金账户或净额。

brief 随后消费 Journal 的活动 count/groups/totals、分页业务20项及可选焦点业务，并调用 FundsRead 的8金额摘要。默认业务页确实只消费少量 Outcome.values/fact，但整月金额证明覆盖所有正式凭证，分页不能缩小该范围。

当前 `account_amounts` 保留的独立保证：

1. Journal `_sql`（1045）先验证整个开放 scope，再按选定期取正式 voucher；精确 current publication、physical current head、subject/period、clear/withdrawn/forward/reversal 关系保护仍不可省。
2. 精确闭期 frozen voucher/adopted 范围、source/basis header 和 digest、原冻结凭证身份及冲正出处；开放月另核 physical current version 集合。
3. 所有 owner、basis、必要 reversal original/frozen adopted 的保存内容及 seals/fact bytes；既有 `verify_selected_content` 是正文证明，不只是 header。
4. 每个 voucher 真实完整有序 lines，与 saved normal owner/basis/adopted lines 精确相等；冲正与认证 original 完整反向相等；不能只核月总额或逐条幸存行。
5. 逐行整数、int64、非负单边、account/cashflow shape、借贷平衡及 header.total；所有账户 checked 聚合，最终完整双边对照 monthly_account。

既有 `test_owner_brief_amounts.py` 有真实页外损坏、balanced-lines+projection、两凭证反向金额抵消、重复 Outcome key、缺 seal/fact、闭期采用、更正/无影响复核和原凭证编号负例。本轮仅读断言，没有重跑。

## 贡献能证明什么、仍缺什么

`report_open_contribution._publication_rows`（119）读取某 calculation 实际创建的 **normal** voucher_version 全部 line；`prepare_open_contribution`（138）保存 version/line_no/account/debit/credit/cashflow，以及报表分类与关系、own/direct source bindings。engine `_sync_publication_projections`（1295）只对本写入事务新 publication 铸造 immutable anchor；完整核验的 `compare_open_contributions`（632）在完整源/链/lines 已独立核验后重建并对照 anchor。

`read_open_contributions`（501）验证 anchor/body SHA、内容身份、parents、全部保存 source bindings；同 owned snapshot 用 `_verify_anchored_source_bytes`（query_reads 1866）验证原 calculation/fact bytes、精确身份与 seals，非规范源字节仍走原 decoded-digest fallback。这个私有 byte proof 不填 `_verified_source_contents`，不能声称完整 Outcome/dependency/adoption 已核。

`selected_open_line`（604）验证一条幸存实际行与锚定行（冲正时交换 debit/credit），并返回分类/关系。它不是完整 voucher 行集证明：缺行、额外行、重复 line_no、整 version 消失的保证仍需独立完整集合检查。贡献 `_decode`（332）检查整行类型，却没有执行 `_lines` 的全部 int64/单边/平衡约束。因此直接逐条匹配再 SUM 不等价。

已证实不适用：`test_report_open_contribution.test_no_impact_review_with_old_voucher_uses_exact_fallback`（180）明确真实 review contribution.rows==[]，实际 selected row.basis 是 review calculation，physical normal voucher 仍属旧 owner。writer engine 1164 的 no_impact 分支保留原凭证。旧 owner 的贡献只能证明旧 physical lines，不能证明 review/basis saved lines 等价。没有已保存的独立“review Outcome.lines 完整投影”，仍需读取这份精确 review 结果。不能从 verified byte digest 推断其 lines。

closed adopted review、反向 original、改期冲正、连续闭期更正有同样的 owner/basis/adoption 多身份区别。原贡献可证明 original 正常行，但不能一概替代 frozen adoption 或新 correction baseline/expected head 核验。clear/withdrawn/零凭证没有幸存行：仍由既有完整前向 scope 判断，不能从空贡献集合认定合法。

## 可行但未测的窄候选

唯一可静态说明的初始范围：current 格式、owned 同一只读事务、精确开放月，正常 voucher 且 physical owner==basis，没有 frozen adoption、review/ancestor/reversal 特殊证明需求，并命中完整健康贡献。先保留完整 selector/forward/publication/source/fact/seal 证明；再对每个 exact version 核 **两向完整行集合**（version coverage、连续唯一 line_no、account/debit/credit/cashflow 完全相等、所有 shape/int64/balance/total）。成功后可汇总物理 voucher_line 的所有账户 debit/credit；保持非零 unmapped 风险、monthly_account 对照和期初独立状态。SQL SUM 溢出须保持 KernelError/checked 语义，不许 float/净额抵消。

这只产生“精确 voucher lines 成功证明”；不得写入完整 decoded source 缓存或冒充完整 dependency/adoption 证明。缺 contribution/body 或不适用特殊关系保留原完整 source reader，现有 malformed/checksum mismatch 必须拒绝。批次成功末尾才登记既有 Journal summary/rows；失败不能留新的半批金额证明。

此候选不是立即可实施的收益结论：现 full contribution reader 比原结果多搬运约3倍字节，装载所有分类/关系并核 direct dependencies；这些在金额职责不消费。直接接它可能减少 Outcome decode 却增加传输/解析/父源核验。brief 当前不预先读取贡献，与季度报表不同 HTTP 请求不能共享；现有 report cache 不自动给 brief 收益。无真实净 work/CPU 测量，暂保留方案，不建议为此先造新投影/decoder/aggregate-authority 框架。

## 全局消费者及版本边界

- brief：唯一 account_amounts 调用；只可候选替换内部 eligible normal 行证明，20项业务显示和焦点仍需要其真正消费的正文，FundsRead、opening、unmapped、完整 month scope 保持。
- funds：`FundsRead._verify_event_sources`（249）及 events（352）消费 saved balances/category/key/actual_date 等资金来源，不只凭证行。报表贡献的 rows/分类不是完整资金 balances 或期初账户身份投影；不得共享成资金正文证明。已有 verified_rows/lines 复用不代表这些字段已核。
- employees/assets：业务工资/卡片/member/settlement 与身份采用职责独立；不能用营业凭证行替代业务金额和冻结目录。本轮不重复资产3universes审查，不改其必要采用。
- reports：`report_projection._party_delta`（297）和 `Reports._report`（1058，贡献消费1433）已按精确来源使用贡献与原 resolver fallback。其任务是 party/profit/cash 分类，并非 Journal 完整月 Outcome.lines 等价；代码相似不是重复缺陷。opened/closed/frozen source 边界保持。
- core journal/default/detail、CLI/MCP：service 796/801 分派到 Dashboard；普通 core/save-result/detail 需要完整 typed result、关系和来源，不受新 owned amount proof影响。没有证据证明它们与 brief 同 snapshot 重复 full decode。
- owner preparation/close-review/final close：`periods._manifest` 和 `close_review.build_owner_review` 仍重建完整契约及业务审核，不能以老板标量替代完整 manifest。本轮未证实新重复。
- full integrity：integrity 1298 起独立 journal -> `_check_sources` -> contribution compare -> closes，先严格所有源后重建投影；repair maintenance 46/100 前后独立 integrity，不能使用普通页的 anchored line proof 作为修复 authority。
- backup/registered validators：沿 schema_bundle 完整 integrity 入口保留相同全源/冻结/投影核验；无同 owned 页缓存复用授权。
- fixed-v1：content_history_context 165/175 分派 fixed contribution/journal；`report_projection_v1._party_delta`（202）使用独立 V1Reads/resolver，没有当前贡献 shortcut。不得把当前 reader或当前 owned 缓存接进去；历史使用其固定编码/模型/来源核验。

## 若后续批准该窄候选，必要验证范围

先新增一组实际 normal/open amount 等价及 work 对照（rows/bytes/VM/真正 result/contribution decodes），增加页外、未映射账户、非利润账户、缺整 version/line、重复 line_no、cashflow/account改变、balanced单凭证改动和跨凭证抵消、seal/fact/source/pub/anchor/body损坏、非规范源/重复key/int64。工作量必须同时计新增 contribution/parents 读取，不能仅计少解码的 Outcome。

特殊分支用现有 `test_owner_brief_amounts.py` 与 `test_report_open_contribution.py` 中 review/closed adoption/reversal/move/连续 correction 的真实 fixture，证明按职责 fallback 后业务金额相同；owned/unowned/fixed 分派与 cold/warm 失败缓存另加实际断言。不需要机械全仓回归；此处只有建议，没有执行次数/通过数或500ms承诺。

本轮未发现现有 account_amounts 的新完整性缺陷；发现的是“标量消费者仍需整月 lines 证明”的必要成本及 eligible normal 的未测架构候选。不能把本审计归为已经排除所有汇总问题。

## 独立追加判定：lines-only 严格原生 JSON 模型

根节点另提出不接贡献、仅在现 header/fact/seal/raw digest 检查后物化 lines。当前直接落地应拒绝，与上面的贡献候选分别判定。

`stored_json.verify_outcome_bytes`（59）明确保留全层 `loads_unique`：结果原文与同记录的 digest 可以一起损坏，raw SHA 匹配不能证明原文 canonical 或没有重复对象成员。`publication.CONTENT_FIELDS`（12）仅包含 sequence/subject/previous/calculation/mode/post/baseline/voucher，没有独立 result_digest。calculation ID/input identity 和正常 voucher version identity 绑定输入及版本关系，也没有替这份结果原文摘要建立独立 anchor；seals 的存在检查不提供另一个结果摘要。

因此“raw SHA 等于 c.digest”只说明两者相等，不是 canonicalbytes 确证。静态可复现触发是给合法 Outcome 的非 lines 对象（如 values）或嵌套对象注入重复 key，同时令 c.digest 等于修改后 raw SHA；保持原 calculation ID、publication、seals、物理 lines。原 `loads_unique` 拒绝，忽略其他字段的 lines-only 模型缺少拒绝该错误的依据。此触发本轮未运行，不标为实测。Pydantic 严格字段类型也不等于全层唯一 JSON key 规则；未知/跳过字段的重复键不能只靠 strict=True 检查。

要安全缩投影，需要另外已认证的不可变精确原文摘要，或者继续全层唯一 key/原 JSON 语义检查。前者是贡献/冻结等不同职责的独立依据，当前这批开放结果没有现成强保证；后者已由现 decoder 执行，新增投影解析还会二次解析，收益未测。不为此造 parser/框架、不扩 proof API。fixed-v1 和等价非 canonical 源仍走固定/原完整 decoder，任何 lines proof 都不能发布 fullbody/input/adoption 成功缓存。
