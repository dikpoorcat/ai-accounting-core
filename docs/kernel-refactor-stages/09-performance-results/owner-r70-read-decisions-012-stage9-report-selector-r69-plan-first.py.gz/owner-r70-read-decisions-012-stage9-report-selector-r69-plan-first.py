"""Actual main48 report SQL/VM only; readonly, no native timer or business writes."""

import hashlib
import json
import sqlite3
from pathlib import Path
from types import SimpleNamespace

from ai_accounting.kernel import report_projection
from ai_accounting.kernel.query_reads import QueryReads
from ai_accounting.kernel.storage import _active_fact_reads

ROOT = Path(__file__).resolve().parents[1]
DB = ROOT / ".tmp/stage9-owner-main48-r63/91310000123456789S/company.sqlite"
PERIOD = (2019 - 1) * 12 + 11  # Exact r68 quarterly report's one open month.


def size(value):
    if value is None:
        return 0
    if isinstance(value, str):
        return len(value.encode("utf-8"))
    if isinstance(value, bytes):
        return len(value)
    return 8


class Cursor:
    def __init__(self, cursor, entry):
        self.cursor, self.entry = cursor, entry

    def __iter__(self):
        return self

    def count(self, row):
        if row is not None:
            self.entry["returned_rows"] += 1
            self.entry["returned_value_bytes"] += sum(size(value) for value in row)
        return row

    def __next__(self):
        return self.count(next(self.cursor))

    def fetchone(self):
        return self.count(self.cursor.fetchone())


class Connection:
    def __init__(self, connection):
        self.connection, self.entries = connection, []

    @property
    def in_transaction(self):
        return self.connection.in_transaction

    def execute(self, sql, parameters=()):
        self.connection.set_progress_handler(None, 0)
        plan = [tuple(row) for row in self.connection.execute(
            "EXPLAIN QUERY PLAN " + sql, parameters
        )]
        entry = {
            "sql": sql, "parameters": list(parameters), "plan": plan,
            "sqlite_vm_steps_rounded_100": 0,
            "returned_rows": 0, "returned_value_bytes": 0,
        }
        self.entries.append(entry)

        def progress():
            entry["sqlite_vm_steps_rounded_100"] += 100
            return 0

        self.connection.set_progress_handler(progress, 100)
        return Cursor(self.connection.execute(sql, parameters), entry)


def run(reuse):
    with sqlite3.connect(DB.as_uri() + "?mode=ro", uri=True) as raw:
        raw.row_factory = sqlite3.Row
        raw.execute("PRAGMA query_only=ON")
        raw.execute("BEGIN")
        connection = Connection(raw)
        # The isolated diagnostic supplies just the reader state used by this
        # helper. Actual strict publication checks still execute against source.
        engine = SimpleNamespace(store=SimpleNamespace(
            registry=SimpleNamespace(content_version=2)
        ))
        reads = QueryReads(engine, connection)
        reads._snapshot_active = True
        token = _active_fact_reads.set(reads)
        original_guard = report_projection._owns_current_selector_snapshot
        try:
            if not reuse:
                report_projection._owns_current_selector_snapshot = lambda *a: False
            rows = report_projection._authoritative_rows(
                connection, "open", PERIOD, reads=reads
            )
        finally:
            report_projection._owns_current_selector_snapshot = original_guard
            _active_fact_reads.reset(token)
            raw.set_progress_handler(None, 0)
            raw.rollback()
        return {
            "sql_calls": len(connection.entries),
            "sqlite_vm_steps_rounded_100": sum(
                item["sqlite_vm_steps_rounded_100"] for item in connection.entries
            ),
            "returned_rows": sum(item["returned_rows"] for item in connection.entries),
            "returned_value_bytes": sum(
                item["returned_value_bytes"] for item in connection.entries
            ),
            "verified_publication_ids": len(reads._verified_publication_ids),
            "source_rows": len(rows),
            "source_tuple_fields": sorted({len(row) for row in rows}),
            "source_sha256": hashlib.sha256(repr(rows).encode("utf-8")).hexdigest(),
            "sql": connection.entries,
        }, rows


independent, old_rows = run(False)
selected, new_rows = run(True)
assert old_rows == new_rows
assert independent["verified_publication_ids"] == selected["verified_publication_ids"]
out = {
    "mode": "read_only_actual_SQL_plan_VM_no_native_timing",
    "root": str(DB), "period": PERIOD,
    "independent": independent, "selected": selected,
    "exact_17_field_source_tuples_equal": True,
}
(ROOT / ".tmp/stage9-report-selector-r69-plan.json").write_text(
    json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8"
)
print(json.dumps({key: value for key, value in out.items()
                  if key not in {"independent", "selected"}}, ensure_ascii=False))
for name, work in (("independent", independent), ("selected", selected)):
    print(json.dumps({"path": name, **{key: value for key, value in work.items()
                                      if key != "sql"}}, ensure_ascii=False))
