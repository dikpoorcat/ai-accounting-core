# 资产闭期采用 scope 只读归组结论

本轮决定：保留原路径。静态可推导联合读取候选，但没有测得合并净收益，也没有证明现有返回值足以严格派生全部子 scope。未修改生产、未运行 SQL、测试、服务、构造或计时。

## 实际调用与工作量

来源为 `.tmp/stage9-resident-r75-main48-profile.json` 及对应 assets profiler：assets native 为 394.0754 / 365.7561 / 392.4469 ms；work 为 1216 SQL、13303 行、8323368 字节、875900 VM。以下时间属于已有 profile，不能当新的静态审查测量。

- A：`_asset_card_sources -> asset_member_events(kind=asset_activation) -> _selected_asset_owner_events -> _selected_accounting -> close_accounting_many`：一次完整采用批，37.5509 ms。
- B：分页后的 `_assets -> _selected_asset_member_heads -> _asset_owner_metadata_selection -> close_accounting_many`：一次完整采用批，66.2505 ms。
- C：`_asset_card_sources -> verified_adopted_head_identities -> close_adopted_results_many`：一次仅 adopted-results 批，5.6923 ms。

真实结构为“两次完整采用 + 一次 adopted-only”，不是三次相同完整读取。内部 `_read_accounting` 共 141 次；`_family` 实际 47 次，既有共享没有重复搬运三份 family。三次 `_accounting_authority` 合计 2.7447 ms。SQL 记录未保存每次 subject 参数，不能把静态集合关系标成实测交集。

## 集合与消费边界

A 通过 subject/calculation 双定位以及独立 frozen asset-owner declarations 查 activation owner；B 采用相同双定位和 frozen 权威，同时包含 activation 与 consumption 两种 owner。静态 A 属于 B 的候选集合。A 在分页之前用于资产状态/购置来源，B 只在 fast-assets 且所选页面非空时消费；提前无条件构造 B 会让 summary-only、空页和 fallback 分支新增不必要来源读取。

C 的身份集合还包含 opening/reimbursed/disposal/project/labor 等 asset-card 来源，而且只要求其精确 head posting-month adopted 依据；不属于 B 的完整采用 scope。不能把 C 的成功证明升级为完整 voucher/历史采用证明。

`close_storage._read_accounting` 对完整 scope 同时证明 expected publications 和独立 physical voucher-ID 集合。现有 authority 批的 voucher 返回值只有 ID 集合，完成的 slice 也不携带独立 physical voucher -> subject 分区。因此只按 B 的 adopted IDs 过滤得到 A，不能证明 A 的独立 physical voucher 集合相等：跨 subject 的错误采用在联合集合上可能互相抵消。此为拟议派生方案的缺失条件，不是现有路径的已证实缺陷。

安全派生至少需要同 owned current transaction、高水位及 storage 摘要一致、独立物理 voucher 的 subject 分区、每个子 scope 的 publication/voucher 精确覆盖、成功末尾一次登记；失败不得留下半批缓存，不能遍历全部缓存寻 superset。此处增加字段/分区和预读的收益未验证，本轮不实施。

## 公共消费者边界

完整采用还供 `_selected_accounting` 的 core 详情/关联、资金 `_verify_event_sources`、Journal 冲正原凭证核验消费；各自来源集合与资产 A/B 不同，没有共同 superset 收益证据。完整 integrity、repair、backup 需要完整独立来源核验。fixed-v1 保持其独立逐月 reader，不套当前 owned 缓存。directory/bucket 调用次数不能等同物理重复读取：既有 `_prime_buckets` 仅取缺失精确 key，空 bucket 不发 SQL。

本结论只证明调用、静态集合与必要边界，未排除未来职责窄处的联合读取优化，也不证明它有净收益。停止该组工具；不为 141 次函数调用数量引入新框架或缓存。
