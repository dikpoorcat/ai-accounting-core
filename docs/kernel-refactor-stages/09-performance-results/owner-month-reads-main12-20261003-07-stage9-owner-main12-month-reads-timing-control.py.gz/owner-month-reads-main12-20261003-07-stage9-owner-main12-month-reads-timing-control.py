import ctypes,json,subprocess,time
from ctypes import wintypes
from pathlib import Path
workspace=Path(__file__).resolve().parents[1]
ready=workspace/'.tmp/stage9-owner-main12-month-reads-timing-ready.json'
start=workspace/'.tmp/stage9-owner-main12-month-reads-timing-start.json'
report=workspace/'.tmp/stage9-owner-main12-month-reads-browser.json'
control=workspace/'.tmp/stage9-owner-main12-month-reads-timing-control.json'
assert not start.exists() and not control.exists()
signal=json.loads(ready.read_text())
assert signal['pid']==36804 and Path(signal['output']).resolve()==report
kernel=ctypes.WinDLL('kernel32',use_last_error=True)
kernel.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD]
kernel.OpenProcess.restype=wintypes.HANDLE
kernel.CloseHandle.argtypes=[wintypes.HANDLE]
kernel.WaitForSingleObject.argtypes=[wintypes.HANDLE,wintypes.DWORD]
class FILETIME(ctypes.Structure):
    _fields_=[('low',wintypes.DWORD),('high',wintypes.DWORD)]
kernel.GetProcessTimes.argtypes=[wintypes.HANDLE,*([ctypes.POINTER(FILETIME)]*4)]
def times(handle):
    values=[FILETIME() for _ in range(4)]
    assert kernel.GetProcessTimes(handle,*[ctypes.byref(v) for v in values])
    return dict(zip(('creation','exit','kernel','user'),[v.high*2**32+v.low for v in values]))
browser=kernel.OpenProcess(0x0400|0x00100000,False,36804)
peer=kernel.OpenProcess(0x0400|0x00100000,False,48684)
assert browser and peer
state={'status':'waiting_for_quiet_interval','browser_pid':36804,'existing_demo_pid':48684,'scope':'no_build_regression_construction_instrumentation','started_epoch':time.time(),'existing_demo_modified':False}
try:
    state['peer_before_quiet']=times(peer)
    time.sleep(10)
    state['peer_before_timing']=times(peer)
    assert all(state['peer_before_quiet'][k]==state['peer_before_timing'][k] for k in ('kernel','user')),'Existing demo busy; timing gate withheld'
    assert kernel.WaitForSingleObject(browser,0)==258
    with start.open('x',encoding='utf-8') as handle:
        json.dump({'status':'pure_timing_released','epoch':time.time()},handle)
    state['released_epoch']=time.time()
    print(json.dumps({'status':'timing_released'}),flush=True)
    assert kernel.WaitForSingleObject(browser,600000)==0,'Browser timing exceeded ten minutes'
    assert report.is_file()
    state['peer_after_timing']=times(peer)
    state['existing_demo_idle_during_timing']=all(state['peer_before_timing'][k]==state['peer_after_timing'][k] for k in ('kernel','user'))
    timing=json.loads(report.read_text(encoding='utf-8'))
    state['browser_status']=timing['status']
    state['status']='timing_finished' if state['existing_demo_idle_during_timing'] else 'timing_retained_with_peer_activity'
except BaseException as exc:
    state['status']='control_failed'
    state['error']={'type':type(exc).__name__,'message':str(exc)}
    raise
finally:
    kernel.CloseHandle(peer)
    kernel.CloseHandle(browser)
    state['finished_epoch']=time.time()
    with control.open('x',encoding='utf-8') as handle:
        json.dump(state,handle,indent=2)
    print(json.dumps({'status':state['status'],'browser_status':state.get('browser_status')}),flush=True)
