"""Private full response comparison: verified original vs indexed copied database."""

import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp/stage9-build-source-r33-release"
BOOK = ROOT / ".tmp/stage9-release-main-48-verified-r32.json"
CLONE = ROOT / ".tmp/stage9-report-count-covering-r33/company.sqlite"
OUTPUT = ROOT / ".tmp/stage9-report-count-response-parity-r33.json"


def normalized(value):
    if isinstance(value, dict):
        return {key: normalized(item) for key, item in value.items() if key != "generated_at"}
    if isinstance(value, list):
        return [normalized(item) for item in value]
    return value


def differences(left, right, path=""):
    if type(left) is not type(right):
        return [path]
    if isinstance(left, dict):
        return [new_path for key in set(left) | set(right)
                for new_path in (differences(left.get(key), right.get(key), path + "/" + key)
                                 if key in left and key in right else [path + "/" + key])]
    if isinstance(left, list):
        if len(left) != len(right):
            return [path + "/length"]
        return [new_path for n, (a, b) in enumerate(zip(left, right))
                for new_path in differences(a, b, path + f"/{n}")]
    return [] if left == right else [path]


def main():
    if OUTPUT.exists():
        raise RuntimeError("Preserve output")
    sys.path.insert(0, str(SOURCE / "src"))
    from ai_accounting.kernel.daemon import _prepare_static_runtime
    from ai_accounting.kernel.dashboard import Dashboard
    from ai_accounting.kernel.engine import Engine
    from ai_accounting.kernel.permissions import adopt_private_file
    from ai_accounting.kernel.storage import Store

    book = json.loads(BOOK.read_text(encoding="utf-8"))
    identity = book["company"]
    bundle = _prepare_static_runtime()[0]
    original = Store(identity["path"], bundle, identity["id"], identity["database_id"], taxpayer_id=identity["taxpayer_id"])
    for suffix in ("-shm", "-wal"):
        sidecar = Path(str(CLONE) + suffix)
        if sidecar.exists():
            adopt_private_file(sidecar)
    clone = Store(CLONE, bundle, identity["id"], identity["database_id"], taxpayer_id=identity["taxpayer_id"])

    def private_clone_validator(connection):
        row = connection.execute("SELECT company_id,database_id,taxpayer_id FROM identity WHERE id=1").fetchone()
        if row is None or tuple(row) != (identity["id"], identity["database_id"], identity["taxpayer_id"]):
            raise RuntimeError("Clone company identity changed")

    clone.validate_connection = private_clone_validator
    left = normalized(Dashboard(Engine(original)).quarterly_report(2019, 4, preparation="deferred"))
    right = normalized(Dashboard(Engine(clone)).quarterly_report(2019, 4, preparation="deferred"))
    diff = differences(left, right)
    encode = lambda value: json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()
    result = {
        "status": "diagnostic", "source": str(SOURCE), "book_report": str(BOOK),
        "only_excluded_field": "generated_at", "same_response": not diff,
        "difference_paths": diff[:20],
        "original_sha256": hashlib.sha256(encode(left)).hexdigest(),
        "indexed_clone_sha256": hashlib.sha256(encode(right)).hexdigest(),
        "caveat": "Clone schema validation bypassed only because private indexes alter its registered structure; identity and report content checks remained.",
    }
    OUTPUT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(OUTPUT)


if __name__ == "__main__":
    main()
