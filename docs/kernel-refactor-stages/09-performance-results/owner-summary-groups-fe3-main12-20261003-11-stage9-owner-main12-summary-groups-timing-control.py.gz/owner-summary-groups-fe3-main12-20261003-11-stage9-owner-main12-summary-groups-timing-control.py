"""Pause only our synthetic main120 copy while the qualified main12 timer runs."""
import ctypes
from ctypes import wintypes
import json
import subprocess
import time
from pathlib import Path

workspace = Path(__file__).resolve().parents[1]
ready = workspace / '.tmp/stage9-owner-main12-summary-groups-timing-ready.json'
start = workspace / '.tmp/stage9-owner-main12-summary-groups-timing-start.json'
report = workspace / '.tmp/stage9-owner-main12-summary-groups-browser.json'
control = workspace / '.tmp/stage9-owner-main12-summary-groups-timing-control.json'
assert not start.exists() and not control.exists()
copy_pid, browser_pid, tests_pid = 14312, 24072, 31560
kernel = ctypes.WinDLL('kernel32', use_last_error=True)
nt = ctypes.WinDLL('ntdll')
kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
kernel.OpenProcess.restype = wintypes.HANDLE
kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
kernel.WaitForSingleObject.restype = wintypes.DWORD
kernel.CloseHandle.argtypes = [wintypes.HANDLE]
nt.NtSuspendProcess.argtypes = [wintypes.HANDLE]
nt.NtSuspendProcess.restype = ctypes.c_long
nt.NtResumeProcess.argtypes = [wintypes.HANDLE]
nt.NtResumeProcess.restype = ctypes.c_long
class FILETIME(ctypes.Structure):
    _fields_ = [('low',wintypes.DWORD),('high',wintypes.DWORD)]
kernel.GetProcessTimes.argtypes = [wintypes.HANDLE, *([ctypes.POINTER(FILETIME)]*4)]
def times(handle):
    values = [FILETIME() for _ in range(4)]
    assert kernel.GetProcessTimes(handle,*[ctypes.byref(v) for v in values])
    return dict(zip(('creation','exit','kernel','user'),[v.high*2**32+v.low for v in values]))
def description(pid):
    ps=f"Get-CimInstance Win32_Process -Filter 'ProcessId={pid}' | Select-Object ProcessId,ParentProcessId,CommandLine | ConvertTo-Json -Compress"
    result=subprocess.run(['powershell','-NoProfile','-Command',ps],capture_output=True,text=True,check=True)
    return json.loads(result.stdout) if result.stdout.strip() else None
copy=description(copy_pid)
browser=description(browser_pid)
assert copy and copy['ParentProcessId']==22836 and 'scripts/prepare_stage9_main120.py' in copy['CommandLine'] and 'stage9-main120-candidate-cache-group-20261003' in copy['CommandLine']
assert browser and browser['ParentProcessId']==36652 and 'scripts/benchmark_stage9_browser.py' in browser['CommandLine'] and 'stage9-build-source-owner-summary-groups-20261003-release' in browser['CommandLine']
tests=description(tests_pid)
if tests is not None:
    assert tests['ParentProcessId']==52464 and 'pytest' in tests['CommandLine'] and 'stage9-report-source-group.xml' in tests['CommandLine']
tests_handle=kernel.OpenProcess(0x0400|0x00100000,False,tests_pid) if tests is not None else None
copy_handle=kernel.OpenProcess(0x0800|0x0400|0x00100000,False,copy_pid)
browser_handle=kernel.OpenProcess(0x0400|0x00100000,False,browser_pid)
assert copy_handle and browser_handle
state={'status':'waiting_for_qualified_ready','copy_pid':copy_pid,'browser_pid':browser_pid,'scope':'owned_synthetic_processes_only','started_epoch':time.time()}
suspended=False
try:
    deadline=time.monotonic()+3600
    while not ready.exists():
        assert kernel.WaitForSingleObject(browser_handle,0)==258, 'Browser qualification exited before ready'
        assert time.monotonic()<deadline,'Ready wait timed out'
        time.sleep(1)
    signal=json.loads(ready.read_text())
    assert signal['pid']==browser_pid and Path(signal['output']).resolve()==report
    while tests_handle and kernel.WaitForSingleObject(tests_handle,0)==258:
        assert kernel.WaitForSingleObject(browser_handle,0)==258, 'Browser exited while waiting for regression'
        assert time.monotonic()<deadline, 'Regression wait exceeded ready deadline'
        time.sleep(1)
    state['affected_regression_finished_before_timing']=True
    if kernel.WaitForSingleObject(copy_handle,0)==258:
        assert nt.NtSuspendProcess(copy_handle)==0,'Unable to pause owned copy'
        suspended=True
        state['copy_paused_epoch']=time.time()
        state['copy_times_before_timing']=times(copy_handle)
        time.sleep(10)
    else:
        state['copy_already_finished']=True
    with start.open('x',encoding='utf-8') as f:
        json.dump({'status':'pure_timing_released','synthetic_copy_paused':suspended,'epoch':time.time()},f)
    state['timing_released_epoch']=time.time()
    print(json.dumps({'status':'timing_released','copy_paused':suspended}),flush=True)
    assert kernel.WaitForSingleObject(browser_handle,600_000)==0,'Timed browser exceeded ten-minute pause window'
    assert report.is_file(),'Timed browser exited without final report'
    timing=json.loads(report.read_text(encoding='utf-8'))
    state['browser_status']=timing['status']
    if suspended:
        state['copy_times_after_timing']=times(copy_handle)
        state['copy_cpu_unchanged']=all(state['copy_times_before_timing'][k]==state['copy_times_after_timing'][k] for k in ('kernel','user'))
        assert state['copy_cpu_unchanged'],'Suspended copy consumed CPU during timing'
    state['status']='timing_finished'
except BaseException as error:
    state['status']='control_failed'
    state['error']={'type':type(error).__name__,'message':str(error)}
    raise
finally:
    if suspended:
        result=nt.NtResumeProcess(copy_handle)
        state['resume_status']=result
        state['copy_resumed_epoch']=time.time()
        if result!=0:
            state['status']='resume_failed'
    if tests_handle:
        kernel.CloseHandle(tests_handle)
    kernel.CloseHandle(copy_handle)
    kernel.CloseHandle(browser_handle)
    state['finished_epoch']=time.time()
    with control.open('x',encoding='utf-8') as f:
        json.dump(state,f,ensure_ascii=False,indent=2)
    print(json.dumps({'status':state['status'],'control':str(control)}),flush=True)
    assert state.get('resume_status',0)==0,'Owned synthetic copy resume failed'
