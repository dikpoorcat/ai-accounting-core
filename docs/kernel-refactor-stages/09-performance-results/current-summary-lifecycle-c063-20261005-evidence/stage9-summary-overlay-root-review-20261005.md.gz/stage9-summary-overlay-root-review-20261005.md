# Root 对候选的静态复核

尚未应用、导入或测试。8c98 三组测量仍未完成；保留 fixed source。

1. Dashboard `_position` 是账户子集汇总消费者，但主 brief 本次未命中；不能拿此改法解释其慢样本。
2. JSON 形状判定必须再收紧：仅检查 canonical 与 Hashable 不足以排除解码别名。例如 canonical `["party",1]` 与 `["party",true]` 是不同字符串，解码 tuple 却相等；`1.0` 也与 `1` 相等。Dashboard 旧流程会按解码后的 key 净额，新 raw-string 汇总必须对 bool/float/None 等有歧义的组件退回原 fullrows，不能错算正负余额。需要别名反例；这只是候选缺陷，没有生产复现。
3. 私有 `_accounts` 在非 owned 的纯 summary 分支也应准确筛选，或明确拒绝这一内部组合；目前 fallback 返回全部 account lines。生产 Dashboard 传 `_validate_party_keys=True` 会走原 fullrows，仍需让新内部合同自洽。
4. 惰性 tail 保留逐月认证和算术次序；失败、未知和原有 full materialization 必须有真实组回归。不能因数学 fixture 成功就认定来源核验未退化。
5. 行查找和 compact 候选仍未实施；没有实际收益证据，不扩大本组。

实施前修正以上草稿问题，完成真实 owner/current 与外部/固定历史分支对照；代码收敛后统一回归及实际工作量、五页验证。不要重跑不受本组影响的 120 月银行关账宽测试。
