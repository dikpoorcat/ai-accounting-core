# root 决策稿：仅 summary base + overlay

未应用、未导入候选源码、未运行测试。dashboard候选整文件另为 `stage9-summary-overlay-dashboard-candidate.py`。具体草稿为 `stage9-summary-overlay-candidate.patch` 与可阅读整文件 `stage9-summary-overlay-candidate.py`；数学与工作量测试草稿 `stage9-summary-overlay-tests-draft.py` 预期放入既有 `test_report_party_summary.py`，未修改该文件。

| 候选 | 必须保留 | summary可省的工作 | 本轮建议 |
|---|---|---|---|
| checkpoint base + delta overlay | 原opening/history判断；精确account/party基准；每月权威源、root、完整格式与classification采用核验；真正party_balance_rows完整nets | 第二cutoff不再copy全部基准dict、展开全部非零tuple或重分类未变party；每cutoff独立changed-key overlay | 优先评估本patch |
| selected_open_line精确索引 | 全contribution/source/parents认证、精确voucher+line_no、重复候选列表和反向金额核验 | 每个查询反复扫描已认证content.rows | old累计19ms，列未实施候选 |
| report_party_splits按line索引 | 同行全部relations及原顺序、role/state/party/金额校验，纯函数任意Mapping语义 | 每个查询反复筛同一resolution所有关系 | old累计10ms，列未实施候选 |

具体patch从现有uncached算法提取 `_party_balance_inputs`，仍由同一算法选checkpoint和逐月open/closed源。尾部用私有惰性迭代器逐月认证、立即供消费者计算；fullnets保留基准copy、逐月净额和非零tuple的完整物化。原 `report_party_checkpoint_totals` dict cachekey和值保留。summary另存同一checkpoint的per-account/per-sign classified totals，只在现有 `_owns_current_selector_snapshot` 的真实QueryReads/current registry/activeContext/transaction/close_reader/publication_reader全条件满足且engine非None时使用。全net普通/固定v1/其他连接/无owned路径仍走原full消费。

dashboard._position已复核为account子集summary消费者；patch同时将该支接到现有classify_financial_position的_net_party_lines。基准保存(account,report_line)维度，filter先按account筛后汇总，不能在共用report_line上筛account。projected_fallback/journal_accounts/obligation/residual原逻辑保持；只把fallback_accounts整个完整集的纯金额作为private lines注入，其他账号仍走原party净额/未知传播，避免同account的部分summary与其他rows重新抵销。

summary基准一旦分类成功，后续cutoff不遍历它，tail触碰key以旧精确净额撤销旧abs贡献、加上新净额对应行贡献。它只copy数量有限的报表行dict。unsupported基准或tail key退回完整nets，保留“未知账户可被后续变动冲为零”语义；只有tail全部消费成功才发布classified base和summary结果缓存。已认证月份/header缓存仍遵守现有独立成功proof语义。缓存原dict从不被overlay更改。Dashboard原party_balance_rows会在filter之前解码全部非零JSONkey；draft保留同范围解码形状证明：第一次按基准建立坏JSON/不可分类key集合，后续只检查变动key与已知坏key最终是否非零。任何坏形状、None/unhashable key、非canonical解码别名、非int金额都保留原fullrows/classify路径，避免吞掉原异常或unknown。Reports纯raw-key摘要路径仍不进行JSON展示解码。

测试草稿明确在已认证month reader边界和guard判定边界建立unit fixture，不放宽生产guard。它实计基准dict `copy/items/__iter__/get` 工作与RECLASS实际分类查找，在12/48/120月不同历史义务量、固定触碰键的后续cutoff断言未变基准访问不增长；同样验证full明细随后仍copy且保全全部party。还有不同party正负、同key穿零再恢复、cutoff/lanes交错以及late None/exception不缓存成功summary。

实施前必须补齐真实book集成：实际QueryReads owned/current使用快路；otherconnection/noactivecontext/noBEGIN/v1/engineNone使用full；期初RECLASS非零、无checkpoint已有历史、negative/nohistory、checkpoint换年、未知/unsupported在尾部抵消与不抵消、晚月来源/root损坏，以及Reports normal/open/closed、Dashboard季度页与close readiness现有业务结果等价。old525 brief profile与current brief函数计数均未命中_position/party_balance_rows，主brief用_brief_amounts；此处是全局适用支而非已测brief慢样本根因。现有源完整性测试必须保留，不把draft数学fixture当实际auth证据。实际pool需确认SQL/rows/bytes/source核验量无减少，summary额外展开/分类量降低；本稿没有证明wall改善。

取舍：候选1有明确可消除的每cutoff历史展开，结构改动在current report_projection和dashboard._position的单一消费支，风险是共用读取职责提取及不同消费者错误/fallback顺序，应以真实book和full明细结果对照收敛。候选2/3收益证据较弱、涉及异常重复索引语义，暂不一起实施。compact会扩大私有来源接口/测试改动，本轮仅记录，不进行大接口改造。源码与生产测试继续冻结，等root同版三组完成后决定。

需审阅风险：draft惰性tail把认证与消费者相连，未知None以内部yield None表示并立刻结束；保持原full消费逐月算术次序。summary对unsupported的fallback可能再次执行已认证的月选择语句，但不消费未认证字段。罕见合成畸形payload需特设异常顺序对照，不能假定通常writer数据足够证明所有错误语义。源码草稿仅是审查输入，尚非可合入验证结果。
