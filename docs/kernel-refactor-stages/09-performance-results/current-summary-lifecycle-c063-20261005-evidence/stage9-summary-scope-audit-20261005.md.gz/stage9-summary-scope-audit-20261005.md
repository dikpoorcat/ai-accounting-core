# 只读静态排查：汇总、来源集合与精确行查找

审查源码为当前 reader-group-converged（8c98）。只读源码和既有诊断小字段，未开库、服务、浏览器或运行测试；未改生产源码或测试。以下均为候选，不是 reports 516.3ms 超线根因或已验证收益。

## 1. 优先：认证往来基准 + 变动键 overlay

- 位置：`report_projection.py:902,922,939,997-1011,1046`；调用为 `Reports._report:1227` 的期初/期末 position summary。`dashboard._position:2755` 也只将这些 rows 按 fallback_accounts筛选后送2840分类，最终只返回金额/问题，属于account子集summary消费者；完整 party_balance_rows 接口与非owned/fixed-v1路径仍保留。
- 已证实：8c98 同快照缓存认证 checkpoint dict，但每 cutoff 仍 `.copy()`、更新 tail、构造完整非零 tuple，再在 `_party_balance_position_lines` 遍历全部 account/party。同一基准的两次汇总仍展开未变历史。旧525 profile 两次 uncached self 76.57ms，含多个区段，不能归因 checkpoint 或当作可节约值。
- 最小结构：从 uncached 提取共用“定位并认证 base、逐月认证 tail”的私有职责。fullnets 消费者继续 base.copy + tail + tuple；summary 消费者共享 base 精确键 dict 与已分类 line totals，各调用仅持有自己的 changed-key dict，按键撤去旧余额贡献、加上新余额贡献。先净额再按符号/abs分类，绝不先合并不同 party。
- 伪实现：`old = changed.get(key, base.get(key, 0)); new = old + delta; lines -= class_contribution(account, old); lines += class_contribution(account, new); changed[key] = new`。同键重复 delta 逐条处理；基准和其他 cutoff 的 overlay 不变。只复制数量有限的报表行 totals，不复制全部 party dict。
- 初次 base 建立仍必须读取、认证和遍历所有 checkpoint 行；后续 cutoff 的额外汇总工作应仅随 tail/触碰键增长。基准缓存必须键入认证月份/源根及同一 owned connection snapshot 的身份，不跨请求；只有所有被消费结果认证成功后发布 summary 成功缓存。采用失败、None、异常不能成为零或成功缓存。
- 保留原起点判断、opening RECLASS 阻断、历史缺口、last usable checkpoint 选择、每月 closed/open 选择、source 不同语义、engine=None 的 `_stored_month` 独立核验、cutoff<0、无历史空结果。非 owned/current/v1 请求保留旧完整路径；不要仅靠 `_snapshot_active` 判断当前 reader 权限。未知/unsupported 情况保持原 fallback 或原异常，不新增默认值。
- 风险：同一账户不同 party 正负余额不能抵消；余额穿零、归零后又恢复、同键多条变动、不同 cutoff 顺序会击穿错误的累加共享对象。已有 `test_report_party_summary` 只数原始 `CheckpointRows.__iter__`，看不到 dict.copy、tuple 构造或完整分类遍历，不能证明本候选工作量。

## 2. 次优先：精确贡献行索引

- 位置：`report_open_contribution.selected_open_line:604-639`，仅 `report_projection._party_delta:490` 和 `Reports._report:1458` 两个生产调用。current 池 reports 2067 调用；旧525 profile cumulative 19.05ms（含自身与后续 runtime resolution），收益尚未验证。
- 每次精确 `(原凭证版本, line_no)` 查找仍遍历该 content 的全部 `rows`。在经过 anchor digest、完整 decode shape、全部 source bindings/parents 认证后的私有 decoded content 内建立一次索引，值为原顺序的候选列表，不能单值覆盖重复行。未查询的重复行不提前报错；查询到重复时维持 `line_duplicated`。缺失仍 None，反向行交换debit/credit及全部金额/cashflow比对保持。
- key 必须同时含 voucher identity 和 line_no；不同 voucher 相同 line_no 不可混合。对非确切 str/int 请求键、异常形状或不在受控 decoder 产生的对象上走原扫描，避免 dict hash 改变 bool/int等价、unhashable值或原错误顺序。私有索引不进入 canonical、摘要、保存内容或 API 输出；不得供固定v1使用。

## 3. 次优先：按行关系索引

- 位置：`query_semantics.report_party_splits:754-767`，每行筛完整 `line_relations`。current reports 938调用，旧 profile cumulative10.05ms，尚无证据说明它是主要成本。`report_party_needs_ancestry:848` 有同类扫描，若索引同一 resolution 应一起复用。
- 调用范围：current `report_projection._party_delta`、Reports fallback、dashboard `_position`、`resolve_line_parties`，另 report contribution writer/query_reads 的 ancestry 判断。固定历史使用独立 `report_party_v1.py`，不得改。
- 最小结构：仅受控私有 resolution 建立精确 line_no→原顺序关系列表；同 line 所有关系必须保留。lookup 后仍运行原 role/state/party/金额完整检查。不要往通用 resolution dict 增加可被 `**resolution` 输出的新键；可用私有 dict 子类属性或独立私有包，由受控 constructor/resolver显式建立，普通 Mapping继续扫描。
- line_no不是exact int、relation非Mapping等异常对象不强行索引；保持原比较、短路、异常次序。不要对关系 role 提前过滤，未匹配行的异常 role 原来不会被消费。不在纯函数上隐式memoize可变的任意caller Mapping。

## 4. 后列：冻结事实集合的中间对象

- 位置：`reports._closed_report_fact_sources:352-393`；读取并认证所有119个financial_reports readiness块，current返回块1,727,257值字节。genexpr总49428调用涵盖badtype any和extend两个生成器，不能写成49428条来源记录。旧profile cumulative47.09ms包含必要section读取，不是可消除Python成本。
- 生产消费者只需ID union和每ID最早close：`_report_references:395`、`_frozen_unused_classification_ids:538`、`Reports.closed_period_coverages:973`、`Reports._report:1111-1157`。可以一次生成私有包 `ids/first_close`，避免逐次 `{close_period,reference_id}` 的中间对象和后续重复转换；但收益证据比候选1弱。
- 不能直接把当前返回list去重而宣称无差异：测试显式断言每个月精确rows。若实施，必须重构全部上述生产消费者及这些私有接口测试；包仍保全ID union/earliest，有需要保留原顺序的消费者则提供每月原ID列表。不要再保留两套运行来源接口。
- `retain_ids` 只过滤消费输出，不能跳过任何block或任何ID格式检查。完整包与retain包的缓存key必须不同（或只缓存完整包后投影）；`_issues_only` 当前窄profile/tax/carry集合不能污染正常full reference缓存。`complete_references()` fallback必须取得完整union，早年未使用classification必须获得真实earliest_close。`closes` 外部传入顺序可能非升序：earliest须min而非first，输出顺序要明确保留。坏types、空str、晚月坏ID、异常不能因过滤或compact而放过；不依据repairable close_reference替代原readiness源。

## 全局边界与必要验证

- CLI/MCP通过service的 `report/preview_report_export/confirm_report_export` 到Reports完整规划；dashboard季度页open采用 `_issues_only=True`，closed ready计划和正式导出走完整路径。共享私有读取职责可覆盖这些调用，展示summary与正式明细分开消费；不能让dashboard窄集合成为正式报表完整采用证明。
- close的 `check_report_readiness` 也是Reports `_issues_only=True`，但在正式事务/close上下文，不能获得owned只读快路径权限；写出的readiness/flow/root与冻结内容不变。full verify/repair/backup要从原始source重建/对照全部业务，继续 `compare/require_report_projection`、`compare/require_report_flow`、`compare_open_contributions`，不得用summary缓存取代。fixed-v1保留content_history_context独立reader/party路径和逐月proof，不交给新私有package。
- shared QueryReads close accounting目前 exact key字典lookup，未发现每次遍历全部cache。`verify_balance_scope`有scope集合线性包含检查，正常页调用证据不足且scope数很小，不能宣布瓶颈。query_semantics.cached_own只扫该来源ancestry不是全cache，reports只调用1次；不建议本组扩大修改。asset_member_events过滤已有全scope有明确源码路径，但无normalpool本次调用证据；不能按代码相似宣称问题。资产238 slices=119 full owner+119 adopted的不同证明；report stored_month13调用=12 distinct months；open voucher完整来源/方向核验都是必要工作，保留。
- 业务反例：不同party正负同账户、单party穿零/归零再恢复、多月重复键、开闭来源不同、cutoff乱序、不同checkpoint/年度、无checkpoint有历史、unsupported/opening、engine=None、负cutoff；晚月root/来源缺失、坏digest、badtype、filter外坏ID、retain→full及issues→normal；精确voucher相同line_no、查询/未查询重复行、反向行、金额/cashflow异常、多关系同一line、排除role、未匹配异常role、caller非标准键形状。
- 工作量反例：固定touch-key数量，历史party从12/48/120月增长，summary在第二cutoff不能多copy/展开/classify未变party；首次必要认证字节/行允许增长并如实记录。实际统计summary消费者的base遍历、changedkey处理、物化fullnet条数，不只数SQL或原始checkpoint iter。full明细仍包含全部非零party。贡献/关系索引需大单一payroll来源多行与多voucher实例，索引构建一次、lookup候选访问随选中行增长；所有来源/root认证数量不减少。compact不能减少119认证blocks，仅限制派生中间对象数量；原raw业务响应除既定时间字段外全等。
- 建议集中改法优先1，再按工作量证据选2/3；4需先确认Python派生分配的实际占比。四者分属基准汇总、贡献行、关系、readiness来源集合，不宜用一个通用缓存/万能summary API覆盖不同证明职责。Dashboard._position的适用范围已复核，但old525 brief profile及current brief函数计数均未命中这一支，本次brief走_brief_amounts，不能宣称已覆盖其实际性能。无DDL或frozen格式变化，无跨请求业务cache。
