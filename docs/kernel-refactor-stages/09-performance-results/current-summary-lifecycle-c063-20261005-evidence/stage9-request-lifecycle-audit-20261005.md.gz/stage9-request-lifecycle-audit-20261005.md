# 第9阶段：请求对象生命期同类审查

本次审查对象是8c98五页共同读链及其关账证明、snapshot缓存和resident pool；2026-10-05随后仅获准窄改`close_storage._private_overlay`与`test_close_physical_batch.py`。本文件不把旧host的GC结论继承到当前主库。

## 结论与证据边界

静态确定的一处问题是原`_private_overlay`局部递归函数`append`的自引用闭包。函数对象→closure cell→函数对象形成环；同一函数的另一个closure cell持有`maps`列表，列表持有全部prior叶map。返回的ChainMap销毁后，该环仍可能保留认证parts/positions map及其内容，直到正常循环垃圾回收处理。QueryReads结束时换成空dict不能主动断这个额外环。这是滞后释放路径，不是跨请求业务缓存。

当前main48 reports index2=516.3ms（API474.9/context57.5/tail40.6），main120 assets index29=637.6ms（API604.2/context249.4/tail32.8），同页其余median457.2/p95 477.6。上述样本没有与暂停重合的GC事件、generation或对象规模证据；**不能据此宣称GC导致慢样本、该修复已消除慢样本或预计节省多少ms**。pool instrumentation的SQL/rows/bytes/decode不是纯wall因果证据。此次没有运行浏览器、profile或纯计时。

## 五页与必要存活

| 链条/位置 | 必要存活与现有结束行为 | 本轮判断 |
|---|---|---|
| HTTP Handler→LocalService.dispatch/_dispatch→Engine→Dashboard（service.py:487/522，http.py:51/81/84） | service/pool为进程对象；Engine与domain/action bound methods为本次dispatch对象；HTTP响应被json序列化并写出，Handler未保存结果到service/pool | Engine.commit_guard closure持service，但service无请求Engine回边；未发现该链的请求环 |
| brief/funds/employees/assets→Dashboard._snapshot（dashboard.py:1705）→QueryReads.snapshot | 查询、核验与页面组装必须共享同一SQLite snapshot；结束先清dashboard，再清reads与transaction | 现有finally完整，不重复修改 |
| quarterly_report（dashboard.py:2313）→QueryReads.snapshot→Reports | 直接持reads，不创建dashboard helper图；report caches限同一snapshot | 不适用dashboard helper环；同样可能调用close storage overlay |
| `_Snapshot`→ClosedPeriods/Journal/Calculations/FrozenFacts/DashboardMetadata→snapshot（dashboard.py:268；dashboard_reads.py:954/985/1029/1589/1671/1699；dashboard_metadata.py:45/255/351） | 存在正常请求内回边；lazy views需要读snapshot。正常退出`release:323`清`__dict__`；初始化BaseException也先release | 回边已断。不能把已有释放遗漏重新当新问题 |
| QueryReads（query_reads.py:848/852/910） | parts、headers、slices、positions、relations、report caches等成功证明必须保留到本请求末；finally reset ContextVar token并_reset全部业务/proof容器，非owned移除authorizer | 未发现其容器保存QueryReads自身/loader callback的回边；外部仍持reads时已失去旧proof缓存 |
| Store._snapshot_connection（storage.py:307）→ResidentReadPool.borrow（resident_reads.py:105） | idle entries仅path/signature/connection/ownedflag；pool最多4连接；native statement/page缓存为连接资源，不是业务结果缓存 | finally清trace/progress；非owned清authorizer；遗留事务rollback，owned异常discard；未发现idle entry保存snapshot/reads |
| `_OwnedReadGuard`（runtime.py:88）与_owned_read_transaction:184 | connection持guard，guard只有permit，不持connection/store/reads；permit允许本线程一次BEGIN/ROLLBACK并结束清理 | 稳定guard不构成业务图回边。保留原授权与事务约束 |

ContextVar token对嵌套作用域保存前一个reads是必要语义，现有finally恢复；未发现正常五页把复制的context交给持久任务。常驻catalog observer、server Handler class/service closure和SQLite原生连接资源属于服务寿命，不把它们误判成跨请求业务缓存。异常traceback可能临时持frame的一般Python行为不构成当前代码已证实的持久保留问题。

## Close proof与缓存对象

`CloseHeader`、CloseAccountingSlice/CloseAdoptedResultsSlice/CloseMaterialSlice是冻结dataclass，其中业务字典/tuple不指回reads。`_AccountingAuthorityBatch:134`持本次connection和认证scope/roots/publications/vouchers，由batch读局部变量持有；结果slice不保存authority，也没有authority→reads回边。

`_MaterialSqlOutcomeBatch`与`_OpenVoucherScopeHeads`（query_reads.py:54/89）有reads/connection/token引用，资格和精确scope需要这些引用；它们为局部操作句柄，不被reads缓存反向保存。scope成功缓存保存已验证标识与ordinal，不保存heads对象。

完整核验的`VerifiedCloseArchive`/`_CloseLookup`（verified_close_archive.py:31/65）持pairs、connection与lease；lease没有反向archive引用。`verified_source_lease`在finally reset ContextVar+close，archive.lookup仍严格核对同事务、同集合与原始行。它属于fullverify/repair/backup/close复用完整认证源的职责，不是五页owned普通snapshot的SAVEPOINT复用路径；不因生命周期排查削弱这些证明或改fixed-v1。

## 实际同类排查与窄修

原递归overlay用于当前close storage单期会计读（`_read_accounting:1072`的parts/positions）、多期会计读（`_read_accounting_many:1387`的parts/positions）和跨月source reference（`reference_leaves_many:1571`的staged parts）。不同来源证明即使共用helper也仍各自必要：asset238 slices是119 fullowner+119 adopted-only，不是238重复同proof；月选择/完整来源核验保持原状。

已改`_private_overlay:116`：用局部pending list迭代展开，逆序push standard ChainMap.children，再按原左到右顺序取leaf。保留`type(mapping) is ChainMap`限制；custom subclass整体作为leaf；重复leaf、空map、leaf原引用都保留；fresh仍是唯一新writes map；prior None仍直接返回fresh；不迭代leaf keys或复制leaf内容。两条局部list在函数正常结束时释放，没有局部函数自引用环。没有改任何caller、cache资格、proof逻辑、v1、事务或pool。

同类局部函数复核包括query_reads.relations_many/report_line_relations_many、close_storage.reference_leaf.family、report_open_contribution的loader、query_semantics.resolve_calculation_relations局部helpers。query_semantics.source_records本已用显式stack；其他检查到的helper不自引用，不互相递归，解析结果也不保存loader callback。dashboard_funds.FundsRead持snapshot但snapshot不持该reader；未发现同型遗漏。本审查是对指定读链的静态引用审查，不宣称所有Python/SQLite内部对象均无环。

root本轮应用新的summary候选时还发现`_party_key_shape_problems`内部`stable_identity`局部递归自引用。它是新候选引入的小closure环，没有捕获认证大map；不属于8c98慢样本的已有对象图。root负责把它提到report_projection模块级私有函数，同组消除；本agent没有修改root负责的文件。不能把此小环与原overlay保留整份parts/positions的环等量归因。

## 定向验证及未验证项

新增8个定向case：

- 未遍历leaf map：0/1024 unrelated keys，禁止__iter__/keys/items；断言嵌套standard ChainMap展开的每个leaf原引用/空map/重复map/顺序，以及custom subclass特殊lookup、fresh私有写入、原leaf更新可见、prior None。
- 两种真实owned业务读取lane×12/48/120次overlay：每次局部owner退出后weakref立即为空；同一snapshot内保留真实三月采用结果(1,1,0)，full accounting保持100分voucher结果，复读相等。snapshot仍活时proof maps存活；退出后即使reads变量仍存在，旧parts/positions weakrefs为空。未调用gc.collect，未禁用/冻结GC，未改变阈值。

仓库venv运行新增定向selection：**8 passed，22 deselected，10.19s**。首次运行因新增段落插到旧record_property语句之前产生NameError，已把旧记录语句放回原测试；重跑上述8case全部通过。两文件Ruff：**All checks passed**。原test_private_overlay_reduces_actual_lookups...的业务采用/full voucher、lookups、SQL/VM/rows/bytes/JSON全部断言原样保留；本轮未再运行旧测试或宽组，交给root统一受影响组验证。

待root统一检验：原两lane实际work断言、后月故障不发布prefix、unowned/single/v1路径、五页同版实际SQL/rows/bytes/decode对照与必要新pure timing。此修复预计消除flatten产生的隐藏持有者，展开工作只随ChainMap结构/leaf引用数增长；必要认证数据加载仍可随历史增长。是否影响五页暂停频次或wall需实测，不能由weakref通过推算。
