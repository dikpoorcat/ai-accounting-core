"""Owner money amounts retain proofs without consuming bank matching presentation."""

import json
from copy import deepcopy

import pytest
import test_banking as banking
import test_platforms as platforms
from stage9_metrics import measure_work
from test_funds_historical_account_identities import source
from test_integrity_content import damage
from test_opening_continuation import book as _opening_book

from ai_accounting.kernel.business_queries import BusinessQueries
from ai_accounting.kernel.contracts import KernelError
from ai_accounting.kernel.dashboard import Dashboard
from ai_accounting.kernel.dashboard_funds import FUND_TYPES, FundsRead, _sum, funds

bank_book = banking.book
platform_book = platforms.book
opening_book = _opening_book
MONTH = "2026-09"
AMOUNTS = {
    "total_fen", "bank_fen", "cash_fen", "payment_platform_fen", "inflow_fen",
    "outflow_fen", "net_change_fen", "internal_transfer_fen",
}


def summary(engine, period=MONTH):
    with Dashboard(engine)._snapshot(period) as snap:
        # Match the brief's preceding complete month-amount proof.
        snap.month_journal.account_amounts()
        return funds(snap, summary_only=True)


def legacy_summary(engine):
    """Execute the actual retired bank work on the same reader, without mocks."""
    with Dashboard(engine)._snapshot(MONTH) as snap:
        snap.month_journal.account_amounts()
        read = FundsRead(snap)
        movements = read.account_summary()
        bank = read.bank_summary()
        assert bank["transaction_count"] > 0
        accounts = [*read.account_rows.values(), *read.omitted_account_rows.values()]
        return {
            "total_fen": _sum(accounts, "closing_fen"),
            "net_change_fen": _sum(accounts, "net_change_fen"),
            **{
                FUND_TYPES[category] + "_fen": _sum(
                    [item for item in accounts if item["type"] == FUND_TYPES[category]],
                    "closing_fen",
                )
                for category in FUND_TYPES
            },
            **{key: movements[key] for key in (
                "inflow_fen", "outflow_fen", "internal_transfer_fen",
            )},
        }


@pytest.mark.parametrize("unrelated_pairs", [4, 104])
def test_amount_equivalence_and_real_retired_bank_work(
    bank_book, unrelated_pairs, record_property,
):
    engine, save, publish, _ = bank_book
    banking.opening(save, publish)
    banking.opening(save, publish, bank="zero-bank")
    banking.funding(save, publish)
    entries = [banking.entry()]
    for index in range(unrelated_pairs):
        entries.extend([
            banking.entry(f"unrelated-in-{index}", amount=1),
            banking.entry(f"unrelated-out-{index}", amount=-1),
        ])
    banking.statement(save, publish, entries)
    narrow_work, narrow = measure_work(engine, lambda: summary(engine))
    old_work, old = measure_work(engine, lambda: legacy_summary(engine))
    assert narrow == old == {
        "total_fen": 1000, "bank_fen": 1000, "cash_fen": 0,
        "payment_platform_fen": 0, "inflow_fen": 1000, "outflow_fen": 0,
        "net_change_fen": 1000, "internal_transfer_fen": 0,
    }
    detailed = Dashboard(engine).funds(MONTH)["data"]
    assert narrow == {key: detailed[key] for key in AMOUNTS}
    assert detailed["bank_account_count"] == 2  # Independent zero-account source remains.
    assert detailed["bank_statement"]["transaction_count"] == len(entries)
    assert len(detailed["collections"]["statements"]["items"]) == min(20, len(entries))
    for counter in ("sqlite_vm_steps", "returned_rows", "returned_value_bytes"):
        assert narrow_work["counters"][counter] < old_work["counters"][counter]
    for counter in ("typed_fact_json_decodes", "calculation_result_json_decodes"):
        assert narrow_work["counters"][counter] <= old_work["counters"][counter]
    narrow_children = sum(row["calls"] for row in narrow_work["sql"]
                          if "fact_bank_statement_entries" in row["statement"])
    old_children = sum(row["calls"] for row in old_work["sql"]
                       if "fact_bank_statement_entries" in row["statement"])
    assert narrow_children < old_children
    record_property("owner_money_scope_work", json.dumps({
        "original_rows": len(entries), "narrow": narrow_work["counters"],
        "legacy": old_work["counters"],
        "bank_child_sql_calls": {"narrow": narrow_children, "legacy": old_children},
    }, sort_keys=True))


def test_all_money_channels_and_internal_transfer_keep_business_amounts(platform_book):
    engine, save, publish, _ = platform_book
    banking.opening(save, publish)
    banking.funding(save, publish)
    save("cash_funding", "cash-capital", {
        "period": MONTH, "actual_date": MONTH + "-01", "cash_account_id": "cash",
        "owner_id": "owner", "funding_kind": "capital", "amount_fen": 200,
    })
    save("platform_funding", "platform-capital", platforms.funding_data(amount=500))
    save("bank_platform_transfer", "transfer",
         platforms.transfer_data(direction="bank_to_platform", amount=100))
    publish("cash-capital", "platform-capital", "transfer")
    actual = summary(engine)
    assert actual == {
        "total_fen": 1700, "bank_fen": 900, "cash_fen": 200,
        "payment_platform_fen": 600, "inflow_fen": 1700, "outflow_fen": 0,
        "net_change_fen": 1700, "internal_transfer_fen": 100,
    }
    detailed = Dashboard(engine).funds(MONTH)["data"]
    assert actual == {key: detailed[key] for key in AMOUNTS}
    assert detailed["collections"]["movements"]["page"]["total_count"] == 5


@pytest.mark.parametrize("corruption", ["outcome", "fact_seal", "publication", "zero_state"])
def test_cold_and_previously_warm_summaries_still_reject_money_source_damage(
    bank_book, corruption,
):
    engine, save, publish, _ = bank_book
    banking.opening(save, publish)
    banking.funding(save, publish)
    assert summary(engine)["total_fen"] == 1000
    row = source(engine, "opening-bank-a" if corruption == "zero_state" else "funding")
    if corruption == "outcome":
        damage(engine, "calculation", "UPDATE calculation SET outcome=? WHERE id=?",
               ('{"values":{},' + row["outcome"][1:], row["id"]))
    elif corruption in {"fact_seal", "zero_state"}:
        damage(engine, "fact_seal", "DELETE FROM fact_seal WHERE fact_id=?",
               (row["fact_id"],), foreign_keys=False)
    else:
        damage(engine, "calculation_publication",
               "DELETE FROM calculation_publication WHERE calculation_id=?",
               (row["id"],), foreign_keys=False)
    for _ in range(2):
        with pytest.raises(KernelError) as failure:
            summary(engine)
        assert failure.value.code == "content_integrity_failed"


def test_uncertain_opening_retains_none_after_actual_source_verification(
    opening_book, monkeypatch,
):
    engine, _, _, package, _ = opening_book
    package([
        ("opening_cash", "cash", {"cash_account_id": "cash", "balance_fen": 100}),
        ("opening_equity", "equity", {
            "equity_kind": "paid_in_capital", "balance_fen": 100,
            "holder_or_basis_id": "owner",
        }),
    ])
    original = BusinessQueries._selected_accounting

    def uncertain(*args, **kwargs):
        # Exercise a legal downstream uncertainty using a genuinely proven source;
        # this is not the SQL/work comparison and does not invent an opening body.
        selected = deepcopy(original(*args, **kwargs))
        through = selected["through_period"]
        candidate = next(item for item in through["state_results"]
                         if item["kind"] == "opening_package")
        through["state_results"].remove(candidate)
        through["unestablished_state_selections"].append({
            "reason": "state_selection_unavailable", "candidates": [candidate],
        })
        return selected

    monkeypatch.setattr(BusinessQueries, "_selected_accounting", uncertain)
    actual = summary(engine, "2026-01")
    assert set(actual) == AMOUNTS
    assert actual["total_fen"] is actual["cash_fen"] is None
    assert actual["bank_fen"] == actual["payment_platform_fen"] == 0
    with Dashboard(engine)._snapshot("2026-01") as snap:
        full = funds(snap, sections=set())
    assert actual == {key: full[key] for key in AMOUNTS}


def test_retired_matching_display_does_not_disable_core_match_checks(bank_book):
    engine, save, publish, _ = bank_book
    banking.opening(save, publish)
    banking.funding(save, publish)
    banking.statement(save, publish, [banking.entry(amount=999)])
    assert summary(engine)["inflow_fen"] == 1000
    detailed = Dashboard(engine).funds(MONTH)["data"]
    assert detailed["bank_statement"]["inflow_fen"] == 999
    assert detailed["bank_statement"]["review_state"] == "pending"
    with pytest.raises(KernelError) as failure:
        banking.reconciliation(save, publish, [banking.match()])
    assert failure.value.code == "bank_match_difference"
