# r71 资产读取与历史证明范围审查

本项先以 GPT-6.1 Sol、xhigh 完成只读架构审查，阅读 AGENTS.md、FRONTEND.md、整体架构和已有 r70 profile，随后按根线程明确授权实施并作合成库窄验证。前半保留 r70 静态审查的依据与建议，实施结果在后半；最终固定源码关联组实际为103通过191.75秒，不与早期29、15、35等回执相加。本代理不操作真实data、不运行服务/浏览器/构建或大型native样本，不据小fixture耗时宣称500ms达标。

## 结论与处理顺序

资产默认页目前把三种职责连在一起：全对象身份和状态、完整金额汇总、本页的最近计提月份与友好说明。前两种必须保持全 scope；第三种只进入分页后的卡片，并不参与金额或筛选。`fast_assets` 已从独立核验的 carrying 余额取得累计计提，从本期贡献取得当月计提；它的旧批次成员明细不再用于累计金额。

最有希望的首批修改，是保留 owner/member 必要证明，把闭期成员目录的独立依据改用**已核验冻结根中原本保存的完整 `asset_batch_adoptions` 与 `membership_digest`**，同时停止为纯元数据消费者先展开每个旧 owner 的宽 Outcome。它不需要新 checkpoint、DDL、修改冻结 v4 内容或回写历史。随后可以把最近状态的请求放到分页之后，按能够影响本页字段的 owner 逐组认证；无独立覆盖依据或不能确定剩余范围时，走原完整路径。

不能仅把 `asset_ids` 改为默认 20 个，不能从 `asset_batch_member` 直接取每个资产最新一行，也不能把某个 owner 的摘要存在当作该资产没有其他成员记录的证明。现有 `complete_owners=True` 仍会选择所有 owner 并先解码全部旧 owner；单改 20 不解决这一组织问题。

先完成一个相关修改组：资产默认页职责拆分、当前格式的 owner 元数据读取、闭期成员目录独立认证、必要的候选缺行守卫及工作量回归。核心历史查询、关账、完整核验、维修、备份与固定 v1 保持完整原路径。终端提前停止只在下述覆盖条件成立时启用；不确定时保留完整范围。不得把完整历史测试删掉来获得通过。

## 既有实测与源码绑定

依据为 `.tmp/stage9-resident-r70-main48-profile.json`，其中 `operations.assets.work.sql` 是实际 SQL 工作量记录，不是 `statement_work`。固定源目录为 `.tmp/stage9-build-source-owner-r70-release`，合成主48根为 `.tmp/stage9-owner-main48-r63`。原诊断请求是 `Dashboard.assets('2019-12', limit=20)`。本轮没有运行或手算 SQL 参数。

| 已有记录 | 数值 | 解释边界 |
| --- | ---: | --- |
| assets native 三样本 | 411.485 / 387.945 / 366.631 ms | 原 r70 native 诊断，不是 browser 验收 |
| `_asset_card_sources` inclusive | 160.660 ms | 含 activation owner/member 选择 |
| `_selected_asset_owner_events` 两调用 inclusive | 157.705 ms | 两次分别属于 activation 与 head 路径 |
| `_selected_asset_member_heads` inclusive | 152.056 ms | 含其内部 owner 选择；不能和上一行相加 |
| 完整成员头 SQL | 1,176 行；1,015,512 B；86,600 VM；35.617 instrumented ms | 同时含 activation/consumption，不能把1176全部写成计提成员 |
| owner Outcome 元数据批取 SQL | 两调用；96 行；1,145,264 B；3,600 VM；10.861 instrumented ms | 行少但宽；并不代表全部CPU成本只在 execute |
| owner 凭证选择 SQL | 两调用；143 行；75,814 B；65,600 VM | 保留原始、复核采用及冲正关系 |
| activation 正向 locator | 48 行；700 VM | 成员目录定位，不是不存在证明 |
| complete owner 主体 locator | 96 行；400 VM | locator 本身不是主要扫描成本 |
| 独立 card head SQL | 96 行；27,121 B；61,400 VM | acquisition/lifecycle/project 身份必要范围，不按相似代码改成员工 witness |
| 全 assets 请求 | 703,700 VM；11,501 行；8,448,529 B | 385个结果体解码、2,591次stdlib JSON读取；零完整close manifest解码 |

这些 inclusive 时间存在嵌套，不能用160+157+152推算可节省时间。`asset_members_many` 有三次调用，实际 `frozen_members_many` 只有两次；已有同快照成功 owner 成员复用在工作，不能再将第三次函数调用计为第三次完整 proof。

读取时以下四文件与 r70 固定副本字节哈希相同：

| 文件 | SHA256 |
| --- | --- |
| business_queries.py | AACEB656A93C70D3981ED974710C0CC0B974DB16CF8085109C0D73A3D32D8DAD |
| dashboard_reads.py | 00E282C27A03477F89E04361777FD8A800F994D16838D1D7145E81E08F5D7A5F |
| asset_batches.py | 760B040F722C3B70F42218DD114D2F9DEE573F874D0BBACDCF2D7B9EF4E97C42 |
| query_reads.py | 0C7481AC3D8D8F93A6F325B72F18D3558702288FAA9A6E952AB0B48C0AB95C32 |

当前 dashboard.py 全文件已被根线程修改 brief 片段，不能称全文件固定 r70。对 `_asset_card_sources` 开始至 `_quarterly_view` 之前的资产函数片段作只读文本比较，当前与 r70 固定副本完全相同。

## 职责、所有调用方与处理决定

| 位置/调用方 | 实际消费 | 决定 |
| --- | --- | --- |
| dashboard._asset_card_sources（当前约4069） | acquisition/batch/lifecycle/project 全对象身份；activation 成员覆盖及撤去；scalar 精确事实 | 全对象枚举与状态必要。独立 head 的冻结双定位臂、current缺源、subject/fact缺行与withdrawal核验全部保留 |
| dashboard._assets（约4191）金额部分 | 完整 acquisition journal、rooted carrying、当月 contribution、独立旧单笔计提与 fallback 批次金额 | 全 scope 必要；默认20、筛选、summary_only都不能减少总额范围 |
| `_assets` 的 full_batch_events | opening/disposed/不满足fast条件的资产，其历史金额与零影响说明 | 保留完整现有 member body proof，不能套用fast元数据路径 |
| `_assets` 的 head_batch_events | fast资产最近计提期间、最近正向结果的zero_reason、内部batch参考 | 元数据职责；当前却在分页前对所有fast资产展开完整历史，应拆到分页后 |
| `_assets` 的 batch_references / selected_heads | batch_references已不进入公开item；仍扩大随后asset_members_many owner集合 | 待改：保留字段实际消费所需的latest positive及精确期间见证，不因已退出output的内部参考额外要求完整member body。activation身份在card枚举路径继续完整认证 |
| `_Snapshot.asset_member_events`（约398） | `(kinds,subjects,asset_ids)`精确范围缓存；已有全范围可过滤子范围 | 现有复用有效；subset先查再superset查不会合并证明。宜组织单次明确union读取，不用松散子集成功宣称union完整 |
| business_queries._selected_asset_owner_events（991） | 为两条成员路径选择through-period原始/冲正voucher事件与state-only owner | 当前两次历史选择重叠。候选定位与最终authority应分清；不是所有调用都能改成latest owner |
| business_queries._selected_asset_members（915） | 全owner frozen_members_many后过滤；core business_status和普通成员历史消费 | 完整历史公共语义必要，保持原路径；不在此全局加LIMIT/latest |
| business_queries._selected_asset_member_heads（1038） | 唯一生产调用在_assets；先complete owner，再检查全目录，最后过滤asset IDs | 宜换为当前格式专用元数据消费者。它已共享本调用解码的owner，不能把再次取消内部body读当作新收益 |
| business_queries._selected_accounting（406） | 凭证/采用/零行状态/独立冻结subjectfilter/物理voucher与publication双authority | 共用完整读取必须保留。元数据消费者不能仅用最后subject head替代全部原始/冲正/复核事件；`include_lines=False`也不能绕过voucher authority |
| dashboard_reads.adopted_head_metadata / verified_adopted_head_identities | 独立头身份、精确pub/header/seal/adopted leaf；不证明未读Outcome | 保留当前窄proof边界；不能写入full source proof集合。这里没有_asset_card_sources定义 |
| dashboard_reads.Calculations.selected | 通用独立及成员选择，core/page按需来源选择 | 保留通用调用语义；不按资产默认页改所有消费者 |

五页静态调用图中，`_selected_asset_member_heads`只由资产页调用。`_asset_card_sources`用于资产页和 `_long_term_assets`；后者本次检索只有定义、没有生产调用，因此不能把它写成 brief 现行默认路径。brief使用完整金额汇总；funds/employees/reports通过各自journal/贡献/结算来源取得资产相关金额，并不调用资产卡片历史头选择。相同kind不是相同消费职责，不能替换这些路径的全scope金额proof。

资产默认及分页集合是 assets/projects；显式详情还有 settlement_events。`dashboard_pages.SECTIONS`和前端 AssetsQuery都不接受source_history。Dashboard.assets中仍有source_history旧分支/注释，但被validate_page挡住，不是现行可调用资产历史端点。正式历史/来源能力仍由CLI/MCP business_status、trace和核心查询保留，不能以退出看板输出为理由删除它们。

## 根因一：金额消费者被用作元数据定位器

`_selected_asset_member_heads`调用complete_owners后进入 `_selected_accounting`。后者为了state_results先通过metadata读取每个直接采用owner的完整Outcome，用line_count判断哪些owner没有凭证；包含有凭证owner的state_adoptions也先读。这符合通用会计结果消费者，但fast卡片金额已经由另一条独立路径完成，最近期间/友好说明不需要每个旧owner的lines/balances正文。

闭期已有充分的替代保存依据：

1. `periods.py`构建v4关账时，对asset_batch_owner先调用完整frozen_members，再保存`asset_batch_adoptions=[{owner_calculation_id,membership_digest}]`。它与直接adopted_results一起冻结。
2. `close_storage.write_close`只把ACCOUNTING_FIELDS等大字段移出small；asset_batch_adoptions仍在root.small。`verified_header`核对保存root摘要、逻辑身份、公司/数据库和source marker。
3. `close_storage.read_section(header,'asset_batch_adoptions')`返回已认证small完整字段，不依赖close_reference候选行。它是真实冻结来源，不能和派生目录自己的hash混淆。
4. 准确owner候选仍需与本期adopted_results中role=asset_batch_owner的精确身份集合一致，并保留pub/header/seal/source/frozen leaf关系。完整核验已有declared owner集合等于batch_owners的检查。元数据路径不能只拿一个digest就视其余owner不存在。
5. 一个必要owner的**完整、按position排序的成员目录**按既有结构规范化后，与冻结membership_digest比较，可发现少成员、重复/改序/改summary等目录损坏，而不必为获得该目录摘要再解码同一旧owner宽Outcome。成员calculation/header、seal、dependency、foreign ownership和精确所选成员来源仍按原核验。

开放期没有冻结membership_digest authority，必须读取严格owner Outcome并认证完整目录。当前格式以外、fixed v1、自定义reader/rule注入及不能确定覆盖范围的情形，保留原完整读取。上述闭期窄proof不证明旧owner正文完整性，不把成功登记成full source/outcome proof；正文实际被金额/详情/history消费时继续严格读取。被消费目录损坏必须直接拒绝，不能把坏候选丢掉、用另一候选合并成功或吞错回退。

`asset_card_adoptions`只认证报销验收批次形成的单卡来源，不是monthly consumption最近状态checkpoint。rooted资产余额证明钱，不证明最近月份/zero_reason/activation身份。两者都不能替代本节的owner会员目录authority。

## 根因二：本页元数据在分页前收集，终端定位缺少独立覆盖

all_items只用cost/accumulated/monthcharge/status以及本期取得/启用/退出标志；filter与完整汇总均不读取latest_charge_period或charge_state_label。因此可先保留原完整枚举/金额/activation身份，构建all_items和page_keys，再仅为selected fast资产取得最近计提字段。summary_only或仅projects无需取得这些卡片字段；fallback资产的历史金额仍在分页前完整处理。

内部batch_references已不输出，但目前仍作为selected_heads输入。删去它作为额外member-body需求，不等于删除activation采用证明；后者在_asset_card_sources仍是全scope必要身份。真实消费的latest-positive zero_reason及latest-period精确头继续认证。当前代码的“latest”并非一个简单max：latest_charge_period取全部事件的最大calculation_period（含reversal），zero_reason取排序后最后一个positive，撤去仅按精确旧CID影响参考。不能把它们统一成最后publication而改变业务输出。

可实施的终端定位需要以下明确覆盖规则：

1. 从完整已验冻结asset_batch_adoptions和对应精确adopted/voucher集合，外加独立current/publication缺源候选，建立截至typed月份的owner事件完整身份范围。目录仅作正向定位，缺reference或member行不能消掉冻结owner。
2. 保留每个事件经authority绑定的source period、adoption period、voucher排序/方向及精确owner身份。先依据这些头部筛出仍可能改变某个本页字段的owner；不能只依赖member表返回哪些hit。
3. 对每个可能改变尚未确定字段的owner，认证其完整成员目录；即使该目录不包含目标资产，也必须经独立digest核验后才能当作该owner的真实negative。包含目标的必要成员精确来源/summary按消费者核验。
4. 只有全部目标字段已有见证、且余下owner的已绑定source period与原事件排序证明它们不能改变这些字段，才可以停止。较新的owner目录少行、零影响成员、同月纠错/review/restoration或方向关系无法确认，都不得被SQL排序隐藏。
5. 没有计提记录的资产、无法建立独立owner全集、source/current缺源、未登记身份或coverage不确定时，完整原scope读取或现有一次性fallback；unknown不变成零。已证实的必要来源损坏直接拒绝，不当成不确定性跳过。audit24原回退保持，不重试。

首批建议先以完整owner头身份+完整必要目录digest检查取代旧宽Outcome组织，并完成分页职责拆分。终端停止分支只有正面证明上述规则后才启用；否则目录仍完整检查。这一部分没有SQL计划或新VM实测，不声明能把1176减少到某个数字。

## 根因三：positive locator可能在严格核验前消失

这次只读确认两个不同的候选边界，尚未运行新负例，不能称为已复现缺陷：

| 位置 | 静态风险 | 最小处理/验证 |
| --- | --- | --- |
| `_selected_asset_owner_events(complete_owners=False)` | member→owner calculation→member subject都是JOIN；丢member/owner calc/member subject可让locator返回空 | 对仍必须消费的activation及fallback owner，用独立冻结owner/current source候选补定位，随后严格认证完整directory；不得以空hit证明不存在 |
| complete_owners subject-kind枚举及_selected_accounting的kind筛选 | 缺owner subject会在进入独立current/frozen守卫之前缩小候选 | 冻结small owner列表独立可见；开放source/current采用现有双身份思路，LEFT缺行作为损坏候选。不构造全库索引完整性假证明 |

区别是：普通引用分页只核验命中，不承诺索引全表无缺行；这里必要owner membership完整性关系到activation状态或本页metadata，不能借普通查询边界漏掉已独立定位的owner。本轮未实测单缺行分支。已有adopted独立资产头的缺pub/calc/subject负例不是这两个owner locator分支自动已通过的证据。

## 完整消费与固定历史保持

| 入口 | 必须保留 |
| --- | --- |
| CLI/MCP business_status / core `_business_status` | `_selected_asset_members`完整owner/member事件与金额/来源；公开合同中的完整asset_members历史不能缩为最近头 |
| Engine.trace | 保存的精确dependency graph、计算/凭证原始来源；不从新看板元数据推导历史 |
| Display._content_basis | 对实际monthly basis展开完整owner成员，保持关账准备与来源展开范围 |
| Periods.preview_close / close | 本期完整frozen_members、asset_batch_adoptions和card_adoptions；原冻结v4及approval/preview摘要不变 |
| integrity._check_sources / _check_closes | 完整owner/member正文、line slice/余额拼合、dependency、declared owner集合和frozen采用；完整verify不采用最近元数据优化 |
| Maintenance repair | 修复前独立源检查，修复后完整核验与repair revision；不自动补造冻结依据 |
| Backup/restore/verify_file/portable verify | 版本对应company verifier全库内容验证，不能凭页面成功交付备份 |
| fixed v1 / historical_content | asset_membership_v1、close_storage_v1及原采用检查；不改发布合同与固定模块，不用当前规则重算历史 |

既有`test_active_asset_head_rejects_damaged_older_membership`损坏旧activation目录；当前页真实使用activation身份，该拒绝语义仍需要。`test_ambiguous_owner_body_still_rejects_before_membership`当前开放owner重复JSON字段应继续拒绝。若将来缩小某段旧consumption正文scope，必须明确哪些正文不再被普通页消费，并以core/history/fullverify/backup仍拒绝的真实用例证明；不能直接删断言或把旧fixture失败改称通过。

## 初始修改建议与工作量回归范围

生产范围应集中在dashboard.py资产段、business_queries.py当前格式专用owner元数据/成员头组织、dashboard_reads.py仅必要的精确header/候选复用；query_reads若已有close_header/close_section足够则不修改。asset_batches完整checker、通用_selected_accounting公共合同、v1模块、freeze/app批准合同及其他页不改。复用限同一个owned只读事务、同一owner CID/冻结依据/范围；失败不缓存，partial成功不冒充union完整，不能引入跨请求cache。

必要测试从现有test_asset_owner_outcome_reads、test_adopted_asset_head_locator、test_asset_identity_reads族和active/frozen membership invariants选实际受影响分支，加新scope回归；不是机械重跑旧全组。新组至少覆盖：

- 默认20、下一页、精确非前20对象、筛选、summary_only/projects-only，所有成本/累计/当期/净值/status/count与完整基线等价；最近月份和zero_reason逐卡业务预期等价。
- 冷/暖snapshot：必要owner及member目录单缺行、member/owner calculation或publication缺行、owner/member subject缺行、dependency/seal/foreign owner、已冻结digest或summary损坏；选中坏候选不能被rank/drop隐藏，无半批成功proof。
- 有金额和零行/零影响owner、未开始/完全计提、无计提记录、期初与已退出fallback、未来合法posting不误消费其body、合法撤去及精确reversal、开放replace/闭期correction/无影响review/再次身份恢复、旧身份与无姓名对象。
- 固定v1、unowned snapshot、reader/rule注入仍走完整原路径；audit24一次回退不重复尝试。core/fullverify/close/repair/backup保持全历史拒绝必要源损坏。
- 增长用真正业务合成库：固定资产数量增加月份、固定月份增加资产数量，再覆盖每月新增资产形成的成员目录增长；至少包含接近主48的50对象×48月情况。不能仅加异kind噪声或对helper名字断言。
- 比較同请求原完整读取与新默认读取的完整业务输出，并记录actual VM、SQL调用、返回行/字节、owner/member结果体读取及严格JSON解码、必要owner proof数量。既要确认减少宽body/重复selection，也要确认新候选扫描没有吃回收益；不以少返回行或测试耗时宣称native/browser达标。

初始只读阶段没有新收益实测或单缺行复现。既有主48 profile支持定位“全历史会计结果选择用于本页metadata”的组织问题；下述授权实施与固定关联组补充小fixture证据，最终native/browser仍需根线程统一诊断。

## 已授权实施边界

根线程随后授权本代理仅修改business_queries.py、新test_owner_asset_metadata_scope.py，并允许更新test_asset_owner_outcome_reads两个失效的monkeypatch业务对照；根线程独立负责dashboard.py分页后置，以及后续公共money前向核验。初始静态记录保留；最终验证以实际固定103项关联组为准。

本批不实现终端提前停止：保留全部所选owner的完整目录核验，只减少旧闭期owner宽Outcome读取。专用selection用全部已认证small.asset_batch_adoptions独立定位闭期owner，精确identity header与publication/seal核验，再以close_accounting_many保留完整冻结采用/凭证authority。全部原始/冲正事件排序、无凭证state、review与source period分离仍与原完整消费者等价。开放current及没有独立冻结membership_digest的必要owner一批严格Outcome/完整目录核验；不能确定coverage、fixedv1、非owned snapshot或reader注入时只走原完整路径一次。该消费者不创建member/source正文成功proof，不把闭期membership摘要核验提升为Outcome正文核验。

新测试对照使用真实原_selected_asset_members消费者，比较事件实际业务字段及measure_work，不为测试引入产品fallback flag。旧activation目录损坏、开放owner重复字段、失败半批proof断言全部保留。新范围测试覆盖冻结与开放、零行、撤去/更正、单缺源和目录坏尾；真实月份增长只用小fixture，不运行大型主48或browser。

## 实施与实证状态

生产改动集中在business_queries.py。当前格式、owned只读事务的资产metadata selection不调用amount-oriented `_selected_accounting`：完整冻结small.asset_batch_adoptions定位全部owner，精确header/publication/seal与冻结adopted/voucher核对，完整成员目录绑定独立membership_digest；开放owner严格消费真实Outcome。成员目录LEFT读取真实calculation、fact_revision、subject及两类seal，目录中字符串相等不能代替来源存在。每个所选owner仍检查完整目录，不实现终端提前停止。该身份核验不发布旧owner/member正文成功proof。

同类排查实际复现旧完整资产消费者的locator缺陷：3月真实计提成员的owner calculation或subject单缺行，旧member JOIN返回成功；原窄负例是4失败/4通过。当前格式完整路径改用requested member kind对应owner kind的subject/calculation双身份，且在缩小scope之前从独立冻结small取得ownerCID并核真实header/publication/seal，即使calculation和subject同时被删除仍拒绝。asset_ids消费不能以可损坏member目录空hit推导不存在。代价是当前格式完整资产查询按requested owner kind核验所有必要owner完整源；不会为仅activation查询展开consumption Outcome，但精确冻结owner身份会完整取得。普通CLI/MCP/core完整成员与历史接口不是本次提速承诺；原v1/unowned及非当前authority注入仍沿原完整路径，正文损坏拒绝已有实际测试。

原fixture在2月28日启用，2月计提owner合法为空目录。repair1误把它称作有成员，失败原件保留。必要member/owner损坏改为先合法关闭2月，再正式计提及关闭3月；零owner测试单独验证合法空目录与owner当前发布身份，不能要求不存在的member。修复后的29项组于共享冻结owner helper进一步抽取前通过72.83秒；随后新增22项组实际19通过/3失败67.21秒。新增通过包括calculation与subject同时删除、owner fact/seal缺行、开放正数owner完整member目录删除、合法撤去/闭期更正、v1/unowned全文scope、冻结摘要/空/重复坏尾及真实1/3月增长。3失败均为开放正数owner voucher_current缺行，metadata/history/page错误返回成功。

这个指针问题属于公共当前采用边界。另用银行、工资、普通核算真实fixture实证accounting/current_publication六分支全失败；开放当前发布只作为calc/pub候选，selected_voucher_sql以实际voucher_current反向取得版本，缺指针之后非零当前结果被state过滤，必要事件消失。现有verify_current_voucher_publications只核实际选中版本的原/当前发布，不能证明未选中的必要版本存在。公开页定性实际为：银行与工资brief拒绝，funds与quarterly_report仍返回成功；季度报表原返回合同没有data键，pages-initial两fixture访问错误保留，pages-repair1才是有效定性。

最终owned `_current_accounting_heads`复用根线程的 `query_reads.verify_current_publication_voucher_heads`，不保留临时h/v JOIN字段或重复inline实现。cutoff/未来/闭期边界之后，独立current头和未独立发布成员所属的必要current owner分别传真实p.*。公共实现从已核pub.voucher_id LEFT取得真实current/version，核ID/期间/正向身份；normal指向精确正常采用计算，no-impact沿已认证previous publication链找到正常采用，允许保留对应旧version，拒绝回指更早已替换版本。缺头异常只严格读精确Outcome区别合法清零保留编号与非零缺指针，不写body/adoption成功。独立immutable reversal最新版本仍须匹配真实current pointer。闭期保留独立frozen authority。

根线程将同一前向职责接入Journal、报表开放累计与完整current-reader源核验，避免纯版本selector反向查询漏掉必要来源。最终公开bank/payroll资金、简报、季度报表均有未损坏真实成功baseline和缺指针必须content_integrity_failed断言；资产metadata/history/page/member_publication也直接验证必要current owner头。维修两类入口在normal/reverse缺指针时拒绝，完整数据库dump及read_repair_revision保持；备份使用真实fixture bundle注册的当前company verifier，先正常verify_file成功，再缺头拒绝且源不变。

最终103组中的小fixture工作量只诊断组织方式，不是native/browser验收：闭1月metadata/full分别0/8个结果体、0/5066字节、700/1200 VM、34/49返回行、10385/18058返回字节；闭3月0/20个结果体、0/16218字节、2100/3100 VM、76/113行、27059/49402字节，完整事件业务字段相同。开放3月metadata/full分别4/22个结果体、6565/18890结果体字节、2800/3000 VM，开放必要owner仍完整消费。旧repair2的1100/2800及其他计数只是旧源档案，不作为最终源数字。新冻结small/header定位使完整核心路径增加部分工作，不能宣称所有路径提速。

31卡分页例包含默认20、下一页11、精确第31卡、full31，以及projects-only/internal summary的全scope金额/枚举；验证实际命中结果、返回字节和typed_fact解码工作量。共享open-voucher scope工作量例将无关已冻结业务从1增至80，均9SQL/7行/1322字节、无结果体解码。这些已纳入同一固定组，不能仅从少返回行推断整页收益。大型主48、当前最终source的统一资产native/browser和完整50对象×48/120月增长未运行，不声明性能达标。

原始log/XML都保留：asset-metadata-scope-initial、repair1、march-locator、repair2、boundaries-initial；current-voucher-pointer-common-initial、pages-initial、pages-repair1、common-repair1均以`.tmp/stage9-r71-`前缀保存。旧通过、新通过、fixture失败和真实业务失败分别记录，不能相加成一个最终完整组。

最终统一回执为 `.tmp/stage9-r71-asset-forward-voucher-related.log` / `.xml`：103 passed in191.75s，无error、skip或warning，Ruff由根线程统一检查通过。五文件范围如下，计数只属于这个固定组：

| 文件 | 实际项数 | 主要范围 |
| --- | ---: | --- |
| test_owner_asset_metadata_scope.py | 62 | 当前格式冻结/current完整owner与成员头、必要缺源/坏目录、普通core及公开页指针拒绝、旧版本回指/连续review、维修/备份、unowned/v1全文fallback、小月份增长 |
| test_asset_owner_outcome_reads.py | 7 | 原完整成员事件实际等价、开放重复JSON、坏批次无半成功proof、冻结正文组织 |
| test_owner_asset_card_page_scope.py | 1 | 真实31卡全金额与20+11/直跳分页、summary/projects职责 |
| test_publication_v1_voucher_heads.py | 32 | 固定v1凭证头与历史authority相关控制，保持其固定source边界 |
| test_open_voucher_scope_work.py | 1 | 无关冻结业务增长与开放前向核验工作量 |

删开放reversal pointer且保留真实version的案例已由定性升级明确拒绝断言；raw旧定性日志/XML仍保留。最终normal旧version回指有0/2次review两个负例；真实replacement后连续两次no-impact的合法保留也通过。固定v1这32项不是所有历史authority或组合损坏的完整证明。reverse version与pointer同时删除、其他全部来源同时消失的组合，以及完整维修前置是否另有独立权威拒绝，仍由根线程单独核查；本代理不把现存version正向定位称为不可缺行的全库目录完整性证明。

本代理所有production/tests编辑与测试已停止，无运行session。仅在根线程103回执后更新本审计记录；后续source固定、完整核验和统一native/browser由根线程处理。
