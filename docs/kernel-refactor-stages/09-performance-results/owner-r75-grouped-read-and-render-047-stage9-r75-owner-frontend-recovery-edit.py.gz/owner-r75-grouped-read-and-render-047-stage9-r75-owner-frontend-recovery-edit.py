from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for name in ['Brief','Funds','Employees','Assets']:
    path=ROOT/f'frontend/src/views/{name}View.vue'
    source=path.read_text(encoding='utf-8')
    old='async function refresh() {\n  invalidateRequests(true);'
    assert source.count(old)==1,name
    source=source.replace(old,'''function refresh() { return refreshCurrent(true); }
function refreshChanged() {
  updateNotice.value = "资料已更新，正在重新读取。";
  return refreshCurrent(false);
}
async function refreshCurrent(keepContent: boolean) {
  invalidateRequests(keepContent);
  loading.value = true;''')
    source=source.replace('updateNotice.value = "资料已更新，正在重新读取。"; await refresh();', 'await refreshChanged();')
    source=source.replace('@changed="refresh"','@changed="refreshChanged"')
    path.write_text(source,encoding='utf-8',newline='')
path=ROOT/'frontend/tests/funds-filters.test.mjs'
source=path.read_text(encoding='utf-8')
source=source.replace('  const pending = view.refresh();\n  assert.equal(calls.length, 2, "funds starts', '  const before = view.funds.value;\n  const pending = view.refresh();\n  assert.equal(view.loading.value, true);\n  assert.equal(calls.length, 2, "funds starts')
source=source.replace('  assert.equal(view.funds.value, null, "the new funds response waits for context validation");', '''  assert.equal(view.funds.value, before, "retain the hidden prior scope until context is validated");
  assert.equal(view.funds.value.movements[0].account_id, "bank-a", "unchecked bank-b must not be committed");
  assert.equal(view.loading.value, true, "the retained projection remains hidden");''')
path.write_text(source,encoding='utf-8',newline='')
path=ROOT/'frontend/tests/t6-details.test.mjs'
source=path.read_text(encoding='utf-8').replace("tag.includes('@changed=\"refresh\"')", "tag.includes('@changed=\"refreshChanged\"')")
path.write_text(source,encoding='utf-8',newline='')
