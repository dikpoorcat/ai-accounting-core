# r73公共HTTP请求与历史构造准备

主48固定r73纯浏览器实际150次成功响应中79次≥500ms，性能失败；主12先前5／150失败与r70先前37／150失败各保留原件，内容完整核验通过不替代性能通过。固定source SHA420ceb395fc5aec17ddaedf8914c7fc8de640da9f08cb35aded8a3a99a4eb7f4，browser backend build及静态hash与保存的snapshot manifest绑定；本次不重新扫描全树。

| 页面 | 慢样本／30 | median／p95／max ms |
| --- | --- | --- |
| 简报 | 30 | 636.6／697.0／735.3 |
| 资金 | 4 | 436.8／535.6／536.3 |
| 员工 | 0 | 316.7／471.9／473.2 |
| 资产 | 17 | 515.9／596.3／715.4 |
| 报表 | 28 | 556.8／615.1／616.0 |

冷开与首次加载另存原JSON，不能并入热刷新成功结论；切公司为single_eligible_company unavailable。六路native各3样本小于500ms没有证明本轮browser通过。

## 请求范围与必要安全检查

| 问题类型 | 已保存证据与结论 | 未验证边界 |
| --- | --- | --- |
| 五页重复请求／请求串行 | attempt3请求计数和HTTP/dispatch时间表确认正常五页热刷新没有重复主请求，相关请求启动间距小于2ms，已并行。setup、warmup和冷开请求仍在完整记录中，不能按总计数声称重复。 | 该诊断受主48设置活动影响，不是独占纯浏览器计时，不能用3次样本替代30次失败。 |
| 并发cProfile归因 | browser attempt3保存真实仪表化结果；Python3.12并发profile可能污染调用图，不能按其中函数图断言某个请求独占耗时或精确调用归属。 | 不据污染图归因GIL／network或关闭安全复验。 |
| 串行请求边界 | sequential attempt2成功串行context／brief／close-review；各endpoint实际4次metadata、4次schema、2次_check_catalog、1次authorize、1次response validate、1次dump，SQLite实际open通常2次，首次context3次。 | schema自身own时间<1ms，不等于包含连接开销的inclusive耗时<1ms；摘要检查／序列化小于1ms，authorize约12.8ms是brief样本，首次context与其他路径独立，不外推所有请求。安全职责仍须对应真实复验。 |
| 初失败与尝试身份 | browser初次warmups>=1断言失败；attempt2 close-review prepared等待超时／ERR_EMPTY_RESPONSE；sequential初次failed保留。attempt3 over_target、sequential attempt2 passed各为独立原件。 | 没有独立保存的请求runner stdout/log不补造；当前存在的JSON、runners及profile summaries完整归档。 |

## 同进程HTTP配对与实际渲染边界

同fixed r73 source、同服务／进程的main48 direct与dispatch正反配对，warm3、实际3对语义相同；精确剔除generated_at／checked_at展示时间。direct wall median407.013ms、dispatch446.657ms，公共dispatch路径差额约39.644ms。它包括公共授权／目录／响应处理等职责，不是网络传输测量；此前浏览器约190ms差额尚未归因，不能把39.64ms推成全部190ms原因。原attempt1在samples=[]时AssertionError失败保留；attempt2 complete与session撤销／app关闭分别保存。

RSS／peak、GC及SQL调用量只是同进程观察线索；不能仅凭RSS差异宣布缓存、内存压力或GIL根因，也不能据此关闭安全检查复验。同owned快照后续head scope只有brief2／assets4／reports0小重叠，已确认不是此前的大返回根因；未新增缓存。

真实release主12五页DOM基线attempt3各1次，加载时旧root disconnected、旧节点全断开，完成后same_root=false，确认刷新导致五页DOM卸载重建。response_end到两个requestAnimationFrame为40.3–57.2ms，是等待两个帧的诊断边界，不等于纯Vue渲染CPU耗时或全部可省收益。刷新总时延、旧节点／mutations原样保存。原两次failed/returncode1不抹去；优化实施与收益尚未验证，不称页面500ms通过。

公共金额来源audit另证实首次批次物理头重复搬运，见[发布证明与必要读取](owner-publication-proof-reuse-r72.md)及[本轮原件manifest](owner-r74-root-cause-audit-manifest.json)。本轮仅保存已完成的窄diagnostic，不重新执行浏览器／SQL或固定源码；主12r73仍5／150慢、主48r73仍79／150慢，正式仓库draft／0、阶段未完成。RSS、未解释差额及未实施渲染优化都保留未验证。

## 技术预览持有、组件重建与当前验证边界

真实preview生命周期attempt1因KeyError在第一响应核对时失败，reads=[]，未保留已完成before测量；attempt2被动记录24reads，第0各作预热，无collect／阈值调整。去预热wall median简报369.930→501.649ms、资产196.847→237.074、报表363.983→409.170；GC暂停median分别7.429→34.443、4.577→5.228、16.422→31.071。各样本扣实际暂停后的median仍增104.535／33.652／35.712ms，剩余未归因。观察器自身长期保留13,911条GC记录及读取事件片段，inventory未做referrer分解；不能把新增24,718 tracked或RSS241.9→672.9MB全归活动preview。5,278,127B为返回preview编码含locator，不是缓存heap或各section大小。

当前真实runtime消费者只需活动身份／版本／confirmation和同一已核预览的PublicOwnerReview摘要；CLI／MCP完整preview及真实冻结全合同保留，密码批准／close仍事务重建全manifest并比较digest。专用不可变intent为适当窄方案，但r75仍实施／验证中，本批不读在写回执或声称通过，收益亦未验。旧缓存损坏拒绝须保留为新摘要／绑定损坏负例，不能因内部dict测试接口改变删除安全事实。

前端同选择刷新保留隐藏挂载，必要公司／月份／筛选与失效恢复仍清空。修复前完整suite148 passed／2 failed和early release build原件保存；恢复修正后一次统一全前端153／153通过，contracts:check／vue-tsc／vite release通过，验收source hash前后相同。早期28及恢复定向40全部已包含153，不相加。dashboard_snapshot_changed、显式续页version mismatch与详情changed走清空主投影／旧版本／分页后双门控重新读取，不能保留已知失效金额。

r74真实DOM及合成fixture final确认挂载隐藏、错误／切换边界，但使用恢复修复前Vue，不能当当前后修复源码浏览器验收；旧失败attempts完整保留。恢复后只有前端统一检查，没有新增HTTP／preview／纯性能结果。fixedr73旧慢样本保持：主12 5／150、主48 79／150。新r75 source snapshot尚未创建，等待统一候选核验及纯browser。

当前证据及分时source绑定见[读取与render归并manifest](owner-r75-grouped-read-and-render-manifest.json)，raw／gzip双SHA、bytes／mtime与解压逐字节一致。未实际核对的根因和收益继续为未验证。

## 历史manifest与构造准备

历史source inventory曾被当前required-file集合解释，因历史没有frontend/local-api-proxy.ts被错误阻断。工具守卫改为按各旧固定source原manifest声明核完整路径／字节／汇总SHA；当前r73仍按当前完整source guard执行。轻量guard实际验证三种旧source及current_r73，负例覆盖缺文件、改字节、错汇总、路径逃逸、未知CASE拒绝；健康小fixture通过。它没有读取SQLite、构造、内容核验或preview。

readiness现为static_ready_runtime_guards_mandatory，保留initial_preflight_result原失败与实际后续静态结果。main120／independent48仍built_not_verified；independent120旧verified保留旧source身份。main120的186,767,161字节checkpoint本批不读取、不复制、不压缩；原SHA在准备报告中引用，JSON完整source guard仍留实际构造前执行。源SQLite身份／FK／冻结row digest与目标注册完整核验及真实开放preview尚未由readiness证明；磁盘预算只是保守规划估算。不能把准备、源码负例或语法通过写为构造通过。

原件集中见[本批manifest](owner-r73-main48-browser-request-readiness-manifest.json)，保存raw／gzip双SHA、bytes／mtime并解压逐字节核对。全部未实际检查的事项保持未验证。本次仅档案与文档整理，无SQL、tests、服务、构造或计时。
