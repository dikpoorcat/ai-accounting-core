# 已验证非负凭证行合计专项审查

2026-10-04 初次为只读审查；随后按根任务授权实施下面记录的局部优化及新增小型测试。使用仓库 `.tmp-kernel-venv`，未访问真实 data、启动服务、执行大型测试或改动 docs/v1 modules。新增测试仅复用现有临时合成公司 fixture。

## 结论

重复检查真实存在，适合做一个局部、小范围的公共核验层优化，但目前未验证端到端耗时收益。首选在共享的 `kernel.integrity._lines` 内、所有行检查完成之后，将两侧的 `sum_fen(generator)` 改为 `source_checked(sum(generator))`，保留其原始返回类型 `list[tuple]`。不需要新建公开“可信金额”框架或改变 `types.sum_fen` 的合同。

`_lines` 已逐行证明 debit/credit 为 exact int、非负、单边非零、各自 int64，且把读出的整数存入新 tuple。非负序列的每个前缀均不超过最终总额，因此最终 int64 检查与逐前缀检查在接受/拒绝上等价；Python int 加法本身不会机器溢出。

保留原来的 `if result and (len(result) < 2 or …)` 短路和左右求值顺序。不要在逐行校验时提前累计并检查总额：原实现先完成所有逐行检查，再检查合计；提前总额溢出会遮盖后续 `invalid_line_shape` / `invalid_line`。使用当前 `source_checked` 而非硬编码 `types.checked`，维持历史内容上下文和原 ValueError 文本。

## 可验证的工作量

对 n>=2 的合格行，原实现逐行检查 2n 次，再两次 `sum_fen` 检查输入和前缀共 4n 次，总计 6n。候选逐行检查仍为 2n，再对借、贷最终总额各检查一次，共 2n+2。空行及单行仍完全沿原短路处理。

probe 通过 monkeypatch 所选 encoding 的 `checked` 精确计数，current 和 historical_content(1) 一致：

|行数|原 checked 次数|候选 checked 次数|
|---|---:|---:|
|2|12|6|
|10|60|22|
|100|600|202|

1,688 次合成比较覆盖 current/v1、opening True/False、列表和字典子类、拒绝 bool/float/int 子类、空行、单行、形状缺失/多字段、空账号/现金流、负数、每行 int64 超限、平衡/不平衡、合计超限及“前面合计超限但后面形状错误”，比较正常值和异常类型、文本、details，全部一致。此为小 probe，不替代正式测试。

CPU 计时未验证：`process_time_ns` 实测出现 15.625ms 量化及零时长小块；2/10 行 median 无区分，100 行出现较小数值，但粒度不足以据此声明百分比收益。未扩大计时任务。此前 `_lines` 1,006 calls / 54ms cumulative / 18ms self 不代表 54ms 都可省；行形状检查、逐行 int64 检查、tuple 构建和函数调度仍保留。证实的是 4n−2 次重复 checked 可去掉，收益随行数增长；典型两行凭证总耗时改善应重新测量。

## 消费者与适用边界

全局检索了 src 中 `_lines` 定义/调用、integrity import、历史上下文、sum_fen 定义/调用及公司备份 verifier 分派。

|路径|如何使用该共享核验|本候选影响/边界|
|---|---|---|
|integrity._outcome → _check_sources|计算正文 lines/opening_lines；凭证实际行及 expected 计算行|直接受益；保留 JSON、digest、依赖/证据/发布链检查|
|verify_sources / verify_publication / verify_prepared_sources|按选中来源或写入前后核验|受益；不跳过来源与发布前后两侧核验|
|verify_integrity|完整保留版本与来源、关账、投影、索引核验|受益；不改变任何范围或封签|
|verify_close_integrity / periods|关账累计实际来源与冻结采用|经 _check_sources 受益；关账专属核验全部保留|
|content_v1.verify_v1_company → historical_content(1) → schema_bundle.verify_company_with_registry|released v1 固定 reader/encoding|共享 integrity 受影响，必须做 v1 错误等价测试；任何 v1 module 不改|
|report_open_contribution / report_open_contribution_v1|调用 _check_sources|两者共享路径受益；v1 文件不改|
|dashboard_reads.result_lines|对 selected saved outcome 调 _lines|直接受益；current/frozen adopted result 都涉及|
|query_reads / dashboard_owner / dashboard_reads / reports / exports / duplicates / duplicate_freeze / close_review|调用 verify_sources，或经读 API 按来源核验|经共享路径受益；所有读取路径不承诺都调用 _lines，SQL/body 封签路径保持现状|
|engine / asset_batches / identity_corrections / settlement_freeze|发布、修改与冲正前后调用 prepared/publication 核验|经共享路径受益；不改变业务类型和原子性|
|maintenance.verify_integrity / _repair|维修前验证源、维修后验证结果|经共享路径受益；不改变 repair revision 或维修目标|
|backup._verify_connection（verifier 分派）→ schema_bundle|按公司版本选 current/v1 完整内容 verifier；备份/恢复的核验复用|经共享路径受益；公司身份、合同、指纹、原件与 ZIP 验证全部保留|

`integrity._check_sources` 第 424 行在 `_lines(actual)` 已成功后，又 `sum_fen(actual debit)` 核对 voucher total；此处输入已由同次局部调用证明有效及两侧总额 int64，是另一个真实重复检查点。可单独改为直接 sum（_lines 已完成该总額 int64 检查），或 checked(sum) 保守保留最终检查；不缓存跨请求证明、不改变 `_lines` 返回类型。此 probe 仅验证 `_lines` 候选，未对该消费者候选执行等价 probe。

`integrity._check_closes` 第 1138 行的 trial.values() 来自 `_totals`，逐行 exact/int64/nonnegative、每账户前缀 int64 已核验；跨账户最终总额检查可能同样可用 checked(sum)，但属单独范围，需要保留 `_totals` 的逐行及每账户错误顺序。不要合并进本次首选小修改。

`dashboard_reads` 第 1408 行的 actual voucher debit 合计发生在与已核验 expected 完整 equality 之前；此时只有 exact-int 显式证明，没有非负/int64 证明。不能由于附近存在 `result_lines()` 就替换成“已验证总额”。

`publication._correction_baseline_total` 第 426 行虽检查 exact/nonnegative，但不先单独 checked 每个金额，sum_fen 承担金额范围边界；其报错合同、单行条件求值顺序与 _lines 也不同。`contracts.Outcome` / `history_types_v1.Outcome` 虽接受 Line，却是公开对象层，不应机械假定运行时输入一定经过本次 `_lines` 证明。保持这些消费者现状。

## 不可泛化替换的合计

current `types.sum_fen`、fixed `history_encoding_v1.sum_fen`，以及 material_inspection_v1/report_flow_rules_v1 的独立实现保留逐项和前缀 checks（report_flow_rules_v1 内联校验，且具有独立错误文本）。允许正负金额的调用含 banking.opening_fen + entries.signed_fen、banking matching、BalanceEffect 聚合、assets outstanding − paid、tax/payroll difference、reports 余额和现金流等。

反例 `[MAX_FEN, 1, -1]`：当前在第二项前缀越界时失败，checked(sum(...)) 的最终值 MAX_FEN 却通过。`[MAX_FEN+1, -1]` 也会由逐项检查失败而最终合计通过。对这类合计减少检查会改变合同，禁止批量替换。业务模型中 NonNegativeFen 字段的其他聚合虽可能可优化，必须独立证明来源、类型和错误优先级，本审查不作自动替换建议。

## 若实施，必要验证

1. current 与 historical_content(1) 参数化 `_lines` 等价测试：空/单行、合法 2 行与多行、opening、允许 list/dict 子类；拒绝 bool/float/int 子类、额外/缺少 key、账号/现金流错误、两边同零/同非零。
2. 边界 MAX_FEN 本身平衡可通过、合计 MAX_FEN+1 失败、借方先于贷方的合计异常文本保持；合计溢出加后续坏行必须仍返回该坏行的原 component/record_id/reason。
3. 公开 verify_sources / verify_integrity / verify_publication / close wrapper 对 ValueError 包装的 code、中文文本、component 与 invalid_stored_content 不变；已有合成库中正文/凭证错误不得被忽略。
4. 选中 current/frozen 来源读取、closed reversal、v1 company verifier、关账、维修前后、便携备份 verifier 的针对性集成验证。复用现有小型 synthetic fixtures，不建大库、不使用真实资料。
5. 用 checked 精确次数作稳定工作量验证，防止重复逐项/前缀校验回流。另以足够时钟分辨率、代表性调用组合验证 CPU；没有可信测量前只报告调用数下降，不报告端到端速度提升。

建议值得实施的是 `_lines` 两个局部表达式；收益是稳定消除已证实重复工作、改动和证明面小。当前证据不足以把它列为显著响应时间优化，更不值得为此扩展 API、改变冻结规则或进行跨请求缓存。

## 授权后的实际实施

改动文件：`src/ai_accounting/kernel/integrity.py`、新建 `tests/kernel/test_verified_line_totals_work.py`。建测试前确认目标文件不存在。

实际消除三个位置的逐项及前缀重复检查，保守保留 source_checked(final sum)：

- `_lines`：两侧合计；逐行验证全部保留，先全部逐行验证后才合计，单行短路不变。
- `_check_sources`：actual 来自紧邻同次 `_lines` 返回的新 tuple 列表，非负/exact/int64 及总额已证实，因此 voucher.total 比较只再 checked 最终借方合计。空 actual 仍短路报 voucher_total_mismatch。
- `_check_closes`：trial 来自同次 `_totals` 返回的新字典；其内部每行 exact/int64/nonnegative、每账户合计 checked 均保留，跨账户合计改为两侧 checked(final sum)。duplicate_trial_account 的前置顺序不变。

integrity 已无 sum_fen 调用，移除该文件的 source_sum_fen import；全局类型函数、版本上下文、所有领域合计和 v1 文件不改。dashboard/publication/contracts 等未具备同次前置证明的位置保持原实现。

新增测试一次收敛执行：`.tmp-kernel-venv/Scripts/python.exe -m pytest tests/kernel/test_verified_line_totals_work.py -q` → **83 passed in 5.09s**。包含 current/v1 与 opening 组合、empty/单行/合法 list/dict 子类、错误组件及中文文本、exact type 拒绝、MAX_FEN 合法及各侧总额越界、总额越界加后续坏行、checked 调用量、general signed prefix overflow 保持、公共 verify_sources/verify_publication current/v1、current frozen close/完整 verify/close verify 和损坏凭证总额拒绝。

本次实施后未执行 CPU 或浏览器复测，没有足以达到 500ms 的证据。后续受影响回归及业务读取组统一测量由根任务进行。
