# Stage 9 evidence-reference boundary group

Completed scope: malformed public evidence-reference strings/types now fail as `invalid_command`; lawful unknown hashes retain each existing content-lookup error. No business inference, accounting precision, period policy, frozen record, SQL contract, package, AGENTS, frontend, real company database, owner identity, configured service or credential changed. No Git commit.

## Implementation

Shared `kernel.types.EvidenceDigest`: original exact JSON pattern, strict strings and fullmatch validator. No trimming, lowercasing or source creation. Existing nested fact JSON schemas remain byte-equivalent after canonicalization, with unchanged generated SQL. Safe public conversion helpers produce only static issue messages and field paths. Diagnostics continues to classify unrelated ValueError as internal_error.

Public signatures changed in entities, engine, duplicates, identity_corrections, discovery, periods, exports, materials, asset_batches, display and replay_close. Dynamic command_schema registration rows use list[EvidenceDigest] for save/amend/batch commands. Existing nested declarations in duplicates, materials, display, replay_close, domains/platforms, domains/managed_reserve and domains/taxes reuse the shared type. `prepare_fact_registration.source_locations` is a typed SourceLocation sequence: the former unrestricted Mapping union could bypass its digest constraint.

Internal frozen/raw source readers retain their conversion behavior. Materials validates at inspect/receive entry points; its shared private inspection reader remains unchanged. Exports keeps its internal worker converter; public payee/template references use the safe converter. Fact evidence registration, identity and asset preparation validate element formats before sorting/querying. Note/entity/commentary reject malformed input before their writes. Deletion and close reference conversion retains content lookup behavior.

## Actual checks

- Before fix: synthetic LocalService register_entity with a one-character hash returned rejected/internal_error; complete company SQLite iterdump stayed unchanged (`before.json`).
- New targeted tests: first execution 54 passed / 3 failed in 26.84 seconds. The three failures were test baselines (material treatment name, missing-period field location, JSON list versus native tuple locations); repaired failing tests 3 passed / 54 deselected in 6.87 seconds. One subsequently discovered nested Mapping escape regression passed in 6.23 seconds. These cover all 58 current test cases, but do not claim a final simultaneous module run.
- New tests cover 18 malformed string/type cases, complete wire baselines for 29 public fields, direct Python guards, later batch item rejection without writes, missing accounting information, existing unknown-reference results including inventory's accounting_constraint, registered entity/note/fact/inventory/identity/asset operations and idempotency/source history, CLI and MCP error envelopes, nested models/commands and SQL contracts.
- Modified production files and the new test module pass Ruff. Scoped git diff --check passes.
- After fix: generated company DDL `c9f9f7051bca67f1241ee5c89676fb9476bc819dc8f92c1a0c0bd1e940f459cb`; catalog `b484d315272bb64de3856b458f04d2d4881da05db7552250864260916c69a4ee`; both equal before and packaged draft/0 contracts. All registered fact JSON schemas equal the before snapshot (`contract-check.json`). No regenerated contract or DB adjustment.

Logs/scripts use only `.tmp/stage9-evidence-reference-group-fix-20261004-*`. Regression module: `tests/kernel/test_evidence_reference_boundary.py`.

## Verification limits

Root owns the single affected-group regression after convergence. No broad regression, performance test, package build, HTTP network test, actual running daemon/MCP stdio process, configured service or real business data was accessed. CLI/MCP tests call their actual transport wrapper functions with ServiceClient replaced by an isolated synthetic LocalService dispatch; they verify shared rejection behavior but do not claim live daemon/network acceptance. Not every legitimate business workflow for every command was executed; existing content policies were preserved without rewriting their queries.
