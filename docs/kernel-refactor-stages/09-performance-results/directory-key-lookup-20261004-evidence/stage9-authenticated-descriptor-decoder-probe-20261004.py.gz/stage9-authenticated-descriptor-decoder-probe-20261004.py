"""Read-only parser comparison; no production or page-latency claim."""
from contextlib import closing
import hashlib
import json
from pathlib import Path
import platform
import struct
import sys
import time

from pydantic_core import from_json

W = Path(__file__).resolve().parents[1]
S = W / '.tmp/stage9-build-source-voucher-owner-converged-20261004'
Q = W / '.tmp/stage9-owner-proof-read-work-large-main120-browser-20261004-qualified.json'
OUT = W / '.tmp/stage9-authenticated-descriptor-decoder-probe-20261004.json'

def sha(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()

def typed_fingerprint(value):
    """Include types, insertion order and exact IEEE float bits, not only ==."""
    hashed = hashlib.sha256()
    def visit(item):
        hashed.update(type(item).__name__.encode() + b':')
        if type(item) is dict:
            for key, child in item.items():
                visit(key)
                visit(child)
        elif type(item) is list:
            for child in item:
                visit(child)
        elif type(item) is float:
            hashed.update(struct.pack('!d', item))
        elif type(item) is str:
            raw = item.encode('utf-8', 'surrogatepass')
            hashed.update(str(len(raw)).encode() + b':' + raw)
        else:
            hashed.update(repr(item).encode())
        hashed.update(b';')
    visit(value)
    return hashed.hexdigest()

def main():
    assert Path(sys.prefix).resolve() == W / '.tmp-kernel-venv'
    assert not OUT.exists()
    manifest = json.loads((S / 'source-manifest.json').read_text('utf-8'))
    assert manifest['sha256'] == 'bfb70cb0bdcffe8a17bfa326364242386e2b9e497fc9f1da00dc91b300f77919'
    sys.path.insert(0, str(S / 'scripts'))
    import stage9_source
    stage9_source.configure_source(S, W)
    from ai_accounting.kernel.runtime import connect
    from ai_accounting.kernel.versions import verify_schema
    from ai_accounting.kernel.schema_bundle import production_bundle
    from ai_accounting.kernel import close_storage
    import snapshot_stage9_source as snapshot
    qualified = json.loads(Q.read_text('utf-8'))
    database = Path(qualified['company']['path']).resolve()
    assert database.is_relative_to(W / '.tmp/stage9-draft-fixture-main120-20261003')
    wal = Path(str(database) + '-wal')
    before = {'db': sha(database), 'wal': sha(wal) if wal.exists() else None}
    bundle = production_bundle()
    groups = {'accounting': [], 'close_headers': [], 'settlement_roots': []}
    with closing(connect(database, read_only=True,
                         validator=lambda c: verify_schema(c, bundle=bundle))) as c:
        assert c.execute('PRAGMA query_only').fetchone()[0] == 1
        c.execute('BEGIN')
        try:
            closes = list(c.execute('SELECT * FROM period_close ORDER BY period'))
            assert len(closes) == 119
            headers = close_storage.verified_headers(c, closes)
            for header, close in zip(headers, closes, strict=True):
                groups['close_headers'].append(close['manifest'])
                row = c.execute('SELECT content,digest FROM close_storage_subroot '
                                'WHERE period=? AND family=?', (header.period, 'accounting')).fetchone()
                assert hashlib.sha256(row['content'].encode()).digest() == bytes(row['digest'])
                assert bytes(row['digest']).hex() == header.root['subroots']['accounting']
                groups['accounting'].append(row['content'])
            last = headers[-1]
            row = c.execute('SELECT * FROM settlement_freeze_root WHERE period=?',
                            (last.period,)).fetchone()
            assert bytes(row['close_digest']) == last.logical_digest
            assert bytes(row['root_digest']) == hashlib.sha256(row['root_json'].encode()).digest()
            assert bytes(row['root_digest']) == close_storage.derived_root(last, 'settlement')
            groups['settlement_roots'].append(row['root_json'])
        finally:
            c.rollback()
    result = {'status': 'diagnostic_started', 'source_sha256': manifest['sha256'],
              'python': platform.python_version(), 'script_sha256': sha(Path(__file__)),
              'before': before, 'groups': [],
              'scope': 'complete raw-SHA-authenticated synthetic descriptors only; '
                       'parser timing excludes source reads, guards, validation and whole pages; '
                       'no source, database, model, projection or runtime parser changes'}
    decoders = {'stdlib': json.loads,
                'existing_pydantic_core': lambda raw: from_json(raw, cache_strings=False,
                                                               allow_partial=False)}
    for name, blobs in groups.items():
        expected = [json.loads(blob) for blob in blobs]
        assert [decoders['existing_pydantic_core'](blob) for blob in blobs] == expected
        assert [typed_fingerprint(decoders['existing_pydantic_core'](blob)) for blob in blobs] == [
            typed_fingerprint(value) for value in expected
        ]
        del expected
        item = {'group': name, 'blobs': len(blobs),
                'raw_bytes': sum(len(blob.encode()) for blob in blobs), 'same_values': True,
                'same_types_order_and_float_bits': True,
                'raw_group_sha256': hashlib.sha256(json.dumps(blobs).encode()).hexdigest(),
                'observations': []}
        for label, decode in decoders.items():
            for _ in range(3):
                for raw in blobs:
                    decode(raw)
            durations = []
            for _ in range(30):
                start = time.perf_counter()
                for raw in blobs:
                    decode(raw)
                durations.append((time.perf_counter() - start) * 1000)
            ordered = sorted(durations)
            item['observations'].append({'parser': label, 'samples_ms': durations,
                'median_ms': (ordered[14] + ordered[15]) / 2,
                'p95_ms': ordered[28], 'max_ms': ordered[-1]})
        result['groups'].append(item)
        print(json.dumps({k: v for k, v in item.items() if k != 'observations'}), flush=True)
    result['after'] = {'db': sha(database), 'wal': sha(wal) if wal.exists() else None}
    result['guards_equal'] = result['before'] == result['after']
    result['source_inventory_unchanged'] = snapshot._inventory(S) == manifest['files']
    assert result['guards_equal'] and result['source_inventory_unchanged']
    result['status'] = 'diagnostic_complete'
    with OUT.open('x', encoding='utf-8') as handle:
        json.dump(result, handle, ensure_ascii=False, indent=2)

if __name__ == '__main__':
    main()
