"""One instrumented native read per entry. No timing or new qualification claim."""
import cProfile
from collections import Counter, defaultdict
from contextlib import closing, contextmanager
import hashlib
import json
from pathlib import Path
import pstats
import sqlite3
import sys
import time

W=Path(__file__).resolve().parents[1]
S=W/'.tmp/stage9-build-source-directory-key-lookup-20261004'
Q=W/'.tmp/stage9-owner-proof-read-work-large-main120-browser-20261004-qualified.json'
R=W/'.tmp/stage9-draft-fixture-main120-20261003'
OUT=W/'.tmp/stage9-directory-key-lookup-profile-20261004.json'
SEAL='8473af5ed77f9c079bdf02912bca9c5070735a12a555df9601d22fd9e7fcb582'
MANIFEST_SHA='286b2058c8cf2bfed25b28aaec00531074b33a0e26a14ae11b28ee504795783a'
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def main():
    assert Path(sys.prefix).resolve()==W/'.tmp-kernel-venv'
    assert not OUT.exists()
    mpath=S/'source-manifest.json'; m=json.loads(mpath.read_text('utf-8')); q=json.loads(Q.read_text('utf-8'))
    assert m['status']==q['status']=='complete' and m['sha256']==SEAL and m['file_count']==770
    assert sha(mpath)==MANIFEST_SHA
    assert q['qualification']['source_manifest_sha256']=='00f133223a9269ed8f232bb66950747250dbfdf48c63c29455aff0b48d7bf66a'
    assert Path(q['source']).resolve()==W/'.tmp/stage9-build-source-owner-proof-read-work-20261004' and Path(q['root']).resolve()==R
    assert q['requested_months']==120 and q['business_count']==120000 and q['monthly_business_count']==1000
    assert q['integrity']['status']=='verified' and q['integrity']['limitations']==[]
    assert q['integrity']['coverage']==dict.fromkeys(('sources','historical_adoption','projections','read_indexes'),'verified')
    co=q['company']; db=Path(co['path']).resolve()
    assert co['name']=='阶段九合成规模企业' and db==R/co['taxpayer_id']/'company.sqlite'
    period=q['verified_open_preview']['period']; state=q['verified_open_preview']['state']
    assert period=='2025-12' and state==[1,5167,2820,296,120598,0]
    assert sha(R/'stage9-builder.json')==q['qualification']['checkpoint_sha256']
    sys.path.insert(0,str(S/'scripts'))
    import stage9_source
    stage9_source.configure_source(S,W)
    import snapshot_stage9_source as ss
    from ai_accounting.kernel.runtime import connect
    from ai_accounting.kernel.versions import verify_schema,database_format
    from ai_accounting.kernel.schema_bundle import production_bundle
    from ai_accounting.kernel.read_state import repair_revision
    from ai_accounting.kernel.catalog import Catalog
    from ai_accounting.kernel.engine import Engine
    from ai_accounting.kernel.dashboard import Dashboard
    from ai_accounting.kernel.resident_reads import ResidentReadPool
    from ai_accounting.kernel.types import canonical
    import stage9_metrics as metrics
    import ai_accounting.kernel.dashboard as dashboard_module
    import ai_accounting.kernel.runtime as runtime_module
    for module,rel in ((stage9_source,'scripts/stage9_source.py'),(ss,'scripts/snapshot_stage9_source.py'),
        (runtime_module,'src/ai_accounting/kernel/runtime.py'),(dashboard_module,'src/ai_accounting/kernel/dashboard.py'),
        (metrics,'tests/kernel/stage9_metrics.py')): stage9_source.require_source_module(module,S,rel)
    assert ss._inventory(S)==m['files'] and ss._digest(m['files'])==SEAL
    bundle=production_bundle(); assert bundle.status=='draft' and dict(bundle.current_versions)=={'company':0,'catalog':0}
    def guard():
        g={'files':{str(p):sha(p) if p.exists() else None for p in (Q,mpath,R/'stage9-builder.json',
            db,Path(str(db)+'-wal'),R/'catalog.sqlite',Path(str(R/'catalog.sqlite')+'-wal'))}}
        for kind,p in (('company',db),('catalog',R/'catalog.sqlite')):
            with closing(connect(p,read_only=True,validator=lambda c:verify_schema(c,bundle=bundle,kind=kind))) as c:
                assert c.execute('PRAGMA query_only').fetchone()[0]==1;c.execute('BEGIN')
                try:
                    g[kind]={'format':database_format(c,bundle=bundle,kind=kind)};c.row_factory=None
                    tables=('identity','state','schema_history','read_repair_state') if kind=='company' else ('catalog_identity','security_owner','schema_history','company')
                    for table in tables:
                        if c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",(table,)).fetchone():
                            g[kind][table]=hashlib.sha256(repr(c.execute('SELECT * FROM '+table).fetchall()).encode()).hexdigest()
                    if kind=='company':
                        assert c.execute('SELECT company_id,database_id,taxpayer_id FROM identity').fetchone()==(co['id'],co['database_id'],co['taxpayer_id'])
                        assert list(c.execute('SELECT * FROM state WHERE id=1').fetchone())==state and repair_revision(c)==0
                    else:
                        owners=c.execute('SELECT login_name FROM security_owner').fetchall()
                        assert len(owners)==1 and owners[0][0] in ('synthetic-stage9-owner','synthetic-stage9-native-profile')
                finally:c.rollback()
        return g
    before=guard()
    class ReadOnlyCatalog(Catalog):
        @contextmanager
        def connection(self,*,read_only=False,_cross_thread=False):
            assert read_only
            with super().connection(read_only=True,_cross_thread=_cross_thread) as c:yield c
        def recover_operations(self):
            with self.connection(read_only=True) as c:
                assert c.execute("SELECT count(*) FROM company_operation WHERE status!='succeeded'").fetchone()[0]==0
    catalog=ReadOnlyCatalog(R,bundle); companies=catalog.companies()
    assert [x for x in companies if x['id']==co['id']]==[co]
    def business(value):
        result = json.loads(canonical(value))
        for field in ('generated_at', 'checked_at'):
            if field in result:
                result[field] = '<response clock>'
        if isinstance(result.get('data'), dict) and 'generated_at' in result['data']:
            result['data']['generated_at'] = '<response clock>'
        if 'read_context' in result:
            result['read_context']['read_version'] = '<source-bound read token>'
        return hashlib.sha256(canonical(result).encode()).hexdigest()
    report={'status':'started','diagnostic_only':True,'source_sha256':SEAL,'source_manifest_sha256':MANIFEST_SHA,
        'source_files':m['file_count'],'qualification_source_scope':'source-bound c3c3 full verifier; converged frozen-head binding, owner reuse and explicit entity type fixes are diagnostic only and not newly qualified','source_diff_receipt_sha256':sha(W/'.tmp/stage9-directory-key-lookup-source-diff-20261004.json'),'qualified_sha256':sha(Q),'script_sha256':sha(__file__),'observations':[],
        'limitations':['instrumented native work includes cProfile, SQL observation and EXPLAIN overhead; not pure timing or render latency',
            'cProfile counts calls, not successful decode returns; only SQL outcome transfer and matching json.loads are successful counted operations',
            'SQL bytes are returned value bytes, not disk IO; VM sampled every 100 instructions',
            'no integrity verifier, preview, business/auth writes, service, HTTP, MCP or browser executed'], 'before':before}
    try:
        with closing(ResidentReadPool(maximum=1)) as pool:
            store=catalog.bind(co['id'],read_pool=pool); original=store.connection
            engine=Engine(store); board=Dashboard(engine,company_name=co['name'],companies=companies)
            operations={'assets':lambda:board.assets(period,limit=20,preparation='deferred'),
                'brief':lambda:board.brief(period,limit=20),
                'quarterly_report':lambda:board.quarterly_report(2025,4,preparation='deferred'),
                'funds':lambda:board.funds(period,limit=20,preparation='deferred'),
                'employees':lambda:board.employees(period,limit=20,preparation='deferred')}
            for name,op in operations.items():
                counts=Counter(); statements=Counter(); work=defaultdict(Counter); outcomes=set();plans={};trace=Counter()
                class ObservedConnection(metrics._Connection):
                    def execute(self,sql,parameters=()):
                        key=' '.join(sql.split()); digest=hashlib.sha256(key.encode()).hexdigest()
                        if name=='assets' and key.lstrip().upper().startswith(('SELECT','WITH')) and any(token in key.lower() for token in ('open_terminal','adopted','period_balance','asset_consumption')) and digest not in plans:
                            # Derived only from the actual application statement and parameters, same read-only transaction.
                            plans[digest]={'statement_prefix':key[:250],'statement_length':len(key),
                                'plan':[list(r) for r in self.connection.execute('EXPLAIN QUERY PLAN '+sql,parameters).fetchall()]}
                        return super().execute(sql,parameters)
                @contextmanager
                def observed(*,read_only=False):
                    assert read_only
                    with original(read_only=True) as c:
                        assert c.execute('PRAGMA query_only').fetchone()[0]==1 and repair_revision(c)==0
                        def progress():counts['sqlite_vm_steps']+=100;return 0
                        def traced(sql):trace[hashlib.sha256(' '.join(sql.split()).encode()).hexdigest()]+=1
                        c.set_progress_handler(progress,100);c.set_trace_callback(traced)
                        try:yield ObservedConnection(c,counts,statements,work,outcomes)
                        finally:c.set_progress_handler(None,0);c.set_trace_callback(None)
                loads=json.loads
                def counted_loads(value,*args,**kwargs):
                    result=loads(value,*args,**kwargs);counts['stdlib_json_loads']+=1;counts['stdlib_json_input_bytes']+=metrics._value_bytes(value)
                    raw=value.encode() if isinstance(value,str) else value
                    if isinstance(raw,bytes) and (len(raw),hashlib.sha256(raw).digest()) in outcomes:counts['calculation_result_json_decodes']+=1
                    return result
                store.connection=observed;json.loads=counted_loads;profile=cProfile.Profile();start=time.perf_counter()
                try:profile.enable();response=op()
                finally:
                    profile.disable();elapsed=(time.perf_counter()-start)*1000;store.connection=original;json.loads=loads
                stats=pstats.Stats(profile)
                entries=[{'file':str(Path(file).relative_to(S)) if Path(file).is_absolute() and Path(file).is_relative_to(S) else file,
                    'line':line,'function':func,'primitive_calls':cc,'calls':nc,'self_seconds':tt,'cumulative_seconds':ct}
                    for (file,line,func),(cc,nc,tt,ct,callers) in stats.stats.items()]
                entries.sort(key=lambda x:x['cumulative_seconds'],reverse=True)
                targets=[x for x in entries if any(t in x['function'] for t in ('verify','check','fact','decode','from_json','inspect_bytes','asset','balance','terminal','selected_content','read_accounting','read_adopted','read_section'))]
                sqls=[{'statement_sha256':hashlib.sha256(sql.encode()).hexdigest(),'statement_prefix':sql[:260],
                    'statement_length':len(sql),'calls':n,**work[sql]} for sql,n in statements.items()]
                sqls.sort(key=lambda x:x.get('sqlite_ms',0),reverse=True)
                payload=canonical(response)
                assert response['read_context']['company_id']==co['id']
                observation={'page':name,'instrumented_ms':elapsed,'counters':dict(counts),'cprofile_top':entries[:60],
                    'cprofile_relevant':targets,'sql':sqls,'actual_assets_plans':plans,'trace_actual_statement_count':sum(trace.values()),
                    'trace_distinct_expanded_statement_hashes':len(trace),'response_bytes':len(payload.encode()),
                    'response_sha256':hashlib.sha256(payload.encode()).hexdigest(),'read_context':response['read_context'],'business_response_sha256':business(response)}
                report['observations'].append(observation)
                print(json.dumps({'page':name,'instrumented_ms':elapsed,'counters':dict(counts),'slowest_sql':sqls[:4]},ensure_ascii=False),flush=True)
            pool.close();assert pool._closed and pool._total==0 and not pool._idle
            report['read_pool_closed']=True
        report['status']='diagnostic_complete'
    except Exception as e:
        report['status']='diagnostic_failed';report['error']={'type':type(e).__name__,'message':str(e)};raise
    finally:
        report['after']=guard();report['guards_equal']=report['before']==report['after']
        report['source_inventory_unchanged']=ss._inventory(S)==m['files']
        with OUT.open('x',encoding='utf-8') as f:json.dump(report,f,ensure_ascii=False,indent=2)
        assert report['guards_equal'] and report['source_inventory_unchanged']
if __name__=='__main__':main()
