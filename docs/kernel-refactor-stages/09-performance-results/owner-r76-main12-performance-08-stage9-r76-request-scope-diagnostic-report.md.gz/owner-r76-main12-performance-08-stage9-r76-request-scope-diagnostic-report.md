# r76 主12 请求范围诊断

固定stage9-build-source-owner-r76-release、完整verified book stage9-owner-main12-r76-verified.json及owned合成stage9-owner-main12-r43，原benchmark_stage9_browser.py --instrument --repeats10 --warmups3，正式release static、正常负责人本机凭据、实际同版prepared preview。未改production/FE/harness/原证据，未cProfile并行线程、调GC/优先级/网络/代理/计时口径。诊断进程exit0，会话已撤销、credential删除、server/thread/app finally关闭。受观察输入/源码及全部release asset SHA前后无变化；具体哈希和起止epoch列于report.json。

全浏览器阶段dashboard HTTP157次= context71、五页主71、close-review15，和dispatch逐一一致、全部HTTP200/succeeded。含初始brief与五页导航、每页warm3和每页sample10；实际测量50次刷新对应110请求（brief每次3，其他每次2），每次无重复。每个主请求对应同次context，brief另对应review。采用既有页面顺序/主请求末10个及近邻HTTP start关联，不虚构request ID；全部完整HTTP/dispatch与50样本映射在原JSON和analysis.json保留。

| 页面 | browser脚本median / max ms | 主dispatch常规median ms | 并行HTTP包络常规median ms | 尚未分段余量median / max ms |
| --- | --- | --- | --- | --- |
| brief | 457.0 / 496.6 | 428.9 | 430.0 | 34.5 / 42.3 |
| funds | 335.3 / 355.5 | 300.3 | 301.4 | 29.3 / 40.0 |
| employees | 237.0 / 296.3 | 208.7 | 209.7 | 32.1 / 43.0 |
| assets | 276.7 / 357.3 | 247.4 | 248.5 | 35.2 / 43.6 |
| reports | 436.0 / 496.1 | 402.7 | 403.7 | 35.7 / 41.6 |

browser脚本median使用既有percentile取位，另外两项包络/dispatch的median使用统计中位数；偶数样本两种口径不同，没有改原计时。余量逐样本为browser elapsed减HTTP并行全区间跨度，不能将表中两个median相减代替逐样本中位数。

所有50测量样本的最后服务端结束均主API；context/review与主读取并行，HTTP start spread最大1.717ms，没有请求串行相加证据。HTTP entry→dispatch start最大0.115ms；dispatch结束→handler结束最大3.346ms，公开HTTP handler入口已观察段没有明显排队或额外大序列化成本。dispatch本身包括授权、业务读取、公共response验证及dump_json，本轮没有内部profile，因此其成本不能继续细分。

简报最慢sample1 browser496.6ms；报表最慢sample8 browser496.1ms。全部诊断样本未复现>=500ms（不是达标验收）；原pure30每页中的brief4/reports3超目标样本完整保留，并列于analysis.json，未将此50样本覆盖、合并或相减为收益。既有pure失败没有HTTP/dispatch telemetry，不能从新样本反推旧7个的原因。

## 时间边界与证据缺口

HTTP与dispatch start/end共享benchmark内部perf_counter原点，它在native login与preview之前设定。HTTP入口是do_GET/do_POST handler开始，结束是handler返回，并不证明浏览器已经responseEnd；前于handler的socket/线程/浏览器调度不在区间中。

原browser harness使用每click ResourceTiming确认同scope/context/main/review已完成，再要求新可见DOM/aria-busy及twoRAF，但measure只输出elapsed并清窗口变量，未保存每次resource start/responseEnd、click epoch或共享origin。按不改harness约束，本轮保留原工具，不能把服务器区间精确落到浏览器时间轴；browser减HTTP包络的24–44ms余量仍混合click→handler前段、最后handler结束→传输/JSON/Ajv/Vue/布局/twoRAF后段。它不是净渲染时间，尚未确定旧慢样本来自其中哪段，若要分开这些区间需要后续明确授权的额外观测。

全样本/失败均保留，未泄露ticket/session/capability。此轮不验证授权/metadata/runtime开库内部call count，不省略既有安全、实际preview与锁语义。backend_build_id为local-kernel-2:9671294c37dd5e878ee9c2fb6dd6563a5ded03560ace4773af38a0ab2a802f20；source及前后文件SHA在独占commands/completion/report JSON。
