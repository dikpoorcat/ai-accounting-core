"""Immutable publication chains and the posting rule shared by all publishers."""

import hashlib

from .contracts import KernelError
from .types import YearMonth, canonical, digest

CONTENT_FIELDS = (
    "sequence",
    "subject_id",
    "previous_publication_id",
    "calculation_id",
    "mode",
    "posting_period",
    "baseline_calculation_id",
    "voucher_id",
)
_CONTENT_JSON_SQL = (
    "json_object(" + ",".join(f"'{field}',{field}" for field in sorted(CONTENT_FIELDS)) + ")"
)


def _invalid(ident, reason):
    raise KernelError(
        "content_integrity_failed",
        "正式发布关系不完整或不一致",
        component="publication",
        record_id=ident,
        reason=reason,
    )


def verify_record(row):
    """Verify a bounded publication record without loading its calculation."""
    if row["id"] != "p_" + digest({key: row[key] for key in CONTENT_FIELDS}).hex():
        _invalid(row["id"], "publication_digest")


def verified_period_headers(connection, periods):
    """Check every source field while returning only the period index metadata.

    The publication contract contains only TEXT, INTEGER and NULL fields. Its
    sorted-key SQLite JSON is the same UTF-8 canonical representation used to
    create the identity. No calculation body or second Python object is needed.
    Full chain verification continues to use ``verify_record`` independently.
    """
    yield from _verified_period_headers(connection, periods, {})


def _verified_period_headers(connection, periods, verified_ids):
    """Enumerate every actual header, reusing only an owned snapshot's digests.

    QueryReads supplies its existing successful identities only in its current
    read-only snapshot. Coverage and ordering still come from all physical rows;
    this private helper neither accepts public proof flags nor publishes success.
    """
    if verified_ids:
        selected = list(connection.execute(
            "SELECT id,posting_period,sequence FROM calculation_publication "
            "WHERE posting_period IN (SELECT value FROM json_each(?)) "
            "ORDER BY posting_period,sequence",
            (canonical(sorted(set(periods))),),
        ))
        pending = {}
        for row in selected:
            if row[0] in verified_ids:
                if verified_ids[row[0]] != row[1]:
                    _invalid(row[0], "publication_period_mismatch")
            else:
                pending[row[0]] = (row[1], row[2])
        checked = set()
        if pending:
            for row in connection.execute(
                "SELECT id,posting_period,sequence," + _CONTENT_JSON_SQL + " content "
                "FROM calculation_publication WHERE id IN (SELECT value FROM json_each(?)) "
                "ORDER BY posting_period,sequence",
                (canonical(sorted(pending)),),
            ):
                if pending.get(row[0]) != (row[1], row[2]) or row[0] in checked:
                    _invalid(row[0], "publication_header_mismatch")
                if row[0] != "p_" + hashlib.sha256(row[3].encode("utf-8")).hexdigest():
                    _invalid(row[0], "publication_digest")
                checked.add(row[0])
            if checked != pending.keys():
                _invalid("*", "publication_header_missing")
        for row in selected:
            yield {"id": row[0], "posting_period": row[1], "sequence": row[2]}
        return
    for row in connection.execute(
        "SELECT id,posting_period,sequence," + _CONTENT_JSON_SQL + " content "
        "FROM calculation_publication WHERE posting_period IN "
        "(SELECT value FROM json_each(?)) ORDER BY posting_period,sequence",
        (canonical(sorted(set(periods))),),
    ):
        if row[0] != "p_" + hashlib.sha256(row[3].encode("utf-8")).hexdigest():
            _invalid(row[0], "publication_digest")
        yield {"id": row[0], "posting_period": row[1], "sequence": row[2]}


def chain_rows(connection, subject_ids=None, *, publication_highwater=None):
    restrictions = []
    parameters = []
    if subject_ids is not None:
        restrictions.append("subject_id IN (SELECT value FROM json_each(?))")
        parameters.append(canonical(sorted(subject_ids)))
    if publication_highwater is not None:
        restrictions.append("sequence<=?")
        parameters.append(publication_highwater)
    restriction = " WHERE " + " AND ".join(restrictions) if restrictions else ""
    return [
        dict(r)
        for r in connection.execute(
            "SELECT * FROM calculation_publication" + restriction + " ORDER BY sequence", parameters
        )
    ]


def head(connection, subject_id):
    return heads(connection, [subject_id]).get(subject_id)


def heads(connection, subject_ids):
    rows = connection.execute(
        "SELECT p.*,c.period AS source_period FROM calculation_publication p "
        "JOIN json_each(?) ids ON p.subject_id=ids.value "
        "LEFT JOIN calculation c ON c.id=p.calculation_id WHERE "
        "NOT EXISTS(SELECT 1 FROM calculation_publication n "
        "WHERE n.previous_publication_id=p.id)",
        (canonical(sorted(subject_ids)),),
    )
    return {row["subject_id"]: dict(row) for row in rows}


def route(
    source_period, previous, closed_through, requested=None, *, no_impact=False, explicit=True
):
    """Return the complete decision; calling time never determines posting time."""
    requested = YearMonth(requested).ordinal if requested is not None else None
    if previous and previous["mode"] != "withdrawn":
        if no_impact:
            posting, mode = previous["posting_period"], "review_no_impact"
        elif previous["posting_period"] <= closed_through:
            posting, mode = requested, "closed_correction"
            if (
                requested is not None
                and source_period > closed_through
                and requested != source_period
            ):
                raise KernelError("posting_period_conflict", "所属月仍开放，更正须记入该所属月")
        else:
            # An open correction tranche keeps its original month, even if the
            # subject's original accounting month is already frozen.
            moved_to_open = (
                source_period > closed_through and source_period != previous["source_period"]
            )
            posting = source_period if moved_to_open else previous["posting_period"]
            mode = "open_replace"
    else:
        posting = requested if source_period <= closed_through else source_period
        mode = "initial"
    if posting is None:
        raise KernelError("posting_period_required", "所属月或原结果已关账，须明确指定开放入账月")
    if mode != "review_no_impact" and posting <= closed_through:
        raise KernelError("closed_period", "实际入账月份必须处于开放期")
    # An automatically recalculated open dependant retains its own month. The
    # requested month selects a closed correction; it cannot move that dependant.
    # Explicit roots still reject a conflicting month, including standalone review.
    constrained = (
        explicit
        or mode == "closed_correction"
        or (mode == "initial" and source_period <= closed_through)
    )
    if requested is not None and requested != posting and constrained:
        raise KernelError(
            "posting_period_conflict",
            "指定入账月与业务应采用的月份冲突",
            posting_period=str(YearMonth.from_ordinal(posting)),
        )
    baseline = (
        previous["calculation_id"]
        if mode == "closed_correction"
        else previous["baseline_calculation_id"]
        if previous and mode != "initial"
        else None
    )
    return {
        "source_period": source_period,
        "posting_period": posting,
        "mode": mode,
        "previous_publication_id": previous["id"] if previous else None,
        "baseline_calculation_id": baseline,
    }


def append(connection, subject_id, calculation_id, decision, voucher_id):
    sequence = connection.execute(
        "SELECT coalesce(max(sequence),0)+1 FROM calculation_publication"
    ).fetchone()[0]
    values = {
        "sequence": sequence,
        "subject_id": subject_id,
        "previous_publication_id": decision["previous_publication_id"],
        "calculation_id": calculation_id,
        "mode": decision["mode"],
        "posting_period": decision["posting_period"],
        "baseline_calculation_id": decision["baseline_calculation_id"],
        "voucher_id": voucher_id,
    }
    ident = "p_" + digest(values).hex()
    connection.execute(
        "INSERT INTO calculation_publication(id,sequence,subject_id,previous_publication_id,"
        "calculation_id,"
        "mode,posting_period,baseline_calculation_id,voucher_id) VALUES(?,?,?,?,?,?,?,?,?)",
        (ident, *values.values()),
    )
    return ident


def active_tranches(connection, subject_ids=None, *, publication_highwater=None):
    """Reconstruct effective segments without evaluating any historical fact."""
    active = {}
    for row in chain_rows(
        connection, subject_ids, publication_highwater=publication_highwater
    ):
        segments = active.setdefault(row["subject_id"], [])
        if row["mode"] in ("initial", "closed_correction"):
            segments.append(row)
        elif row["mode"] in ("open_replace", "review_no_impact"):
            if not segments:
                _invalid(row["id"], "missing_segment")
            segments[-1] = row
        elif row["mode"] == "withdrawn":
            if not segments:
                _invalid(row["id"], "missing_segment")
            segments.pop()
    return [row for segments in active.values() for row in segments]


def verify_publication_chain(connection, subject_ids=None):
    rows = chain_rows(connection, subject_ids)
    calculations = {
        row[0]: row[1]
        for row in connection.execute(
            "SELECT id,subject_id FROM calculation WHERE id IN (SELECT value FROM json_each(?))",
            (canonical(sorted({row["calculation_id"] for row in rows if row["calculation_id"]})),),
        )
    }
    heads = dict(
        connection.execute(
            "SELECT subject_id,calculation_id FROM calculation_current WHERE subject_id IN "
            "(SELECT value FROM json_each(?))",
            (canonical(sorted({row["subject_id"] for row in rows})),),
        )
    )
    previous = {}
    for row in rows:
        prior = previous.get(row["subject_id"])
        if row["previous_publication_id"] != (prior["id"] if prior else None):
            _invalid(row["id"], "chain_fork_or_gap")
        verify_record(row)
        if row["mode"] == "initial":
            if row["baseline_calculation_id"] or (prior and prior["mode"] != "withdrawn"):
                _invalid(row["id"], "initial_baseline")
        elif prior is None or prior["mode"] == "withdrawn":
            _invalid(row["id"], "missing_predecessor")
        elif row["mode"] == "closed_correction":
            if (
                row["baseline_calculation_id"] != prior["calculation_id"]
                or row["posting_period"] <= prior["posting_period"]
            ):
                _invalid(row["id"], "correction_baseline")
        elif row["baseline_calculation_id"] != prior["baseline_calculation_id"]:
            _invalid(row["id"], "segment_baseline")
        if row["mode"] == "review_no_impact" and (
            row["posting_period"] != prior["posting_period"]
            or row["voucher_id"] != prior["voucher_id"]
        ):
            _invalid(row["id"], "review_moved_accounting")
        if row["calculation_id"]:
            if calculations.get(row["calculation_id"]) != row["subject_id"]:
                _invalid(row["id"], "calculation_identity")
        elif row["mode"] != "withdrawn" or row["voucher_id"]:
            _invalid(row["id"], "missing_calculation")
        previous[row["subject_id"]] = row
    for subject, row in previous.items():
        if heads.get(subject) != row["calculation_id"]:
            _invalid(row["id"], "current_head")
    return {"subjects": len(previous)}


def verify_open_correction_heads(connection, calculations, publications, vouchers):
    """Check expected reversals only after complete source/chain/line verification.

    The supplied maps are the caller's strictly verified source scope. This
    helper creates neither a source proof nor a cache and never loads bodies.
    Preserved publications independently determine required versions, so a
    deleted reversal cannot disappear from its own expected set.
    """
    if not calculations:
        return
    by_id = {row["id"]: row for row in publications.values()}
    closed_through = connection.execute(
        "SELECT coalesce(max(period),-1) FROM period_close"
    ).fetchone()[0]
    current = list(connection.execute(
        "SELECT h.subject_id,h.calculation_id FROM json_each(?) ids "
        "JOIN calculation_current h ON h.calculation_id=ids.value",
        (canonical(sorted(calculations)),),
    ))
    expected_heads = {}

    def previous(publication):
        prior = by_id.get(publication["previous_publication_id"])
        if prior is None or prior["subject_id"] != publication["subject_id"]:
            _invalid(publication["id"], "correction_predecessor_missing")
        return prior

    def require_version(ident, voucher_id, calculation_id, period, reverses_id):
        actual = vouchers.get(ident)
        if actual is None or (
            actual["id"], actual["voucher_id"], actual["calculation_id"],
            actual["period"], actual["reverses_id"],
        ) != (ident, voucher_id, calculation_id, period, reverses_id):
            _invalid(ident, "correction_voucher_source_missing")
        return actual

    for head in current:
        terminal = publications.get(head["calculation_id"])
        if terminal is None or terminal["posting_period"] <= closed_through:
            continue
        if terminal["subject_id"] != head["subject_id"]:
            _invalid(terminal["id"], "correction_current_identity")
        path, visited = [], set()
        root = terminal
        while root["mode"] in {"review_no_impact", "open_replace"}:
            if root["id"] in visited:
                _invalid(root["id"], "correction_chain_cycle")
            visited.add(root["id"])
            path.append(root)
            root = previous(root)
        if root["mode"] != "closed_correction":
            continue
        baseline = calculations.get(root["baseline_calculation_id"])
        if baseline is None:
            _invalid(root["id"], "correction_baseline_source_missing")
        if not baseline["decoded"]["lines"]:
            # A cleared baseline has no posted version to reverse, even when
            # its publication retains an older reserved logical voucher.
            continue
        prior = previous(root)
        if prior["calculation_id"] != root["baseline_calculation_id"]:
            _invalid(root["id"], "correction_baseline_identity")
        original_publication = prior
        reviewed = set()
        while original_publication["mode"] == "review_no_impact":
            if original_publication["id"] in reviewed:
                _invalid(original_publication["id"], "correction_chain_cycle")
            reviewed.add(original_publication["id"])
            original_publication = previous(original_publication)
        if prior["voucher_id"] is None:
            _invalid(root["id"], "correction_baseline_voucher_missing")
        original_id = "v_" + digest([
            prior["voucher_id"], original_publication["calculation_id"],
            prior["posting_period"], None,
        ]).hex()
        original = require_version(
            original_id, prior["voucher_id"], original_publication["calculation_id"],
            prior["posting_period"], None,
        )
        reverse_voucher = root["calculation_id"] + ":reverse"
        reverse_calculation = root["calculation_id"]
        posting = root["posting_period"]
        for later in reversed(path):
            if later["posting_period"] != posting:
                if later["mode"] != "open_replace":
                    _invalid(later["id"], "correction_review_moved_period")
                reverse_calculation = later["calculation_id"]
            posting = later["posting_period"]
        reverse_id = "v_" + digest([
            reverse_voucher, reverse_calculation, posting, original_id,
        ]).hex()
        reversal = require_version(
            reverse_id, reverse_voucher, reverse_calculation, posting, original_id,
        )
        if reversal["total"] != original["total"]:
            _invalid(reverse_id, "correction_reversal_total_mismatch")
        expected_heads[reverse_voucher] = reverse_id
    if not expected_heads:
        return
    heads = dict(connection.execute(
        "SELECT ids.value,h.version_id FROM json_each(?) ids "
        "LEFT JOIN voucher_current h ON h.voucher_id=ids.value",
        (canonical(sorted(expected_heads)),),
    ))
    if heads != expected_heads:
        _invalid("*", "correction_current_reversal_missing")
