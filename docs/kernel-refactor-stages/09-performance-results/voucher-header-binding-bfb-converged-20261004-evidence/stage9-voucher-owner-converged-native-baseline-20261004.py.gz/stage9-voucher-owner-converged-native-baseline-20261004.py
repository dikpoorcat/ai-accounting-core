"""One instrumented native read per entry. No timing or new qualification claim."""
import cProfile
from collections import Counter, defaultdict
from contextlib import closing, contextmanager
import hashlib
import json
from pathlib import Path
import pstats
import sqlite3
import sys
import time

W=Path(__file__).resolve().parents[1]
S=W/'.tmp/stage9-build-source-frozen-member-guard-20261004'
Q=W/'.tmp/stage9-owner-proof-read-work-large-main120-browser-20261004-qualified.json'
R=W/'.tmp/stage9-draft-fixture-main120-20261003'
OUT=W/'.tmp/stage9-voucher-owner-converged-native-baseline-20261004.json'
SEAL='80735c1e2832458cacb1e13097b9efd3e357cd5bd09fe6a67ad56716eef08613'
MANIFEST_SHA='fd92ae66b32a466f4f1f7526668094098c6fc5b1b05f3e6d2248cd0092a85d95'
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def main():
    assert Path(sys.prefix).resolve()==W/'.tmp-kernel-venv'
    assert not OUT.exists()
    mpath=S/'source-manifest.json'; m=json.loads(mpath.read_text('utf-8')); q=json.loads(Q.read_text('utf-8'))
    assert m['status']==q['status']=='complete' and m['sha256']==SEAL and m['file_count']==766
    assert sha(mpath)==MANIFEST_SHA
    assert q['qualification']['source_manifest_sha256']=='00f133223a9269ed8f232bb66950747250dbfdf48c63c29455aff0b48d7bf66a'
    assert Path(q['source']).resolve()==W/'.tmp/stage9-build-source-owner-proof-read-work-20261004' and Path(q['root']).resolve()==R
    assert q['requested_months']==120 and q['business_count']==120000 and q['monthly_business_count']==1000
    assert q['integrity']['status']=='verified' and q['integrity']['limitations']==[]
    assert q['integrity']['coverage']==dict.fromkeys(('sources','historical_adoption','projections','read_indexes'),'verified')
    co=q['company']; db=Path(co['path']).resolve()
    assert co['name']=='阶段九合成规模企业' and db==R/co['taxpayer_id']/'company.sqlite'
    period=q['verified_open_preview']['period']; state=q['verified_open_preview']['state']
    assert period=='2025-12' and state==[1,5167,2820,296,120598,0]
    assert sha(R/'stage9-builder.json')==q['qualification']['checkpoint_sha256']
    sys.path.insert(0,str(S/'scripts'))
    import stage9_source
    stage9_source.configure_source(S,W)
    import snapshot_stage9_source as ss
    from ai_accounting.kernel.runtime import connect
    from ai_accounting.kernel.versions import verify_schema,database_format
    from ai_accounting.kernel.schema_bundle import production_bundle
    from ai_accounting.kernel.read_state import repair_revision
    from ai_accounting.kernel.catalog import Catalog
    from ai_accounting.kernel.engine import Engine
    from ai_accounting.kernel.dashboard import Dashboard
    from ai_accounting.kernel.resident_reads import ResidentReadPool
    from ai_accounting.kernel.types import canonical
    import stage9_metrics as metrics
    import ai_accounting.kernel.dashboard as dashboard_module
    import ai_accounting.kernel.runtime as runtime_module
    for module,rel in ((stage9_source,'scripts/stage9_source.py'),(ss,'scripts/snapshot_stage9_source.py'),
        (runtime_module,'src/ai_accounting/kernel/runtime.py'),(dashboard_module,'src/ai_accounting/kernel/dashboard.py'),
        (metrics,'tests/kernel/stage9_metrics.py')): stage9_source.require_source_module(module,S,rel)
    assert ss._inventory(S)==m['files'] and ss._digest(m['files'])==SEAL
    bundle=production_bundle(); assert bundle.status=='draft' and dict(bundle.current_versions)=={'company':0,'catalog':0}
    def guard():
        g={'files':{str(p):sha(p) if p.exists() else None for p in (Q,mpath,R/'stage9-builder.json',
            db,Path(str(db)+'-wal'),R/'catalog.sqlite',Path(str(R/'catalog.sqlite')+'-wal'))}}
        for kind,p in (('company',db),('catalog',R/'catalog.sqlite')):
            with closing(connect(p,read_only=True,validator=lambda c:verify_schema(c,bundle=bundle,kind=kind))) as c:
                assert c.execute('PRAGMA query_only').fetchone()[0]==1;c.execute('BEGIN')
                try:
                    g[kind]={'format':database_format(c,bundle=bundle,kind=kind)};c.row_factory=None
                    tables=('identity','state','schema_history','read_repair_state') if kind=='company' else ('catalog_identity','security_owner','schema_history','company')
                    for table in tables:
                        if c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",(table,)).fetchone():
                            g[kind][table]=hashlib.sha256(repr(c.execute('SELECT * FROM '+table).fetchall()).encode()).hexdigest()
                    if kind=='company':
                        assert c.execute('SELECT company_id,database_id,taxpayer_id FROM identity').fetchone()==(co['id'],co['database_id'],co['taxpayer_id'])
                        assert list(c.execute('SELECT * FROM state WHERE id=1').fetchone())==state and repair_revision(c)==0
                    else:
                        owners=c.execute('SELECT login_name FROM security_owner').fetchall()
                        assert len(owners)==1 and owners[0][0] in ('synthetic-stage9-owner','synthetic-stage9-native-profile')
                finally:c.rollback()
        return g
    before=guard()
    class ReadOnlyCatalog(Catalog):
        @contextmanager
        def connection(self,*,read_only=False,_cross_thread=False):
            assert read_only
            with super().connection(read_only=True,_cross_thread=_cross_thread) as c:yield c
        def recover_operations(self):
            with self.connection(read_only=True) as c:
                assert c.execute("SELECT count(*) FROM company_operation WHERE status!='succeeded'").fetchone()[0]==0
    catalog=ReadOnlyCatalog(R,bundle); companies=catalog.companies()
    assert [x for x in companies if x['id']==co['id']]==[co]
    def business(value):
        result = json.loads(canonical(value))
        for field in ('generated_at', 'checked_at'):
            if field in result:
                result[field] = '<response clock>'
        if isinstance(result.get('data'), dict) and 'generated_at' in result['data']:
            result['data']['generated_at'] = '<response clock>'
        if 'read_context' in result:
            result['read_context']['read_version'] = '<source-bound read token>'
        return hashlib.sha256(canonical(result).encode()).hexdigest()
    report = {'status':'started', 'diagnostic_only':True,
        'source_sha256':SEAL,'source_manifest_sha256':MANIFEST_SHA,
        'qualified_sha256':sha(Q),'source_diff_receipt_sha256':sha(W/'.tmp/stage9-voucher-owner-converged-source-diff-20261004.json'),
        'qualification_scope':'source-bound c3c3 full verification and prepared preview; current changed source is native diagnostic only, not fresh browser qualification',
        'script_sha256':sha(__file__),'before':before,'observations':[],
        'limitations':['native synchronous read latency only, not HTTP, rendering or whole-page 500ms acceptance',
            'no profiler, SQL/VM/decode observer, service, auth, preview or business writes',
            'owner_review_request is absent: this does not exercise prepared owner TODO',
            'three warmups and all thirty successful measured samples per native entry; slow and failed samples retained']}
    try:
        with closing(ResidentReadPool(maximum=1)) as pool:
            store=catalog.bind(co['id'],read_pool=pool)
            engine=Engine(store)
            board=Dashboard(engine,company_name=co['name'],companies=companies)
            operations={'assets':lambda:board.assets(period,limit=20,preparation='deferred'),
                'brief':lambda:board.brief(period,limit=20),
                'quarterly_report':lambda:board.quarterly_report(2025,4,preparation='deferred'),
                'funds':lambda:board.funds(period,limit=20,preparation='deferred'),
                'employees':lambda:board.employees(period,limit=20,preparation='deferred')}
            for name,op in operations.items():
                warmups=[]
                for _ in range(3):
                    start=time.perf_counter();response=op();warmups.append((time.perf_counter()-start)*1000)
                assert response['read_context']['company_id']==co['id']
                expected=business(response)
                measured=[];digests=[]
                for i in range(30):
                    start=time.perf_counter()
                    try:
                        response=op()
                    except Exception as exc:
                        measured.append({'round':i,'milliseconds':(time.perf_counter()-start)*1000,
                            'status':'error','error_type':type(exc).__name__})
                        report['observations'].append({'page':name,'warmups':warmups,'samples':measured})
                        raise
                    duration=(time.perf_counter()-start)*1000
                    measured.append({'round':i,'milliseconds':duration,'status':'succeeded'})
                    digests.append(business(response))
                    assert digests[-1]==expected
                values=sorted(x['milliseconds'] for x in measured)
                observation={'page':name,'warmups':warmups,'samples':measured,
                    'median_ms':(values[14]+values[15])/2,'p95_ms':values[28],'max_ms':values[-1],
                    'business_response_sha256':expected,'business_digest_stable':True,
                    'response_bytes':len(canonical(response).encode())}
                report['observations'].append(observation)
                print(json.dumps({k:v for k,v in observation.items() if k not in ('samples','warmups')},ensure_ascii=False),flush=True)
            pool.close();assert pool._closed and pool._total==0 and not pool._idle
            report['read_pool_closed']=True
        report['status']='diagnostic_complete'
    except Exception as exc:
        report['status']='diagnostic_failed';report['error']={'type':type(exc).__name__,'message':str(exc)};raise
    finally:
        report['after']=guard();report['guards_equal']=report['before']==report['after']
        report['source_inventory_unchanged']=ss._inventory(S)==m['files']
        with OUT.open('x',encoding='utf-8') as f:json.dump(report,f,ensure_ascii=False,indent=2)
        assert report['guards_equal'] and report['source_inventory_unchanged']
if __name__=='__main__':main()
