"""Fixed r73 native/work diagnosis; not browser acceptance or full verification."""
from pathlib import Path

previous = Path(__file__).with_name("stage9-resident-r64-main48-profile.py")
source = previous.read_text(encoding="utf-8")
assert source.count("stage9-build-source-owner-r64-release") == 1
assert source.count("stage9-owner-main48-r63-verified.json") == 1
exec(compile(source.replace("r64", "r73"), str(previous), "exec"))
