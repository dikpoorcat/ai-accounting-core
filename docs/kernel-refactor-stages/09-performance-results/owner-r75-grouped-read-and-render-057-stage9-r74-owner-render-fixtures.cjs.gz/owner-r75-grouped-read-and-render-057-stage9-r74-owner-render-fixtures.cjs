const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {createRequire}=require('node:module');
const {pathToFileURL}=require('node:url');
const requireFrontend=createRequire(path.resolve('frontend/package.json'));
(async()=>{
 const {createServer}=await import(pathToFileURL(requireFrontend.resolve('vite')).href);
 const vue=(await import(pathToFileURL(requireFrontend.resolve('@vitejs/plugin-vue')).href)).default;
 const {chromium}=require('C:/Users/MD01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
 const samples=JSON.parse(fs.readFileSync('frontend/tests/fixtures/dashboard-contracts.json','utf8'));
 const responses={context:samples.company_with_period.response,brief:samples.brief.response,funds:samples.cash_funds.response,employees:samples.employees.response,assets:samples.assets.response,'quarterly-report':samples.quarterly_report.response};
 const cid=responses.context.current_company.company_id;
 responses['close-review']={schema_version:2,company_id:cid,database_id:'synthetic-fixture-db',period:'2026-01',state:'unprepared',preview_digest:null,close_digest:null,reason:'preview_missing',covered_by:null,owner_review:null};
 const entry=`import {createApp,h} from 'vue';import {createRouter,createWebHistory,RouterView} from 'vue-router';
 import Brief from '/src/views/BriefView.vue';import Funds from '/src/views/FundsView.vue';import Employees from '/src/views/EmployeesView.vue';import Assets from '/src/views/AssetsView.vue';import Reports from '/src/views/ReportsView.vue';
 const router=createRouter({history:createWebHistory(),routes:[{path:'/',name:'brief',component:Brief},{path:'/funds',name:'funds',component:Funds},{path:'/employees',name:'employees',component:Employees},{path:'/assets',name:'assets',component:Assets},{path:'/reports',name:'reports',component:Reports}]});
 window.__renderRouter=router; const App={render:()=>h(RouterView)};await router.isReady();createApp(App).use(router).mount('#app');`;
 // Install Router before waiting for its first navigation.
 const fixedEntry=entry.replace("await router.isReady();createApp(App).use(router).mount('#app');","const app=createApp(App);app.use(router);await router.isReady();app.mount('#app');");
 const server=await createServer({root:path.resolve('frontend'),configFile:false,optimizeDeps:{noDiscovery:true},plugins:[{name:'synthetic-render-entry',resolveId(id){if(id==='/@render-entry.js')return '\0render-entry';},load(id){if(id==='\0render-entry')return fixedEntry;},configureServer(s){s.middlewares.use(async(req,res,next)=>{if(['/','/funds','/employees','/assets','/reports'].includes(req.url.split('?')[0])){res.setHeader('Content-Type','text/html');res.end(await s.transformIndexHtml(req.url,'<html><body><div id="app"></div><script type="module" src="/@render-entry.js"></script></body></html>'));}else next();});}},vue()],server:{port:0,host:'127.0.0.1',hmr:false,ws:false}});
 let browser,activePage;const observations=[],failures=[];
 const output='.tmp/stage9-r74-owner-render-fixtures-final.json';assert(!fs.existsSync(output));
 try{
  await server.listen();const origin=`http://127.0.0.1:${server.httpServer.address().port}`;
  browser=await chromium.launch({channel:'msedge',headless:true});
  for(const [name,urlPath,action,selector] of [['brief','/','brief','#overview'],['funds','/funds','funds','#funds-overview'],['employees','/employees','employees','#employees-overview'],['assets','/assets','assets','#assets-overview'],['reports','/reports','quarterly-report','#report-overview']]){
   const page=await browser.newPage();activePage=page;page.on('pageerror',e=>failures.push({page:name,error:e.name,message:e.message.slice(0,140)}));
   let phase='normal',release,mainCalls=0,reviewCalls=0;
   await page.route('**/api/**',async route=>{
    if(!new URL(route.request().url()).pathname.startsWith('/api/'))return route.continue();
    const api=new URL(route.request().url()).pathname.split('/').at(-1);
    if(api===action){mainCalls++;if(phase==='held')await new Promise(r=>release=r);if(phase==='error')return route.fulfill({status:500,contentType:'application/json',body:JSON.stringify({code:'synthetic_read_failure',message:'资料读取失败'})});}
    if(api==='close-review')reviewCalls++;
    return route.fulfill({status:200,contentType:'application/json',body:JSON.stringify(responses[api]||{})});
   });
   const url=new URL(urlPath,origin);url.searchParams.set('company_id',cid);url.searchParams.set('period','2026-01');if(name==='reports')url.searchParams.set('quarter','2026-Q1');
   await page.goto(url.href);await page.waitForFunction(sel=>document.querySelector(sel)?.getClientRects().length && document.querySelector('.module-header')?.getAttribute('aria-busy')==='false',selector);
   const beforeMain=mainCalls,beforeReview=reviewCalls;
   await page.evaluate(sel=>{window.__oldRoot=document.querySelector(sel);window.__oldContent=document.querySelector('.brief-content,.funds-result,.employee-result,.asset-result,.report-dashboard');window.__oldChildren=[...window.__oldContent.querySelectorAll('*')];},selector);
   phase='held';await page.locator('.module-header button.refresh').click();
   await page.waitForFunction(()=>document.querySelector('.module-header')?.getAttribute('aria-busy')==='true');
   const loading=await page.evaluate(()=>({connected:window.__oldRoot.isConnected,visible:!!window.__oldRoot.getClientRects().length,content_display:getComputedStyle(window.__oldContent).display,old_children_connected:window.__oldChildren.filter(n=>n.isConnected).length}));
   assert(loading.connected&&!loading.visible,`${name}: retained old content must be mounted and hidden`);
   assert.equal(loading.content_display,'none',`${name}: hide the complete old projection`);
   await page.waitForTimeout(20);assert(release,`${name}: main request started`);phase='normal';release();
   await page.waitForFunction(sel=>document.querySelector(sel)?.getClientRects().length&&document.querySelector('.module-header')?.getAttribute('aria-busy')==='false',selector);
   const completed=await page.evaluate(sel=>({same_root:window.__oldRoot===document.querySelector(sel),old_children_connected:window.__oldChildren.filter(n=>n.isConnected).length,old_child_count:window.__oldChildren.length}),selector);
   assert(completed.same_root,`${name}: refresh must reuse overview root`);
   assert.equal(mainCalls-beforeMain,1,`${name}: no duplicated main request`);
   if(name==='brief')assert.equal(reviewCalls-beforeReview,1,'one new owner review prefetch');
   phase='error';await page.locator('.module-header button.refresh').click();
   await page.waitForFunction(()=>document.querySelector('.module-header')?.getAttribute('aria-busy')==='false'&&!!document.querySelector('[role="alert"]'));
   const error=await page.evaluate(()=>({old_connected:window.__oldRoot.isConnected,old_visible:!!window.__oldRoot.getClientRects().length}));assert(!error.old_connected&&!error.old_visible,`${name}: failed read must clear old content`);
   phase='normal';await page.reload();await page.waitForFunction(sel=>document.querySelector(sel)?.getClientRects().length&&document.querySelector('.module-header')?.getAttribute('aria-busy')==='false',selector);
   await page.evaluate(sel=>window.__scopeRoot=document.querySelector(sel),selector);
   phase='held';await page.evaluate(()=>window.__renderRouter.push({query:{...window.__renderRouter.currentRoute.value.query,company_id:'synthetic-other-company'}}));
   const switched=await page.evaluate(()=>({old_connected:window.__scopeRoot.isConnected,old_visible:!!window.__scopeRoot.getClientRects().length}));assert(!switched.old_connected&&!switched.old_visible,`${name}: company switch clears immediately`);
   observations.push({page:name,loading,completed,error,switched,main_requests_per_refresh:1,review_requests_per_refresh:name==='brief'?1:0});await page.close();
  }
  assert.deepEqual(failures,[]);fs.writeFileSync(output,JSON.stringify({status:'complete',scope:'current_vue_generated_synthetic_fixture_mount_hide_error_scope_diagnostic_not_acceptance',observations,failures},null,2));
 }catch(e){const rendered=activePage&&!activePage.isClosed()?await activePage.locator('body').innerText():'';fs.writeFileSync(output,JSON.stringify({status:'failed',error:e.message,rendered:rendered.slice(0,800),observations,failures},null,2));process.exitCode=1;}
 finally{if(browser)await browser.close();await server.close();}
 console.log(JSON.stringify({output,observations,failures}));
})();
