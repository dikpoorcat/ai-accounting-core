"""Read-only exact frozen-flow/header overlap diagnostic; not latency acceptance."""

from __future__ import annotations

import hashlib
import json
import sys
import traceback
from collections import Counter, defaultdict
from contextlib import contextmanager
from pathlib import Path
from types import SimpleNamespace

WORKSPACE = Path(__file__).resolve().parents[1]
SOURCE = WORKSPACE / '.tmp/stage9-build-source-owner-read-groups-20261003-release'
SOURCE_SHA = '46f84508afd54165f23af5a83434b1881002ab45490f4358f0c1755c743748be'
MANIFEST_SHA = 'f6712860b71bda18b8c41078410c8fba918f97da6fd6426d47992e4a8130283a'
BOOK = WORKSPACE / '.tmp/stage9-owner-main48-read-groups-qualified.json'
BOOK_SHA = 'edca0e5294a91520cbfeacb71df0f4b90862c12d89236c9399465ca675f0d846'
OUTPUT = WORKSPACE / '.tmp/stage9-report-flow-header-overlap-46f845.json'
LOG = WORKSPACE / '.tmp/stage9-report-flow-header-overlap-46f845.log'
HEADER_PREFIX = 'SELECT f.id,f.digest,f.period,s.kind,c.voucher_version_id'


def require(value, message):
    if not value:
        raise ValueError(message)


def file_hash(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def main():
    require(not OUTPUT.exists() and not LOG.exists(), 'Refuse existing diagnostic output/log')
    require(Path(sys.prefix).resolve() == (WORKSPACE / '.tmp-kernel-venv').resolve(),
            'Use repository virtual environment')
    log = LOG.open('x', encoding='utf-8')
    report = {'status': 'started', 'scope': 'read_only_frozen_flow_header_overlap',
              'latency_acceptance': False, 'source': str(SOURCE), 'source_sha256': SOURCE_SHA,
              'book': str(BOOK), 'book_sha256': BOOK_SHA, 'months': []}
    OUTPUT.open('x', encoding='utf-8').close()

    def save():
        OUTPUT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

    def note(message):
        print(message, flush=True)
        log.write(message + '\n')
        log.flush()

    try:
        require(file_hash(SOURCE / 'source-manifest.json') == MANIFEST_SHA, 'Manifest changed')
        require(file_hash(BOOK) == BOOK_SHA, 'Qualified book receipt changed')
        manifest = json.loads((SOURCE / 'source-manifest.json').read_text(encoding='utf-8'))
        require(manifest['sha256'] == SOURCE_SHA and manifest['status'] == 'complete'
                and Path(manifest['target']).resolve() == SOURCE, 'Wrong manifest binding')
        sys.path.insert(0, str(SOURCE / 'scripts'))
        import stage9_source
        stage9_source.configure_source(SOURCE, WORKSPACE)
        import snapshot_stage9_source
        import stage9_metrics
        from ai_accounting.kernel import close_storage, query_reads, report_flow, schema_bundle, storage
        from ai_accounting.kernel.types import YearMonth, canonical
        from ai_accounting.kernel.versions import database_format

        modules = ((stage9_source, 'scripts/stage9_source.py'),
                   (snapshot_stage9_source, 'scripts/snapshot_stage9_source.py'),
                   (stage9_metrics, 'tests/kernel/stage9_metrics.py'),
                   (close_storage, 'src/ai_accounting/kernel/close_storage.py'),
                   (query_reads, 'src/ai_accounting/kernel/query_reads.py'),
                   (report_flow, 'src/ai_accounting/kernel/report_flow.py'),
                   (schema_bundle, 'src/ai_accounting/kernel/schema_bundle.py'),
                   (storage, 'src/ai_accounting/kernel/storage.py'))
        for module, relative in modules:
            stage9_source.require_source_module(module, SOURCE, relative)
        inventory = snapshot_stage9_source._inventory(SOURCE)
        require(inventory == manifest['files']
                and snapshot_stage9_source._digest(inventory) == SOURCE_SHA, 'Source bytes changed')
        report['module_bindings'] = {module.__name__: str(module.__file__) for module, _ in modules}
        report['source_inventory_count'] = len(inventory)
        book = json.loads(BOOK.read_text(encoding='utf-8'))
        root = stage9_source.synthetic_path(Path(book['root']), WORKSPACE)
        require(root == WORKSPACE / '.tmp/stage9-owner-main48-r63'
                and Path(book['source']).resolve() == SOURCE and book['requested_months'] == 48
                and book['monthly_business_count'] == 1000 and book['employee_count'] == 50,
                'Wrong synthetic sample')
        company = book['company']
        database = Path(company['path']).resolve(strict=True)
        require(database.is_relative_to(root) and database.name == 'company.sqlite', 'Wrong database')
        bundle = schema_bundle.production_bundle()
        require(bundle.status == 'released', 'Wrong release contract')
        store = storage.Store(database, bundle, company['id'], company['database_id'],
                              taxpayer_id=company['taxpayer_id'])
        original_connection = store.connection
        counts, statements, work = Counter(), Counter(), defaultdict(Counter)
        outcomes = set()
        current = [None]
        requested_counts = Counter()
        actual_counts = Counter()
        header_records = []
        sql_text = [None]
        sql_plan = []

        class HeaderCursor:
            def __init__(self, cursor):
                self.cursor = cursor

            def __iter__(self):
                return self

            def __next__(self):
                row = next(self.cursor)
                if row['id'] is not None:
                    actual_counts[row['id']] += 1
                current[0]['queried_headers'].append({
                    'id': row['id'], 'digest': row['digest'].hex() if row['digest'] else None,
                    'period': row['period'], 'kind': row['kind'],
                    'voucher_version_id': row['voucher_version_id'],
                })
                return row

            def __getattr__(self, name):
                return getattr(self.cursor, name)

        class Connection(stage9_metrics._Connection):
            def execute(self, statement, parameters=()):
                normalized = ' '.join(statement.split())
                if normalized.startswith(HEADER_PREFIX):
                    require(current[0] is not None, 'Header query outside tracked month')
                    ids = json.loads(parameters[0])
                    current[0]['requested_ids'] = ids
                    requested_counts.update(ids)
                    header_records.append((normalized, parameters))
                    sql_text[0] = normalized
                    return HeaderCursor(super().execute(statement, parameters))
                return super().execute(statement, parameters)

        @contextmanager
        def counted_connection(*, read_only=False):
            require(read_only, 'Diagnostic forbids writes')
            with original_connection(read_only=True) as raw:
                def progress():
                    counts['sqlite_vm_steps'] += 100
                    return 0
                raw.set_progress_handler(progress, 100)
                try:
                    yield Connection(raw, counts, statements, work, outcomes)
                finally:
                    raw.set_progress_handler(None, 0)

        store.connection = counted_connection
        with query_reads.QueryReads.snapshot(SimpleNamespace(store=store)) as reads:
            connection = reads.connection
            initial_state = list(connection.execute('SELECT * FROM state WHERE id=1').fetchone())
            identity = dict(connection.execute(
                'SELECT company_id,taxpayer_id,database_id FROM identity WHERE id=1').fetchone())
            require(initial_state == book['verified_open_preview']['state']
                    and identity == {'company_id': company['id'], 'taxpayer_id': company['taxpayer_id'],
                                     'database_id': company['database_id']}, 'Sample identity/state drift')
            format_receipt = database_format(connection, bundle=bundle)
            require(format_receipt == book['integrity_contract'], 'Sample schema binding drift')
            report['schema_binding'] = format_receipt
            report['state'] = initial_state
            report['database'] = str(database)
            for period_string in ['2018-12', *[f'2019-{month:02d}' for month in range(1, 12)]]:
                month = {'period': period_string, 'requested_ids': [], 'queried_headers': []}
                current[0] = month
                before_counts = counts.copy()
                before_header = work[sql_text[0]].copy() if sql_text[0] else Counter()
                period = YearMonth(period_string).ordinal
                flow = report_flow.read_report_flow(connection, period, reads=reads)
                require(flow is not None, 'Flow classification selection fallback')
                refs = [list(item) for item in flow['classification_refs']]
                require(month['requested_ids'] == [item[0] for item in refs], 'SQL IDs differ from flow refs')
                source_vouchers = set(flow['source_vouchers'])
                selected = [row for row in month['queried_headers']
                            if row['period'] == period or row['voucher_version_id'] in source_vouchers]
                require([(row['id'], row['digest']) for row in selected] == [tuple(item) for item in refs],
                        'Exact monthly reference membership/digest mismatch')
                month.update({'independent_frozen_root_verified': True, 'source_root': flow['root'].hex(),
                              'classification_refs': refs, 'source_voucher_count': len(source_vouchers),
                              'month_period_matches': sum(row['period'] == period for row in selected),
                              'voucher_membership_matches': sum(row['voucher_version_id'] in source_vouchers
                                                                for row in selected),
                              'both_matches': sum(row['period'] == period
                                                  and row['voucher_version_id'] in source_vouchers
                                                  for row in selected),
                              'filtered_out_headers': len(month['queried_headers']) - len(selected),
                              'all_sql_work': dict(counts - before_counts),
                              'header_sql_work': dict(work[sql_text[0]] - before_header)})
                report['months'].append(month)
                save()
                note(f"{period_string}: verified refs={len(refs)} filtered_out={month['filtered_out_headers']}")
            require(list(connection.execute('SELECT * FROM state WHERE id=1').fetchone()) == initial_state,
                    'Business state changed during read transaction')
            connection.connection.set_progress_handler(None, 0)
            for query, parameters in header_records[:1]:
                sql_plan = [list(row) for row in connection.connection.execute(
                    'EXPLAIN QUERY PLAN ' + query, parameters)]
            report['header_sql'] = sql_text[0]
            report['header_sql_plan'] = sql_plan
            report['header_total_work'] = dict(work[sql_text[0]])
        sets = {month['period']: set(month['requested_ids']) for month in report['months']}
        report['requested_id_query_counts'] = dict(sorted(requested_counts.items()))
        report['actual_id_query_counts'] = dict(sorted(actual_counts.items()))
        report['requested_total'] = sum(requested_counts.values())
        report['unique_ids'] = len(requested_counts)
        report['repeated_requests'] = sum(requested_counts.values()) - len(requested_counts)
        report['pairwise_intersections'] = [
            {'left': left, 'right': right, 'count': len(sets[left] & sets[right])}
            for index, left in enumerate(sets) for right in list(sets)[index + 1:]
        ]
        require(snapshot_stage9_source._inventory(SOURCE) == inventory, 'Source drifted during diagnostic')
        require(file_hash(BOOK) == BOOK_SHA, 'Qualified receipt drifted')
        report['status'] = 'diagnostic_complete'
        save()
        note(f"complete: total={report['requested_total']} unique={report['unique_ids']} "
             f"repeated={report['repeated_requests']}; no latency claim")
    except BaseException as exc:
        report['status'] = 'failed'
        report['error'] = {'type': type(exc).__name__, 'message': str(exc), 'traceback': traceback.format_exc()}
        save()
        note(report['error']['traceback'])
        raise
    finally:
        log.close()


if __name__ == '__main__':
    main()
