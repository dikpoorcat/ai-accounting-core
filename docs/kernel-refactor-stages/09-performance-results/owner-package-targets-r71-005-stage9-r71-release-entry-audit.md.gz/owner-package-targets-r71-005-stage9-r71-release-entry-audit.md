# r71 正式发布入口只读核对

本次只读当前代码、已保存合成回执及计划，不执行测试、SQL、建库、冻结、服务、包或计时，不读真实data。当前生产仍draft/0，仅catalog/company draft合同存在；r70注册主12/主48/独立12核验通过不等于正式仓库冻结，主48browser仍37/150失败。r71银行相关84项包含原9项，资产和最终性能尚未完成；不能据此提前执行下面正式步骤。

## 根因分组：实现、实际依据、缺口

| 类别及实际位置 | 可执行的实现／已保存依据 | 确实缺失或仍待验证 |
| --- | --- | --- |
| 冻结引导顺序：scripts/export_kernel_schema_contracts.py:15–126，schema_bundle.py:18–19,187–231 | --candidate-v1只用default_registry算正文；--freeze-v1要求选择器released/1，三正文先全部计算，再open(x)创建，已有目标拒绝，失败回撤本次文件；--check比较三正文。无需先调用缺合同的production_bundle。 | 当前正式三合同未创建／选择器未切；这是已实现但未执行。内容合同会冻结必要v1规则源SHA，不能在冻结后回写合同来掩盖后续规则改动。 |
| 升级被误称跨库原子／自动备份：cli.py:71–81，offline_upgrade.py:131–314 | CLI --root ROOT upgrade直接调用upgrade_root；锁前完整预检、resident锁后再核验；公司逐库事务，目录最后，已完成库verified_skip。公司源／目标核验及保留历史，目录登记／身份／历史摘要核对。隔离fixture已覆盖失败、回滚及重试；复制released源码真实call/daemon负测有8通过＋2定向修复回执。 | production_bundle未提供任何正式v2合同或steps；真实跨版产品能力缺失，不能拿合成v2或同版verified_skip充当已发布跨版迁移。首版交付应验证同版skip／真实daemon锁拒绝即可，不为了演示升级添加假生产v2。正式upgrade不自动备份；开发upgrade-development是另一入口，也不是draft→released转换。 |
| v1被误称复制全部实现／存在文件即通过：content_v1.py:459–577，content_history_context.py，integrity.py | 固定descriptor重建models/references，核历史／存储／领域模块源摘要；verify_v1_company进入historical_content(1)，通用完整核验编排按版本选择固定解码／规则。test_v1_stored_json_isolation真实非空来源、冻结结果、重复键及未来decoder抛错场景；其fixture使用隔离bundle与monkeypatch，不能替代正式工厂。 | 机制已实现；当前最终released工厂／独立包非空v1重验未完成。未来新增正式v2须登记对应合同／步骤／内容checker；没有“自动接受当前模型变化”的通用迁移。 |
| 独立包被误称文件复制即验收：package_local_kernel.py:266–393，verify_local_package.py:1223–1290,1988–2102,2222–2297 | packager只有--output与--skip-validation，无--source；固定Windows Python3.12.13／SQLite3.53.1。拷allowlist、排env/DB/宿主路径；source_build_id与包runtime构建身份核对；ZIP新建并重定位，以包内-I -B解释器、毒化宿主环境执行完整自检。released分支实际CLI锁拒绝、停后两次same-version upgrade、默认启动器真实daemon锁拒绝；stdio initialize/list_tools/业务查询。 | 两旧stage9-package-draft-check-{1,2}-verification.json确为passed，但均draft/0、packaged_offline_upgrade=null，不能证明released专用分支；最终released包不存在对应完成证据。此为未执行，不是缺packager。固定脚本路径本身不保证导入固定src：packager的REPOSITORY取脚本目录，但Python可仍导入checkout editable包，须明确绑定导入并比对最终source_build_id。 |
| MCP握手被误称实际AI全业务：stage9_package_agent_harness.py:48–255,278–291 | host用包解释器、包内LocalService/CLI stdio MCP，读取complete seed，目录在该脚本REPOSITORY/.tmp，四队列目录须新建； provision仅隔离测试身份。call/schema送请求文件，native只接受明确approve request_id；保存tools/native请求、实际与交付响应，支持lose_next_write_response故障控制及stop清理。 | relay已实现，自动host自检不是实际AI自主业务验收。没有自动生成完整AI任务计划／请求集／恢复后的场景预期；需以当前schema准备并让实际AI执行、保存原始任务与回执，不能只跑helper模拟。schema模式也是提交请求并打印回执路径，并非自动取schema的无参入口。 |
| seed准备入口与目标护栏 | .tmp/stage9_prepare_agent_seed.py已有只读可核对实现：--source / --directory；仅新workspace .tmp/stage9-final-agent，final released1，MixedBook2人40业务/1开放月，真实verify_file＋registered开放月preview、owner尚未provision，exclusive seed.json。 | 未执行最终seed。它是.tmp准备helper，不是harness子命令；--directory硬编码stage9-final-agent，已有目录即拒绝，不能把文档“另取新名字”直接当支持参数。可在授权后窄改helper的允许新命名护栏，或保留该目标只执行一次；不删旧目录重跑。benchmark_stage9的root限.tmp直属stage9-*，不能直接拿它建agent/data。 |

## 已保存回执如何使用

- .tmp/stage9-contract-files-r46-results.json是工具摘录：26passed且Windows编码warning，编码修复后严格单例1passed；没有完整log/XML，不合称27个最终统一通过，不重跑只为补log。
- .tmp/stage9-released-cli-rejection-results.json保留10setup errors、6failed/4passed、2failed/8passed、末两项2passed/8deselected；属于复制源码实际子进程拒绝，原组没有被重写为10passed。
- .tmp/stage9-package-draft-check-1/2-verification.json是旧draft完整包自检。实际读取draft-2 relay ready/tools/native日志：38条真实MCP请求（36command、1schema、1security）及1native批准，含工资、更正、close、request_result、backup等；其package_database_formats仍draft0。日志证明当时relay与业务调用，不证明当前released包或本轮AI任务完成。
- r70当前三根注册核验/preview及银行r71局部回执均另有来源身份；本audit不归档它们、不更改旧结果，也不把test文件存在当当前验收。

## 可直接使用的入口（均未执行）

以下PowerShell均须在任务获准的最终步骤运行；$finalSource必须是已经固定且完成正式冻结的完整源码目录，$package为全新软件包目标，$agent为workspace/.tmp/stage9-final-agent；所有目标必须不存在。冻结前候选可现在只读生成，但输出亦须exclusive；此audit没有实际生成。

1. 冻结顺序：candidate → 审阅／固定／选择器released1 → 新进程freeze → check。当前draft不能运行freeze；不先调用production_bundle。候选stdout重定向默认可覆盖文件，任务包装须先拒绝存在并用exclusive输出，不照抄覆写旧报告。

    & ./.tmp-kernel-venv/Scripts/python.exe -X utf8 scripts/export_kernel_schema_contracts.py --candidate-v1
    # 性能与结构收敛后按批准范围切STATUS/VERSION，再在新进程运行：
    & ./.tmp-kernel-venv/Scripts/python.exe -X utf8 scripts/export_kernel_schema_contracts.py --freeze-v1
    & ./.tmp-kernel-venv/Scripts/python.exe -X utf8 scripts/export_kernel_schema_contracts.py --check

2. 正式工厂历史定向组现成可运行，是否重跑按最终改动风险；源码／输出必须同一最终来源，不只运行隔离fixture就宣布最终包通过：

    & ./.tmp-kernel-venv/Scripts/python.exe -X utf8 -m pytest tests/kernel/test_offline_upgrade.py tests/kernel/test_offline_upgrade_history_preservation.py tests/kernel/test_stage9_backup_upgrade_history.py tests/kernel/test_v1_stored_json_isolation.py tests/kernel/test_history_reads_v1_warm_cache.py tests/kernel/test_versions_recovery.py -q --junitxml=.tmp/stage9-r71-final-upgrade-history.xml

该命令本身多数是隔离bundle/fault路径；最终正式工厂非空v1可直接用同源benchmark的registered --verify-only，主样本--read-existing，独立样本--resume，先明确其root与冻结结构匹配。r70 rebase dry并没有目标full proof，不能作为现成released根。正式跨版真实发行包验收没有v2目标，勿扩大首版门槛为必须造v2。

3. 包构建及自检：

    # 固定源构包前显式选择该src，并确认导入位置；保存并恢复原PYTHONPATH。
    $env:PYTHONPATH = Join-Path $finalSource "src"
    & ./.tmp-kernel-venv/Scripts/python.exe -X utf8 "$finalSource/scripts/package_local_kernel.py" --output $package

不使用--skip-validation，也不传不存在的--source。独占门禁覆盖package/ZIP/relocated，但-verification.json由write_text写出，不在现有目标预检中；包装需同时拒绝该报告已存在。通过报告须status=passed、manifest/source/runtime build一致、released1格式、packaged_offline_upgrade非空；默认released目录名不自动使draft源码变正式。自检已默认运行，除排错或源码改变不重复手工跑tools/verify_local_package.py；其validation目录存在会拒绝。

4. 正式离线CLI：

    & "$package/runtime/python.exe" -I -X utf8 -m ai_accounting.kernel.cli --root $syntheticReleasedRoot upgrade

root是已登记、完成目录操作的合法released合成根；首次正式1同版公司/catalog返回verified_skip，上层status仍upgraded。实际daemon锁拒绝及same-version两次调用由包自检released分支自动覆盖，不与现有真实服务联系或另启重复服务。已发布合同变化需要真实前向合同及MigrationStep，当前没有v2实现。

5. seed和实际MCP relay：

    & ./.tmp-kernel-venv/Scripts/python.exe -X utf8 .tmp/stage9_prepare_agent_seed.py --source $finalSource --directory .tmp/stage9-final-agent
    & "$package/runtime/python.exe" -I -X utf8 tests/kernel/stage9_package_agent_harness.py host .tmp/stage9-final-agent $package
    & "$package/runtime/python.exe" -I -X utf8 tests/kernel/stage9_package_agent_harness.py call .tmp/stage9-final-agent .tmp/stage9-final-agent/request.json
    & "$package/runtime/python.exe" -I -X utf8 tests/kernel/stage9_package_agent_harness.py native .tmp/stage9-final-agent .tmp/stage9-final-agent/approve-request.json

workspace harness须与固定最终源同字节，尤其assert_owner_brief_result匹配最终合同；若改从$finalSource脚本运行，其REPOSITORY/.tmp也变为fixedSource/.tmp，不能还用workspace agent目录。host有且只有一家公司/开放月的起点，后续切公司场景需实际MCP创建第二合成公司并保存明确预期。request文件结构为tool/arguments，native为operation=approve/request_id，来自当前真实预览；没有自动猜审批。stop文件结束host并做清理，日志证明实际任务结束。

## 需要纠偏的计划表达

release-remaining-gates可保留正式冻结／历史保留／两档证据／最终包／实际AI门槛，但“不足”要具体区分：缺正式v2产品合同/steps；最终发布和场景执行未做；seed helper固定目标／packager导入及verification报告目标护栏需编排解决。不得把这些都写成“升级尚未实现”或为了计划表新增无必要运行API。本次没有生产改动或执行通过声明，完成后停工具。
