"""Actual small published fixtures; cache visits only, never page timing."""
import hashlib
import inspect
import json
import sys
import tempfile
from collections import Counter
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "src"), str(ROOT / "tests/kernel")]
from test_engine import engine as engine_fixture, publish, save
from ai_accounting.kernel import publication, query_reads
from ai_accounting.kernel.query_reads import QueryReads, verify_current_voucher_publications
from ai_accounting.kernel.types import YearMonth
from ai_accounting.kernel.content_history_context import historical_content

OUTPUT = ROOT / ".tmp/stage9-publication-period-cache-scope-fix2.json"
JAN = YearMonth("2026-01").ordinal
original = query_reads._verify_current_voucher_publication_rows
source = inspect.getsource(original)
begin = source.index("    verified_publications = (")
end = source.index("    for row in current:\n        head_id", begin)
replacement = '''    verified_publications = (
        {item["id"] for item in publications.values()
         if item["id"] in reads._verified_publication_ids
         and reads._verified_publication_ids[item["id"]] == item["posting_period"]}
        if reads is not None and reads.connection is connection
        and reads._snapshot_active and connection.in_transaction else set()
    )
'''
namespace = dict(query_reads.__dict__)
exec(source[:begin] + replacement + source[end:], namespace)
bounded = namespace[original.__name__]


class CountedRows(tuple):
    def __new__(cls, rows, calls):
        value = super().__new__(cls, rows)
        value.calls = calls
        return value

    def __iter__(self):
        for row in super().__iter__():
            self.calls["period_tuple_rows_visited"] += 1
            yield row


class CountedIDs(dict):
    def __init__(self, values, calls):
        super().__init__(values)
        self.calls = calls

    def __contains__(self, key):
        self.calls["id_membership_visits"] += 1
        return super().__contains__(key)

    def __getitem__(self, key):
        self.calls["id_period_visits"] += 1
        return super().__getitem__(key)


def probe(engine, *, bounded_lookup, shape="normal"):
    calls = Counter()
    with QueryReads.snapshot(engine) as reads:
        if shape != "ids-only":
            rows = reads.verify_publication_periods({JAN})
            assert all(reads._verified_publication_ids[row["id"]] == JAN for row in rows)
            reads._verified_publications[JAN] = CountedRows(rows, calls)
        else:
            rows = list(reads.connection.execute("SELECT * FROM calculation_publication"))
            reads.verify_publication_records(rows)
            assert not reads._verified_publications
        ident = reads.connection.execute(
            "SELECT h.version_id FROM voucher_current h JOIN voucher_version v "
            "ON v.id=h.version_id JOIN calculation c ON c.id=v.calculation_id "
            "WHERE c.subject_id='item-0'"
        ).fetchone()[0]
        if shape == "tuple-only-private-tamper":
            reads._verified_publication_ids.clear()
        reads._verified_publication_ids = CountedIDs(reads._verified_publication_ids, calls)
        verify = publication.verify_record

        def checked(row):
            calls["record_digest_checks"] += 1
            if shape == "tuple-only-private-tamper":
                raise ValueError("injected required digest-check failure")
            return verify(row)

        with patch.object(query_reads, original.__name__, bounded if bounded_lookup else original), \
                patch.object(publication, "verify_record", checked):
            try:
                result = verify_current_voucher_publications(reads.connection, {ident})
                first = dict(calls)
                again = verify_current_voucher_publications(reads.connection, {ident})
                assert result == again and dict(calls) == first
                return {"status": "accepted", "publication_ids": sorted(result),
                        "visits": first, "repeat_additional_visits": 0,
                        "tuple_cache_rows": len(rows)}
            except ValueError as exc:
                return {"status": "rejected", "error": str(exc), "visits": dict(calls)}


def boundary(engine, name, *, bounded_lookup):
    with QueryReads.snapshot(engine) as reads, patch.object(
        query_reads, original.__name__, bounded if bounded_lookup else original
    ):
        token = None
        old_version = getattr(engine.store.registry, "content_version", None)
        if name == "unowned":
            token = query_reads._active_fact_reads.set(QueryReads(engine, reads.connection))
        if name == "registry-v1":
            engine.store.registry.content_version = 1
        try:
            ident = reads.connection.execute("SELECT version_id FROM voucher_current LIMIT 1").fetchone()[0]
            if name == "historical-v1":
                with historical_content(1):
                    result = verify_current_voucher_publications(reads.connection, {ident})
            else:
                result = verify_current_voucher_publications(reads.connection, {ident})
            return {"publication_ids": sorted(result),
                    "period_cache": len(reads._verified_publications),
                    "relation_cache": len(reads._verified_current_voucher_publications)}
        finally:
            if token is not None:
                query_reads._active_fact_reads.reset(token)
            if name == "registry-v1":
                if old_version is None:
                    del engine.store.registry.content_version
                else:
                    engine.store.registry.content_version = old_version


def main():
    report = {"status": "started", "scope": "small_actual_fixture_cache_work_not_timing",
              "function_sha256": hashlib.sha256(source.encode()).hexdigest(),
              "growth": [], "boundaries": [], "errors": []}
    with OUTPUT.open("x", encoding="utf-8") as output:
        try:
            with tempfile.TemporaryDirectory(prefix="stage9-pub-cache-", dir=ROOT / ".tmp") as path:
                engine = engine_fixture.__wrapped__(Path(path))
                previous = 0
                for size in (12, 48, 120):
                    subjects = [f"item-{i}" for i in range(previous, size)]
                    for subject in subjects:
                        save(engine, subject=subject, request="save-" + subject)
                    publish(engine, subjects, request="publish-" + str(size))
                    native, candidate = probe(engine, bounded_lookup=False), probe(
                        engine, bounded_lookup=True
                    )
                    assert native["publication_ids"] == candidate["publication_ids"]
                    assert native["visits"]["period_tuple_rows_visited"] == size
                    assert candidate["visits"].get("period_tuple_rows_visited", 0) == 0
                    report["growth"].append({"actual_same_month_publications": size,
                                             "native": native, "id_lookup": candidate})
                    previous = size
                for shape in ("ids-only", "tuple-only-private-tamper"):
                    report["boundaries"].append({"shape": shape,
                        "native": probe(engine, bounded_lookup=False, shape=shape),
                        "id_lookup": probe(engine, bounded_lookup=True, shape=shape)})
                for name in ("unowned", "historical-v1", "registry-v1"):
                    native = boundary(engine, name, bounded_lookup=False)
                    candidate = boundary(engine, name, bounded_lookup=True)
                    assert native == candidate and native["relation_cache"] == 0
                    report["boundaries"].append({"shape": name, "native": native,
                                                 "id_lookup": candidate})
            report["status"] = "diagnostic_completed"
        except BaseException as exc:
            report["status"] = "failed"
            report["errors"].append({"type": type(exc).__name__, "message": str(exc)})
            raise
        finally:
            json.dump(report, output, ensure_ascii=False, indent=2)
            output.write("\n")
    print(json.dumps({"status": report["status"], "output": str(OUTPUT)}))


if __name__ == "__main__":
    main()
