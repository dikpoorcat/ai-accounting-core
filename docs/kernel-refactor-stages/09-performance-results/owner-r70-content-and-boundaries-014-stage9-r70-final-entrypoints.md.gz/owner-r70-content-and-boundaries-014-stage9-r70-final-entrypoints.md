# r70 后固定候选交付入口（只读准备）

本次仅读源码/文档/既存 JSON，没有测试、建库、升级、计时、启动服务或构包。使用 GPT-6.1 Sol / medium。以下命令待主线程绑定最终不可变源码和新输出后执行，不表示已通过；release-remaining-gates.md 中 r67 等状态是历史，不能当作每轮统一重跑门禁。

## 关键阻碍

1. 当前仓库仍 draft/0。必须先完成本轮修改收敛并固定候选；snapshot 只是复制源码，不自动转换 released 或冻结三份合同。正式冻结与隔离候选不同，不能用修改旧 candidate 清单/指纹来承接新源码。记录 source inventory SHA、company/catalog/content 合同 SHA、build_id 和静态产物身份。
2. 主48根 `.tmp/stage9-owner-main48-r63` 是现有同结构合成根，可在最终候选合同核对相同后用 current source 重新验证；prior r63 full verify 不能当 current source full verify。r69 六入口和 r70 cache 诊断 `current_source_full_integrity=not_run`，不能直接喂浏览器。
3. 主120、独立48/120的原根仍存在，属于旧结构候选。不能直接把其 report.source 改成新候选，也不能用 --resume 在错误结构上重建/重放历史。需显式合成 raw-copy constructor，保持冻结业务行、rowid/bytes、原采用/原预览及checkpoint；随后目标 current registered full verifier + real open preview。
4. 现有 `.tmp/stage9-rebase-owner-r63.py` 仅加载 r49 并替换 NEW_TREE/NEW_SNAPSHOT、禁止恢复staging；仍保留 r49 精确 NEW_COMPANY/NEW_CONTENT/CATALOG、允许delta、CASES及源SHA。不能直接当 r70 后 constructor；必须另建专属包装器/constructor并核当前目标实际delta、完整source inventory/contract和原report/checkpoint SHA。这项准备未创建或运行constructor。
5. package_local_kernel.py 无 --source。从最终源码的脚本路径调用，且 imports 必须指向该源码；受控运行时硬门禁 Windows Python3.12.13/SQLite3.53.1。静态 release 的 index.html/local.html 必须存在。源码/静态改变后只重做受影响项，不无条件重跑历史所有组。

## 变量和路径约束

PowerShell仓库根；本机 Python 一律 `.tmp-kernel-venv/Scripts/python.exe -X utf8`。`$fixedSource` 为新固定源码绝对路径；`$main120Root`/`$independent48Root`/`$independent120Root` 为承接并核验的隔离合成根，不能直接绑定旧根。`$node`/`$playwrightModule` 必须来自实际配置的现有运行时，不猜路径。

stage9_source.synthetic_path 要求 root/output/stop/gate/book-report 是workspace `.tmp` 的直接子项且名以 stage9- 开头。新report必须不存在；rebase目标/staging必须都不存在。浏览器还要求仓库venv sys.prefix；所有模块从 selected source 导入。边界脚本另要求执行脚本自身就是 `$fixedSource/scripts/benchmark_stage9_boundaries.py`。

## 当前同结构主48：先独立验证，不先重测

```powershell
& ./.tmp-kernel-venv/Scripts/python.exe -X utf8 "$fixedSource/scripts/benchmark_stage9.py" --source $fixedSource --workspace . --root .tmp/stage9-owner-main48-r63 --output .tmp/stage9-post-r70-main48-verified.json --months 48 --employees 50 --businesses 1000 --read-existing --verify-only
```

主入口 --verify-only 必须配 --read-existing；与 --resume 互斥。不会业务构造或原生读取计时，但执行注册完整核验和开放月preview并记录其耗时。`MixedBook.resume`保留checkpoint及构造snapshots；不修改历史构造preview_digest以迎合current结果。

## 主120与独立48/120的历史承接

现有r49 CASES精确绑定如下（非空旧样本，不重建业务）：

| 旧根 | 原源码 | 原report | 原状态 | 目标stem |
| --- | --- | --- | --- | --- |
| stage9-release-main-120 | stage9-build-source-r22-release | stage9-release-main-120-build-r22h.json | built_not_verified | stage9-owner-main120 |
| stage9-release-independent-48 | stage9-build-source-r11-release | stage9-release-independent-48-build-r11d.json | built_not_verified | stage9-owner-independent48 |
| stage9-release-independent-120 | stage9-build-source-r30-release | stage9-release-independent-120-verified-r30.json | complete（旧源） | stage9-owner-independent120 |

constructor的现有参数完整为 --workspace、--source-root、--target-root、--source、--target-source、--source-report，另有 --dry-run、--resume-staging、--attest-copy-only；后两者只允许精确白名单，不能用于新的失败staging。连--dry-run也需精确CASE和目标名；未准备新constructor时没有可直接执行的新候选rebase命令。

必要实现路径：校验原root/report/checkpoint/identity/合同/源inventory；新建目标同身份库；只允许明确结构delta；原业务表逐表复制且核columns/rowid/bytes摘要；仅identity/schema_meta/schema_history是目标生成元数据，新表为空；foreign_key/integrity check；保留原closed manifest和所有checkpoint；目标bundle登记的company verifier覆盖 sources/historical_adoption/projections/read_indexes，再真实preview；核验证前后数据未变，才发布staging。这是合成夹具构造，不是生产迁移，不绕过完整来源。

承接完成且完整月份/最后一月开放后，可再次使用以下入口；constructor已完成相同目标full verify/preview时，不为名字不同自动重复一遍，应复用对应当前源报告。

```powershell
& ./.tmp-kernel-venv/Scripts/python.exe -X utf8 "$fixedSource/scripts/benchmark_stage9.py" --source $fixedSource --workspace . --root $main120Root --output .tmp/stage9-post-r70-main120-verified.json --months 120 --employees 50 --businesses 1000 --read-existing --verify-only
& ./.tmp-kernel-venv/Scripts/python.exe -X utf8 "$fixedSource/scripts/benchmark_stage9_independent.py" --source $fixedSource --workspace . --root $independent48Root --output .tmp/stage9-post-r70-independent48-verified.json --months 48 --objects 50 --businesses 1000 --resume --verify-only
& ./.tmp-kernel-venv/Scripts/python.exe -X utf8 "$fixedSource/scripts/benchmark_stage9_independent.py" --source $fixedSource --workspace . --root $independent120Root --output .tmp/stage9-post-r70-independent120-verified.json --months 120 --objects 50 --businesses 1000 --resume --verify-only
```

独立wrapper只解析source/workspace，其余转发tests/kernel/stage9_independent_book.py；没有--read-existing/--repeats。--verify-only要求--resume、排除--build-only，未完成月份直接拒绝。独立构造要求--build-only与--defer-historical-verification同时出现；当前承接任务不走构造。

## 书册、源码、开放预览与浏览器门禁

书册必须status=complete、integrity.status=verified且limitations为空；months/snapshots恰好requested_months，每月1000笔且有owner_confirmation/preview_digest，前N-1月closed、末月open。main应50员工mixed_cumulative；independent应50对象independent_local_pairs。报告source绝对路径必须精确等于selected source。

verified_open_preview必须精确含source/company_id/database_id/period/construction_preview_digest/digest/epochs/state；state为6个int，epochs对应accounting/material/management。当前源注册verifier根据实际database_format version分派，验证前后核身份/state；preview_close另开真实读事务。construction digest保留旧值，current digest单独记录；浏览器重新preview并对current digest/epochs，不能拿旧源preview冒充。

```powershell
& ./.tmp-kernel-venv/Scripts/python.exe -X utf8 "$fixedSource/scripts/benchmark_stage9_browser.py" --source $fixedSource --workspace . --book-report .tmp/stage9-post-r70-main48-verified.json --output .tmp/stage9-post-r70-main48-browser.json --node $node --playwright-module $playwrightModule --static-build release --browser-channel msedge --repeats 30 --warmups 3
```

热刷新验收不加--instrument/--layout-only/--navigation-only，release静态必须来自同源；dist仅diagnostic。layout-only可独立配--screenshots；冷开另--navigation-only cold；切换需--navigation-only switch和--switch-book-report，第二公司须同目录库且另有已核报告，不可把两个独立root的报告直接并用。timing-ready/start-file必须一起提供、是四个distinct新文件；只在需要隔离预检与计时窗口时使用。

## 边界、原件规模、正式包与AI harness

```powershell
& ./.tmp-kernel-venv/Scripts/python.exe -X utf8 "$fixedSource/scripts/benchmark_stage9_boundaries.py" --source $fixedSource --workspace . --root .tmp/stage9-post-r70-boundaries --full
```

boundaries无--output/--months；结果为root/report.json。--full实际20MiB evidence、100000 bank rows、5000 batch；默认calibration rows/facts=3是校准，不替代边界验收。它会新建合成库/执行业务，因此不是本次准备已执行内容。

原件240/1536MiB工具是benchmark_stage9_evidence.py而非boundaries，参数--size-mib 240/1536 --profile mixed --root/--output/--source/--workspace；默认foreground=http。browser前台另加--foreground browser --node/--playwright-module。这些证据与五页纯浏览器分开，不重复同一已固定结果。release-remaining-gates记录资源预检约4×size+512MiB，未重新执行核验。

正式STATUS/VERSION切为released/1后，一次export_kernel_schema_contracts.py --freeze-v1，再--check；--candidate-v1只计算候选。三份company/v1.json/catalog/v1.json/content-v1.json不能已存在，不回写已发布合同。正式freeze、合同组和包专用released烟测仍需按主线程最终受影响范围执行。

```powershell
$env:PYTHONPATH = "$fixedSource/src"
& ./.tmp-kernel-venv/Scripts/python.exe -X utf8 "$fixedSource/scripts/package_local_kernel.py" --output .tmp/stage9-post-r70-released-package
```

packager无--source，使用fixed script路径和显式source import；执行后恢复既有PYTHONPATH设置。output、同名.zip和-relocated均须不存在；禁止--skip-validation。生成manifest source_build_id、ZIP、-verification.json和-relocated；包自检status=passed/database_formats released1/非空packaged_offline_upgrade才属当前正式包。已验证包不无故再次创建validation根。

AI relay入口只有位置参数（无--package/--root）：

```powershell
& .tmp/stage9-post-r70-released-package/runtime/python.exe -I -X utf8 "$fixedSource/tests/kernel/stage9_package_agent_harness.py" host .tmp/stage9-post-r70-agent .tmp/stage9-post-r70-released-package
& .tmp/stage9-post-r70-released-package/runtime/python.exe -I -X utf8 "$fixedSource/tests/kernel/stage9_package_agent_harness.py" call .tmp/stage9-post-r70-agent .tmp/stage9-post-r70-agent/request.json
& .tmp/stage9-post-r70-released-package/runtime/python.exe -I -X utf8 "$fixedSource/tests/kernel/stage9_package_agent_harness.py" native .tmp/stage9-post-r70-agent .tmp/stage9-post-r70-agent/approve-request.json
```

注意harness.REPOSITORY由脚本parents[2]确定，directory必须位于该REPOSITORY/.tmp：若脚本从fixedSource运行，则上例agent必须改成fixedSource/.tmp/stage9-...绝对路径；workspace根的agent只能使用workspace中的同字节harness。host第三位置参数是package；seed.json须complete、root=directory/data且公司为main合成企业，包合同一致；四个requests/responses/native_requests/native_responses目录需不存在。host会provision测试身份、启动HTTP与stdio MCP；初始化/简报资金检查不等于实际AI业务复验。schema/call/native模式第三参数为请求文件；native必须准确当前preview明确approve，不能猜审批。
