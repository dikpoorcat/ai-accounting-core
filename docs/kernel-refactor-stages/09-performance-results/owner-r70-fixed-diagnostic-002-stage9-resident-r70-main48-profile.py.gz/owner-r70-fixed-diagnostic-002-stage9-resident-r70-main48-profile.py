from pathlib import Path

path = Path(__file__).with_name('stage9-resident-r64-main48-profile.py')
source = path.read_text('utf-8').replace('r64', 'r70')
exec(compile(source, __file__, 'exec'))
