# r76 五页实际事实绑定交集诊断

本机仓库venv、固定r76 source、完整核验输入stage9-owner-main12-r76-verified.json指定main12合成根。沿用既有stage9_source和stage9_metrics；每页原生一次，无warmup/服务/预览/完整核验/写入，无production/harness修改。全部5页success，进程退出0、wrappers恢复、readpool关闭。详细IDs仅在.tmp原始JSON。

| 页面 | helper批次 | 事实绑定检查/唯一fact ID | 同snapshot同绑定重复 | raw hash命中 | scalar hash输入/成功 |
|---|---:|---:|---:|---:|---:|
| brief | 3 | 1009/1009 | 0 | 0 | 1009/1000 |
| funds | 2 | 507/507 | 0 | 0 | 507/499 |
| employees | 1 | 50/50 | 0 | 0 | 50/50 |
| assets | 1 | 12/12 | 0 | 0 | 12/12 |
| reports | 3 | 1006/1005 | 1 | 1 | 1005/996 |

确认的同根因触发只在reports：第一批939 facts与第二批66 facts不重叠，第三批1 fact与早前锚定核验中同fact kind/period/digest一致。路径：report_projection._party_delta→read_open_contributions→_verify_anchored_source_bytes；后续reports._report→report_line_relations_many→verify_selected_content。精确绑定和caller见原始JSON。

重复的第三批是loan_interest，无sequence字段，所以调用child-order helper但不产生childorder SQL。raw hash命中1，scalar hash输入0；实际重复物理查询只有事实period SELECT返回1行40 value bytes；另重复SHA256原始缓存字节，字节长度未捕获。既有采样VM分辨率100，记录该query fetch阶段0采样步不等于0工作；exec初段、同statement聚合及mixed batch不能分配到重复ID，未声称精确省VM。

brief实际批次1005/1/3、funds504/3、employees50、assets12均无helper跨批同事实重复。reports939/66/1，只有1次重复，不存在复核上千事实的实测证据。scalar hash成功数小于输入数是unsupported composite等fallback的正常候选，不代表内容错误；全部页面成功。

另有 _check_facts / verify_sources childorder batches，其ID与body IDs交集：brief=50, funds=0, employees=0, assets=12, reports=0。这一层未拦截_check_facts返回完整header及connection token，因此只能作为不同核验消费者相同ID线索，不能把它记成相同binding/同scope重复成功证明；typed展示/证据/graph核验也不能省略。见此前静态报告的global边界。

判断：本次main12实际重复body-helper量很小，仅loan_interest1行期间+raw SHA；不支持据此盲目新增正文成功缓存解决brief/reports耗时。若未来扩大修复，应先取得verify_sources→selected的精确绑定和scope交集，再评估窄成功proof能省多少必要/重复工作。现有raw缓存确实没有成功proof但已避免这一次scalar正文重读。main48实际交集仍未验证，r75聚合不能外推。

本次诊断使用独占只读native，与其他AB可能并行；所有instrumented_ms仅诊断线索，无净收益/500ms验收结论。初始只读静态报告仍保留，新增实测结论以本报告为准。

源与完整核验：D:\GitHub\ai-accounting-core\.tmp\stage9-build-source-owner-r76-release
已核验输入SHA256：501332f2a9ae5aca7928fed7c5c923f122518316846421780db99c9573a2f6b3
ai_accounting.kernel.query_reads: 305924fa53da1b7696433efa8c2654bbe50baf69114ad87e390c9c0e8b0727ac
ai_accounting.kernel.storage: eb2d0f71c4805d11d0be48a1230e6deda7377fd86dd305a59242b49d984f245e
ai_accounting.kernel.integrity: d3d965b1e81f78dc0cf437fdd72118a08a5dba18e11ff8b207bdcd7370dd3763

精确产物：stage9-r76-fact-body-scope-probe.py / .log / .json，以及stage9-r76-fact-body-scope-probe-analysis.json / .md；此前静态报告stage9-r76-fact-body-reuse-readonly.json / .md均保留。
