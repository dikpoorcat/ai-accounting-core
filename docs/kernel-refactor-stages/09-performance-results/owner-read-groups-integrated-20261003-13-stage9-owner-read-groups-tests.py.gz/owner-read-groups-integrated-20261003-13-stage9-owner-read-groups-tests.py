"""Grouped consumer and trust-boundary regression bound to the sealed candidate."""
import hashlib
import json
import sys
from pathlib import Path

workspace = Path(__file__).resolve().parents[1]
source = workspace / ".tmp/stage9-build-source-owner-read-groups-20261003-release"
assert Path(sys.prefix).resolve() == workspace / ".tmp-kernel-venv"
manifest = json.loads((source / "source-manifest.json").read_text(encoding="utf-8"))
assert manifest["sha256"] == "46f84508afd54165f23af5a83434b1881002ab45490f4358f0c1755c743748be"
sys.path.insert(0, str(source / "src"))
import ai_accounting
from ai_accounting.kernel.schema_bundle import production_bundle
assert Path(ai_accounting.__file__).resolve() == source / "src/ai_accounting/__init__.py"
assert production_bundle().status == "released"
sys.path.insert(0, str(workspace / "scripts"))
from snapshot_stage9_source import _inventory
assert _inventory(source) == manifest["files"]
files = [
    "test_dashboard_owner_presentation.py", "test_dashboard_funds_alignment.py",
    "test_dashboard_workforce_assets.py", "test_dashboard_reports_adapter.py",
    "test_dashboard_business_queries.py", "test_dashboard_empty_replay.py",
    "test_read_repair_version.py", "test_stored_json_repair_boundary.py",
    "test_foundation_backup.py", "test_integrity_content.py",
    "test_v1_stored_json_isolation.py", "test_history_reads_v1_warm_cache.py",
    "test_publication_record_proof_reuse.py", "test_publication_period_reuse.py",
]
paths = [str(source / "tests/kernel" / name) for name in files]
assert all(Path(path).is_file() for path in paths)
print(json.dumps({"source": str(source), "source_sha256": manifest["sha256"],
                  "format": "released/1", "files": files}, ensure_ascii=False), flush=True)
import pytest
try:
    code = pytest.main([*paths, "-q", "--rootdir", str(source),
                        "--junitxml=" + str(workspace / ".tmp/stage9-owner-read-groups-consumers.xml")])
finally:
    assert _inventory(source) == manifest["files"], "Fixed source drifted during regression"
raise SystemExit(code)
