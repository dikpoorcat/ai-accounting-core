# 五页native work池适配只读审查（2026-10-05）

本审查只读源码、固定manifest、已有失败回执和私有helper，生成v2与精确diff，没有导入会计内核、打开数据库、启动服务或运行测试／诊断。根任务随后启动v2实际old→new→compare，session20312；该运行与main120 Q均由根控制，结果不提前写入本静态记录。本记录不更新主阶段或路线图，不作纯计时、资格或500ms结论。

## 已证实根因

原helper的正常`LocalService(enable_read_pool=True).dispatch`调用`engine(company_id,dashboard_read=True)`，Catalog返回绑定`read_pool`的Store。固定ed96／a5d4的`QueryReads.snapshot`调用`Store._snapshot_connection`，当前内容分支直接`ResidentReadPool.borrow(...,_owned_snapshot=True)`，没有调用`Store.connection`。原helper把公共`stage9_metrics.measure_work`的连接hook接到Store.connection，因此没有进入计量连接；第一页面holder断言失败。此错误属于私有计量适配，不属于产品SQL、采用证明、内核完整核验或池实现失败。

原失败JSON为`diagnostic_failed`、observations=[]、all_guards_passed=true（七项原守卫均true）。原helper先断言holder，再追加observation，故已经返回的真实response/work也没有保全；这解释的是诊断原件缺失，不能把空observations当作页面没有读取工作或业务差分通过。

第二个真实约束是精确类型：`QueryReads.snapshot`以`type(connection) is _OwnedReadConnection`选择正常私有事务。直接yield公共collector的`_Connection`代理会失去该类型，进入普通BEGIN／authorizer路径；不能通过手动BEGIN、关闭pool或更换事务分支补统计。

## 入口／适用矩阵

| 位置 | 实际路径与计量结论 | 审查边界 |
| --- | --- | --- |
| `tests/kernel/stage9_metrics.measure_work` | 原设计只包装`engine.store.connection`，并全局计JSON／当前线程profile；`_Connection.execute`包装execute与其游标行 | 直连scope有效；没有宣称其SQL适配器天然支持新owned provider |
| 普通Store，read_pool=None | `_snapshot_connection`回到`self.connection(read_only=True)`，公共collector能覆盖；QueryReads普通BEGIN仍沿原路径 | 校准test_stage9_metrics的真实fixture属于此路，未重跑测试 |
| fixed-v1／历史context的Store | `_snapshot_connection`历史分支仍走Store.connection；带pool的普通borrow也由Store.connection进入 | 保持历史选择，不把current owned适配套到v1；v2两side为current draft |
| current draft＋LocalService.dashboard_read＋pool | `_snapshot_connection`直接borrow owned连接；Store.connection hook漏SQL／行／outcome传输 | 原本轮helper已实失败；v2只修这一适配 |
| `scripts/benchmark_stage9 --instrument` | MixedBook构造／resume的Engine由`catalog.bind`默认不传pool，调用公共measure_work | 实际当前调用使用直连，不据当前pool缺陷作废其结果；未来传pool须另适配 |
| `test_stage9_metrics`及普通Engine／book work测试 | 当前fixture直连；源码扫描未发现这些metrics测试在同文件显式启用pool | 没有执行全部测试，也不以词检索证明每个动态fixture的路径 |
| `scripts/benchmark_stage9_browser --instrument` | 记录HTTP状态、请求区间及dispatch区间，独立于Store.connection | 不提供同类SQL／row计数，真实pool不会让这些时间区间消失；不能升级为纯计时 |
| package／restore agent harness、默认包自检 | 正常LocalService pool和stdio→HTTP，没有调用公共measure_work来宣称SQL工作量 | 本缺陷不影响这些实际业务入口结果；不借它们校准SQL计数 |
| `scripts/verify_t5_read_costs.measure` | 正常模式hook Store.connection；fixed_connection模式直接给已传入connection装trace／progress | 当前明确直连及caller transaction适用；若未来normal mode注入owned pool，同样须审查provider，不能自动宣称覆盖 |
| r63、r64、r73、r75 resident profile helpers | 已读对应固定QueryReads.snapshot：仍直接Store.connection，即使Store使用ResidentReadPool也经过原hook | 这是不同历史实现，不能只因pool字样追溯宣布旧工作量无效 |
| `.tmp/stage9-g-five-page-workload.py` | book_object.engine是MixedBook默认catalog.bind，无pool参数 | 直连适配；不称服务热池入口 |
| `.tmp/stage9-report-flow-header-overlap-46f845.py` | 显式Store不传pool，手动代理原connection后进入QueryReads | 专用SQL形状诊断，原scope不是current LocalService热池 |
| 导入metrics但声明无observer的native helpers | metrics可能只用于源码hash守卫；实际只做native计时／profile | 不能仅按import认定漏计SQL或存在SQL计量结论 |
| 动态来源、exec继承或私有QueryReads overlay helpers | 必须按实际运行输入、overlay和Store实现分别解析 | 文字候选不等于缺陷，未通过相似代码推断所有历史结果无效 |

静态扫描读取scripts、tests/kernel和忽略.tmp顶层共1864个Python文件，完整发现列表在`stage9-metrics-pool-readonly-inventory-v2-20261005.json`。94个“pool＋measure_work”文字候选含说明、归档脚本及继承脚本；具名可读固定来源解析见`stage9-metrics-pool-source-route-review-v2-20261005.json`。其中实际指向已经改用owned provider的两份业务helper是原本轮helper及待审v2，另有本审查脚本自身引用；这不是对未解析动态来源的全局保证。没有运行候选脚本或改历史回执。

## v2窄适配

保留正常dispatch、engine、Catalog binding、Store、ResidentReadPool借还及QueryReads私有事务。只在实际返回的engine Store实例上暂时包装`_snapshot_connection`。先调用原provider得到真实owned连接并完成正常池验证；原始连接类型、guard和transaction入口保留。

公共measure_work仍建立原有计数器、progress interval100、JSON和profile。其meter连接context只yield已经借到的同一raw连接，没有第二次borrow。公共`_Connection`仅用作execute计数委托：先捕获原raw.execute bound method，将其放在delegate中，然后暂时令raw.execute调用collector.execute；后者委托捕获的原bound method，避免递归。最终yield给QueryReads的始终是原raw owned对象，不是代理。

finally按实例原有override是否存在恢复／删除execute和provider，不改Store.connection、authorizer、guard、isolation_level、autocommit、cache_size或业务事务。记录原／后精确类型、guard对象同一性、permit、事务状态、execute恢复、provider恢复、正常provider enter／exit及计量context enter／exit；首条实际execute应处于QueryReads原私有事务内，execute次数必须等于公共sql_calls。

每page从collector返回后，先落完整response／work／holder；若operation抛错，则保全实际已经累积的SQL／VM／行／字节／decode counters并明确partial，不虚构最终耗时、峰值或函数统计。每page raw文件和report.observations在holder、业务、编码断言之前保存，因此断言失败不再导致observations=[]。pool／catalog／company／identity／state／history／session／source七项原后守卫保持原样。

资金仍先以未计量first定位保存完整回执，计量请求使用真实显式账户type／ID、limit20。季度仍使用normal dashboard_quarterly_report的deferred默认入口，不冒充closed_report。原3类精确动态字段（read_context.read_version、brief.data.generated_at、quarterly.checked_at）、独立read／snapshot／cursor编码、原raw diff及未知字段失败均未放宽。实际period来自book；old ed96／new a5d4及声明升级前置不改，不使用TEMP影子。

## 直接cursor／executemany与验证前查询

实际SQL列表和row／byte计数仅来自安装hook后调用的`connection.execute`及其返回游标，包含正常业务来源证明、snapshot内metadata和结果传输。公共collector的`__getattr__`不包装cursor、executemany或executescript；v2也不新增这些API代理。因此不能宣称计了所有SQLite语句或所有输入／磁盘字节。

对两份固定来源的正常五页消费者和读取依赖检查，未发现读取核心使用connection.cursor().execute；找到的executemany在Store保存、读取目录重建、report projection／flow安装及其他写入／维修函数，正常read-only／deferred五页入口不走这些写入分支。普通完整核验／备份／恢复不是这次五页计量调用，不因这次路径检索假定它们的所有SQL已计量。

owned runtime的BEGIN使用`sqlite3.Connection.executescript(connection,'BEGIN')`，ROLLBACK使用基类rollback，直接绕过instance.execute；保持这些私有操作原样，它们不进入SQL列表或row计数。公共progress handler在其作用期间会观察SQLite VM采样，包括可能发生的私有事务指令；因此全局VM是同窗口采样，不能承诺等于逐execute列表VM之和或精确单指令数。

正常认证／authority核对、command／response模型处理、Catalog.bind的公司目录查询、pool文件签名、connect／reused connection验证、verify_schema／三身份及cache_size PRAGMA，都按原入口执行。provider yield之后才安装计数，之前的这些查询不计入本SQL／row值；不是跳过验证。这与公共collector“after connection validation”口径一致。公司snapshot正常业务execute未被提前移出计量。JSON／profile包裹整个dispatch，可能含认证／绑定等函数；不能把它们与仅company snapshot的SQL计数合称全链路范围。prepare_static_runtime、输入守卫、未计量账户定位、login／logout、HTTP／DOM／刷新均不属于五页SQL工作量。

以上是静态调用依据及准备后的断言，不是新增动态覆盖证明；若根运行出现未预期cursor／connection路径、多个snapshot、编码差异或守卫失败，应保留原件并停止，不能放宽结果凑通过。Q并行时耗时只作instrumented diagnostic。诊断自己的login/logout只处理自身token，原session守卫不放宽；根负责协调新side Q与共享合成catalog，不能修改Q凭据或会话。

## 原件与交付

| 文件 | SHA256 |
| --- | --- |
| 原helper（不改） | `2a45d8dc8a863251cf14616949af68fa175a05747324b1dba122b1add507a35c` |
| 原old失败JSON（不改） | `dd915053153d1da1f78019098a154fa1771f965f999196ea68bf763635ddf162` |
| 原controller log（不改） | `c17f5e68478f99e5a94417f5c078a9db6e2eb04dbfdbdf73da6d3943632eedf9` |
| 原controller源码（不改） | `cbd3b6fb2dc0d7196ee28e13987f2e0eeaea6d1bea748039e1dae89b3026943a` |
| v2 helper | `25e2fceef9cf099dda8e29d2bad1f80ab45101aa0733a4e61b78ed8fbed1876a` |
| 精确v2 patch | `a7f09b085ea269243e7865cffe48eeeffffba417abce343fa9a0a98ef6976f30` |

helper为`.tmp/stage9-index-flow-five-page-work-v2-20261005.py`，diff为`.tmp/stage9-index-flow-five-page-work-v2-20261005.patch`。静态log及JSON在忽略.tmp。完整ed96 771项／a5d4 776项文件SHA与两manifest source digest均核对；两边公共collector SHA一致。receipt_gate、load_guards、ancestry、编码函数、business_response、raw_diff、compare、main与SIDES／UPGRADE／metadata exclusions／PAGES的AST逐项相同。没有修改生产、固定源、原controller、原helper或既有失败回执，没有自执行v2。
