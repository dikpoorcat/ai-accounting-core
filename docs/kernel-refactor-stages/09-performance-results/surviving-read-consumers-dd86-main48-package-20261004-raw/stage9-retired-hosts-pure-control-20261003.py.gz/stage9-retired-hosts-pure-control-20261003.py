"""Release pure timing after completed isolated hosts have exited normally.

No process is suspended, resumed, stopped or killed by this controller. Historical
PIDs are never treated as current identities; the exact retired command markers
and their stop files are checked instead. Real services are outside this scope.
"""
import argparse
import ctypes
from ctypes import wintypes
import hashlib
import json
from pathlib import Path
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('--pid', type=int, required=True)
parser.add_argument('--parent', type=int, required=True)
parser.add_argument('--prefix', type=Path, required=True)
args = parser.parse_args()
workspace = Path(__file__).resolve().parents[1]
prefix = args.prefix.resolve()
assert prefix.parent == workspace / '.tmp' and prefix.name.startswith('stage9-')
ready, start, report, receipt = (Path(str(prefix) + suffix) for suffix in
    ('-timing.ready.json', '-timing.start.json', '-browser.json', '-pure-control.json'))
retired_path = workspace / '.tmp/stage9-retire-completed-isolated-mcp-hosts-20261003.json'
retired_sha = 'a53e5271519fe32848e6964a1e73670860948053e0990d7d4fe025692e5c3055'
assert hashlib.sha256(retired_path.read_bytes()).hexdigest() == retired_sha
retired = json.loads(retired_path.read_text(encoding='utf-8'))
assert retired['status'] == 'retired_by_normal_stop_marker_cleanup'
assert ready.is_file() and not start.exists() and not report.exists() and not receipt.exists()
signal = json.loads(ready.read_text(encoding='utf-8'))
assert signal['pid'] == args.pid and Path(signal['output']).resolve() == report

kernel = ctypes.WinDLL('kernel32', use_last_error=True)
kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
kernel.OpenProcess.restype = wintypes.HANDLE
kernel.CloseHandle.argtypes = [wintypes.HANDLE]
kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
kernel.WaitForSingleObject.restype = wintypes.DWORD

def processes():
    command = 'Get-CimInstance Win32_Process | Select-Object ProcessId,ParentProcessId,CommandLine | ConvertTo-Json -Compress'
    value = subprocess.run(['powershell', '-NoProfile', '-Command', command],
                           capture_output=True, text=True, check=True)
    records = json.loads(value.stdout)
    return {item['ProcessId']: item for item in records}

def verify_no_owned_work(inventory):
    item = inventory[args.pid]
    assert item['ParentProcessId'] == args.parent
    assert 'benchmark_stage9_browser.py' in item['CommandLine'] and prefix.name in item['CommandLine']
    for previous in retired['before']:
        directory = Path(previous['directory']).resolve()
        assert directory.parent == workspace / '.tmp'
        assert Path(previous['stop_path']).resolve() == directory / 'stop'
        assert (directory / 'stop').is_file()
        # A recycled PID is harmless; an exact previously owned command is not.
        command = previous['host']['command']
        assert not any(row.get('CommandLine') == command for row in inventory.values())
        for child in previous['children']:
            if child['name'].lower() == 'python.exe':
                assert not any(row.get('CommandLine') == child['command'] for row in inventory.values())
    owned = str(workspace / '.tmp').replace('\\', '/').lower() + '/stage9-'
    prohibited = ('-m pytest', 'regression-', 'build_windows_package.py',
                  'build_windows_package', 'stage9_package_agent_harness.py',
                  'stage9_restore_agent_harness.py', 'stage9_prepare_agent_seed.py',
                  'stage9_metrics', 'snapshot_stage9_source.py')
    for row in inventory.values():
        command = (row.get('CommandLine') or '').replace('\\', '/').lower()
        if owned not in command:
            continue
        assert not any(marker in command for marker in prohibited), 'Owned heavy work still running'
        if 'benchmark_stage9_browser.py' in command:
            assert prefix.name.lower() in command, 'Another owned benchmark still running'

state = {'status': 'started', 'scope': 'exact_owned_retired_hosts_and_single_benchmark_only',
         'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
         'retirement_receipt_sha256': retired_sha, 'started_epoch': time.time(),
         'browser_pid': args.pid, 'targets': {}, 'process_mutations': 0}
browser = None
try:
    verify_no_owned_work(processes())
    browser = kernel.OpenProcess(0x0400 | 0x00100000, False, args.pid)
    assert browser and kernel.WaitForSingleObject(browser, 0) == 258
    time.sleep(3)
    verify_no_owned_work(processes())
    state['window_started_epoch'] = time.time()
    with start.open('x', encoding='utf-8') as handle:
        json.dump({'status': 'pure_timing_released', 'owned_completed_hosts_retired': 4,
                   'process_mutations': 0, 'epoch': time.time()}, handle)
    print(json.dumps({'status': 'pure_browser_started', 'pid': args.pid}), flush=True)
    deadline = time.monotonic() + 600
    while kernel.WaitForSingleObject(browser, 1000) == 258:
        assert time.monotonic() < deadline, 'Owned benchmark timeout'
    result = json.loads(report.read_text(encoding='utf-8'))
    state.update(window_finished_epoch=time.time(), result_status=result['status'],
                 status='timing_finished')
except BaseException as error:
    state.update(status='control_failed', error={'type': type(error).__name__, 'message': str(error)})
    raise
finally:
    if browser:
        kernel.CloseHandle(browser)
    state['finished_epoch'] = time.time()
    with receipt.open('x', encoding='utf-8') as handle:
        json.dump(state, handle, indent=2)
        handle.write('\n')
    print(json.dumps({'status': state['status'], 'output': str(receipt)}), flush=True)
