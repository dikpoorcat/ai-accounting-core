# C4 同快照关账物理读取批量化

本轮仅修改 `close_storage.py` 和一个专用测试文件，不改 DDL、冻结合同或现有调用 API，不操作真实资料。依据 same-source 12→48 资产 SQL 322→825，其中目录/块各 188 次、subroot 47 次；这些源内容仍必要，不能裁掉历史 member 目录。

`read_accounting_many` / `read_adopted_results_many` 已先建立全组 publication/voucher authority，再逐月读取。只在现有 current reader、owned read transaction、至少两个 header 时，提前批取缺失 accounting subroots，再用原 authenticated subject filter 计算精确命中 buckets，批取目录及块。完整 accounting 使用 authority 的 complete_subjects；adopted-only 使用该月候选 scope。仍由原 `_bucket_rows` 校验目录/块 digest、count、part multiset，再由原 `_read_accounting` 校验 bucket identity、position、adoption 与 voucher authority。新内容只放本组 staging maps，全组成功才更新 snapshot cache。

公共消费者：BusinessQueries 的冻结 accounting 选择及 asset owner identity；FundsRead 历史资金；Journal 历史采用；员工精确 adopted head identity；历史银行身份。五页及 CLI/MCP 通过这些共同入口受益，功能与源 proof 不变。完整 verify/repair/backup/restore 的 complete decode、reference_leaves、single read 保持原路径；固定 content-v1 和非 owned 连接保持逐月读取。

同一物理 helper 供 `read_readiness_checks_many(connection, headers, name)` 使用，按 headers 顺序返回 tuple。仅命中指定 checker（例如 financial_reports），仍使用原 management subroot contract 和单 value position/count/hash 规则；缺少 checker 返回 `{}`，不读取 sibling checker 或 management_snapshot。无公开提前 cache，任一失败整组不返回。QueryReads/reports 接线由 root 负责。

测试覆盖：批量 vs 原路完整值相等；空 scopes/filter negatives/空 buckets；adopted-only vs complete 的不同 authority universe；多个 fields/重复请求/新 snapshot；末月 subroot、directory、block 及 authority 损坏无成功 prefix；原 `_bucket_rows` 故障仍可注入；单头、非 owned、fixed-v1 fallback。工作量比较实际 SQL/VM/rows/returned bytes，routing scalar 与正文 bytes 分别陈述；不把诊断 wall clock 当页面收益。现有内部 helper monkeypatch 涉及 single read 或 one-header many，保留该原路及断言。

本阶段不启动测试或真实 DB probe；集中修改完成交 root 审查和组验证。未验证当前真实页面净延迟，历史 member 裁范围和其他已否定方案不实施。

C5 同批收敛：`verified_header` 在 `require_marker=True` 且既有 owned/current guard 下，只复用 active QueryReads `_close_headers` 的精确 period `CloseHeader`；同时匹配 header.period、logical digest 与该 row 原 manifest bytes 的 storage SHA。所有当前 cache 写入来自原 marker-required verified_header/verified_headers 或 authoritative_close_rows（也调用 verified_headers），没有 require_marker=False 的生产者。cache miss、不匹配、非 owned、固定 v1、require_marker=False 原路；不把新 header 放入 cache，各消费者仍执行自己的 family/source 检查。main48 已有 root 原件证明 report 60 次中 47 必要首次、13 次精确成功重复；不裁必要的首次读取。
