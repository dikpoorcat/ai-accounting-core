# r71 资产必要来源独立静态复核

GPT-6.1 Sol/high，仅源码、现有测试和已有日志读取；未编辑生产、运行测试、SQL、
服务或计时。实现仍在并行修订，本报告对应本轮实际读到的函数分支，不能当固定源验收。

## 已有证据与正确边界

- `business_queries._asset_owner_metadata_selection`（读时约1060行）限定当前内容模型、
  当前 close/publication/asset membership reader、owned QueryReads 活跃事务。
  v1或unowned返回None，`_selected_asset_member_heads`走原完整选择/成员核验。
- 冻结月份先核全部独立 `small.asset_batch_adoptions`，检查字段、重复owner、规范摘要；
  `calculation_identity_headers(membership)`强制全部ID覆盖，缺calculation/fact/subject/pub
  会拒绝。因此即使最后一个冻结owner的subject和calculation同时消失，新的metadata
  helper也不会因双定位空集而绕过核验。这是代码成立的独立定位链，不是实际双删测试。
- 冻结owner头再与scoped accounting里所有 `asset_batch_owner` 采用集合精确相等，
  adopted_header比对publication/subject/fact/source period/posting period/result digest。
  已选冻结voucher核独立reference，并与确切adopted结果/摘要对应。cs/fs与精确来源身份
  保留；冻结member目录全量读取、缺member/位置/行归属/依赖/foreign owner/来源身份拒绝，
  完整directory digest与small声明比较，不能凭命中asset页局部目录证明完整性。
- 开放owner使用subject.kind与calculation.kind两条定位，current helper以LEFT JOIN检查
  指针/身份/缺pub，并核终端发布与合法withdrawn。单缺subject或calculation不会在定位
  阶段消失。真实future发布先核其pub摘要再作期间排除；不要求未消费future正文解析。
  未冻结owner仍由metadata严格解正文及完整目录核对。
- `_selected_asset_owner_events`新owned分支（约1010行）把requested member kind映射到
  owner kind：activation只定位activation_batch，consumption只定位consumption_month。
  因而activation选择不会机械加载全部consumption正文；最后仍按requested subject/asset
  过滤成员，完整owner证明与member过滤的职责不同。
- `_assets`先完成acquisition/lifecycle身份、全scope scalar与ledger carrying/charge证明，
  再按页选卡（约4431行），只为selected fast卡获取last-charge及zero reason；selected
  最新owner最终仍走`asset_members_many`完整严格正文/成员证明。新metadata目录身份结果
  不写body成功cache，不升格为正文证明。summary/project页没有卡片字段消费者时不装
  last-charge正文；期初/处置等fallback仍保留完整必要历史。
- 31卡测试源码检查了20条首屏、11条续页、精确最后卡、projects/summary、全体金额和
  每卡最后月份，以及真实bytes/typed-decode增量。该测试本轮未运行；不能报告通过。

已有真实日志 `.tmp/stage9-r71-asset-metadata-scope-march-locator.log` 是4失败/4成功的
原负例：新metadata拒绝必要closed consumption owner缺calculation/subject，旧完整
`_selected_asset_members`由JOIN隐藏owner，故该后续断言失败。实施agent正在修该owned
定位，日志不应被改写为新代码已通过。

## 具体静态可触发候选，公开运行仍未验证

开放March非零 `asset_consumption_month` owner，保留其calculation、subject、pub、seals、
member目录与period_balance，只删除它所对应的 `voucher_current` 行：

1. `_current_accounting_heads`仍得到有效owner，pub及当前计算身份存在。
2. `selected_voucher_sql`非冻结分支要求voucher_current，故该voucher不进入selected。
3. `_asset_owner_metadata_selection`的`verify_selected_voucher_adoptions`只检查已命中的
   frozen voucher；`verify_publication_records`只认证pub内容摘要，不核current voucher存在。
4. `full.metadata`严格解有效owner，因line_count>0不构造state；没有事件替代，返回空events。
5. `_selected_asset_member_heads`在`if not events:return []`结束。对于fast卡，新last-charge
   字段可能消失，而月金额仍由保留的period_balance证明。没有把“helper能返回空”说成
   已运行公开Dashboard负例；整个页面其他路径是否会提前拦截尚须真实fixture定性。

对应读时位置：business_queries约1137/1138（selected/frozen voucher proof）、1165
（full metadata）、1194（只把零行current列state）、1243（空事件return）；dashboard约4436
（页后调用）/4638（latest_charge_period消费）。这不是因为函数相似而推断，而是上述
具体数据变更与每个条件分支的组合。

最窄复核建议：在已有March消费fixture上只验证这个开放owner的current voucher缺失；
若确认，使用已认证current owner pub.voucher_id核实际精确current版本，再走现有current
publication/voucher证明。不能只对已selected非空ID检查，否则缺失仍被隐藏。保留no-impact
允许旧voucher原calculation与新review owner的关系，不把两者强制相等，也不要求所有
unused历史正文恢复全解析。本复核不实施、不运行该测试，由根集中决定。

## 明确未验证与保持项

普通完整 `_selected_asset_owner_events` 双定位本身不解决subject+calculation同时删除：
若两臂及其他owner都为空，其提前return()没有读独立small列表。新的metadata helper有
独立small保护，两者不能混称。仅静态多损坏边界，本轮不主张全库多删或扩大成全仓修复。

双定位目前会完整认证所选ownerkind的全部owner；具体asset/subject scoped core可能因此
读取其他资产owner正文。这是缺候选时不能凭未认证member目录作负面排除的保守代价，
没有实际work证据就不定性性能缺陷。若要进一步限scope，需正面的独立member目录证明；
不能先按可损坏JOIN删掉候选。activation/consumption kind分离已有实际代码依据。

闭期correction、no-impact原voucher/新adoption、全零batch、合法撤去、未来边界的组合
未在本轮运行新负例；已有test_asset_identity_reads覆盖相关业务场景，但未宣称它们
已经覆盖本轮新metadata helper。固定v1/unowned明确保留旧分派，不用当前模型解释旧内容。

目录完成核验前只构建local result，没有把partial member成功写入 `_asset_members`；pub
摘要或close header独立核验成功可在同snapshot保存，不能当正文/采用/完整目录成功。
跨请求cache、历史存储合同、audit24方案均未改变。

完成静态复核后停止工具，交根统一修复/验证。
