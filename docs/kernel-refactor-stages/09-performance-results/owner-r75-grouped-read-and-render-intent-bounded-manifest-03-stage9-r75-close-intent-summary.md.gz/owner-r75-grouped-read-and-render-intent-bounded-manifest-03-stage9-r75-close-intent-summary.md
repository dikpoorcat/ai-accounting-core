# r75 活动关账 intent

仅本轮专用 runtime 持有退出；无真实资源操作、无 DDL/模型/历史格式修改、未触碰 query_reads。

## 实际修改

- `close_preview.py`：frozen/slots dataclass，身份、月份、digest、不可变 epochs/read_version tuple（含 repair）、owner_confirmation、精确规范 native-int 公共摘要 bytes、SHA 和每 LocalService 短期 HMAC。签名覆盖全部绑定及原始摘要 bytes。唯一 key JSON 解码、strict PublicOwnerReview 校验和规范 bytes 一致；返回新摘要对象。
- `service.py`：由同份 complete manifest 经 require_close_contract 和 full preview digest 复核后投出摘要，核 store 身份后记 intent；同月再预览删除旧 intent，FIFO 仍至多128项，service.close 清除持有。require_active 返回 immutable intent 与本次解码摘要，不返回缓存可变 alias。
- `close_review.py`：开放分支只消费认证摘要，只有 preview_expired 转 stale；内容损坏先于 snapshot_changed 拒绝。闭期仍 verified_header/read_section/require_owner_review 完整源后投同摘要。
- `daemon.py`：inspect 展示精确公共摘要，issue 使用 intent 版本与 confirmation；BEGIN IMMEDIATE 内完整 _manifest 重建、epochs/digest 比较、approval INSERT/rollback 原职责保留。
- `security/window.py`：新增明确 summary text 入口；独立 full _owner_review_text/public_owner_review 的完整源验证保留。
- 新 `test_close_preview_intent.py`，迁移 `test_close_review_validation_boundaries.py` 内部损坏注入和验证次数边界。

CLI/MCP 的 preview_close 完整 manifest 返回未改变。正式 Periods.close、冻结写入、历史完整核验、HTTP 字段/版本与固定 v1 无本轮变更。

## 实际回执

- 早期：`.tmp/stage9-r75-close-intent-early.command.txt/log/xml/json`，4 passed / stdout18.10s / XML17.923s。
- 最终：`.tmp/stage9-r75-close-intent-related.command.txt/log/xml/json`，39 passed / stdout91.07s / XML90.894s，0fail/0error/0skip，7修改文件前后SHA相等。完整命令及每个文件精确 SHA 在 JSON；不将早期重复项叠加为最终通过数量。
- Ruff 实际命令为 `.tmp-kernel-venv/Scripts/python.exe -m ruff check src/ai_accounting/kernel/close_preview.py src/ai_accounting/kernel/service.py src/ai_accounting/kernel/close_review.py src/ai_accounting/kernel/daemon.py src/ai_accounting/kernel/security/window.py tests/kernel/test_close_preview_intent.py tests/kernel/test_close_review_validation_boundaries.py`，最终输出 All checks passed。此工具输出未单独保存 Ruff 原始 log；最初2条静态格式错误保留在本轮工具回执，已修正。pytest 无失败原件。

39项固定选择：新 intent5项；transport、validation、identity_native三个完整文件；resident真实bound approval；owner-window；package1000分expense/frozen review；identity approval rollback、5种target损坏、fresh password/30分钟expiry。

业务/负例：真实 payroll 非零费用与 preview/HTTP/native_inspect/text 精确一致；普通 expense 的1000分开放/冻结金额一致；原 full preview 和 require 返回字典被 caller 修改不会改变缓存显示；signature、摘要+普通SHA、company/database/month/digest/epochs/repair/confirmation 损坏拒绝且不被 stale 隐藏；真实跨公司/月/旧intent交换拒绝；repreview淘汰；three lanes+repair失效；closed/covered/unprepared/service-restart读取；独立 full-source 校验；native私有/公开边界；真实密码错误（保留持久 throttle）/取消/window过期/双执行拒绝；消费 approval 后写 close 的合成故障导致同事务 rollback，恢复后同批准成功close；既有approval双消费/过期/target核验。

## 限制与下一步

均为明确隔离合成fixture。原生窗打开器是合成列表，实际Tk交互未运行；private controller及loopback HTTP/签发/完整关账为真实路径。fault分支只注入专属缓存损坏或冻结写故障；极值金额测试为既有明确序列化probe，不冒充自然业务金额。

未运行浏览器、规模核验、RSS/GC性能测量；不能据此声明500ms达标或全部额外成本解决。缓存结构已不保存 full manifest/collections；净 retained-heap 和净页面收益仍需根节点固定候选测量。r74 public-head 组不改变、不重复测试。最终 session56586 exit0，早期session4049 exit0；全部运行工具已停止。
