"""Pinned, read-only instrumented diagnostic; this is never browser acceptance timing."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from contextlib import contextmanager
from pathlib import Path

WORKSPACE = Path(__file__).resolve().parents[1]
SOURCE = WORKSPACE / ".tmp/stage9-build-source-owner-close-proof-groups-20261003-release"
MANIFEST = SOURCE / "source-manifest.json"

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--months", type=int, choices=(48,), required=True)
parser.add_argument("--book-report", type=Path, required=True)
parser.add_argument("--report-sha256", required=True)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
BOOK_REPORT = args.book_report.resolve(strict=True)
OUTPUT = args.output.resolve()
assert BOOK_REPORT.is_relative_to(WORKSPACE / ".tmp")
assert OUTPUT.is_relative_to(WORKSPACE / ".tmp") and not OUTPUT.exists()
MANIFEST_FILE_SHA256 = "9a66dffa78791171750a2cf6d9bde43ea43708fdd10ec865c2b73d64171115d3"
SOURCE_SHA256 = "8cc0b0300835a7359aa0399dd78714f048abeef6debc5f2acc3a858c33b384d8"
REPORT_SHA256 = "029e0eb04fdf4a51cde2d2f1ce235031a3086f33735eec92d70321d562f54656"
assert args.report_sha256 == REPORT_SHA256, (
    "Only this pinned old-qualified main48 qualification is permitted"
)
assert BOOK_REPORT == (WORKSPACE / ".tmp/stage9-owner-main48-month-reads-qualified.json").resolve()
assert (
    OUTPUT
    == (WORKSPACE / ".tmp/stage9-frozen-unused-classification-overlap-main48-8cc.json").resolve()
)


def file_hash(path):
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def main():
    require(
        Path(sys.prefix).resolve() == (WORKSPACE / ".tmp-kernel-venv").resolve(),
        "Use the repository virtual environment",
    )
    require(not OUTPUT.exists(), "Diagnostic output must not exist")
    require(file_hash(MANIFEST) == MANIFEST_FILE_SHA256, "Pinned manifest bytes changed")
    require(file_hash(BOOK_REPORT) == REPORT_SHA256, "Pinned verified report bytes changed")
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    require(
        manifest["status"] == "complete"
        and manifest["sha256"] == SOURCE_SHA256
        and Path(manifest["target"]).resolve() == SOURCE.resolve(),
        "Wrong source manifest",
    )

    # Bootstrap only from the fixed candidate, before importing any accounting module.
    sys.path.insert(0, str(SOURCE / "scripts"))
    import stage9_source

    stage9_source.require_source_module(stage9_source, SOURCE, "scripts/stage9_source.py")
    stage9_source.configure_source(SOURCE, WORKSPACE)
    import benchmark_stage9_browser
    import snapshot_stage9_source
    import stage9_metrics

    from ai_accounting.kernel import catalog as catalog_module
    from ai_accounting.kernel import dashboard as dashboard_module
    from ai_accounting.kernel import engine as engine_module
    from ai_accounting.kernel import (
        report_classification_directory,
        report_flow,
        reports,
        resident_reads,
        schema_bundle,
    )
    from ai_accounting.kernel.types import canonical
    from ai_accounting.kernel.versions import database_format

    for module, relative in (
        (snapshot_stage9_source, "scripts/snapshot_stage9_source.py"),
        (benchmark_stage9_browser, "scripts/benchmark_stage9_browser.py"),
        (stage9_metrics, "tests/kernel/stage9_metrics.py"),
        (catalog_module, "src/ai_accounting/kernel/catalog.py"),
        (dashboard_module, "src/ai_accounting/kernel/dashboard.py"),
        (engine_module, "src/ai_accounting/kernel/engine.py"),
        (resident_reads, "src/ai_accounting/kernel/resident_reads.py"),
        (schema_bundle, "src/ai_accounting/kernel/schema_bundle.py"),
        (reports, "src/ai_accounting/kernel/reports.py"),
        (
            report_classification_directory,
            "src/ai_accounting/kernel/report_classification_directory.py",
        ),
        (report_flow, "src/ai_accounting/kernel/report_flow.py"),
    ):
        stage9_source.require_source_module(module, SOURCE, relative)

    def check_source():
        inventory = snapshot_stage9_source._inventory(SOURCE)
        require(
            inventory == manifest["files"]
            and snapshot_stage9_source._digest(inventory) == SOURCE_SHA256,
            "Fixed source bytes drifted",
        )
        require(
            file_hash(MANIFEST) == MANIFEST_FILE_SHA256 and file_hash(BOOK_REPORT) == REPORT_SHA256,
            "Pinned attestations drifted",
        )

    check_source()
    book = json.loads(BOOK_REPORT.read_text(encoding="utf-8"))
    OLD_SOURCE = WORKSPACE / ".tmp/stage9-build-source-owner-month-reads-20261003-release"
    old_manifest_path = OLD_SOURCE / "source-manifest.json"
    require(
        file_hash(old_manifest_path)
        == "845318d7e9857cbae422033a7e8b87a5fb7edd2896f1c5f0617709eabca1c979",
        "Old qualification source manifest changed",
    )
    old_manifest = json.loads(old_manifest_path.read_text(encoding="utf-8"))
    contract_prefix = "src/ai_accounting/kernel/schema_contracts/"
    current_contracts = {
        k: v for k, v in manifest["files"].items() if k.startswith(contract_prefix)
    }
    old_contracts = {
        k: v for k, v in old_manifest["files"].items() if k.startswith(contract_prefix)
    }
    require(
        current_contracts and current_contracts == old_contracts,
        "Diagnostic requires identical manifest contracts",
    )
    for relative, digest in current_contracts.items():
        require(
            file_hash(SOURCE / relative) == digest and file_hash(OLD_SOURCE / relative) == digest,
            "Contract bytes changed",
        )
    benchmark_stage9_browser.require_report_source(book, OLD_SOURCE)
    period = benchmark_stage9_browser.validate_book_report(book, company_name="阶段九合成规模企业")
    require(
        book["requested_months"] == args.months
        and book["employee_count"] == 50
        and book["monthly_business_count"] == 1000
        and book["distribution"] == "mixed_cumulative",
        "Wrong main sample dimensions",
    )
    root = stage9_source.synthetic_path(Path(book["root"]), WORKSPACE)
    company = book["company"]
    checkpoint_path = root / "stage9-builder.json"
    checkpoint_hash = file_hash(checkpoint_path)
    require(
        checkpoint_hash == book["qualification"].get("checkpoint_sha256"),
        "Old qualified checkpoint changed",
    )
    checkpoint = json.loads(checkpoint_path.read_text(encoding="utf-8"))
    preview = book["verified_open_preview"]
    require(
        checkpoint["company"] == company
        and checkpoint["snapshots"] == book["snapshots"]
        and checkpoint["epochs"] == preview["state"],
        "Checkpoint no longer matches proof",
    )
    expected_state = preview["state"]
    expected_identity = {
        "company_id": company["id"],
        "database_id": company["database_id"],
        "taxpayer_id": company["taxpayer_id"],
    }
    integrity_contract = book["integrity_contract"]
    del checkpoint, book
    require(
        (root / "catalog.sqlite").is_file() and Path(company["path"]).is_file(),
        "Existing databases are required",
    )

    class ReadOnlyCatalog(catalog_module.Catalog):
        @contextmanager
        def connection(self, *, read_only=False, _cross_thread=False):
            require(read_only, "Diagnostic forbids catalog writes")
            with super().connection(read_only=True, _cross_thread=_cross_thread) as connection:
                yield connection

        def recover_operations(self):
            # Never resume pending publications during a read diagnostic.
            with self.connection(read_only=True) as connection:
                count = connection.execute(
                    "SELECT count(*) FROM company_operation WHERE status!='succeeded'"
                ).fetchone()[0]
            require(
                count == 0, "Catalog has unfinished operations; diagnostic will not recover them"
            )

    bundle = schema_bundle.production_bundle()
    catalog = ReadOnlyCatalog(root, bundle)
    require(
        catalog.database_format()["status"] == "released"
        and catalog.database_format()["version"] == 1,
        "Wrong catalog contract",
    )
    companies = catalog.companies()
    require(
        [row for row in companies if row["id"] == company["id"]] == [company],
        "Catalog company identity changed",
    )
    with catalog.connection(read_only=True) as connection:
        catalog_identity = dict(connection.execute("SELECT * FROM catalog_identity").fetchone())

    pool = resident_reads.ResidentReadPool(maximum=4)
    store = catalog.bind(company["id"], read_pool=pool)
    original_connection = store.connection

    @contextmanager
    def read_only_connection(*, read_only=False):
        require(read_only, "Diagnostic forbids company writes")
        with original_connection(read_only=True) as connection:
            yield connection

    store.connection = read_only_connection
    engine = engine_module.Engine(store)
    dashboard = dashboard_module.Dashboard(
        engine, company_name=company["name"], companies=companies
    )
    year, month = map(int, period.split("-"))
    quarter = (month - 1) // 3 + 1

    def check_state():
        require(
            file_hash(old_manifest_path)
            == "845318d7e9857cbae422033a7e8b87a5fb7edd2896f1c5f0617709eabca1c979",
            "Old source manifest drifted",
        )
        for relative, digest in old_contracts.items():
            require(
                file_hash(OLD_SOURCE / relative) == digest, "Old qualification contracts drifted"
            )
        with store.connection(read_only=True) as connection:
            connection.execute("BEGIN")
            state = list(connection.execute("SELECT * FROM state WHERE id=1").fetchone())
            identity = dict(
                connection.execute(
                    "SELECT company_id,taxpayer_id,database_id FROM identity WHERE id=1"
                ).fetchone()
            )
            require(
                state == expected_state and identity == expected_identity,
                "Company identity, business state or repair revision changed",
            )
            require(
                database_format(connection, bundle=bundle) == integrity_contract,
                "Company format differs from verified source",
            )
        with catalog.connection(read_only=True) as connection:
            require(
                dict(connection.execute("SELECT * FROM catalog_identity").fetchone())
                == catalog_identity,
                "Catalog identity changed",
            )
        require(catalog.companies() == companies, "Catalog registration changed")
        require(file_hash(checkpoint_path) == checkpoint_hash, "Construction checkpoint changed")
        return {"state": state, "identity": identity, "catalog_identity": catalog_identity}

    report = {
        "status": "diagnostic_started",
        "scope": "normal_quarterly_report_classification_overlap",
        "instrumented": True,
        "browser_acceptance": False,
        "source": str(SOURCE),
        "source_sha256": SOURCE_SHA256,
        "book_qualification_source": str(OLD_SOURCE),
        "current_source_full_verification": False,
        "verified_report": str(BOOK_REPORT),
        "verified_report_sha256": REPORT_SHA256,
        "checkpoint_sha256": checkpoint_hash,
        "root": str(root),
        "period": period,
        "quarter": f"{year}-Q{quarter}",
        "calls": [],
        "notes": [
            "Exactly one normal quarterly_report; no measure_work, cProfile, observation SQL, "
            "full verifier or preview.",
            "All wrappers call originals; successful directory results provide observation data.",
            "Comparison scans returned Python rows; instrumented work is not latency acceptance.",
            "Old1c37 qualification binds sample; new8cc source is not fully qualified.",
        ],
    }
    directory_results = []
    originals = []

    def caller():
        frame = sys._getframe(2)
        result = []
        for _ in range(5):
            if frame is None:
                break
            file = Path(frame.f_code.co_filename).resolve()
            if file.is_relative_to(SOURCE):
                result.append(
                    {
                        "file": file.relative_to(SOURCE).as_posix(),
                        "function": frame.f_code.co_name,
                        "line": frame.f_lineno,
                    }
                )
            frame = frame.f_back
        del frame
        return result

    def begin(name, **fields):
        record = {
            "call": len(report["calls"]) + 1,
            "function": name,
            "callers": caller(),
            "status": "started",
            **fields,
        }
        report["calls"].append(record)
        return record

    def invoke(original, record, *args, **kwargs):
        try:
            result = original(*args, **kwargs)
            record["status"] = "original_succeeded"
            return result
        except BaseException as error:
            record.update(
                status="original_failed",
                error_type=type(error).__name__,
                error_code=getattr(error, "code", None),
            )
            raise

    def wrap_directory(original):
        def observe(connection, end, keys, *, reads=None):
            record = begin("classification_directory_scope", end=end, key_count=len(keys))
            result = invoke(original, record, connection, end, keys, reads=reads)
            if result is None:
                record["directory_present"] = False
            else:
                record.update(
                    directory_present=True,
                    directory_close=result["period"],
                    membership_keys=len(result["membership"]),
                    unsafe_count=len(result["unsafe"]),
                    conflicts_count=len(result["conflicts"]),
                )
                directory_results.append((connection, reads, end, result, record["call"]))
            return result

        return observe

    def wrap_closed(original):
        def observe(connection, end, reads=None, *, closes=None, retain_ids=None):
            record = begin(
                "_closed_report_fact_sources",
                end=end.ordinal,
                retain_ids_count=None if retain_ids is None else len(retain_ids),
                supplied_closes_count=None if closes is None else len(closes),
            )
            result = invoke(
                original, record, connection, end, reads, closes=closes, retain_ids=retain_ids
            )
            record.update(
                returned_references=len(result),
                returned_unique_ids=len({row["reference_id"] for row in result}),
                returned_close_periods=sorted({row["close_period"] for row in result}),
            )
            return result

        return observe

    def wrap_rooted(original):
        def observe(connection, reads, source_vouchers, end, source, problems):
            record = begin(
                "_rooted_classification_headers",
                end=end.ordinal,
                source=source,
                source_vouchers_count=len(source_vouchers),
                problems_before=len(problems),
            )
            result = invoke(
                original, record, connection, reads, source_vouchers, end, source, problems
            )
            record.update(
                returned_headers=None if result is None else len(result),
                problems_after=len(problems),
            )
            return result

        return observe

    def wrap_unused(original):
        def observe(connection, reads, pending, source_vouchers, end):
            from ai_accounting.kernel.types import YearMonth

            year_start = YearMonth(str(end)[:4] + "-01").ordinal
            candidates = {
                row["revision_id"]: (voucher, row)
                for voucher, row in pending.items()
                if source_vouchers is not None
                and voucher not in source_vouchers
                and row["fact_period"] is not None
                and row["fact_period"] < year_start
                and row["fact_digest"] is not None
            }
            cache_key = ("closed_report_fact_sources", end.ordinal)
            record = begin(
                "_frozen_unused_classification_ids",
                end=end.ordinal,
                source_vouchers_count=None if source_vouchers is None else len(source_vouchers),
                pending_count=len(pending),
                candidate_count=len(candidates),
                same_connection=reads.connection is connection,
                snapshot_active=bool(reads._snapshot_active),
                in_transaction=bool(connection.in_transaction),
                closed_sources_cached_before=cache_key in reads._report_snapshot_cache,
            )
            # No values produced above are passed as proof or substituted into originals.
            result = invoke(original, record, connection, reads, pending, source_vouchers, end)
            closed_sources = reads._report_snapshot_cache.get(cache_key)
            first = {}
            if closed_sources is not None:
                for item in closed_sources:
                    ident = item["reference_id"]
                    if ident in candidates:
                        first[ident] = min(
                            item["close_period"], first.get(ident, item["close_period"])
                        )
            dirs = [
                entry
                for entry in directory_results
                if entry[0] is connection and entry[1] is reads and entry[2] == end.ordinal
            ]
            candidate_rows = []
            for ident, (voucher, row) in sorted(candidates.items()):
                matches = []
                for _, _, _, directory, call in dirs:
                    entries = directory["membership"].get(voucher, ())
                    entries = tuple(entries) + tuple(
                        directory["conflict_membership"].get(voucher, ())
                    )
                    entries += tuple(
                        entry[1:] for entry in directory["unsafe"] if entry[0] == voucher
                    )
                    for entry in sorted(set(tuple(entry) for entry in entries)):
                        if entry[0] == ident:
                            matches.append(
                                {
                                    "directory_call": call,
                                    "first_close": entry[2],
                                    "digest": entry[1],
                                    "safe": entry[3],
                                    "same_first_close_as_closed_sources": None
                                    if ident not in first
                                    else entry[2] == first[ident],
                                    "same_digest_as_pending": entry[1] == row["fact_digest"].hex(),
                                }
                            )
                candidate_rows.append(
                    {
                        "id": ident,
                        "voucher": voucher,
                        "pending_digest": row["fact_digest"].hex(),
                        "fact_period": row["fact_period"],
                        "closed_sources_first_close": first.get(ident),
                        "covered_by_original": ident in result,
                        "authenticated_directory_matches": matches,
                    }
                )
            record.update(
                covered_count=len(result),
                closed_sources_count=None if closed_sources is None else len(closed_sources),
                candidates=candidate_rows,
            )
            return result

        return observe

    with OUTPUT.open("x", encoding="utf-8") as output:
        try:
            report["before"] = check_state()
            for module, name, wrapper in (
                (report_classification_directory, "classification_directory_scope", wrap_directory),
                (reports, "_closed_report_fact_sources", wrap_closed),
                (reports, "_rooted_classification_headers", wrap_rooted),
                (reports, "_frozen_unused_classification_ids", wrap_unused),
            ):
                original = getattr(module, name)
                originals.append((module, name, original))
                setattr(module, name, wrapper(original))
            try:
                result = dashboard.quarterly_report(year, quarter, preparation="deferred")
                require(
                    result.get("read_context", {}).get("company_id") == company["id"],
                    "Quarterly report wrong company",
                )
                report["response"] = {
                    "schema_version": result["schema_version"],
                    "sha256": hashlib.sha256(canonical(result).encode("utf-8")).hexdigest(),
                }
                del result
            finally:
                for module, name, original in reversed(originals):
                    setattr(module, name, original)
            report["after"] = check_state()
            check_source()
            report["status"] = "diagnostic_complete"
        except BaseException as error:
            report["status"] = "diagnostic_failed"
            report["error"] = {"type": type(error).__name__, "message": str(error)}
            raise
        finally:
            for module, name, original in reversed(originals):
                setattr(module, name, original)
            directory_results.clear()
            pool.close()
            json.dump(report, output, ensure_ascii=False, indent=2)
            output.write("\n")
    print(json.dumps({"status": report["status"], "output": str(OUTPUT)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
