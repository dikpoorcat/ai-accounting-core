"""Fixed released source/tests regression; no fixture substitution or source writes."""
import contextlib
import hashlib
import importlib
import json
import os
from pathlib import Path
import sys
import time

WORKSPACE = Path(__file__).resolve().parents[1]
SOURCE = WORKSPACE / '.tmp/stage9-build-source-owner-close-proof-groups-20261003-release'
import argparse
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--group', choices=('direct', 'consumers', 'boundaries'), required=True)
args = parser.parse_args()
PREFIX = WORKSPACE / ('.tmp/stage9-close-proof-groups-regression-' + args.group)
GROUPS = {
'direct': ['test_close_physical_batch.py', 'test_close_header_batch.py', 'test_report_readiness_batch.py', 'test_report_header_reuse.py'],
'consumers': ['test_close_accounting_filter.py', 'test_full_accounting_period_scopes.py', 'test_report_flow.py', 'test_report_flow_header_aggregate.py', 'test_report_flow_integrity.py', 'test_report_projection.py', 'test_period_readiness.py'],
'boundaries': ['test_stage9_production_verifier_coverage.py', 'test_v1_verified_close_prefix.py', 'test_report_classification_v1.py', 'test_stage9_backup_upgrade_history.py', 'test_stored_json_repair_boundary.py', 'test_read_repair_version.py::test_actual_repair_invalidates_pages_and_deferred_checks_but_noop_does_not', 'test_runtime_backup.py::test_close_manifest_corruption_is_detected', 'test_runtime_backup.py::test_initial_portable_round_trip_and_rollover_are_verified'],
}
FILES = GROUPS[args.group]
paths = {k: Path(str(PREFIX)+suffix) for k,suffix in [('log','.log'),('xml','.xml'),('metadata','.json'),('temp','-temp')]}
assert all(not p.exists() for p in paths.values()), 'must-new outputs'
assert Path(sys.prefix).resolve() == WORKSPACE/'.tmp-kernel-venv'
os.environ.pop('FINANCE_DATA_ROOT', None)
os.environ['PYTHONDONTWRITEBYTECODE']='1'
os.environ['PYTHONPATH']=str(SOURCE/'src')
sys.dont_write_bytecode = True
sys.path[:0] = [str(SOURCE),str(SOURCE/'scripts')]
import stage9_source
stage9_source.require_source_module(stage9_source,SOURCE,'scripts/stage9_source.py')
stage9_source.configure_source(SOURCE,WORKSPACE)
import snapshot_stage9_source
stage9_source.require_source_module(snapshot_stage9_source,SOURCE,'scripts/snapshot_stage9_source.py')
manifest_path=SOURCE/'source-manifest.json'
manifest_bytes=manifest_path.read_bytes()
assert hashlib.sha256(manifest_bytes).hexdigest()=='9a66dffa78791171750a2cf6d9bde43ea43708fdd10ec865c2b73d64171115d3'
manifest=json.loads(manifest_bytes)
assert manifest['sha256']=='8cc0b0300835a7359aa0399dd78714f048abeef6debc5f2acc3a858c33b384d8'
assert Path(manifest['target']).resolve()==SOURCE.resolve()
def inventory():
    result=snapshot_stage9_source._inventory(SOURCE)
    assert result==manifest['files']
    assert snapshot_stage9_source._digest(result)==manifest['sha256']
    assert manifest_path.read_bytes()==manifest_bytes
    return result
before=inventory()
modules={}
for name in ['ai_accounting','ai_accounting.kernel.schema_bundle','ai_accounting.kernel.content_v1',
'ai_accounting.kernel.history_reads_v1','ai_accounting.kernel.offline_upgrade',
'ai_accounting.kernel.versions','ai_accounting.kernel.catalog','ai_accounting.kernel.service',
'ai_accounting.kernel.backup','ai_accounting.kernel.close_storage',
'ai_accounting.kernel.query_reads','ai_accounting.kernel.reports','ai_accounting.kernel.report_flow',
'ai_accounting.kernel.close_storage_v1']:
    module=importlib.import_module(name)
    path=Path(module.__file__).resolve()
    assert path.is_relative_to(SOURCE/'src')
    modules[name]=str(path)
from ai_accounting.kernel.schema_bundle import production_bundle
bundle=production_bundle()
assert bundle.status=='released' and dict(bundle.current_versions)=={'company':1,'catalog':1}
assert set(bundle.company_verifiers)=={1}
report={'status':'running','pid':os.getpid(),'source':str(SOURCE),'source_sha256':manifest['sha256'],
'manifest_file_sha256':hashlib.sha256(manifest_bytes).hexdigest(),'source_inventory_before':before,
'production_module_paths':modules,'test_files':FILES,'fixture_mode':'unchanged sealed source tests and fixtures',
'log':str(paths['log']),'junit':str(paths['xml']),'contract':{'status':bundle.status,'versions':dict(bundle.current_versions)},
'counts':{},'stage_complete':False}
print('PID',os.getpid(),'LOG',paths['log'],flush=True)
started=time.perf_counter()
class Record:
    def pytest_sessionfinish(self,session,exitstatus):
        terminal=session.config.pluginmanager.getplugin('terminalreporter')
        report['counts']={key:len(value) for key,value in terminal.stats.items() if key in ('passed','failed','error','skipped','xfailed','xpassed')}
import pytest
os.chdir(SOURCE)
exitcode=1
with paths['log'].open('x',encoding='utf-8') as log:
    with contextlib.redirect_stdout(log),contextlib.redirect_stderr(log):
        try:
            print(json.dumps({k:v for k,v in report.items() if k!='source_inventory_before'},ensure_ascii=False))
            exitcode=pytest.main(['-c',str(SOURCE/'pyproject.toml'),'-p','no:cacheprovider',
                '--basetemp',str(paths['temp']),'--junitxml',str(paths['xml']),'-q',
                *[str(SOURCE/'tests/kernel'/name) for name in FILES]],plugins=[Record()])
            report['source_inventory_after']=inventory()
            report['source_inventory_equal']=report['source_inventory_after']==before
            report['status']='passed' if exitcode==0 else 'failed'
        except BaseException as exc:
            report['status']='runner_failed'
            report['error_type']=type(exc).__name__
            raise
        finally:
            report['exitcode']=int(exitcode)
            report['seconds']=time.perf_counter()-started
            with paths['metadata'].open('x',encoding='utf-8') as target:
                json.dump(report,target,ensure_ascii=False,indent=2)
                target.write('\n')
print('DONE',report['status'],report['counts'],flush=True)
raise SystemExit(exitcode)