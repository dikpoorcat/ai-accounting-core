"""Isolated synthetic voucher-header damage, never a performance measurement."""
import hashlib
import json
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(REPO / "src"), str(REPO / "tests/kernel")]

from test_asset_batch_reads import prepare_batch_assets
from test_asset_batches import month
from test_integrity_content import damage, verify
from test_payroll_corrections import Company
from ai_accounting.kernel.business_queries import BusinessQueries
from ai_accounting.kernel.dashboard import Dashboard
from ai_accounting.kernel.types import canonical

OUT = Path(__file__).parent


def invoke(function):
    try:
        value = function()
        return {"status": "accepted", "value": value,
                "sha256": hashlib.sha256(canonical(value).encode()).hexdigest()}
    except Exception as error:
        return {"status": "rejected", "type": type(error).__name__,
                "code": getattr(error, "code", None), "message": str(error),
                "details": getattr(error, "details", None)}


receipt = {"scope": "three new isolated synthetic company fixtures", "cases": []}
for field in ("reverses_id", "total", "number"):
    path = OUT / f"{field}.sqlite"
    if path.exists():
        raise RuntimeError(f"Refusing existing synthetic database: {path}")
    company = Company(path)
    prepare_batch_assets(company)
    engine = company.engine
    with engine.store.connection(read_only=True) as connection:
        proof = engine.store.current_fact(connection, "computer").evidence[0]
    company.close("2026-02")
    month(engine, proof, "2026-03", f"header-{field}-march")
    company.close("2026-03")
    with engine.store.connection(read_only=True) as connection:
        target = dict(connection.execute(
            "SELECT v.*,n.number,c.subject_id FROM voucher_version v "
            "JOIN voucher n ON n.id=v.voucher_id JOIN calculation c ON c.id=v.calculation_id "
            "WHERE c.kind='asset_consumption_month'"
        ).fetchone())
        original = dict(connection.execute(
            "SELECT v.* FROM voucher_version v JOIN calculation c ON c.id=v.calculation_id "
            "WHERE c.kind='asset_activation_batch'"
        ).fetchone())
        before_mirror = [list(row) for row in connection.execute(
            "SELECT * FROM close_reference ORDER BY close_period,path,position,reference_type"
        )]
    calls = {
        "assets": lambda: Dashboard(engine).assets("2026-03", preparation="deferred"),
        "asset_detail": lambda: Dashboard(engine).assets(
            "2026-03", asset_id="computer", preparation="deferred"),
        "business_status": lambda: BusinessQueries(engine).business_status(
            target["subject_id"], "2026-03"),
        "core": lambda: verify(engine),
    }
    baseline = {name: invoke(call) for name, call in calls.items()}
    if any(value["status"] != "accepted" for value in baseline.values()):
        receipt["cases"].append({"field": field, "baseline": baseline})
        (OUT / "receipt.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2),
                                         encoding="utf-8")
        raise RuntimeError(f"Synthetic baseline failed: {field}")
    table = "voucher" if field == "number" else "voucher_version"
    ident = target["voucher_id"] if field == "number" else target["id"]
    changed = original["id"] if field == "reverses_id" else target[field] + 1000
    damage(engine, table, f"UPDATE {table} SET {field}=? WHERE id=?", (changed, ident))
    after = {name: invoke(call) for name, call in calls.items()}
    with engine.store.connection(read_only=True) as connection:
        after_mirror = [list(row) for row in connection.execute(
            "SELECT * FROM close_reference ORDER BY close_period,path,position,reference_type"
        )]
    result = {"field": field, "target": target, "changed_value": changed,
              "close_reference_unchanged": before_mirror == after_mirror,
              "baseline": baseline, "after": after,
              "same_accepted_response": {
                  name: before["status"] == after[name]["status"] == "accepted"
                  and before["sha256"] == after[name]["sha256"]
                  for name, before in baseline.items()
              }}
    receipt["cases"].append(result)
    (OUT / "receipt.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2),
                                     encoding="utf-8")
    print(json.dumps({"field": field, "after": {name: {key: value.get(key)
           for key in ("status", "code", "details")} for name, value in after.items()},
           "same_response": result["same_accepted_response"]}, ensure_ascii=False), flush=True)
print("COMPLETED", flush=True)
