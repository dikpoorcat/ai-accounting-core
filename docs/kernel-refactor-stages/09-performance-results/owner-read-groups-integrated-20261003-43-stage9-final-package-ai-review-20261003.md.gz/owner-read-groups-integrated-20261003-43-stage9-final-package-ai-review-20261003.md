# 最终正式包与实际 AI 复验入口（只读审查，2026-10-03）

使用 GPT-6.1 Sol / high。本次只读源码、测试和既存合成回执；未构包、冻结、建库、执行测试、启动服务、读取真实数据库或操作负责人身份。46f84508afd54165f23af5a83434b1881002ab45490f4358f0c1755c743748be 是已固定的 released 候选 source inventory，不是仓库正式发布或最终包验收。仓库当前仍 draft/0。以下命令仅供主线程在性能、源码与正式冻结收敛后执行。

## 真实入口与最短执行顺序

1. `scripts/package_local_kernel.py` 仅接受 `--output PATH`、`--skip-validation`。正式执行不加后者。无 `--source`、`--release` 参数；必须同时选择固定脚本和固定 `src` 导入。PowerShell wrapper `scripts/package-local-kernel.ps1` 只有 `-OutputDirectory`、`-SkipValidation`，且固定使用该脚本所在仓库的 venv，不适合直接从没有 venv 的 source snapshot 调用。
2. 包构建已经执行自检：新建软件目录和 ZIP，重新解压至 `-relocated`，逐文件 inventory/hash 核对，毒化 PYTHONHOME/PYTHONPATH，再用包内解释器执行 `tools/verify_local_package.py`，成功写 `-verification.json`。不要再为同一成功包重复自检；其 `-validation` 目录通过 `mkdir()` 拒绝重用。
3. 实际 AI relay 是 **`tests/kernel/stage9_package_agent_harness.py`**，不是 `scripts/stage9_package_agent_harness.py`。只有位置参数：`host DIRECTORY PACKAGE`，`call DIRECTORY ARGUMENT_JSON`，`schema DIRECTORY ARGUMENT_JSON`，`native DIRECTORY ARGUMENT_JSON`。`schema` 也要提供请求文件；它只打印响应文件路径，避免整个 schema 输出到终端。
4. 现成 seed helper 是 **`.tmp/stage9_prepare_agent_seed.py --source SOURCE --directory DIRECTORY`**，不是 harness 子命令。它只允许 workspace `.tmp/stage9-final-agent`，整个目录必须不存在；本次只读检查该目标不存在。它以最终源建立 2 员工、40 业务、1 开放月的 MixedBook，执行真实 `backup.verify_file` 和开放月 preview，才 exclusive 写 `seed.json`；不 provision 身份。它用源码 API 准备夹具，不能算 AI 经 MCP 新建或登记。
5. host 用包解释器和包内 LocalService / stdio CLI MCP，读取该 seed、建立合成身份和 Windows session credential，校验简报/资金响应后写 `ready.json`；然后等待请求。harness 的 `REPOSITORY` 来自自身 `parents[2]`，因此 workspace 下的 agent 目录应使用 workspace harness，并先核它与最终固定源同字节。直接运行固定源内 harness 会要求固定源自己的 `.tmp`。

## 待执行命令

在仓库根运行。`$finalSource` 必须由主线程绑定到最终冻结并批准用于构包的源码，不能默认把 46f845 候选称为正式发布；源码内 `schema_bundle` 应已选择 released/1，三份正式合同已冻结且 `--check` 通过，静态 release 产物来自同源。下面不切选择器、不再 freeze 已存在合同、不触碰现有服务根。

```powershell
$workspace = (Resolve-Path .).Path
$kernelPython = (Resolve-Path .tmp-kernel-venv/Scripts/python.exe).Path
$finalSource = (Resolve-Path .tmp/stage9-final-release-source).Path # 主线程替换为最终实际路径
$package = Join-Path $workspace '.tmp/stage9-final-released-v1-package'
$agent = Join-Path $workspace '.tmp/stage9-final-agent'
$sourceRunner = 'import pathlib,runpy,sys; root=pathlib.Path(sys.argv[1]).resolve(); script=root/"scripts"/sys.argv[2]; sys.path.insert(0,str(root/"src")); sys.argv=[str(script),*sys.argv[3:]]; runpy.run_path(str(script),run_name="__main__")'

# 只执行检查；正式合同已经存在时不要再次 --freeze-v1。
& $kernelPython -X utf8 -c $sourceRunner $finalSource export_kernel_schema_contracts.py --check
if ($LASTEXITCODE -ne 0) { throw 'Final released contract check failed' }

# 控制早期停止，同时保全迟阶段自检目录；构包自身也拒绝前四个旧目标。
foreach ($target in @($package, "$package.zip", "$package-relocated", "$package-verification.json", "$package-relocated-validation")) {
    if (Test-Path -LiteralPath $target) { throw "Preserve existing delivery target: $target" }
}
& $kernelPython -X utf8 -c $sourceRunner $finalSource package_local_kernel.py --output $package
if ($LASTEXITCODE -ne 0) { throw 'Package build or its automatic self-check failed; retain all outputs' }

$receipt = Get-Content -LiteralPath "$package-verification.json" -Raw | ConvertFrom-Json
$manifest = Get-Content -LiteralPath "$package/manifest.json" -Raw | ConvertFrom-Json
if ($receipt.status -ne 'passed' -or -not $receipt.packaged_offline_upgrade) { throw 'Released package self-check incomplete' }
foreach ($kind in @('catalog','company')) {
    $format = $receipt.runtime.database_formats.$kind
    if ($format.status -ne 'released' -or $format.version -ne 1) { throw 'Wrong package database contract' }
}
if ($manifest.source_build_id -ne $manifest.runtime.build_id -or $receipt.runtime.build_id -ne $manifest.runtime.build_id) { throw 'Source/package/self-check build mismatch' }
Get-FileHash -LiteralPath "$package.zip", "$package/manifest.json" -Algorithm SHA256

& $kernelPython -X utf8 .tmp/stage9_prepare_agent_seed.py --source $finalSource --directory $agent
if ($LASTEXITCODE -ne 0) { throw 'Seed failed; keep the partial directory and report' }
$harness = Join-Path $workspace 'tests/kernel/stage9_package_agent_harness.py'
$restoreCheck = Join-Path $workspace 'tests/kernel/stage9_package_restore_check.py'
foreach ($helper in @('stage9_package_agent_harness.py','stage9_package_restore_check.py')) {
    $a = (Get-FileHash -LiteralPath "$workspace/tests/kernel/$helper" -Algorithm SHA256).Hash
    $b = (Get-FileHash -LiteralPath "$finalSource/tests/kernel/$helper" -Algorithm SHA256).Hash
    if ($a -ne $b) { throw 'Workspace helper differs from final source; stop before relay startup' }
}
$packagePython = Join-Path $package 'runtime/python.exe'
```

保存构包 stdout/stderr 为新的 exclusive 日志，并保存最终 source inventory、三合同 SHA、manifest 和 ZIP SHA。以上 `$sourceRunner` 只改变新进程导入顺序，不设置全局 PYTHONPATH，也不改变 FINANCE_DATA_ROOT。构包使用包内显式根；默认 launcher 的自检还主动移除继承的 FINANCE_DATA_ROOT，使用新包自己的默认根。

host 是持续进程，不能在一个前台同步命令之后等待它自己退出。可在单独终端运行下列第一行；若主线程用后台 helper，使用 `Start-Process -WindowStyle Hidden`、独立 stdout/stderr 文件，并保留进程 ID。先等 `ready.json`，再开始子智能体回放；不得在同根并启第二个 daemon。

```powershell
& $packagePython -I -X utf8 $harness host $agent $package

# 其他终端/实际子智能体通过文件 relay 发送 MCP；每个输入名及 request_id 保持明确。
& $packagePython -I -X utf8 $harness schema $agent "$agent/schema-request.json"
& $packagePython -I -X utf8 $harness call $agent "$agent/business-request.json"
& $packagePython -I -X utf8 $harness native $agent "$agent/approve-request.json"
```

`schema-request.json` 内容为 `{"tool":"finance_local_schema","arguments":{}}`。业务请求为 `{"tool":"finance_local_command","arguments":{"command":"COMMAND","payload":{...}}}`；安全请求为 `{"tool":"finance_local_security","arguments":{"action":"request","payload":{"kind":"approve_period_close",...}}}`。native 输入为 `{"operation":"approve","request_id":"真实安全请求返回值"}`，只由宿主按同版核对后的明确批准处理；不把密码交给子智能体或写进 MCP payload。

故障模拟文件是 `$agent/lose_next_write_response`。它将下一笔带 payload.request_id、实际非 rejected/needs_information 的响应改成 service_unavailable；真实已提交响应保存在 tools.jsonl。模拟前安排好唯一下一笔写入，不能在并发读/写间随意开关。子智能体必须用同一个 request_id 查 `request_result` 或精确重发原载荷，不生成新键重复登记。回执 300 秒等待超时也可能仍在执行：保留响应路径，不能自动改键重试。

host **不启动 JobRunner**。实际 AI 备份、失败和中断恢复在 relay 内应使用 MCP `run_jobs`，再查 `jobs`；一轮 run_jobs 对每个 job 最多尝试一次，三次耗尽后须先消除明确合成原因，再 `retry_job`。包自检另有真实后台 JobRunner，能证明后台机制。relay 不证明自动后台重启，旧 AI replay 也只是正常队列 `run_jobs`，没有失败任务再 retry 的记录。

## 实际子智能体最小任务与验收点

实际子智能体应先读当前 schema/agent_operating_protocol，再用上面的 call 接口；不是脚本自动重放旧 JSON。由主线程指定模型并保存原始任务、对话和完整工具回执。本轮没有启动子智能体。

1. 从 ready.json 绑定主合成公司的 company_id/database_id、2016-01、当前事实及采用版本。若验收要求“AI 本人新建”，通过 MCP 新建第二个明确合成公司，并检查两公司上下文/读写隔离；host 初次公司列表校验结束后允许此步骤。主公司由 seed 创建这一事实应保留。
2. 当前 seed 已确认并发布工资。实际 AI 至少要真实执行工资确认/发布链；可以在后续闭期更正中完成，而不能把 seed 过程冒充代理行为。合成更正事实明确为 `wage-2016-01-0` 从 administration 改为 sales，工资金额、人员、净额和实际付款不变；读取当前工资及 `wage-plan-2016-01-0` 精确版本，更新所需确认依据、prepare_payroll/confirm_payroll_preparation，再 preview/confirm，posting_period 使用明确开放的 2016-02。先关闭 2016-01，再作该更正，才能证明 closed_correction 和原冻结月份不变。
3. 关闭前 preview_close → dashboard_close_review（精确 digest）→ finance_local_security request（同 company/database/period/digest/epochs）→ 宿主 native approve → close。只关 2016-01，保留原冻结结果。把 lose_next_write_response 安排在 close 前；代理通过 request_result 找回已提交关账，不重复关账。
4. 合成实际办理及独立复核使用 `stage9-agent-report-completion` / `stage9-agent-report-review`。明确外部义务为合成 2016-01 财务报告，合成办理日 2016-02-10、截至日 2016-02-28；先取得 obligation_basis，只采用真实返回的 fact/calculation/evidence 身份，再完成、发布、独立复核和发布。没有事实则停止并报告，不猜版本/日期/金额。
5. 制造明确的新合成备份目标阻碍，观察 jobs 错误与 attempts；消除该合成阻碍后 retry_job + run_jobs 至 succeeded，再正常备份和核验。只动该 agent 目录的人工测试阻碍，不能读取或清理当前真实备份。保存正常和失败回执，不把 pending 当成功。
6. 提交最终摘要及精确 close_digest、最新 wage/completion/review fact_id、成功 ZIP 路径后，主线程创建 `$agent/stop`，等待 host 正常退出/撤销 session/移除该 catalog 的 credential，再执行恢复检查。不得用 repo 默认 root 或清理真实常驻服务来停 relay。

恢复检查命令（变量全部从上述真实回执取得，不能沿用旧 draft ID）：

```powershell
& $packagePython -I -X utf8 $restoreCheck `
    --archive $backupZip `
    --source "$agent/data/91310000123456789S/company.sqlite" `
    --target "$agent/restored.sqlite" `
    --output "$agent/restore-check.json" `
    --company-id $companyId --close-digest $closeDigest `
    --wage-fact-id $wageFactId --completion-fact-id $completionFactId --review-fact-id $reviewFactId
if ($LASTEXITCODE -ne 0) { throw 'Restored business/frozen state verification failed' }
```

restore helper 只有这九个 required 参数；所有 archive/source/target/output 必须在它所属 REPOSITORY/.tmp 内；target/output 均须不存在。它调用包内 backup.restore_portable/verify_file，比较完整冻结 manifest/digest、三项当前事实和 calculation、材料规则、结构合同及完整核验。它断言恰好一月关账、一个 material_close_rule，并固定以上三个 subject 名，不能改任务形状后仍照抄。它恢复到独立 SQLite 文件，**不是 AI 经 MCP restore_company 的公司重新登记**；后者已由包自检真实覆盖。不要把两种恢复合称代理本人全部执行。

## 已实现覆盖与真正缺项

| 要求 | 当前实现与回执性质 | 最终仍需 |
| --- | --- | --- |
| 新建、对象/事实登记、发布与幂等 | verify_local_package.py:1296–1550 通过包内独立 CLI、真实 LocalService/HTTP；不是 mock。旧 draft 两包自检确有 passed。 | 最终 released 包的新自检回执；若要求 AI 新建，增加上述第二公司 MCP 步骤。 |
| 工资确认、发布、更正 | verify_reserve_business:255–816 有真实工资政策/确认、缺确认拒绝、闭期分类更正、当前与冻结确认来源保留，restore 后金额/来源比较。 | 最终包复跑；AI 实际 prepare/confirm_payroll_preparation、preview/confirm，而不是仅查询 seed。 |
| 同版密码批准与单月关账 | approve_close:1418–1451 先真实精确 review，再 production controller/private native 执行合成密码，close/自动备份/冻结/冲正/恢复有断言。 | 最终包回执；AI 原生请求与宿主批准关联。 |
| 人工安全窗口 | start_resident:1092–1194 实际 pythonw login 窗口显示/取消；另实际 SecurityForm 自动输入合成密码并登录。close 批准和 AI host 的 window_opener 均为空，native relay 自动执行密码。 | **人工关账表单查看/输入/批准未覆盖**。若最终标准要求这一操作，另用新隔离根的真实 daemon / security login 与 security close，同版请求后让负责人操作；现 harness 没有打开窗口模式。不得与 active relay 在同根并行启动 daemon。 |
| 实际办理/独立复核 | verify_stage8_workflow:887–1030 经真实 CLI 保存/发布 completion 与 review、业务状态和跨公司 request_result；实际外部办理仅合成确认，不连接税局。 | 最终包/实际 AI 回执及相同来源核对；不宣称真实申报已办。 |
| 失败任务与恢复 | verify_stage8_job_recovery:1033–1089 是真实新文件阻碍、持久 jobs 三次失败、停止测试 runner、清理阻碍、retry_job 并启动真实 runner 至成功；未 mock jobs。 | 最终 released 自检。AI relay 另需明确失败/retry/run_jobs；旧 draft AI 38 请求没有 retry_job。真正杀进程后重启中断恢复不由此脚本证明，若需该项应另做隔离任务断点场景，不能称已有全过程。 |
| 备份/恢复 | 包自检多次 backup/jobs → restore_company → 冻结/当前金额/完整 verify_integrity；AI restore helper 实际 restore_portable/verify_file。 | 最终包的新 ZIP 和 restore-check.json。 |
| released 专用门禁 | 自检 released 分支实际 CLI 对真实 daemon/root lock 拒绝，停后两次同版 upgrade verified_skip，验证四家公司；draft 分支 upgrade_smoke=null。 | 最终 released 回执 packaged_offline_upgrade 非空。现包自检未构造 draft/旧体系库负测，源码测试/复制工厂负测不能冒称包实测。 |

`test_stage9_package_upgrade_smoke.py` monkeypatch subprocess/daemon 活性及 metadata，验证检查器识别污染；`test_package_contract_selection.py` 有 synthetic bundle/monkeypatch 及复制源子进程冻结；`test_stage9_package_parallel_smoke.py` 用源码 resident fixture；`test_stage9_package_owner_contracts.py` 用 native_samples/resident fixtures。这些是检查器/合同的单元或集成保护，不等于实际独立软件包已经跑过。

只读核对既存 `.tmp/stage9-package-draft-check-2-verification.json`：passed、158 CLI calls、draft/0；旧 `.tmp/stage9-package-agent-draft-2/tools.jsonl` 为 38 MCP 请求（36 command、1 schema、1 security），一个 native 批准，close 丢响应后 request_result committed，有工资更正/办理/备份/run_jobs；未有 create_company、retry_job 或 MCP restore_company。旧 restore-check.json 为 draft/0 passed。上述均不能抵充当前正式包。

## 停止与保全边界

任一正式合同/源码 build/软件 inventory 不一致、旧输出已存在、seed 非 complete、host/stdio 错误、公司/月份错误、preview 失效、批准不匹配、资料缺项、失败/超时未查明、job 非 succeeded、恢复差异，均保留原日志/目录/请求和实际结果并停止依赖步骤。不要删目录重试、改标签/指纹、修改已冻结合同、以新 request_id 重写或换库。host stop 应正常等待清理；若 host 在其 try/finally 之前启动失败，当前 harness 未保证那段清理，需只定位该合成 catalog/credential 的残留，不能泛化 stop 当前服务或清 Windows credentials。

当前缺口是最终正式来源/包/AI 回放的新证据和明确的人机窗口边界，不是缺少包构建器或需要新增业务 API。本审查没有执行任何一项最终验收，也没有修改生产或他人文档。
