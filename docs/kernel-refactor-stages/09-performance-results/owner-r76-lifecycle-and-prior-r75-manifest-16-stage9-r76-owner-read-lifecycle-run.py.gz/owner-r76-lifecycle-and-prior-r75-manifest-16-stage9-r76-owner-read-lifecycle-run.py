import json
from pathlib import Path
import subprocess
import sys
ROOT=Path(__file__).resolve().parents[1]
path=ROOT/'.tmp/stage9-r76-owner-read-lifecycle-tests.log'
assert not path.exists()
args=[sys.executable,'-X','utf8','-m','pytest','-q',
      'tests/kernel/test_close_review_lifecycle.py',
      'tests/kernel/test_close_review_payroll_parse_reuse.py',
      'tests/kernel/test_v1_position_classification_selector.py']
with path.open('w',encoding='utf-8') as stream:
    result=subprocess.run(args,cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT,text=True)
out=ROOT/'.tmp/stage9-r76-owner-read-lifecycle-tests.json'
assert not out.exists()
out.write_text(json.dumps({'argv':args,'exit_code':result.returncode,'log':str(path.relative_to(ROOT)),
                           'scope':'synthetic lifecycle/current owner/v1 frozen semantic targeted only; no GC or timing'},indent=2),encoding='utf-8')
print(json.dumps({'exit_code':result.returncode,'log':str(path.relative_to(ROOT))}))
