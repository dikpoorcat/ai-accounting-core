"""One synthetic correction probe; preserve every stage, without real data."""

from __future__ import annotations

import json
import sys
import traceback
from pathlib import Path

REPOSITORY = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(REPOSITORY / "tests" / "kernel"), str(REPOSITORY / "src")]

from test_integrity_content import damage
from test_publication_periods import close, company, publish, save

from ai_accounting.kernel.integrity import verify_integrity
from ai_accounting.kernel.business_queries import BusinessQueries
from ai_accounting.kernel.dashboard import Dashboard
from ai_accounting.kernel.query_reads import QueryReads


OUTPUT = REPOSITORY / ".tmp" / "stage9-r71-reversal-pages-combination-probe.json"
COMPANY = REPOSITORY / ".tmp" / "stage9-r71-reversal-pages-combination-probe-company"
if OUTPUT.exists() or COMPANY.exists():
    raise RuntimeError("exclusive synthetic probe output already exists")
COMPANY.mkdir()
result = {"synthetic_root": str(COMPANY), "fixture": "test_publication_periods.company",
          "stages": [], "calls": []}


def serialized(value):
    if isinstance(value, bytes):
        return {"bytes_hex": value.hex()}
    raise TypeError(type(value).__name__)


def persist():
    OUTPUT.write_text(json.dumps(result, ensure_ascii=False, indent=2, default=serialized),
                      encoding="utf-8")


def snapshot(engine, label):
    with engine.store.connection(read_only=True) as connection:
        connection.execute("BEGIN")
        names = [row[0] for row in connection.execute(
            "SELECT name FROM sqlite_schema WHERE type='table' ORDER BY name"
        )]
        tables = {}
        for name in names:
            quoted = '"' + name.replace('"', '""') + '"'
            tables[name] = [dict(row) for row in connection.execute("SELECT * FROM " + quoted)]
        result["stages"].append({"label": label, "tables": tables,
                                 "foreign_keys": [tuple(row) for row in connection.execute(
                                     "PRAGMA foreign_key_check"
                                 )]})
    persist()


def call(label, operation):
    try:
        returned = operation()
    except Exception as failure:
        record = {"label": label, "returned_success": False,
                  "type": type(failure).__name__, "error": str(failure),
                  "code": getattr(failure, "code", None),
                  "details": getattr(failure, "details", None),
                  "traceback": traceback.format_exc()}
    else:
        record = {"label": label, "returned_success": True, "result": returned}
    result["calls"].append(record)
    print(json.dumps(record, ensure_ascii=False, default=serialized), flush=True)
    persist()
    return record


try:
    book = company.__wrapped__(COMPANY)
    engine = book[0]
    save(book, 100)
    publish(book, "initial")
    close(book, "2026-01")
    save(book, 120, 1)
    publish(book, "correction", "2026-03")
    snapshot(engine, "valid_closed_correction")

    def accounting():
        with QueryReads.snapshot(engine) as reads:
            return BusinessQueries(engine, reads=reads)._selected_accounting(
                reads.connection, None, "2026-03"
            )

    consumers = {
        "accounting": accounting,
        "funds": lambda: Dashboard(engine).funds("2026-03", preparation="deferred"),
        "quarterly_report": lambda: Dashboard(engine).quarterly_report(
            2026, 1, preparation="deferred"
        ),
        "brief": lambda: Dashboard(engine).brief("2026-03", preparation="deferred"),
    }
    for name, operation in consumers.items():
        baseline = call("valid_" + name, operation)
        if not baseline["returned_success"]:
            raise RuntimeError("healthy consumer rejected: " + name)
    with engine.store.connection(read_only=True) as connection:
        reverse = dict(connection.execute(
            "SELECT * FROM voucher_version WHERE reverses_id IS NOT NULL"
        ).fetchone())
    result["deleted_reverse"] = reverse
    persist()
    damage(engine, "voucher_current", "DELETE FROM voucher_current WHERE voucher_id=?",
           (reverse["voucher_id"],), foreign_keys=False)
    damage(engine, "voucher_line", "DELETE FROM voucher_line WHERE version_id=?",
           (reverse["id"],), foreign_keys=False)
    damage(engine, "voucher_version", "DELETE FROM voucher_version WHERE id=?",
           (reverse["id"],), foreign_keys=False)
    snapshot(engine, "reverse_pointer_version_and_direct_lines_removed")
    for name, operation in consumers.items():
        call("damaged_" + name, operation)
    snapshot(engine, "after_read_only_consumers")
except Exception as failure:
    result["fatal_error"] = {"type": type(failure).__name__, "error": str(failure),
                             "traceback": traceback.format_exc()}
    print(result["fatal_error"]["traceback"], flush=True)
    persist()
    raise
else:
    result["complete"] = True
    persist()
    print("probe complete: " + str(OUTPUT), flush=True)
