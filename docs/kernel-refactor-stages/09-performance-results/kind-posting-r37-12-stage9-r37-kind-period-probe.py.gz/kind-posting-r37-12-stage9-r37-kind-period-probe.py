"""One bounded read-only plan/VM probe for the r37 selected_kinds month SQL.

Capture parameters from a single real employees read per synthetic book, then
replay only the captured payroll basis and metric statements. No SQL rewrite.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp/stage9-build-source-r37-release"
OUTPUT = ROOT / ".tmp/stage9-r37-kind-period-probe.json"
sys.path[:0] = [str(SOURCE / "src")]
os.environ["STAGE9_WORKSPACE_ROOT"] = str(ROOT)


def row_bytes(row):
    return sum(
        len(value.encode("utf-8"))
        if isinstance(value, str)
        else len(value)
        if isinstance(value, (bytes, bytearray, memoryview))
        else 0
        if value is None
        else 8
        for value in row
    )


def steps_and_rows(connection, statement, parameters):
    steps = 0

    def progress():
        nonlocal steps
        steps += 1
        return 0

    connection.set_progress_handler(progress, 1)
    try:
        rows = connection.execute(statement, parameters).fetchall()
    finally:
        connection.set_progress_handler(None, 0)
    return {"vm_steps": steps, "returned_rows": len(rows),
            "returned_value_bytes": sum(map(row_bytes, rows))}


def main():
    assert Path(sys.prefix).resolve() == ROOT / ".tmp-kernel-venv"
    assert SOURCE.is_dir() and not OUTPUT.exists()
    from ai_accounting.kernel import runtime
    from ai_accounting.kernel.daemon import _prepare_static_runtime
    from ai_accounting.kernel.dashboard import Dashboard
    from ai_accounting.kernel.service import LocalService

    assert Path(runtime.__file__).resolve().is_relative_to(SOURCE)
    results = {"status": "diagnostic", "source": str(SOURCE),
               "source_revision": "r37", "samples": {}}
    for months, book, period in (
        (12, ".tmp/stage9-reseed-main-12-r36", "2016-12"),
        (48, ".tmp/stage9-reseed-main-48-r36.staging", "2019-12"),
    ):
        captured = []
        original_execute = runtime._PrivateConnection.execute

        def capture(self, statement, parameters=(), *args, **kwargs):
            if "scoped_vouchers AS (SELECT original.id FROM json_each(?) selected_kinds" in statement:
                if statement.startswith("SELECT DISTINCT basis_calculation_id"):
                    family = "basis_ids"
                elif statement.startswith("SELECT j.*,json_object('gross_fen'"):
                    family = "payroll_metrics"
                else:
                    family = None
                if family is not None:
                    captured.append((family, statement, tuple(parameters)))
            return original_execute(self, statement, parameters, *args, **kwargs)

        app = LocalService(
            ROOT / book, enable_read_pool=True, enable_parallel_brief=True,
            _static_runtime=_prepare_static_runtime(),
        )
        try:
            companies = app.catalog.companies()
            assert len(companies) == 1 and companies[0]["name"] == "阶段九合成规模企业"
            engine = app.engine(companies[0]["id"], dashboard_read=True)
            runtime._PrivateConnection.execute = capture
            try:
                Dashboard(engine).employees(period, limit=100, preparation="deferred")
            finally:
                runtime._PrivateConnection.execute = original_execute

            # Four normal employee calls: three basis choices, one payroll metric.
            assert len(captured) <= 5 and captured
            assert any(family == "basis_ids" for family, _, _ in captured)
            assert any(family == "payroll_metrics" for family, _, _ in captured)
            records = []
            with engine.store.connection(read_only=True) as connection:
                connection.execute("BEGIN")
                for family, statement, parameters in captured:
                    assert " AND v.period=?" in statement and "j.period=?" in statement
                    target_period = parameters[-1]
                    assert type(target_period) is int
                    # The outer metric query has one voucher_line account
                    # parameter before the selected_kinds CTE.
                    kind_parameter = statement[: statement.index("scoped_vouchers")].count("?")
                    kinds = json.loads(parameters[kind_parameter])
                    assert isinstance(kinds, list) and all(isinstance(k, str) for k in kinds)
                    plan = [list(row) for row in connection.execute(
                        "EXPLAIN QUERY PLAN " + statement, parameters
                    )]
                    work = steps_and_rows(connection, statement, parameters)
                    candidate_statement = (
                        "SELECT count(*) total,"
                        "sum(CASE WHEN original.period=? THEN 1 ELSE 0 END) target_posting_rows,"
                        "sum(CASE WHEN sc.period=? THEN 1 ELSE 0 END) source_period_rows,"
                        "sum(CASE WHEN sc.period<>original.period THEN 1 ELSE 0 END) "
                        "different_source_and_posting_periods "
                        "FROM json_each(?) selected_kinds "
                        "CROSS JOIN calculation sc INDEXED BY calculation_kind_period "
                        "ON sc.kind=selected_kinds.value "
                        "CROSS JOIN voucher_version original INDEXED BY voucher_calculation "
                        "ON original.calculation_id=sc.id"
                    )
                    candidate = connection.execute(
                        candidate_statement,
                        (target_period, target_period, parameters[kind_parameter]),
                    ).fetchone()
                    records.append({
                        "family": family,
                        "statement": statement,
                        "parameters": list(parameters),
                        "selected_kinds": kinds,
                        "target_posting_period_ordinal": target_period,
                        "explain_query_plan": plan,
                        "work": work,
                        "scoped_voucher_candidates": dict(zip(
                            ("all_type_rows", "target_posting_rows", "source_period_rows",
                             "different_source_and_posting_periods"), candidate,
                            strict=True,
                        )),
                    })
                connection.rollback()
            results["samples"][str(months)] = {
                "book": book, "employee_page_period": period,
                "captured_calls": len(captured), "queries": records,
            }
            print(months, "captured", len(captured), flush=True)
        finally:
            runtime._PrivateConnection.execute = original_execute
            app.close()
    OUTPUT.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
