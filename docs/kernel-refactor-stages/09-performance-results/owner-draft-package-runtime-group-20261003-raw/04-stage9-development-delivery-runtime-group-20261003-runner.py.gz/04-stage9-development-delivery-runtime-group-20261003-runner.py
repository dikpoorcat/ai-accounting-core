"""Bind the approved draft source before the real packager's first application import."""
import hashlib
import json
import os
from pathlib import Path
import runpy
import sys
import traceback

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / '.tmp/stage9-build-source-draft-runtime-query-group-20261003'
SHA = 'e0c8cd4d7c03db0743c8e2b3d15c3c0f668e4e0c690b3cb388942fc2b55e0871'
OUTPUT = ROOT / '.tmp/stage9-development-delivery-runtime-group-20261003'
RECEIPT = OUTPUT.with_name(OUTPUT.name + '-source-receipt.json')
REQUIRED_NEW = [OUTPUT, Path(str(OUTPUT)+'.zip'), Path(str(OUTPUT)+'-relocated'),
                Path(str(OUTPUT)+'-verification.json'), RECEIPT]
assert all(not path.exists() for path in REQUIRED_NEW), 'Preserve existing targets'
assert Path(sys.executable).resolve() == ROOT / '.tmp-kernel-venv/Scripts/python.exe'
assert not any(name.startswith('ai_accounting') for name in sys.modules)
os.environ.pop('FINANCE_DATA_ROOT', None)
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
sys.path[:0] = [str(SOURCE/'src'), str(SOURCE/'scripts')]
from prepare_stage9_main120 import require_manifest

require_manifest(SOURCE, expected=SHA)
manifest_path = SOURCE/'source-manifest.json'
manifest = json.loads(manifest_path.read_text('utf-8'))
manifest_sha = hashlib.sha256(manifest_path.read_bytes()).hexdigest()
assert manifest_sha == 'af0fb0e0ea624d992b76821098516cff930c5f5db22b008e798876e8254c8ef9'
front_path = ROOT/'.tmp/stage9-reference-group-frontend-summary-final.json'
front = json.loads(front_path.read_text('utf-8'))
assert front['status'] == 'passed' and front['stages']['release-build']['exit_code'] == 0
front_matches = {}
for prefix in ('frontend/src', 'src/ai_accounting/static/dashboard'):
    saved = {key[len(prefix)+1:]: value for key,value in manifest['files'].items()
             if key.startswith(prefix+'/')}
    assert saved == front['inventory_after'][prefix]['files'], prefix
    front_matches[prefix] = {'files': len(saved), 'same_as_actual_release_build': True}
assert all((SOURCE/'src/ai_accounting/static/dashboard'/name).is_file()
           for name in ('index.html', 'local.html'))
for name in ('vite.config.ts','package.json','package-lock.json'):
    assert (SOURCE/'frontend'/name).read_bytes() == (ROOT/'frontend'/name).read_bytes(), name
import ai_accounting
from ai_accounting.kernel.schema_bundle import production_bundle
from ai_accounting.kernel.build import calculator_build_id

assert Path(ai_accounting.__file__).resolve() == SOURCE/'src/ai_accounting/__init__.py'
bundle = production_bundle()
assert bundle.status == 'draft' and dict(bundle.current_versions) == {'company':0,'catalog':0}
assert set(bundle.company_verifiers) == {0}
report = {
    'status':'prepared', 'source':str(SOURCE),'source_sha256':SHA,
    'manifest_sha256':manifest_sha,'inventory_file_count':manifest['file_count'],
    'frontend_build_receipt':str(front_path),
    'frontend_build_receipt_sha256':hashlib.sha256(front_path.read_bytes()).hexdigest(),
    'frontend_matches':front_matches,'source_build_id':calculator_build_id(),
    'database_formats':{kind:bundle.database_format(kind) for kind in ('catalog','company')},
    'validation_skipped':False,'pure_timing':False,
}
try:
    script = SOURCE/'scripts/package_local_kernel.py'
    sys.argv = [str(script),'--output',str(OUTPUT)]
    runpy.run_path(str(script),run_name='__main__')
    report['status'] = 'packaged_and_self_checked'
except BaseException:
    report['status'] = 'failed_preserved'
    report['error'] = traceback.format_exc()
    raise
finally:
    require_manifest(SOURCE, expected=SHA)
    report['source_inventory_after_equal'] = True
    report['manifest_after_sha256'] = hashlib.sha256(manifest_path.read_bytes()).hexdigest()
    assert report['manifest_after_sha256'] == manifest_sha
    with RECEIPT.open('x',encoding='utf-8') as output:
        json.dump(report,output,ensure_ascii=False,indent=2)
        output.write('\n')
