<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, ref, shallowRef, watch } from "vue";
import { useRoute, useRouter } from "vue-router";
import { fetchDeferredBrief, type BriefQuery } from "../api/brief";
import { prefetchCloseReview, type CloseReviewPrefetch } from "../api/closeReview";
import { dashboardErrorMessage, isDashboardSnapshotChanged } from "../api/client";
import DashboardModuleHeader from "../components/DashboardModuleHeader.vue";
import DashboardPagination from "../components/DashboardPagination.vue";
import DashboardSectionNav from "../components/DashboardSectionNav.vue";
import BriefActivityWorkbench from "../components/brief/BriefActivityWorkbench.vue";
import BriefFinancialOverview from "../components/brief/BriefFinancialOverview.vue";
import BriefOpenItems from "../components/brief/BriefOpenItems.vue";
import CloseReviewPanel from "../components/CloseReviewPanel.vue";
import BusinessStatusDetails from "../components/BusinessStatusDetails.vue";
import { useDashboardSections } from "../composables/useDashboardSections";
import { useDashboardContext } from "../composables/useDashboardContext";
import { fen, formatFen } from "../utils/money";

const route = useRoute(), router = useRouter();
const { context, load: loadContext, refresh: refreshContext } = useDashboardContext();
const response = shallowRef<Awaited<ReturnType<typeof fetchDeferredBrief>> | null>(null);
const loading = ref(false), error = ref(""), updateNotice = ref("");
type BriefSection = NonNullable<BriefQuery["section"]>;
const sectionLoading = ref<Partial<Record<BriefSection, boolean>>>({});
const sectionErrors = ref<Partial<Record<BriefSection, string>>>({});
const pageControllers = new Map<BriefSection, AbortController>();
const closeReviewPrefetch = shallowRef<CloseReviewPrefetch | null>(null);
const closeReviewRefreshKey = ref(0);
const needsMonthlyReview = ref(false);
let controller: AbortController | null = null, initialized = false, mounted = true, requestGeneration = 0;
const selectedPeriod = computed(() => response.value?.selected_period?.key || "");
const data = computed(() => response.value?.data ?? null);
const activity = computed(() => data.value?.collections.activity?.items ?? []);
const openItems = computed(() => data.value?.collections.open_items?.items ?? []);
const periodOptions = computed(() => context.value?.periods || []);
const briefTitle = computed(() => {
  const month = /\d{4}-(\d{2})/.exec(selectedPeriod.value || queryPeriod() || "")?.[1];
  return month ? `${Number(month)} 月经营简报` : "经营简报";
});
const sectionLinks = computed(() => data.value ? [
  { id: "overview", label: "概览" }, { id: "activity", label: "已入账变化" },
  { id: "open-items", label: "待收待付" }, { id: "owner-tasks", label: "老板待办" },
  { id: "monthly-review", label: "月度核对" },
] : []);
const { activeSection, focusSection } = useDashboardSections(sectionLinks, "overview");
function queryPeriod() { return typeof route.query.period === "string" ? route.query.period : null; }
function selectionKey() { return JSON.stringify([route.query.company_id, route.query.period, route.query.voucher]); }
function isCurrent(generation: number, selection: string) { return mounted && requestGeneration === generation && selectionKey() === selection; }
function invalidateRequests() {
  requestGeneration += 1; controller?.abort(); controller = null;
  for (const request of pageControllers.values()) request.abort();
  pageControllers.clear(); sectionLoading.value = {}; sectionErrors.value = {};
  response.value = null; closeReviewPrefetch.value = null; loading.value = false;
  needsMonthlyReview.value = false;
}
async function loadData(period: string | null, contextGate?: Promise<void>) {
  const generation = ++requestGeneration, selection = selectionKey(), companyId = route.query.company_id;
  controller?.abort();
  for (const request of pageControllers.values()) request.abort();
  pageControllers.clear(); sectionLoading.value = {}; sectionErrors.value = {};
  const request = new AbortController(); controller = request;
  loading.value = true; response.value = null; closeReviewPrefetch.value = null; error.value = "";
  try {
    if (typeof companyId !== "string") throw new Error("请先选择公司。");
    const target = typeof route.query.voucher === "string" ? route.query.voucher : undefined;
    const options = target ? /^\d+$/.test(target) ? { voucher_number: Number(target) } : { voucher_version_id: target } : {};
    const mainRequest = fetchDeferredBrief(companyId, period, request.signal, undefined, options);
    if (period) closeReviewPrefetch.value = prefetchCloseReview(companyId, period, request.signal);
    const result = contextGate ? (await Promise.all([mainRequest, contextGate]))[0] : await mainRequest;
    if (!isCurrent(generation, selection) || controller !== request) return;
    response.value = result; closeReviewRefreshKey.value += 1;
    if (!result.data) { request.abort(); closeReviewPrefetch.value = null; }
    if (target) focusSection("activity");
  } catch (caught) {
    request.abort();
    if (!isCurrent(generation, selection) || (caught instanceof DOMException && caught.name === "AbortError")) return;
    closeReviewPrefetch.value = null; error.value = dashboardErrorMessage(caught);
  } finally { if (isCurrent(generation, selection) && controller === request) loading.value = false; }
}
async function loadMore(section: BriefSection) {
  const current = response.value, page = current?.data?.collections[section]?.page;
  if (!current?.data || !page?.has_more || !page.next_cursor || sectionLoading.value[section]) return;
  const generation = requestGeneration, selection = selectionKey(), request = new AbortController();
  pageControllers.set(section, request); sectionLoading.value[section] = true; sectionErrors.value[section] = "";
  const valid = () => isCurrent(generation, selection) && pageControllers.get(section) === request;
  try {
    const next = await fetchDeferredBrief(current.read_context.company_id, selectedPeriod.value, request.signal, current.snapshot_version, { section, cursor: page.next_cursor });
    if (!valid() || !next.data || !response.value?.data) return;
    const latest = response.value, before = latest.data!;
    if (section === "activity" && next.data.collections.activity) {
      const collection = next.data.collections.activity;
      response.value = { ...latest, data: { ...before, collections: { ...before.collections, activity: { ...collection, items: [...before.collections.activity?.items ?? [], ...collection.items] } } } };
    } else if (section === "open_items" && next.data.collections.open_items) {
      const collection = next.data.collections.open_items;
      response.value = { ...latest, data: { ...before, collections: { ...before.collections, open_items: { ...collection, items: [...before.collections.open_items?.items ?? [], ...collection.items] } } } };
    }
  } catch (caught) {
    if (!valid()) return;
    if (isDashboardSnapshotChanged(caught)) { updateNotice.value = "资料已更新，正在重新读取。"; await refresh(); }
    else sectionErrors.value[section] = dashboardErrorMessage(caught);
  } finally { if (valid()) { sectionLoading.value[section] = false; pageControllers.delete(section); } }
}
async function refresh() {
  invalidateRequests();
  const generation = requestGeneration, selection = selectionKey();
  try {
    const company = route.query.company_id, period = queryPeriod();
    if (typeof company === "string" && period && context.value?.current_company?.company_id === company && context.value.periods.some(item => item.key === period)) {
      const contextGate = refreshContext().then(fresh => {
        if (fresh.current_company?.company_id !== company || !fresh.periods.some(item => item.key === period)) throw new Error("当前公司或期间已变化，请重新选择。");
      });
      await loadData(period, contextGate);
    } else {
      await refreshContext();
      if (isCurrent(generation, selection)) await loadData(queryPeriod());
    }
  } catch (caught) { if (isCurrent(generation, selection)) error.value = dashboardErrorMessage(caught); }
}
async function initialize() {
  initialized = true;
  const generation = requestGeneration, selection = selectionKey();
  try {
    const loadedContext = await loadContext();
    if (!isCurrent(generation, selection)) return;
    const requested = queryPeriod(), target = requested || loadedContext.default_period;
    if (!requested && target) { await router.replace({ query: { ...route.query, period: target } }); return; }
    await loadData(target);
  } catch (caught) { if (isCurrent(generation, selection)) { error.value = dashboardErrorMessage(caught); loading.value = false; } }
}
function changePeriod(value: string) { void router.push({ query: { company_id: route.query.company_id, period: value }, hash: "" }); }
watch(() => [route.query.company_id, route.query.period, route.query.voucher], (value, previous) => {
  if (value.some((item, index) => item !== previous[index])) invalidateRequests();
}, { flush: "sync" });
watch(() => [context.value?.current_company?.company_id, route.query.period, route.query.voucher], (value, previous) => {
  if (initialized && value[0] && value.some((item, index) => item !== previous[index])) void loadData(queryPeriod());
});
onMounted(() => void initialize());
onBeforeUnmount(() => { mounted = false; invalidateRequests(); });
</script>

<template>
  <section class="brief-page">
    <DashboardModuleHeader :title="briefTitle" :options="periodOptions" :selected="selectedPeriod" :loading="loading" select-label="查看月份" @change="changePeriod" @refresh="refresh">
      <template #navigation><DashboardSectionNav v-if="data" :items="sectionLinks" :active="activeSection" label="经营简报区段" @select="focusSection" /></template>
    </DashboardModuleHeader>
    <div v-if="error" class="state-panel error" role="alert"><h2>经营简报加载失败</h2><p>{{ error }}</p><button type="button" @click="loadData(queryPeriod())">重新加载</button></div>
    <div v-else-if="loading && !data" class="state-panel" role="status">正在读取经营简报…</div>
    <div v-else-if="!data" class="state-panel"><h2>还没有可查看的月份</h2><p>录入公司业务后，即可按月份查看经营情况。</p></div>
    <template v-else>
      <p v-if="updateNotice" role="status">{{ updateNotice }}</p>
      <section id="overview" class="section-anchor" tabindex="-1" aria-label="经营概览">
        <div class="brief-hero">
        <p class="scope">{{ response?.selected_period?.label }}期末 · 全公司</p>
        <div class="hero"><span>本月账面盈亏</span><strong :class="{ loss: data.position.month_result_fen !== null && fen(data.position.month_result_fen) < 0n }">{{ formatFen(data.position.month_result_fen) }}</strong><p>收入 {{ formatFen(data.position.month_revenue_fen) }} · 费用 {{ formatFen(data.position.month_expense_fen) }}</p><p v-if="!data.position.complete">仅已确认部分 · AI 会计核对中</p></div>
        <div class="kpi-grid">
          <button class="kpi funds" type="button" @click="router.push({ name: 'funds', query: { company_id: route.query.company_id, period: selectedPeriod } })"><span>月末账面资金</span><strong>{{ formatFen(data.funds_overview.total_fen) }}</strong><small>银行、现金与支付平台</small></button>
          <button class="kpi receivable" type="button" @click="focusSection('open-items')"><span>月末待收</span><strong>{{ formatFen(data.open_items.receivable_fen) }}</strong><small>{{ data.open_items.receivable_count }} 项</small></button>
          <button class="kpi payable" type="button" @click="focusSection('open-items')"><span>月末待付</span><strong>{{ formatFen(data.open_items.payable_fen) }}</strong><small>{{ data.open_items.payable_count }} 项</small></button>
        </div>
        </div>
        <div v-if="data.management_commentary_details.current" class="note"><strong>经营说明</strong><p>{{ data.management_commentary_details.current.text }}</p></div>
        <details v-if="data.management_commentary_details.status === 'stale' && data.management_commentary_details.latest" class="note"><summary>之前的经营说明已过期</summary><p>{{ data.management_commentary_details.latest.text }}</p></details>
        <div v-for="note in data.management_commentary_details.supplements" :key="note.id" class="note"><strong>关账后的补充说明</strong><p>{{ note.text }}</p></div>
        <div v-if="data.risks.length" class="risks" aria-label="风险与核对进展">
          <h3>风险与核对进展</h3><article v-for="risk in data.risks" :key="risk.key"><strong>{{ risk.title }}</strong><p>{{ risk.impact }} · {{ risk.status === 'ai_reviewing' ? 'AI 会计核对中' : '需要关注' }}</p></article>
        </div>
        <BriefFinancialOverview :funds="data.funds_overview" />
      </section>
      <section id="activity" class="section-anchor" tabindex="-1">
        <BriefActivityWorkbench :groups="data.activity_groups" :items="activity" :activity-count="data.activity_count" :focused-activity="data.focused_activity" :period="selectedPeriod" :snapshot-version="response?.snapshot_version" @changed="refresh">
          <template #pagination><DashboardPagination compact item-label="项业务" :page="data.collections.activity?.page" :loaded="activity.length" :loading="sectionLoading.activity" :error="sectionErrors.activity" @retry="loadMore('activity')" @more="loadMore('activity')" /></template>
        </BriefActivityWorkbench>
      </section>
      <section id="open-items" class="section-anchor" tabindex="-1">
        <BriefOpenItems :open-items="data.open_items" :items="openItems" :period-label="response?.selected_period?.short_label || ''" :period-status="response?.selected_period?.status || ''" :period="selectedPeriod" :snapshot-version="response?.snapshot_version" @changed="refresh" />
        <DashboardPagination compact item-label="项往来" :page="data.collections.open_items?.page" :loaded="openItems.length" :loading="sectionLoading.open_items" :error="sectionErrors.open_items" @retry="loadMore('open_items')" @more="loadMore('open_items')" />
      </section>
      <section id="owner-tasks" class="section-anchor tasks" tabindex="-1" aria-labelledby="tasks-title">
        <h2 id="tasks-title">老板待办</h2>
        <article v-for="task in data.owner_tasks" :key="task.key">
          <strong>{{ task.title }} · {{ task.object }}</strong>
          <p>{{ task.period }}<template v-if="task.amount_status === 'known'"> · {{ formatFen(task.amount_fen) }}</template><template v-else-if="task.amount_status === 'unknown'"> · 金额待确认</template><template v-if="task.deadline"> · 截止 {{ task.deadline }}</template></p>
          <p>{{ task.impact }}</p><p class="next-step">{{ task.next_step }}</p>
          <BusinessStatusDetails v-if="task.subject_id" :subject-id="task.subject_id" :period="selectedPeriod" :snapshot-version="response?.snapshot_version" @changed="refresh" />
        </article>
        <article v-if="needsMonthlyReview">
          <strong>核对本月业务 · {{ selectedPeriod }}</strong>
          <p>查看本月经营金额和已入账业务，确认后告知 AI 会计。</p>
          <button type="button" @click="focusSection('monthly-review')">查看月度核对</button>
        </article>
        <p v-if="!data.owner_tasks.length && !needsMonthlyReview">目前没有明确需要您处理的事项。</p>
      </section>
      <section id="monthly-review" class="section-anchor" tabindex="-1">
        <CloseReviewPanel v-if="typeof route.query.company_id === 'string' && selectedPeriod" :company-id="route.query.company_id" :period="selectedPeriod" :refresh-key="closeReviewRefreshKey" :prefetch="closeReviewPrefetch" @owner-action="needsMonthlyReview = $event" />
      </section>
    </template>
  </section>
</template>

<style scoped>
.brief-page {
  --brief-page: var(--background);
  --brief-anchor-offset: 78px;
  --brief-surface: var(--surface);
  --brief-soft: var(--surface-soft);
  --brief-metric-surface: var(--brief-soft);
  --brief-text: var(--text);
  --brief-muted: var(--muted);
  --brief-line: var(--line);
  --brief-line-strong: var(--line-strong);
  --brief-green: var(--accent);
  --brief-green-soft: var(--accent-soft);
  --brief-blue: var(--info);
  --brief-blue-soft: var(--info-soft);
  --brief-gold: var(--gold);
  --brief-gold-soft: var(--gold-soft);
  --brief-amber: var(--warning);
  --brief-amber-soft: var(--warning-soft);
  --brief-red: var(--danger);
  --brief-red-soft: var(--danger-soft);
  --brief-panel-radius: var(--radius-panel);
  --brief-control-radius: var(--radius-control);
  --brief-shadow: none;
  --brief-overlay-shadow: var(--shadow-overlay);
  display: grid;
  gap: 32px;
  min-width: 0;
  width: min(calc(100% - 48px), 1320px);
  margin: 0 auto;
  padding: 26px 0 56px;
  color: var(--brief-text);
}

.section-anchor { min-width: 0; scroll-margin-top: var(--brief-anchor-offset); }
#overview { display: grid; gap: 20px; }
.scope { margin: 0; color: var(--brief-muted); font-size: 11px; }
.brief-hero {
  display: grid;
  gap: 24px;
  min-height: 198px;
  padding: 25px 28px;
  border: 1px solid color-mix(in srgb, var(--accent) 20%, var(--line));
  border-radius: 20px;
  background:
    radial-gradient(circle at 7% 12%, color-mix(in srgb, var(--accent) 11%, transparent), transparent 32%),
    linear-gradient(125deg, var(--surface), color-mix(in srgb, var(--accent-soft) 66%, var(--surface)));
}
.hero { display: grid; min-width: 0; gap: 8px; }
.hero > span { color: var(--brief-muted); font-size: 12px; font-weight: 750; }
.hero > strong { font-size: clamp(31px, 4vw, 42px); color: var(--brief-green); line-height: 1.15; letter-spacing: -0.04em; overflow-wrap: anywhere; }
.hero > strong.loss { color: var(--brief-red); }
.hero p { margin: 0; color: var(--brief-muted); font-size: 12px; line-height: 1.6; }
.kpi-grid { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 20px 28px; margin-top: 8px; }
.kpi {
  --kpi-accent: var(--brief-green);
  --kpi-accent-soft: var(--brief-green-soft);
  position: relative;
  display: grid;
  min-width: 0;
  grid-template-rows: auto auto 1fr;
  align-content: start;
  gap: 6px;
  padding: 0 0 0 18px;
  border: 0;
  border-left: 1px solid var(--brief-line);
  border-radius: var(--brief-control-radius);
  background: transparent;
  color: var(--brief-text);
  font: inherit;
  text-align: left;
  cursor: pointer;
  transition: background-color 160ms ease, border-color 160ms ease;
}
.kpi:first-child { border-left: 0; }
.kpi.receivable { --kpi-accent: var(--brief-blue); --kpi-accent-soft: var(--brief-blue-soft); }
.kpi.payable { --kpi-accent: var(--brief-amber); --kpi-accent-soft: var(--brief-amber-soft); }
.kpi::before { position: absolute; top: 2px; bottom: 2px; left: 0; width: 3px; border-radius: 999px; background: var(--kpi-accent); opacity: 0; transform: scaleY(0.4); transition: opacity 160ms ease, transform 160ms ease; content: ""; }
.kpi:hover, .kpi:focus-visible { border-color: color-mix(in srgb, var(--kpi-accent) 18%, transparent); background: color-mix(in srgb, var(--kpi-accent-soft) 70%, transparent); }
.kpi:hover::before, .kpi:focus-visible::before { opacity: 0.85; transform: scaleY(1); }
.kpi:focus-visible { outline: 2px solid var(--focus); outline-offset: 2px; }
.kpi > span { color: var(--brief-muted); font-size: 12px; font-weight: 750; }
.kpi > strong { margin: 4px 0; color: var(--kpi-accent); font-size: clamp(20px, 2vw, 26px); line-height: 1.15; letter-spacing: -0.025em; overflow-wrap: anywhere; }
.kpi > small { color: var(--brief-muted); font-size: 11px; line-height: 1.45; }
.note { padding: 20px 24px; border: 1px solid var(--brief-line); border-radius: var(--brief-panel-radius); background: var(--brief-surface); overflow-wrap: anywhere; }
.note > strong { color: var(--brief-muted); font-size: 11px; font-weight: 650; }
.note p { margin: 6px 0 0; font-size: 15px; line-height: 1.75; white-space: pre-line; }
.note summary { color: var(--brief-muted); font-size: 13px; cursor: pointer; }
.risks { padding: 14px 16px; border-radius: var(--brief-control-radius); background: color-mix(in srgb, var(--brief-amber-soft) 38%, var(--brief-surface)); }
.risks h3 { margin: 0 0 9px; font-size: 12px; font-weight: 650; }
.risks article { padding: 9px 0; }
.risks strong { color: var(--brief-amber); font-size: 12px; }
.risks p { margin: 4px 0 0; color: var(--brief-muted); font-size: 11px; line-height: 1.55; }
.tasks h2 { margin: 0 0 16px; font-size: 22px; letter-spacing: -0.03em; }
.tasks > article { display: grid; gap: 6px; margin: 10px 0; padding: 14px 16px; border: 1px solid var(--brief-line); border-radius: var(--brief-control-radius); background: color-mix(in srgb, var(--brief-amber-soft) 38%, var(--brief-surface)); }
.tasks strong { font-size: 12px; }
.tasks p { margin: 0; color: var(--brief-muted); font-size: 12px; line-height: 1.6; }
.tasks > p { padding: 16px; border: 1px dashed var(--brief-line); border-radius: var(--brief-control-radius); background: var(--brief-surface); }
.tasks .next-step { color: var(--brief-green); font-weight: 650; }
.tasks button, .state-panel button { justify-self: start; min-height: 40px; padding: 0 13px; border: 1px solid var(--brief-line); border-radius: var(--brief-control-radius); background: var(--brief-surface); color: var(--brief-green); font: inherit; font-size: 12px; font-weight: 750; cursor: pointer; }
.tasks button:hover { background: var(--brief-green-soft); }
article { min-width: 0; overflow-wrap: anywhere; }
.state-panel { padding: 28px; border: 1px solid var(--brief-line); border-radius: var(--brief-panel-radius); background: var(--brief-surface); }
.state-panel h2, .state-panel p { margin-top: 0; }
.state-panel.error { border-color: var(--brief-red); }
@media (max-width: 1199px) { .brief-page { --brief-anchor-offset: 124px; } }
@media (max-width: 760px) {
  .brief-page { width: min(calc(100% - 24px), 1320px); gap: 28px; padding: 16px 0 24px; }
  .brief-hero { padding: 20px; border-radius: 17px; }
  .kpi-grid { grid-template-columns: minmax(0, 1fr); gap: 0; }
  .kpi { padding: 13px 0 13px 14px; border-left: 0; }
  .kpi + .kpi { border-top: 1px solid var(--brief-line); }
  .note { padding: 16px; }
}
@media (max-width: 720px) { .brief-page { --brief-anchor-offset: 174px; } }
@media (prefers-reduced-motion: reduce) { .kpi, .kpi::before { transition: none; } }
</style>
