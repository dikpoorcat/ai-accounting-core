# r70 公共 HTTP 分阶段诊断

仅合成主12；不是浏览器、native、500 ms 或30轮验收。未修改 production、池配置、安全语义；没有 provision/reset、preview 构造或真实资料访问。源码固定 r70 SHA `402024802800938685bfb59983e6d717ae32fa55c555bad0a3ced3f3d8a8e404`，报告/三合同/源清单/公司及库身份/六元状态精确 guard，未知 owner 拒绝。

已用真实 LocalService、静态 runtime、原 read pool、loopback HTTP、urllib Bearer 公共 GET。六路各 warm3，六次 stages、六次 handler-thread cProfile、五对 context/main 并发、一次 unprepared close-review，共23 measured requests 全成功；自己 session 已 logout。执行前后业务 state/identity 相等。准备期可能与主48 instrument 重叠，实际 measured 期 root 已明确所有 heavy session 结束。

实际命令：

```powershell
& ./.tmp-kernel-venv/Scripts/python.exe -X utf8 .tmp/stage9-r70-http-stage-diagnostic.py 2>&1 | Tee-Object -FilePath .tmp/stage9-r70-http-stage-diagnostic.log
```

实际 exit 0，stdout 原件保留；仅 compile 的先前语法检查只有 tool 回执，不伪造单独 log。原件为同名前缀 `.py/.json/.log` 和六个 `-cprofile-{context,brief,funds,employees,assets,quarterly-report}.prof`。

| 路由 | 响应 bytes | Handler ms | authorize | auth connect | auth commit | Catalog.bind | pool enter | validate+dump | reply |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| context | 2965 | 32.85 | 9.37 | 6.41 | 2.07 | 0.00 | 11.82 | 0.11 | 0.30 |
| brief | 21538 | 347.15 | 9.52 | 7.21 | 1.78 | 10.94 | 9.69 | 0.50 | 0.13 |
| funds | 20734 | 243.15 | 9.19 | 6.44 | 2.02 | 10.06 | 10.93 | 0.73 | 0.45 |
| employees | 19625 | 146.28 | 9.51 | 7.14 | 1.82 | 11.44 | 14.62 | 0.61 | 0.36 |
| assets | 15742 | 143.79 | 7.95 | 5.82 | 1.66 | 11.39 | 10.93 | 0.59 | 0.26 |
| quarterly-report | 15984 | 326.78 | 8.23 | 5.97 | 1.76 | 10.01 | 11.64 | 0.58 | 0.52 |

嵌套阶段不可相加：auth connect/commit 包含于 authorize；Catalog.bind、pool enter 包含于 service _dispatch。目录/授权共约18–21 ms 是公共入口成本，pool enter 本身也是 direct Dashboard 的必要开销，不全算 HTTP 新增。结构 response 校验、dump 和 reply 很小。没有证据将主48额外百毫秒全归到公共层。客户端 receive 与 Handler 不在同一个边界，urllib 单样本差值也不能直接当 TCP 延迟。

保存的 context cProfile（有 profiler 开销）显示：runtime.connect 4 calls /19.20 ms 是两次真实打开及递归；Security alias caller7.99 ms，Catalog.connection11.21 ms。reused company connection validation9.98 ms。14次 Windows assert_private_path7.45 ms，主要 _safe_path6.02 ms；ACL _assert_private_handle14次0.98 ms。Path.stat337次9.59 ms，reject_reparse_path20次5.95 ms。不是已证明 ctypes/ACL 本体慢。

verify_schema4次6.62 ms 的 caller 分解：Store.validate_connection1次5.74 ms；Security catalog_validator2次合计0.52 ms；Catalog.connection1次0.36 ms。因此不能将全部 schema 时间归到 authorize，也不能把 auth BEGIN IMMEDIATE 前后校验直接合并：两者分别保护首次打开及事务内身份。pool 前后 _signature 保护文件替换，不能因相似删掉。

对应调用：service.dispatch（command validate→authorize→_dispatch→response validate/dump）；service.engine→Catalog.bind→Catalog.connection→runtime.connect；context→独立 Catalog.connection→_bound_store→Dashboard.context；SecurityService._transaction（connect validator→authorization_gate→BEGIN IMMEDIATE→再次 catalog identity/schema→session check/update→commit）；ResidentReadPool.borrow→前 signature→validate_reused_read_connection→后 signature。当前样本仍主要花在 Dashboard 业务内核。

并发五对实用两条物理公司连接；page_count144108、cache_size-262144 保持原配置。顺序 warm3 全在 connection_1；首次 brief 对中新建 connection_2，无其独立 warm3，不能把该对主请求483.16 ms当纯并发收益/损失。其余样本 auth12.59–18.03 ms（首对context30.47），pool enter20.48–28.41 ms（首对17.62–33.78）；这里 enter 含路径/schema/open检查，未独立计 _take 等待，不能声称池容量饥饿。Windows thread_time 数据15.625 ms量化，短阶段0 CPU不证明等待，CPU偶尔大于wall也不能当计算异常。

辅助 close-review 确认 unprepared、owner review None：264 bytes、Handler34.72 ms；不能外推已 prepared 浏览器 close-review 成本。

保留传输负面控制：另已有176样本 NODELAY0/1四大小 off/on/on/off，bytes一致、fetch median2.7–3.8 ms/max6.5、Handler.reply<0.56 ms。没有40–100 ms Nagle收益；不采用 NODELAY 改法、不用20 ms帧阶梯归因网络。实际浏览器两帧正常约30–45 ms，Playwright断言/RPC在计时后。本脚本没有测浏览器 Ajv/Vue。

后续窄候选仅供复核：Windows `_safe_path` 对同一个 ancestor 调 exists 后 lstat，现有 permissions._reject_links 已单次 lstat；可评估单次 stat 等价写法，严格保留 reparse/ACL/owner、缺失与权限错误、文件竞态处理。没有证明可以共享不同事务/borrow前后的检查，也没有实现或计量该候选净收益。若授权，应先针对缺失 ancestor、权限异常、reparse、文件替换、sidecar安全、失败连接 discard 做一组窄回归，再同源公共阶段复测；不跳过授权/结构验证、不引入业务缓存。

当前结论止于主12真实阶段与已有主48浏览器证据；不宣称排除所有公共/汇总问题，不扩展新测试或性能任务。
