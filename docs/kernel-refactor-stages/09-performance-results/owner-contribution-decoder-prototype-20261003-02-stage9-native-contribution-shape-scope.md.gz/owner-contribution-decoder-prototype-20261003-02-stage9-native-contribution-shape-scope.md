# Contribution shape prototype — prepared, not executed

Exclusive helper: `.tmp/stage9-native-contribution-shape.py`. It is independent of production and fixed source. No test/import/probe/build/database/browser execution has been done during preparation.

Pinned source is `stage9-build-source-owner-month-reads-20261003-release`, SHA `1c37c576cb0026b0b39c199b74672a60890c43a7d9e2b944416179fe2bf398e9`, manifest file SHA `845318d7e9857cbae422033a7e8b87a5fb7edd2896f1c5f0617709eabca1c979`. Runtime must bind main12's complete matching `stage9-owner-main12-month-reads-qualified.json`, original builder checkpoint, actual state/identity/schema and exact module/inventory bytes. It refuses source/receipt/state drift, wrong root, missing/mismatched current-month contribution bodies or immutable anchors, and existing output/log. No new qualification or business proof is attempted.

SQL selects existing terminal, nonwithdrawn publication contributions with exact `posting_period` equal to the qualified report period; it does not read all historical content. The actual selection and bytes are reported. These candidates are not claimed to be the exact full report source ID set. Their normal raw bodies are compared against untouched `_decode` as oracle; only local decode loops are timed after DB closure. Original rounds all finish before native rounds. Rows/anchor/body checks, result fingerprints, synthetic vectors and JSON writes are excluded from local timing; there is no page/500 ms acceptance claim.

The native prototype keeps required/exact top-level and resolution keys, strict strings/ints/bools, digest length 64 without hex restrictions, empty IDs, unbounded/negative integer values, arbitrary row-field dictionaries and resolution list contents. Fixed heterogenous tuple schemas are converted back to lists. Publication identity and sorted/unique parents retain the original post-check. Native validation errors run the original decoder, preserving original last-wins duplicate-member acceptance and KernelError semantics. No immutable anchor proof is replaced by a structural assertion.

Every actual candidate records complete typed-container fingerprint equality, acceptance/error code/message/details, raw hash, fallback count and a separate dictionary-order comparison. Dict/list/tuple and bool/int/float/null distinctions are retained. Synthetic vectors cover duplicate members in both orders, bool/float/null/huge ints, empty strings, nonhex/Unicode/invalid-length digests, arbitrary resolution/row JSON including NaN/infinity, parent sorting/duplicates, malformed arrays, missing identity, unknown keys and malformed JSON. Mutations exist only in process memory; they are decoder vectors, not accepted financial content.

Residual risks requiring the planned comparison: tuple-to-list Python callbacks may offset native traversal savings; native parser behavior for duplicated members or permissive JSON may trigger fallback; dict insertion order can differ for noncanonical input and is reported separately. No schema/body/DB format changes are proposed. Existing normal dispatch profile shows approximately 34 ms total `_decode` cost for 1,004 contributions; the separate native 123 ms profile is not a stable savings budget. The original/native round order can have allocator/GC effects, so local numbers remain diagnostic.

Root-controlled command, only after pure browser timing and other CPU work stop:

```powershell
$shapeReceiptSha = (Get-FileHash -LiteralPath '.tmp/stage9-owner-main12-month-reads-qualified.json' -Algorithm SHA256).Hash.ToLowerInvariant()
.tmp-kernel-venv/Scripts/python.exe -B .tmp/stage9-native-contribution-shape.py --report-sha256 $shapeReceiptSha --rounds 5 --output .tmp/stage9-native-contribution-shape-main12-1c37.json
```

The must-new matching `.log` is created alongside the JSON, and completed cases/rounds are preserved on later failure. Any container/acceptance mismatch stops further timing. Failure does not fall back to another source/root or repair a body. Production, released source snapshot, existing tests, schemas, identity, services, catalog and business data remain untouched. No script syntax/runtime verification has been executed yet; this is preparation for root scheduling.
