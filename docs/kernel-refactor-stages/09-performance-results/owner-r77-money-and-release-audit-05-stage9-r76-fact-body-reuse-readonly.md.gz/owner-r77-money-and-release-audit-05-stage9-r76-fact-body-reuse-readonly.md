# r75/r76 同快照事实正文核验只读排查

结论：目前没有按事实完整绑定缓存的成功正文证明。raw fact 缓存已经避免一部分重复物理正文读取，但没有去重 child order、物理行/period 检查和 SHA256；不能把其命中等同为已验证。存在真实可达的重复工作路径，现有聚合 profile 不保存 fact ID/参数/快照 token，因此实际相同事实重复交集和收益尚未验证。未运行测试、服务、建库、GC 或计时；未改生产/测试源码。

## 代码路径与触发条件

- query_reads.py:1623–1701 verify_selected_content：先按 calculation ID 排除已成功结果；同 ID 重入完全去重。缺失结果 header 查询仍核 subject/kind/period 与事实身份、fact/calculation seal。一次 batch 内 _verify_selected_fact_bodies 将 fact ID 按 kind 去重。不同 calculation ID 指向同 fact ID 时，跨 batch 无事实成功证明，继续重做正文子步骤。
- query_reads.py:1703–1763：先 verify_fact_child_order，再逐 kind 查真实 typed 行/period，之后才试 raw byte hash，再 scalar SQL hash，再 exact decoded fallback。raw bytes 命中不会省略前两个步骤。
- storage.py:48–58 _snapshot_fact_hashes 每次 hashlib.sha256(raw[ident])，没有 hash memo。_snapshot_fact_raws 每次 from_json 原始缓存字节。Store.facts 成功后一次性写入 _raw_fact_data（storage.py:443–531）；fact_data_many/_fact_data_many_from_headers 和 _scalar_fact_hashes 不往该缓存新增原始字节或成功标记，因此 scalar hash-only 或 decoder-only 首次核验后仍可能再读同正文。Store.fact_data_many 本身也不读取 raw memo。
- query_reads.py:1866–1966 _verify_anchored_source_bytes：同 anchor calculation ID+绑定已成功时完全去重；普通 selected 内容成功→anchor 省正文但保留绑定/header检查。反向 anchor 成功→selected 不互认，后者再次正文核验并解码所需 outcome；这是保证结果对象并不自动可用的必要区别，但 fact body 再校验可另行考虑复用。
- report_open_contribution.py:495、574：own binding 与完整 contribution 两条实际调用都使用仅本 reads/connection/活动只读 snapshot 可铸造的私有 proof；未命中 contribution 回退仍需正式完整源。anchor正文证明不代表 publication/current head/依赖完整性/冻结采用。

## 已有 r75 单次仪表化工作量（非验收、不能相加推唯一事实数）

| 页面 | selected API / body helper / anchor | 物理period SQL次数/返回行 | scalar JSON SQL次数/返回行 | child-order SQL次数/VM steps |
|---|---:|---:|---:|---:|
| brief | 6 / 3 / 1 | 16/1009 | 17/1021 | 6/53900 |
| funds | 7 / 2 / 0 | 7/507 | 10/530 | 3/53700 |
| employees | 1 / 1 / 0 | 1/50 | 1/50 | 0/0 |
| assets | 2 / 1 / 0 | 1/48 | 3/88 | 2/400 |
| reports | 1 / 3 / 2 | 13/1006 | 10/997 | 9/48800 |

scalar JSON SQL 可由 Store.facts 的必要 typed presentation 和正文核验共同执行；聚合语句相同不能分配全部行到 helper。child-order成功返回零坏行，零返回不等于零扫描。比如 brief fact_expense scalar SQL 3次419行、物理period 2次404行，并不证明404行重复：两个 batch 可能不重叠；reports fact_payment period/scalar各2次495行也不能认定重复495。完整语句/字节/VM steps保留在同名前缀JSON。raw_fact_json_decodes五页均0；这一计数不能证明无scalar hashing重复。

## 全局消费者与复用边界

- 五页/Brief业务状态/资金/资产/报表共用 QueryReads.verify_selected_content；dashboard.py:3382、3919、4156、4291，dashboard_funds.py:302，dashboard_reads.py:1311，query_reads.py:1618、1777，close_review.py:477 均在此范围。Close preview中不同阶段构造的独立 snapshot 必须重新核验，禁止跨阶段只因 ID 相同复用。CLI/MCP/HTTP传输不会扩大只读证明寿命。
- verify_fact_versions（query_reads.py:1062）走 verify_sources→_check_sources→_check_facts，核正文、child order之外还核来源图/封签/证据，并构造 typed fact。其成功只预填 _fact_versions；不发布 fact-body memo，且原始fact_data_many decoder不写raw bytes memo。同快照随后selected可能再读同事实，这不是typed结果可直接当原文的依据。
- fullverify：integrity.py:148 _check_facts 复用匹配 engine.store/connection 的 raw bytes，但仍 child-order/period/digest；_check_sources先联合dependency fact和extra_fact，batch内去重。Maintenance.verify_integrity只有BEGIN，未绑定 QueryReads raw缓存；全库历史验证含证据/graph/完整性，不能拿selected事实正文证明顶替。完整核验已有 verified_source_lease / verified_calculation_source 在后续projection/semantics阶段传递独立已核来源（integrity.py:1219、1350–1383），不能当作全库从未有任何复用。
- repair：maintenance.py:46、100分别修前与修后完整核验，中间实际写入derived targets，属于必要不同状态验证；禁止把只读snapshot memo跨该写入复用。
- backup：backup.py:149 _verify_connection 按保存版本选bundle.company_verifier；schema_bundle.py:157–171新registry Store/Engine独立完整核验。源与复制后数据库、ZIP解析/恢复以及历史版本不是同一只读snapshot；必须独立验证真实文件。
- fixed v1：Store.fact_data_many/facts明确转content_v1.load_v1_*；_scalar_fact_hashes对content_version1直接返回空；integrity.verify_fact_child_order对_v1_fields保留原始逐item_no解释。QueryReads helper仍有完整fallback，但本次建议不改历史codec/合同、不过渡current证明到v1。固定v1/frozen position与current临时视图不可混用。

## 可考虑的窄修法（未实现/未验证）

仅在 QueryReads.snapshot 持有、连接只读事务且current registry 的scope内，新增 fact ID → 完整body绑定签名的成功证明；绑定至少含实际 fact kind、fact period、fact digest（并保留由caller重新核 subject身份和seals；可用完整header签名防不同绑定冲突）。命中仅跳过该事实已证明的child-order/physical period/bodyhash/严格fallback，不跳过新的 calculation outcome hash/解码、header身份/封签、依赖、current publication和冻结采用。
应在相关调用全部事实及结果/绑定核验成功后原子发布本批新增证明；失败不发布本批部分成功。先检查同fact conflicting kind/period/digest不能被dict覆盖静默吞掉。无需外部success flag、全局cache或跨请求cache；query_reads.py:836–859 authorizer禁止事务切换，finally _reset自然清除。unowned/current非受控事务/fixedv1独立执行原路径。
若扩展verify_fact_versions/_check_facts，只能内部精确共享正文子证明，仍要读取真实证据并保留来源完整核验，不让传入dict/typed model或业务成功状态铸造证明；这一扩展比两条selected/anchor读路径风险更高，建议先不扩大。raw SHA memo可另作为算力优化，但不能代替物理child/period验证；它解决的问题小于成功正文proof。

## 证据限制与来源一致性

r75 profile记录明确为main48、此前r73 verified根、未运行该source全核验；不能说是r76全核验profile。r76 HTTP diagnostic只提供请求分段，未录fact workload，不能把r75读取量认作r76 browser每次读取量。三个关键文件working/r75/r76字节SHA完全一致，所以静态正文核验路径对照成立；不推出不同数据库/请求选择相同。
未验证实际相同fact ID跨batch交集、哪个caller带来多少重复、非canonical/composite/corruption失败对照、fixedv1/current语义定向、及真实性能收益。本任务没有权限新增这些运行。

query_reads.py: 305924fa53da1b7696433efa8c2654bbe50baf69114ad87e390c9c0e8b0727ac（working/r75/r76相同）
storage.py: eb2d0f71c4805d11d0be48a1230e6deda7377fd86dd305a59242b49d984f245e（working/r75/r76相同）
integrity.py: d3d965b1e81f78dc0cf437fdd72118a08a5dba18e11ff8b207bdcd7370dd3763（working/r75/r76相同）

现有 profile SHA256: 04757ee4ce509b0fc25c56ae9e01b3197085167acb4a056f49270eea8524e2e6

精确产物：.tmp/stage9-r76-fact-body-reuse-readonly.md、.tmp/stage9-r76-fact-body-reuse-readonly.json。
