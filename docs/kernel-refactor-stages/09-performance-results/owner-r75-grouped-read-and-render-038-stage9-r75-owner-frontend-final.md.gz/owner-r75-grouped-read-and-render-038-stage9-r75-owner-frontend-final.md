# r75 前端收敛验收

修复后统一执行一次全前端测试和一次正式 build:release：153/153通过，contracts:check、vue-tsc、vite --mode release通过。Node24.19.0，Python仓库venv；未用开发mode。日志、命令及before/after源码hash均独立保存为stage9-r75-owner-frontend-postfix-*。验收期间捕获的五View、测试及生成合同hash无变化。

首次150项有2失败（148通过），原stdout与修复前构建均保留，不回写、不和153加总。一次40项恢复定向检查也全部属于153，早期28项同样全部属于153；原三文件现为22+5+4=31项。

修复保持手动同选择刷新隐藏旧组件。明确dashboard_snapshot_changed、Employees/Assets continuation显式响应版本变化、BusinessStatusDetails向父级发出的changed全部走refreshChanged：先清主投影/旧版本/旧分页，持续loading，然后并行读取context及主结果，二者均通过后才能显示。Brief转发组件activity/open_items也接通失效刷新；Reports没有分页/业务详情恢复入口，手动刷新路径不变。共享详情仍同步清其旧结果并只在本身公司/业务/月份/快照generation有效时emit；未改共享组件/API。

三项新恢复测试按实际入口覆盖13条读取/续页路径（Brief2、Funds5、Employees4、Assets2）：失效立即清空，context先完成仍不提交主金额或宣告成功；旧A-B-A失败不得再发恢复请求；四父changed及两显式version mismatch清空。既有公司/月份晚到main成功、catch/finally隔离、Funds旧恢复通知及详情来源隔离覆盖继续通过。资金手动刷新旧null断言改为保持原对象+loading、新bank-b不可提前提交，未删门控断言。

正式构建生成静态dashboard输出；最终输出hash列于stage9-r75-owner-frontend-final.json。r74 DOM最终及失败/early回执列表已在stage9-r75-owner-frontend-receipts.json记录，r74 final实际使用此次恢复修复之前的Vue源，不能当作后修复browser验收。后修复仅统一前端检查，没有HTTP/preview/真实数据/性能测试；主任务将统一固定新candidate及严格browser验收。

本次仅改Brief/Funds/Employees/Assets恢复区分及相关现有context/funds/details测试；此前Reports的隐藏挂载改动保留。没有修改代理/vite配置/AGENTS，没有提交，没有复制海量archives。所有执行进程已经退出。
