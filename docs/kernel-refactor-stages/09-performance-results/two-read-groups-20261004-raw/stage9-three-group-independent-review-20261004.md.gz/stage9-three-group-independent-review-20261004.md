# 第 9 阶段三组收敛代码独立复核

本轮为只读代码复核。未运行测试、性能脚本或数据库命令，未打开业务库，未修改生产代码、测试、服务、合同或固定 v1 文件。对照固定 S 与审查时 workspace 的三组变更，并沿公共调用检查信任边界。**静态复核未发现可证明的新业务正确性缺陷；随后收到的真实整页工作证据证明 physical carrier 没有消费且增加成本，因此该生产候选应撤回。** 正确性没有发现缺陷不构成性能接受；本报告保存撤回前原件的审查，不宣称最终 workspace 仍保留 carrier。

## 固定来源与复核版本

S 的 source SHA 为 `24b9b8b65723cee8c6982b1f41235dce380e62788db33f100176f92c714571fc`，固定目录为 `.tmp/stage9-build-source-open-scope-group-candidate-20261004`；其 `source-manifest.json` SHA256 为 `9D81E82D7E2637637CC052CD42FF80946C6A0274264473D53F1D22A6F48FCEF5`。本次按文件比较该目录与 workspace，没有以不断变化的 Git HEAD 代替 S。

六个生产文件在本次初读与收尾之间 SHA256 一致；随后核对，它们也与实际工作诊断的固定目录 `.tmp/stage9-build-source-three-read-groups-20261004` 完全一致。该诊断 source SHA 为 `c4fd1cb6a845626204805901f5fe59c4f5ef5db654b16f9ba1155b799788a93a`，759 files，manifest SHA 为 `1bdaea758db6b3f1737a3fc6056bd9c810a79f76c474fa686ae7fcc42774a2de`。以下 hash 和行号描述撤回前候选：

| 文件 | Workspace SHA256 |
| --- | --- |
| `src/ai_accounting/kernel/query_reads.py` | `D513D038EDEF64AE1DF08A49D9B6E4C2CE63A45D864375EEBFE941595CBA6C2D` |
| `src/ai_accounting/kernel/dashboard_reads.py` | `42D3931872423AB3BC4BF2BE4F66A8F227A671E7C443AC2108F6404250445478` |
| `src/ai_accounting/kernel/report_projection.py` | `BB849F063CF2819EBB01BB69C61DD01E3EB888A1DABE26DF9AE8FC34870FA2BD` |
| `src/ai_accounting/kernel/dashboard.py` | `8B6B701AD0541E4D600EC7323B23B03F7A170E2C7C6F300726FC99DEC697B7B9` |
| `src/ai_accounting/kernel/dashboard_funds.py` | `A88FF41677D15E67A97501251C5D4FDA5068C3CD3A4509C858A8C9D92CB9A046` |
| `src/ai_accounting/kernel/settlement_freeze.py` | `FE17DDBE8D24D883EB20F91982789D6B287851C9023246084DD8BBF2F082BE0E` |

与 S 比较的 33 个 `*_v1.py` / `content_v1.py` 文件均保持字节一致。其中 `settlement_freeze_v1.py` SHA256 为 `C0DD997E648E43D91575764F2830575E578E3AF3FB340E2AE469F895D70B573C`。固定历史 reader 仍由 `content_history_context` 分派，`position_v1` 仍显式引用固定 `settlement_freeze_v1`。

## 一、settlement dense groups

`settlement_freeze.py:56–175` 的内部表示改为五项 key tuple + 十五项 value list。`_FIELDS` 顺序仍为原十项 counts、五项 sums；局部命名索引由该固定顺序产生。`_group_delta` 的十五个表达式与旧表达式逐项同序，`_add_group` 仍逐项 `checked(old + delta)`，没有把逐步 int64 检查改为一次净额检查。零 obligation group 仍须其余项全零才能删除。

`_groups_from_root` 精确要求每行长度为 20，短行与长行均抛出 `ValueError`；`row[5:]` 是独立 copy，不把 root JSON 中的列表作为可变工作区。`_groups_for_root` 仍按 `canonical(key)` 排序，序列化成相同 `[five keys, fifteen values]`。磁盘 root、block、revision 格式、digest、DDL 和合同没有改变。

已查全模块的 `scope.groups`、`_groups_from_root`、`_groups_for_root`、`_add_group` 调用：

- writer `_build_prepared` 的前态扣除、后态加入及完整 root 输出继续使用所有实际输入；未减少 contribution、source event、unknown 或 movement 输入。
- `_scope:953` 的 closed base、current/historical open tail、增量 tail 读取、完整 tail 认证、逐 key 旧状态扣除及新状态加入未改变。只有完整尾部证明两 scope 相同后才共享 counterpart groups。新工作区来自独立 root copy，已发布共享 scope 在 reader 汇总中只读。
- `frozen_followup_summary:1147` 仍逐 group、逐 `_FIELDS` 汇总，返回命名业务结果；payroll cohort/period guards、employee summary、owner followup 和 position 的相应引用均改为正确索引。`unknown_count`、`unresolved_movement_count`、`bad_paid_count`、`bad_other_count` 仍分别决定原有阻断或 unknown 语义。
- subject scope/subject summary、directory lookup、冻结 page proof、selected leaf/state source proof没有借全局 group 汇总代替各自的认证；外部生产模块没有直接按旧名称读取 `FrozenScope.groups` 的遗留消费者。

此前实施阶段的最小定向测试批次为 35 passed；包含旧数学 oracle 与新 prepared root canonical/digest 对照、长度拒绝、真实 summary/unknown/cohort、tail/counterpart、完整 compare/repair 与删除贡献检测。该结果只适用于当时 dense 收敛版本。本轮没有重跑，也不能据此宣称最新三组整体通过。

表示工作量证据是相同 4096 groups、相同十五值和 canonical 的实际容器对照：旧容器 2,048,088 bytes，新容器 868,440 bytes，减少 1,179,648 bytes；没有减少业务行数。此前 single cold profile 的 `_groups_from_root` self 0.1047 s 不是可承诺的节时量，本轮不作时间推断。

## 二、brief / funds 重复读取

`dashboard.py:293` 从同一 snapshot 的一次 `monthly_account` gross 查询保存 `(account, debit, credit)` tuple，原月 net projection 由该 tuple 形成。`_brief_amounts:2576` 仍使用 debit/credit 原值分别比较完整 `Journal.account_amounts`，保留 `if debit or credit` 筛选；未用 net 相等代替 gross 相等。`Snapshot.release:323` 清理 snapshot 字段，未产生跨请求 gross cache。

`dashboard_funds.py:374–497` 的 `events` 先询问 `_verified_current_event_rows`。该 helper 只接受 current、未限定 subjects、未关闭的当前月；还要求活动 QueryReads、活动事务、同连接、相同 queries owner、当前 context、当前 close/publication reader、非固定 content v1。`verified_rows()` 必须已存在，随后按已经认证的实际 `voucher_line` 账户匹配，选出精确 voucher IDs。没有用科目目录、page rows 或余额推断 voucher 集合。

成功分支复用未过滤 `journal.sql()`，追加精确 IDs 的 `IN json_each(?)`；空账户或空匹配仍形成空集合。`Journal.sql:1033` 返回参数的新 list，追加参数不污染共享 SQL cache。相同 `(current, accounts, subjects)` event query key 没有改变。

该 SQL 仍由后续实际 SQL consumer 消费。来源、`_verify_event_sources`、`verify_sql_outcomes`、冲正 original、close references 核验保持原路径；成功 `_money_event_rows` 只在所有 event proofs 后保存。current=False、任意显式 subject selector、closed month、unowned snapshot 和 v1/history 均保留原 filtered selector。并未将 investment 的历史/当前范围混为一体，也未把已认证凭证头变成任意资金余额证明。

这组消除的是已有成功 whole-month proof 后再次触发账户 locator 的工作，以及 brief 重复同月 gross query。代码不保证所有 reader 均命中成功分支；本轮没有计量它们对 500 ms 阈值的影响。

## 三、physical header carrier

### 集合双向完整性

`query_reads.py:449` 的 open terminal publication 驱动保留原 scope 限制、当前 calculation 与 fact 的 subject/kind/source period 精确绑定，以及 withdrawn 的独立 record/null-head 检查。未过滤完整 scope 才允许 owned carrier；显式 subject scope 不铸造 whole-month receipt。

同函数仍先执行原独立 opposite physical current-voucher probe，防止失去 publication/current calculation 的当前凭证从驱动中消失。完整 `_verify_publication_voucher_head_batch` 通过后才按实际 `posting_period` 铸造 carrier。新增 header 字段来自同一实际 scope SQL 的 joins；没有从 result body 或模式名称推断头。

`_OpenMonthVoucherHeaders.selected:123` 还独立扫描整个实际 current month，拒绝 `voucher_current.h.voucher_id IS NOT voucher_version.voucher_id` 或 carrier IDs 之外的任何当前 version。该扫描没有账户或 subject filter，因此覆盖同 subject 的额外旧 current 以及错误 h.voucher_id。consumer 的完整 current ID equality 检查也继续保留。单向正常头 proof 没有被误称为整月集合 proof。

### owner、basis 与失败回退

carrier 的 `calculation_id` / `voucher_calculation_id` 来自实际 `v.calculation_id`，即原凭证 owner；`basis_calculation_id`、basis subject/kind/fact、source period 与 result digest 来自终端 current calculation。`review_no_impact` 的原 owner 与当前采用 basis 没有混淆。该模式不使用 normal-head shortcut，仍独立核对 current physical relation、review chain 与原非 review publication。

`report_projection.py:180` 先取得经过核验的关系 map，再以 `basis_calculation_id` 选择 publication；`_open_source_rows_from_headers:124` 保留原 seventeen-field 行语义及全部实际 voucher lines。普通 SQL helper 保留 header multiplicity，不把出现相似字段的任意 mapping 接纳为旧 `sqlite3.Row` 专用成功证明。

carrier 只服务于正常 initial/open_replace/review_no_impact/withdrawn 且无 baseline/reversal 的完整月。任何 correction/baseline/reversal、缺 voucher number/total/current digest、关系签名不匹配，整月返回 None 并走原 selector。zero correction 也不能因数额为零进入 carrier。withdrawn/cleared 无 version 行仅在原 complete scope 已认证后忽略，残留 current head 仍由 opposite probe 检出。没有把未满足条件的单项留下再拼成部分“完整月”。

两个 consumer 都保留实际整月 `period_close` / `close_reference` absence probe；出现冻结 voucher reference 立即使用原完整 selection。`report` 的 absence cutoff 与 `Journal` 的 snapshot cutoff 分别作为精确 cache key；carrier 必须在证实的 through-period 和 closed boundary 内。无法匹配 exact absence key 就不消费 carrier。

### snapshot 与 money proof

carrier 检查相同 QueryReads、同 connection、同 snapshot token、活动事务、当前 `_active_fact_reads` 与当前 reader family；`QueryReads.snapshot` 退出时 reset 更换 token并清除缓存。跨连接、跨请求、非活动 context、固定 v1/history 或错误 cutoff 均无法复用。

`Journal.account_amounts:1289` 只在无 kinds/accounts/subjects 限定时尝试 carrier，其后保留完整 adopted selection、current publications、整月 current/frozen ID equality、original frozen source、owner/current basis outcome 与 fact 验证、全 posted line 顺序与整型检查、逐行 saved-result equality、借贷/total 检查及 gross 汇总。`journal_verified_rows` / summary 仍到所有步骤成功才保存。fact seal/outcome/body 失败可能保留已成立的 physical header relation，但不会发布金额 proof。

`report` 后续的 open contribution、source body 与 seal 验证路径不因 carrier 成功而省略；carrier 只替代已经有同 snapshot 物理字段的重复 header selection。失败路径不得把这些字段当作完整 report/money 验证。

## 公共入口与完整核验路径

`Service._dispatch` 的 Reports、dashboard 五页及 CLI/MCP 入口未改变，没有新增 public witness、flag 或 carrier API。Dashboard `_snapshot` 仍拥有独立 QueryReads snapshot 并在 finally release；context 的身份/period 读取没有变成五页钱证明。main/context 的既有并行关系不在本组修改范围。

默认 brief 与按需 sections 仍先取得完整金额 proof，各页的分页窗口没有用于缩小认证输入。quarterly 报表的完整月份 classification 与 frozen flow 检查保留；12 个月的 distinct frozen classification 读取不能因外观相似称为重复。直接 Reports 普通连接不满足 owned active snapshot 时走原路径；Dashboard 中当前 owned 调用才可能用 carrier。

关账与完整 integrity 的 `_check_sources`、source recompute、完整冻结 settlement/report require/compare 仍独立执行，不能接受 header carrier 替代完整 source/history 核验。maintenance repair 的先验核验、重建各投影/open contribution/frozen settlement、后验 compare/schema/revision 边界未改变。backup 的 company verifier、`verify_file`、restore 的 source/target/history/最终文件核验仍保留；dense writer 改表示，但输入源和 canonical 输出义务没有减少。固定 v1 历史 reader 字节及分派未变化。

## 验证范围与未证明事项

阅读了 `test_open_month_physical_header_reuse.py`、`test_owner_funds_summary_scope.py`、`test_brief_activity_reuse.py` 和 dense 相关定向测试源码。其设计包含 no-impact、替换/清空、额外旧 current、错误 h.voucher_id、缺 number、close reference、tamper、snapshot expiry、过滤 scope、literal SQL multiplicity 和 workload 对照，但本轮**没有执行**这些测试，不能将存在断言写成已验证。

parent 已告知某 filtered baseline 测试的旧计数 FAIL 在固定 S 上也重现，helper 修订由其他 agent 处理。本轮未重新确认其运行结果，不把该既有 FAIL 当作候选新增缺陷，也不以此取消合并后定向回归。最新三组组合下 correction、晚期 no-impact、全部页面返回值和完整 repair/backup/restore/v1 oracle 的运行结果仍须由统筹回归确定。

carrier workload 测试的“禁用 carrier”对照仍使用候选新增 scope SQL 字段，只能证明该候选内部 carrier 的差异，不能证明相对固定 S 的净 VM/rows/bytes 收益。后述整页负面证据已否定接受此候选的性能依据。dense 容器证据能证明表示分配下降；brief locator 证据能证明未消费工作被移除；均不能推出现有 real releasebrowser 在 main12/main48 的 500 ms FAIL 已解决。

没有发现需要新增通用框架、持久缓存或放宽业务/历史核验的理由。本轮没有提出或实施新的优化。

## 实际工作证据：carrier 性能拒绝

本次仅解析 parent 提供的 `.tmp/stage9-three-group-work-result-20261004.json`，没有自己测量或连接库。该 JSON 记录的是上述固定 c4fd source 对固定 S 的一次整页 instrumented actual work，明确不是 browser acceptance。其六项 strict business response hash 相等，完整 source/file/identity/state/history/security/repair 守卫保留；这些结果证明业务对照相同，不能抵消新增未消费工作。

| 入口 | carrier 实际消费 | 三组总 VM delta | 三组总 returned bytes delta |
| --- | --- | ---: | ---: |
| context | 未铸造 | 0 | 0 |
| brief | 铸造 1006 行；调用一次，整月 fallback 一次 | +2,300 | +22,604 |
| funds_first | 铸造 1006 行；未调用 selector | +25,100 | +56,304 |
| employees | 铸造 1006 行；未调用 selector | +25,200 | +56,304 |
| assets | 铸造 1006 行；未调用 selector | +25,100 | +56,304 |
| quarterly_report | 铸造 1006 行；调用一次，整月 fallback 一次 | +25,100 | +56,304 |

brief 同时享受其他组的重复 query 去除，仍净增成本。report 的 SQL/rows/result-load/decode 没有减少；其他三个业务页支付扩列成本却没有 consumer。原型局部“小测试 forced selector”不能覆盖这些真实路径的零消费。按需失败返回 None 的保护行为正确，但在实际路径中铸造载荷已成为多余工作，应撤回三文件的新增原型，保留 S 已有关系 proof 复用与其他两组修改。具体撤回由专属 agent 负责，本报告不把准备撤回记录当作撤回完成。

## 混合普通／复核／闭期更正月份的窄审计

**整月业务集合与全量金额认证必须保持完整，但“一项复杂结果使全部普通 header 放弃复用”不是业务规则本身。** 它是当前原型只提供 terminal-publication normal head 的表示限制。没有新的事实允许直接删除 guard：

1. `verify_open_voucher_scope` 的每个 terminal p 只通过 `p.voucher_id` 查其 normal current head。closed correction 的独立 reversal version 由 `publication.verify_open_correction_publication_heads` 根据真实 chain、baseline、original owner、实际 posting 和实际 physical head 单独证明。它不是另一个 terminal p 正常头，无法由该 row 改几个字段生成。
2. `selected_voucher_sql` 的反向凭证保留 `voucher_calculation_id = reversal.calculation_id`，而 `basis_calculation_id = original.calculation_id`；normal no-impact 则是 original voucher owner 与 current reviewed basis。两类 basis 规则不同。source period、kind、fact、digest、report publication ID 全部须跟对应 basis 实际 SQL 行，不能跟一个 terminal current calculation 统一赋值。
3. 同月 open replacement 可以保留 earlier reversal，跨月 moved replacement 可能改变 reversal owner/posting；多次 no-impact review 可以保留更早 normal owner。零 baseline amount 可合法没有 reversal，却仍需 correction chain 证明该缺省；不能以 baseline 非空一概生成两行，也不能用“金额零”跳过 source。
4. S 已有 `_verified_current_voucher_publications` 按 version 保存实际六字段签名与原/current publication pair。普通 normal proof、no-impact 的独立 owner/current proof、独立 reversal proof可以同处一个成功 cache，并不是月份有 correction 就让 ordinary proof 失效。但该 cache **不包含** number、total、basis fact/kind/source period/digest 的完整物理 header，也不证明整月实际 current ID 集合相等。它不能单独代替 selector。

可以审查的最窄关系形状是：仅在 `account_amounts` 或 `_authoritative_rows` 的真实消费点、相同活动 snapshot、精确整月 close/reference absence 已成立时，设普通／复核实际头集合为 N，复杂 normal／reversal 的原 selector 实际行集合为 C。N 必须来自已核物理 version/signature 与其 actual basis 字段；C 必须执行已有 `selected_voucher_sql(voucher_ids=...)` 的精确原语义。合并前独立取得整个实际 current month 的 V，并要求 `N ∪ C = V` 且两支互斥，不能从 terminal IDs 推导 V。缺 number、错误 logical current、extra old current、遗漏 reversal、缺 original basis 或新增 close-reference时走原完整 selector及其原诊断。所有 body/line/unknown/source proofs继续按合并后的完整集合执行；固定 v1及历史范围不进入该关系。

这只是可审查的关系约束，**还没有安全且已证明省成本的实现建议**。当前 S 中可复用的 physical rows 没有 N 所需完整字段；在消费点补读 N 的 number/total/basis 元数据本身仍要执行 SQL，C 也要执行原 selector，还新增 V 的完整集合读取与合并成本。重新给五页 scope 预加载这些字段会重现本轮 +56,304 bytes 的失败。是否能在原有 consumer 查询中取得所需字段、减少 join 而不是重复读取，尚无工作量证据；此处不建议实现新的缓存或预加载，也不建议放宽 baseline/reversal guard 来“制造命中”。

若以后得到更具体、能复用既有物理字段的设计，其最低反例包括：普通 + 多级 no-impact + closed correction 同月、零 baseline correction、same-month replacement 保留 earlier reversal、moved replacement、review 之后再 correction、extra old current／错 h.voucher_id、缺 number／缺 original calculation、unexpected close reference、body tamper、跨连接／snapshot token／v1 history。仍需实际 header 多重集和字段类型逐项等价，完整业务 response 等价及 whole-page 载荷净下降。当前仅能判定混合月的全量业务范围必要，普通 row 理论上可保持自己的成功关系，净收益未验证；不扩展工程，不重试撤回的 whole-contribution 或 audit24 路径。
