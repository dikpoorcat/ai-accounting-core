# 第9阶段冻结清偿 group 表示审计

2026-10-04。先读AGENTS/FRONTEND；先完成只读设计，然后按root后续明确授权实施窄候选。仅修改current settlement_freeze.py、两份已有私有fixture测试及新表示测试；访问的数据库只由定向测试在temporary路径显式新建。未操作真实库、服务、资料根、schema、fixed v1或500ms性能验收。下文分别记录只读依据及已执行的early验证，不作为浏览器通过结论。

sealed source24b9中 settlement_freeze.py 与审计时active字节完全相同：
SHA256 `d7d796b7bd0076d8835809c8e621a31aa0bc1590b867258ec821e51eb68b45f7`。
fixed settlement_freeze_v1.py sealed/active均为
`c0dd997e648e43d91575764f2830575e578e3af3fb340e2ae469f895d70b573c`。
封存来源目录为 `.tmp/stage9-build-source-surviving-read-consumers-fixed-20261003`；
current五页profile source为24b9，实际加载open-scope-group-candidate封存源。

## 决策与工作量

值得尝试当前模块内部15字段dict改为15元素list的局部表示实验。原因是
`_groups_from_root:154`对所有authenticated root.groups反复创建15-key dict，
后续汇总只做固定字段数值读取；不是业务核验、来源读取、SQL或JSON解码本身。
candidate应只减少每group的dict entry分配与name hash lookup，实际输入group数及
15个值不减少，不以persistent proof/cache隐藏工作。

既有singlecold profile中brief该函数self0.1046688s、employees0.0091843s，
两者各一次。相同函数差异很大，包含OS/allocator调度可能性。不能预测省100ms，
不能加inclusive时长，也不据此承诺500ms。

## 必须一起改的消费者

| 路径 | 表示责任 |
|---|---|
| `_group_delta:116`、`_add_group:140` | old state减去、new state加回；按原counts0–9/sums10–14顺序逐项checked；count0时全部15值必须0，才删除group |
| `_groups_from_root:154`、`_groups_for_root:161` | key保持5元素tuple，value独立slice list；恢复必须要求row正好20项，以保留原strict zip短长ValueError；序列化仍canonical(key)排序+完整20元素vector |
| `_build_prepared:584` | 当前关账writer、独立重建/repair/完整backup verifier共用；新prepared root_json、root_digest、blocks/revisions必须与旧oracle完全同字节 |
| `_scope:942` | 认证root、完整tail、old减new加、history/current截止期均保持；counterpart两个scope已共享同groups对象，只有构建新独立scope阶段允许mutate，发布后不能变 |
| frozen_followup_summary:1135 | 全15字段按原included-group顺序checked；unknown/unresolved/status及source/paid/other None语义保持 |
| frozen_payroll_period_payments:1497 | bad_paid/bad_other任何已included group都会fallback，不可仅检查工资或净额 |
| frozen_employee_net_summary:1573 | 非工资unknown/unresolved阻断完整工资快捷径；221101才净额，但所有工资components继续checking；employee必须精确匹配，不改变bad_paid/bad_other及period paid state proof |
| frozen_dashboard_open:1855 | 总义务/unknown/open-count/open-sum/open-unknown照旧；完整汇总与bounded page、精确page_keys/empty keys行为保持 |
| frozen_position_rows:1960 | 按(account/category/party)累计remaining、unknown和known_count；已知/未知并存不能变成完整确定值 |

`frozen_subject_summary:1387`及`_subject_scope:1247`不按groups消费；它们依靠subject leaves、精确states、events、period_amounts及page/publication/source核验。
subject_scope可复用已存在fullscope，但不得从完整groups推断subject采用，也不新增subject groups materialization。
`_page_entries`、`frozen_page/key`不读取groups，不需要改变state/root/page proof格式。

全src搜索未发现current FrozenScope.groups外部生产消费者；全部固定field访问在
current settlement_freeze.py。外部API仍返回原named dict，不传播dense vector。
测试两处employee unknown注入使用group string keys，须改成明确index；
test_settlement_freeze手造partial dict必须改为准确15值，保留原page/unknown业务断言。

## 其他同类循环

- dashboard_funds._sql_summary_page:97将SQL按account group汇总后的少量vectors转dict，
  后续还填账户对象，不是大量义务group即时再汇总；不扩大此candidate。
- query_reads.calculation_identity_headers:1178把header cursor转dict，后续多领域做身份/
  adopted/publication/seal核验，不能用group表示变更同时替换。不是纯汇总输入。
- report_flow._content:145与report_semantics:229将source line vectors转dict，随后分类、
  semantic field expansion、issues与来源解析；只在prepare/完整重建消费，非普通read
  root.group马上汇总。密集表示涉及多个稳定核算函数接口，风险较大，当前不纳入。
- settlement_freeze._authoritative_freezes:2032/2084把14列source向量扩展为有sequence/
  source_kind等named事件，驱动_apply、state/events/subject directories。属于独立
  writer oracle，并非15字段group恢复；当前保持，以减小canonical兼容证明范围。
- close_preview、versions的zip dict是小的版本/合同metadata，非本次热点。
- 所有对应fixed v1表示都保持原实现，内容指纹不能改。

## 风险与窄实现条件

关键风险是固定顺序错位、short/long vector静默接受、slice alias污染base_root、
counterpart共享后mutate、逐项checked顺序改变中间溢出、unknown被当0、
group被错误删去、writer重建canonical不同而导致历史根验证失败。
15_FIELDS只定义本模块明确字段顺序；读者用固定局部索引，不新增通用wrapper。
list切片必须copy；完整row20长度核验继续抛ValueError；不增加推断默认值。
old `_group_delta`无source_event_count返回empty、remaining None/0和opened定义保持。
逐字段checked顺序及fully-reversed检查保持，canonical key排序不改。

定向验证比较new/old纯oracle下old减/new加的groups、rootvectors和prepared
canonical root_json/digest/blocks/revisions，覆盖closed tail、identity correction、
unknown payroll/paid/other、零金额、冲正与overflow；现有完整完整verify/repair测试
以真实synthetic source及immutable root tamper失败为依据。表示工作量可测实际
恢复G行的container storage/peak allocation，不测试源码字符串、不用计时推收益。
schema/root格式和frozenbytes不变，真实draft0库、
服务、目录、身份及资料根均不操作。

## 窄候选实际结果

current helper增加固定 `_FIELDS` 和15个局部索引；delta使用同顺序tuple，group用
15元素list，恢复保留exact20长度ValueError与独立slice。仅在new group时分配零list。
全部group摘要访问改为明确索引，followup totals仍为单个小的named response aggregate，
checked按原字段与included-group顺序执行。writer/current scope构建与counterpart共享
策略未改，subject/state/leaf/page/source proof未改，完整source输入未筛掉。

一次最小early pytest执行：**35 passed**。包括新表示测试的16组已知/未知/零/负余额
增减oracle、六种short/long拒绝、独立slice及实际container工作量、逐项checked顺序/
int64 overflow/未完全逆转阻断、实际两个关账月份的全部PreparedFreeze及blocks/revisions
旧oracle比较；已有tests覆盖完整projection与frozen历史/current/later payment对照、
counterpart同对象复用、bounded page、deleted source contribution完整verify拒绝、
非命中state damage完整verify/repair、工资各component unknown与完整checking。
完整身份更正/late review/其他受影响组由root合并后统一验证，未在此反复跑完整组。

一次四个指定源码/测试文件ruff检查（修正新测试一处101字符换行后）通过。
fixed v1 SHA仍为上述 `c0dd...b573c`。与24b9保全settlement_freeze单文件比较为
58插入/47删除，其余同文件历史修改未覆盖；未改其他生产文件。

表示工作量读取同一实际4096-group synthetic root：旧named groupcontainers
2,048,088 bytes，新dense containers 868,440 bytes，减少1,179,648 bytes。
这仅计共同outer dict及每group value container；双方相同的tuple keys和integer引用
未重复计入。G=4096、每group15值和serializedcanonical完全相同，实际减少的是
表示storage，不是SQL/rows/JSON数量。未测timing，不承诺减少104ms或通过500ms。
