"""Private read-only A/B of a direct voucher-period candidate driver."""

from __future__ import annotations

from collections import Counter
import json
from pathlib import Path
import sqlite3


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp/stage9-r37-kind-period-probe.json"
OUTPUT = ROOT / ".tmp/stage9-r37-kind-period-direct-private-ab.json"
OLD_SCOPE = (
    "scoped_vouchers AS (SELECT original.id FROM json_each(?) selected_kinds "
    "CROSS JOIN calculation sc INDEXED BY calculation_kind_period "
    "ON sc.kind=selected_kinds.value CROSS JOIN voucher_version original "
    "INDEXED BY voucher_calculation ON original.calculation_id=sc.id), "
)
NEW_SCOPE = (
    "has_kind AS (SELECT 1 FROM json_each(?) selected_kinds "
    "CROSS JOIN calculation sc INDEXED BY calculation_kind_period "
    "ON sc.kind=selected_kinds.value LIMIT 1), "
)
OLD_DRIVER = "FROM scoped_vouchers scoped CROSS JOIN voucher_version v ON v.id=scoped.id"
NEW_DRIVER = "FROM has_kind CROSS JOIN voucher_version v INDEXED BY voucher_period"


def read(connection, sql, params):
    plan = [row[3] for row in connection.execute("EXPLAIN QUERY PLAN " + sql, params)]
    steps = 0

    def progress():
        nonlocal steps
        steps += 1
        return 0

    connection.set_progress_handler(progress, 1)
    try:
        rows = [tuple(v.hex() if isinstance(v, bytes) else v for v in row)
                for row in connection.execute(sql, params)]
    finally:
        connection.set_progress_handler(None, 0)
    return rows, steps, plan


def main():
    assert SOURCE.is_file() and not OUTPUT.exists()
    source = json.loads(SOURCE.read_text(encoding="utf-8"))
    result = {"status": "private_read_only_comparison", "variant": "kind_exists_guard_direct_voucher_period_driver", "samples": {}}
    for months, sample in source["samples"].items():
        path = ROOT / sample["book"] / "91310000123456789S/company.sqlite"
        connection = sqlite3.connect(path.as_uri() + "?mode=ro", uri=True)
        connection.execute("PRAGMA query_only=ON")
        connection.execute("BEGIN")
        records = []
        try:
            for captured in sample["queries"]:
                original_sql = captured["statement"]
                assert original_sql.count(OLD_SCOPE) == 1
                assert original_sql.count(OLD_DRIVER) == 1
                candidate_sql = original_sql.replace(OLD_SCOPE, NEW_SCOPE).replace(OLD_DRIVER, NEW_DRIVER)
                params = captured["parameters"]
                old_rows, old_steps, old_plan = read(connection, original_sql, params)
                new_rows, new_steps, new_plan = read(connection, candidate_sql, params)
                old_members = Counter(json.dumps(row, ensure_ascii=False) for row in old_rows)
                new_members = Counter(json.dumps(row, ensure_ascii=False) for row in new_rows)
                records.append({
                    "family": captured["family"],
                    "selected_kinds": captured["selected_kinds"],
                    "original_sql": original_sql,
                    "candidate_sql": candidate_sql,
                    "parameters": params,
                    "original_vm_steps": old_steps,
                    "candidate_vm_steps": new_steps,
                    "same_order": old_rows == new_rows,
                    "same_row_multiset": old_members == new_members,
                    "original_rows": old_rows,
                    "candidate_rows": new_rows,
                    "original_plan": old_plan,
                    "candidate_plan": new_plan,
                })
        finally:
            connection.rollback()
            connection.close()
        result["samples"][months] = records
    OUTPUT.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    assert all(r["same_row_multiset"] for entries in result["samples"].values() for r in entries)


if __name__ == "__main__":
    main()
