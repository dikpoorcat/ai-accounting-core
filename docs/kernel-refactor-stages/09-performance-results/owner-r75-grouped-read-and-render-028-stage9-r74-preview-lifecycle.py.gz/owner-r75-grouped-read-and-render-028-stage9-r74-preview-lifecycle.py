"""Passive lifecycle diagnosis; synthetic r73 only, never acceptance timing."""
from pathlib import Path
import collections
import ctypes
import gc
import json
import os
import statistics
import sys
import time

w = Path(__file__).resolve().parents[1]
src = w / '.tmp/stage9-build-source-owner-r73-release'
sys.path.insert(0, str(src / 'scripts'))
from stage9_source import configure_source
configure_source(src, w)
from ai_accounting.kernel.daemon import _prepare_static_runtime
from ai_accounting.kernel.service import LocalService
from pydantic import SecretStr

book = json.loads((w / '.tmp/stage9-owner-main12-r73-verified.json').read_text('utf8'))
assert book['status'] == 'complete' and book['integrity']['status'] == 'verified'
assert not book['integrity']['limitations'] and Path(book['source']) == src
root = Path(book['root'])
assert root == w / '.tmp/stage9-owner-main12-r43'
output = w / '.tmp/stage9-r74-preview-lifecycle.json'
assert not output.exists()

class Mem(ctypes.Structure):
    _fields_ = [('cb', ctypes.c_ulong), ('PageFaultCount', ctypes.c_ulong),
               ('PeakWorkingSetSize', ctypes.c_size_t), ('WorkingSetSize', ctypes.c_size_t),
               ('QuotaPeakPagedPoolUsage', ctypes.c_size_t), ('QuotaPagedPoolUsage', ctypes.c_size_t),
               ('QuotaPeakNonPagedPoolUsage', ctypes.c_size_t), ('QuotaNonPagedPoolUsage', ctypes.c_size_t),
               ('PagefileUsage', ctypes.c_size_t), ('PeakPagefileUsage', ctypes.c_size_t)]

def memory():
    m = Mem(); m.cb = ctypes.sizeof(m)
    ctypes.windll.kernel32.GetCurrentProcess.restype = ctypes.c_void_p
    ctypes.windll.psapi.GetProcessMemoryInfo(ctypes.c_void_p(ctypes.windll.kernel32.GetCurrentProcess()), ctypes.byref(m), m.cb)
    return {'rss': m.WorkingSetSize, 'peak_rss': m.PeakWorkingSetSize}

phase = {'name': 'startup'}
gc_starts = {}
gc_events = []

def observe_gc(event, info):
    key = info['generation']
    if event == 'start':
        gc_starts[key] = (time.perf_counter(), phase['name'])
    elif event == 'stop':
        start = gc_starts.pop(key, None)
        if start:
            gc_events.append({'phase': start[1], 'generation': key,
                              'ms': (time.perf_counter() - start[0]) * 1000,
                              'collected': info['collected'], 'uncollectable': info['uncollectable']})

def object_inventory():
    counts = collections.Counter()
    tracked_scopes = collections.Counter()
    for value in gc.get_objects():
        kind = type(value)
        counts[f'{kind.__module__}.{kind.__qualname__}'] += 1
        if kind.__module__.startswith('ai_accounting'):
            tracked_scopes[f'{kind.__module__}.{kind.__qualname__}'] += 1
    return {'top_types': counts.most_common(20), 'kernel_types': tracked_scopes.most_common(45),
            'total_tracked': counts.total(), 'memory': memory(), 'gc_count': gc.get_count()}

out = {'scope': 'passive_gc_and_lifetime_diagnostic_not_acceptance', 'source': str(src),
       'root': str(root), 'pid': os.getpid(),
       'concurrency': 'other_agents_may_run_small_directed_work_not_pure_timing',
       'gc_policy': 'unchanged_no_explicit_collection_no_threshold_change', 'reads': []}
app = None
token = None
gc.callbacks.append(observe_gc)
try:
    app = LocalService(root, enable_read_pool=True, _static_runtime=_prepare_static_runtime())
    with app.catalog.connection(read_only=True) as conn:
        owners = [r[0] for r in conn.execute('SELECT login_name FROM security_owner')]
    assert owners == ['synthetic-stage9-owner']
    token = app.security.login(owners[0], SecretStr('Synthetic-stage9-browser-only-2026')).session_token
    cid = book['company']['id']
    def read_pages(stage):
        for command in ('dashboard_brief', 'dashboard_assets', 'dashboard_quarterly_report'):
            args = {'company_id': cid}
            if command == 'dashboard_quarterly_report':
                args.update(quarter='2016-Q4', source='open')
            else:
                args.update(period='2016-12', limit=20, preparation='deferred')
            for iteration in range(4):
                phase['name'] = f'{stage}:{command}:{iteration}'
                first_event = len(gc_events)
                started = time.perf_counter()
                result = app.dispatch(command, args, session_token=token, response_format='http_json')
                elapsed = (time.perf_counter() - started) * 1000
                parsed = json.loads(result)
                assert parsed['company']['company_id'] == cid if 'company_id' in parsed['company'] else parsed['company']['id'] == cid
                out['reads'].append({'stage': stage, 'command': command, 'iteration': iteration,
                                     'ms': elapsed, 'bytes': len(result), 'memory': memory(),
                                     'gc_events': gc_events[first_event:]})
                del result, parsed
    read_pages('before_preview')
    phase['name'] = 'inventory_before'
    out['before_preview'] = object_inventory()
    phase['name'] = 'preview'
    started = time.perf_counter()
    preview = app.dispatch('preview_close', {'company_id': cid, 'period': '2016-12',
                           'owner_confirmation': book['snapshots']['2016-12']['owner_confirmation']},
                           session_token=token)
    out['preview_ms'] = (time.perf_counter() - started) * 1000
    assert preview['digest'] == book['verified_open_preview']['digest']
    out['preview_digest'] = preview['digest']
    out['cached_preview_encoded_bytes'] = len(json.dumps(preview, separators=(',', ':'), ensure_ascii=False).encode())
    del preview
    phase['name'] = 'inventory_after'
    out['after_preview'] = object_inventory()
    read_pages('after_preview')
    out['read_medians_ms'] = {f'{stage}:{command}': statistics.median(r['ms'] for r in out['reads']
                            if r['stage'] == stage and r['command'] == command and r['iteration'] > 0)
                            for stage in ('before_preview', 'after_preview')
                            for command in ('dashboard_brief', 'dashboard_assets', 'dashboard_quarterly_report')}
    out['status'] = 'complete'
except BaseException as exc:
    out['status'] = 'failed'; out['error_type'] = type(exc).__name__
    raise
finally:
    phase['name'] = 'shutdown'
    if app is not None:
        if token is not None:
            app.security.logout(token); out['synthetic_session_revoked'] = True
        app.close(); out['app_closed'] = True
    gc.callbacks.remove(observe_gc)
    out['gc_events'] = gc_events
    out['memory_after'] = memory()
    with output.open('x', encoding='utf8') as handle:
        json.dump(out, handle, ensure_ascii=False, indent=2)
print(json.dumps({'status': out['status'], 'preview_ms': out.get('preview_ms'),
                  'medians': out.get('read_medians_ms'), 'before': out.get('before_preview'),
                  'after': out.get('after_preview'), 'output': str(output)}, ensure_ascii=False))
