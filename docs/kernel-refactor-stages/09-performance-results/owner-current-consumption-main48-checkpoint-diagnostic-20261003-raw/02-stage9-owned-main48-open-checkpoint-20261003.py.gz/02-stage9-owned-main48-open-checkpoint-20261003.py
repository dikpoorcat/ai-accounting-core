"""Measure and checkpoint one owned synthetic clone; never touch a live data root."""
import hashlib
import json
import sqlite3
import time
from pathlib import Path

from ai_accounting.kernel import runtime
from ai_accounting.kernel.versions import fingerprint, objects

workspace = Path(__file__).resolve().parents[1]
target = (workspace / '.tmp/stage9-draft-fixture-main48-20261003').resolve(strict=True)
assert target.parent == (workspace / '.tmp').resolve(strict=True)
book_path = target / 'stage9-draft-copy-book.json'
book_raw = book_path.read_bytes()
book = json.loads(book_raw)
assert book['status'] == 'copied_content_unverified'
assert book['requested_months'] == 48 and book['distribution'] == 'mixed_cumulative'
assert book['company']['id'] == 'c73e4f4d144340c98ade475b8dd8c8b9'
assert book['company']['database_id'] == '6cc5f6cbe6cd402ebdfd072195398780'
database = Path(book['company']['path']).resolve(strict=True)
assert database == target / '91310000123456789S/company.sqlite'
assert database.is_file() and not database.is_symlink()
qualification_path = workspace / '.tmp/stage9-owner-current-consumption-main48-20261003-qualified.json'
qualification_raw = qualification_path.read_bytes()
qualification = json.loads(qualification_raw)
assert qualification['status'] == 'complete' and qualification['company'] == book['company']
assert qualification['qualification']['source_manifest_sha256'] == '95444b11b4655fc3c0224e8a66a8f1d432e8b572527b2ea674c11f8988277a20'
output = workspace / '.tmp/stage9-owned-main48-open-checkpoint-20261003.json'
assert not output.exists()
state = {'status': 'started', 'scope': 'owned synthetic storage only',
         'target': str(target), 'qualification_sha256': hashlib.sha256(qualification_raw).hexdigest(),
         'book_sha256': hashlib.sha256(book_raw).hexdigest(), 'events': []}

def save():
    output.write_text(json.dumps(state, indent=2) + '\n', encoding='utf-8')

def witness(connection):
    identity = dict(connection.execute('SELECT * FROM identity WHERE id=1').fetchone())
    assert identity['company_id'] == book['company']['id']
    assert identity['database_id'] == book['company']['database_id']
    assert identity['taxpayer_id'] == book['company']['taxpayer_id']
    meta = dict(connection.execute('SELECT * FROM schema_meta WHERE id=1').fetchone())
    assert meta == {'id': 1, 'family': 'ai-accounting-kernel/2', 'kind': 'company', 'status': 'draft'}
    schema = fingerprint(objects(connection)).hex()
    assert schema == 'c9f9f7051bca67f1241ee5c89676fb9476bc819dc8f92c1a0c0bd1e940f459cb'
    assert connection.execute('PRAGMA application_id').fetchone()[0] == 0x41414332
    assert connection.execute('PRAGMA user_version').fetchone()[0] == 0
    assert connection.execute('PRAGMA journal_mode').fetchone()[0] == 'wal'
    return {'identity': identity, 'meta': meta, 'schema_sha256': schema,
            'state': list(connection.execute('SELECT * FROM state WHERE id=1').fetchone()),
            'history': [[row[0], bytes(row[1]).hex()] for row in connection.execute(
                'SELECT version,fingerprint FROM schema_history ORDER BY version')],
            'page_count': connection.execute('PRAGMA page_count').fetchone()[0]}

original_execute = runtime._PrivateConnection.execute

def counted_execute(connection, sql, *args, **kwargs):
    started = time.perf_counter()
    try:
        return original_execute(connection, sql, *args, **kwargs)
    finally:
        if sql.startswith('PRAGMA '):
            state['events'].append({'sql': sql, 'milliseconds': (time.perf_counter()-started)*1000})
            save()

def read_open(label):
    started = time.perf_counter()
    runtime._PrivateConnection.execute = counted_execute
    try:
        connection = runtime.connect(database, read_only=True, _permissions=False)
        try:
            connection.execute('BEGIN')
            measured = witness(connection)
            connection.rollback()
        finally:
            connection.close()
    finally:
        runtime._PrivateConnection.execute = original_execute
    state[label + '_read_open_ms'] = (time.perf_counter()-started)*1000
    state[label] = measured
    save()

started = time.perf_counter()
save()
try:
    state['wal_before_bytes'] = Path(str(database) + '-wal').stat().st_size
    read_open('before')
    state['status'] = 'checkpointing'
    save()
    checkpoint_started = time.perf_counter()
    with sqlite3.connect(database, isolation_level=None) as connection:
        connection.row_factory = sqlite3.Row
        assert witness(connection) == state['before']
        result = list(connection.execute('PRAGMA wal_checkpoint(TRUNCATE)').fetchone())
        assert result == [0, 0, 0], result
        assert witness(connection) == state['before']
        state['checkpoint_result'] = result
        state['wal_after_bytes'] = Path(str(database) + '-wal').stat().st_size
        assert state['wal_after_bytes'] == 0
    state['checkpoint_ms'] = (time.perf_counter()-checkpoint_started)*1000
    read_open('after')
    assert state['before'] == state['after']
    assert book_path.read_bytes() == book_raw
    assert qualification_path.read_bytes() == qualification_raw
    state['status'] = 'synthetic_storage_checkpointed'
except BaseException as error:
    state['status'] = 'failed'
    state['error'] = {'type': type(error).__name__, 'message': str(error)}
    raise
finally:
    state['total_ms'] = (time.perf_counter()-started)*1000
    save()
    print(json.dumps({key: state[key] for key in ('status', 'target', 'total_ms')}))
