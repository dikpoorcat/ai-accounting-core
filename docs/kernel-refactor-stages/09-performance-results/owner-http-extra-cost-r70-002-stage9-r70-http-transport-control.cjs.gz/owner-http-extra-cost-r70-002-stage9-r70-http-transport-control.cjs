'use strict';
// Synthetic local transport only. Run through companion Python; same actual Edge instance.
const fs = require('node:fs');
const [configPath, output] = process.argv.slice(2);
if (!configPath || !output) throw new Error('Expected config.json and new browser.json');
if (fs.existsSync(output)) throw new Error('Output already exists; no overwrite');
const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
const {chromium} = require(config.playwright_module);

(async () => {
  const browser = await chromium.launch({channel: config.channel, headless: true});
  const result = {status: 'running', browser_version: browser.version(),
    channel: config.channel, scope: 'one real Edge browser, simulated JSON fetch; no Vue/DB/business verification',
    samples: []};
  try {
    const context = await browser.newContext();
    const page = await context.newPage();
    for (const block of config.blocks) {
      await page.goto(block.url + '/', {waitUntil: 'load'});
      // Reverse payload order in the second half, in addition to off/on/on/off mode order.
      const sizes = block.block >= 2 ? [...config.sizes].reverse() : config.sizes;
      for (const size of sizes) {
        for (const phase of ['warmup', 'measured']) {
          const count = phase === 'warmup' ? config.warmups : config.samples;
          for (let index = 0; index < count; index++) {
            const sample = 'b' + block.block + '-s' + size + '-' + phase + '-' + index;
            const row = await page.evaluate(async ({size, sample, token}) => {
              performance.clearResourceTimings();
              const url = location.origin + '/api/dashboard/context?size=' + size + '&sample=' + sample;
              const start = performance.now();
              const response = await fetch(url, {cache: 'no-store', headers: {Authorization: 'Bearer ' + token}});
              const headersEnd = performance.now();
              const bytes = new Uint8Array(await response.arrayBuffer());
              const end = performance.now();
              // Integrity work occurs AFTER duration ends.
              const expected = new TextEncoder().encode('{"padding":"' + 'A'.repeat(size - 14) + '"}');
              const equal = expected.length === bytes.length && bytes.every((value, i) => value === expected[i]);
              const digest = Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', bytes)))
                .map(value => value.toString(16).padStart(2, '0')).join('');
              const entries = performance.getEntriesByName(url, 'resource');
              if (entries.length !== 1) throw new Error('Expected one matching resource timing');
              const resource = entries[0];
              return {sample, size, status: response.status, duration_ms: end - start,
                headers_ms: headersEnd - start, body_after_headers_ms: end - headersEnd,
                start_time: start, body_end_time: end, body_bytes: bytes.length,
                content_length: response.headers.get('content-length'),
                body_sha256: digest, raw_bytes_equal: equal,
                resource: {startTime: resource.startTime, requestStart: resource.requestStart,
                  responseStart: resource.responseStart, responseEnd: resource.responseEnd,
                  duration: resource.duration, transferSize: resource.transferSize,
                  encodedBodySize: resource.encodedBodySize, decodedBodySize: resource.decodedBodySize,
                  nextHopProtocol: resource.nextHopProtocol}};
            }, {size, sample, token: config.simulation_token});
            result.samples.push({...row, block: block.block,
              disable_nagle_algorithm: block.disable_nagle_algorithm, phase, index});
            if (!row.raw_bytes_equal || row.status !== 200 || row.body_bytes !== size)
              throw new Error('Raw response byte mismatch for ' + sample);
          }
        }
      }
    }
    result.status = 'complete';
  } catch (error) {
    result.status = 'failed';
    result.error = String(error);
    process.exitCode = 1;
  } finally {
    await browser.close();
    fs.writeFileSync(output, JSON.stringify(result, null, 2) + '\n', {flag: 'wx'});
  }
})().catch(error => { console.error(String(error)); process.exitCode = 1; });
