"""Read-only, same-transaction AB of two close accounting authority SQL families.

The normal serial Dashboard page and every original read_accounting check run
unchanged. After each BusinessQueries._selected_accounting call, this script
replays its exact period/subject/highwater scopes using the original per-month
SQL and two private multi-month SQL statements. It does not replace production
rows, prove an integrated page candidate, or alter source/books/schema.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import time
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp/stage9-build-source-r32-release"

OLD_PUBLICATIONS = (
    "SELECT p.subject_id,p.id,p.calculation_id FROM json_each(?) requested "
    "CROSS JOIN calculation_publication p INDEXED BY publication_subject "
    "ON p.subject_id=requested.value "
    "WHERE p.posting_period=? AND p.sequence<=? AND p.calculation_id IS NOT NULL "
    "AND NOT EXISTS(SELECT 1 FROM calculation_publication later "
    "WHERE later.previous_publication_id=p.id AND later.sequence<=?)"
)
OLD_VOUCHERS = (
    "SELECT v.id FROM json_each(?) requested "
    "CROSS JOIN calculation c INDEXED BY calculation_subject "
    "ON c.subject_id=requested.value "
    "CROSS JOIN voucher_version v INDEXED BY voucher_calculation "
    "ON v.calculation_id=c.id "
    "CROSS JOIN voucher_current h ON h.version_id=v.id "
    "WHERE v.period=?"
)
LIMITS = (
    "WITH limits(period,highwater) AS MATERIALIZED ("
    "SELECT CAST(json_extract(value,'$[0]') AS INTEGER),"
    "CAST(json_extract(value,'$[1]') AS INTEGER) FROM json_each(?)) "
)
BATCH_PUBLICATIONS = (
    LIMITS
    + "SELECT p.posting_period,p.subject_id,p.id,p.calculation_id "
    "FROM json_each(?) requested "
    "CROSS JOIN calculation_publication p INDEXED BY publication_subject "
    "ON p.subject_id=requested.value "
    "JOIN limits l ON l.period=p.posting_period "
    "WHERE p.sequence<=l.highwater AND p.calculation_id IS NOT NULL "
    "AND NOT EXISTS(SELECT 1 FROM calculation_publication later "
    "WHERE later.previous_publication_id=p.id AND later.sequence<=l.highwater)"
)
BATCH_VOUCHERS = (
    "WITH wanted(period) AS MATERIALIZED ("
    "SELECT CAST(value AS INTEGER) FROM json_each(?)) "
    "SELECT v.period,v.id FROM json_each(?) requested "
    "CROSS JOIN calculation c INDEXED BY calculation_subject "
    "ON c.subject_id=requested.value "
    "CROSS JOIN voucher_version v INDEXED BY voucher_calculation "
    "ON v.calculation_id=c.id "
    "CROSS JOIN voucher_current h ON h.version_id=v.id "
    "JOIN wanted w ON w.period=v.period"
)


def _sha(value):
    from pydantic_core import to_jsonable_python

    def stable(item):
        if isinstance(item, dict):
            return {key: stable(val) for key, val in item.items() if key != "generated_at"}
        if isinstance(item, list):
            return [stable(val) for val in item]
        return item

    raw = json.dumps(stable(to_jsonable_python(value)), ensure_ascii=False,
                     sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest(), len(raw)


def _bytes(rows):
    return sum(
        len(value.encode("utf-8")) if isinstance(value, str) else 8
        for row in rows for value in row
    )


def _query(connection, sql, parameters):
    steps = 0

    def progress():
        nonlocal steps
        steps += 100
        return 0

    connection.set_progress_handler(progress, 100)
    cpu, wall = time.process_time_ns(), time.perf_counter_ns()
    try:
        rows = [tuple(row) for row in connection.execute(sql, parameters)]
    finally:
        connection.set_progress_handler(None, 0)
    return rows, {
        "vm_lower_bound": steps, "rows": len(rows), "value_bytes": _bytes(rows),
        "cpu_ms_diagnostic": (time.process_time_ns() - cpu) / 1e6,
        "wall_ms_diagnostic": (time.perf_counter_ns() - wall) / 1e6,
    }


def _compare_group(connection, reads, recorded, kinds, ordinal):
    from ai_accounting.kernel.types import canonical

    if len({subjects for _, subjects in recorded}) != 1:
        raise AssertionError("One accounting selector used changing subjects")
    subjects = next(iter({subjects for _, subjects in recorded}))
    by_period = {row["period"]: row for row, _ in recorded}
    if len(by_period) != len(recorded):
        raise AssertionError("Repeated period within one accounting selector")
    limits = [
        [period, reads.close_header(row).root["small"]["publication_sequence"]]
        for period, row in sorted(by_period.items())
    ]
    if any(type(period) is not int or type(highwater) is not int for period, highwater in limits):
        raise AssertionError("Non-integer authenticated close highwater")
    encoded_subjects = canonical(sorted(subjects))
    publications, vouchers = [], []
    old_p = {"vm_lower_bound": 0, "rows": 0, "value_bytes": 0,
             "cpu_ms_diagnostic": 0, "wall_ms_diagnostic": 0}
    old_v = dict(old_p)
    for period, highwater in limits:
        rows, cost = _query(
            connection, OLD_PUBLICATIONS,
            (encoded_subjects, period, highwater, highwater),
        )
        publications.extend((period, *row) for row in rows)
        for key in old_p:
            old_p[key] += cost[key]
        rows, cost = _query(connection, OLD_VOUCHERS, (encoded_subjects, period))
        vouchers.extend((period, *row) for row in rows)
        for key in old_v:
            old_v[key] += cost[key]
    batch_publications, batch_p = _query(
        connection, BATCH_PUBLICATIONS, (canonical(limits), encoded_subjects),
    )
    batch_vouchers, batch_v = _query(
        connection, BATCH_VOUCHERS,
        (canonical([period for period, _ in limits]), encoded_subjects),
    )
    if Counter(publications) != Counter(batch_publications):
        raise AssertionError("Publication per-period row multiset changed")
    if Counter(vouchers) != Counter(batch_vouchers):
        raise AssertionError("Voucher per-period row multiset changed")
    def same_order_within_each_period(old_rows, new_rows):
        return all(
            [row for row in old_rows if row[0] == period]
            == [row for row in new_rows if row[0] == period]
            for period in by_period
        )
    return {
        "selector_ordinal": ordinal,
        "kinds": sorted(kinds) if kinds is not None else None,
        "periods": len(limits), "subjects": len(subjects),
        "publications": {"old": old_p, "batch": batch_p,
                         "multiset_equal": True,
                         "global_row_order_equal": publications == batch_publications,
                         "per_period_row_order_equal": same_order_within_each_period(
                             publications, batch_publications
                         )},
        "vouchers": {"old": old_v, "batch": batch_v,
                     "multiset_equal": True,
                     "global_row_order_equal": vouchers == batch_vouchers,
                     "per_period_row_order_equal": same_order_within_each_period(
                         vouchers, batch_vouchers
                     )},
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--months", type=int, choices=(12, 48), required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    if output.parent != (ROOT / ".tmp").resolve() or output.exists():
        parser.error("Choose new output directly under .tmp")
    if Path(sys.prefix).resolve() != (ROOT / ".tmp-kernel-venv").resolve():
        parser.error("Use repository virtual environment")
    report_path = ROOT / f".tmp/stage9-release-main-{args.months}-verified-r32.json"
    report = json.loads(report_path.read_text(encoding="utf-8"))
    if (
        report.get("status") != "complete"
        or report.get("integrity", {}).get("status") != "verified"
        or report.get("integrity", {}).get("limitations")
        or Path(report.get("source", "")).resolve() != SOURCE.resolve()
    ):
        parser.error("Require independently verified exact fixed-r32 book")
    sys.path[:0] = [str(SOURCE / "src"), str(SOURCE / "tests/kernel")]
    os.environ["STAGE9_WORKSPACE_ROOT"] = str(ROOT)
    from stage9_book import MixedBook
    from ai_accounting.kernel import business_queries, query_reads
    from ai_accounting.kernel.daemon import _prepare_static_runtime
    from ai_accounting.kernel.dashboard import Dashboard

    _prepare_static_runtime()
    book = MixedBook.resume(Path(report["root"]))
    page = Dashboard(book.engine)
    del book
    period = report["months"][-1]["period"]
    stack = []
    groups = []
    old_selector = business_queries.BusinessQueries._selected_accounting
    old_slice = query_reads.QueryReads.close_accounting

    def counted_slice(self, row, *, subjects):
        result = old_slice(self, row, subjects=subjects)
        if stack:
            stack[-1].append((row, frozenset(subjects)))
        return result

    def counted_selector(self, connection, subject_id, period, **kwargs):
        stack.append([])
        try:
            result = old_selector(self, connection, subject_id, period, **kwargs)
            recorded = stack[-1]
            if recorded:
                groups.append(_compare_group(
                    connection, self._reads(connection), recorded,
                    kwargs.get("kinds"), len(groups) + 1,
                ))
            return result
        finally:
            stack.pop()

    business_queries.BusinessQueries._selected_accounting = counted_selector
    query_reads.QueryReads.close_accounting = counted_slice
    records = []
    try:
        for operation in ("brief", "assets"):
            before = len(groups)
            if operation == "brief":
                response = page.brief(
                    period, limit=100, preparation="deferred", _parallel_attempt=None,
                )
            else:
                response = page.assets(period, limit=100, preparation="deferred")
            response_sha, response_bytes = _sha(response)
            records.append({
                "operation": operation, "response_sha256": response_sha,
                "response_bytes": response_bytes, "selector_groups": groups[before:],
            })
    finally:
        business_queries.BusinessQueries._selected_accounting = old_selector
        query_reads.QueryReads.close_accounting = old_slice
    result = {
        "status": "complete_diagnostic", "fixed_source": str(SOURCE),
        "verified_report": str(report_path), "period": period,
        "scope": (
            "Original complete native pages and per-month checks unchanged. "
            "Extra same-transaction authority SQL AB only; no integrated candidate response."
        ),
        "timing_boundary": "Background load may run; CPU/wall diagnostic only",
        "operations": records,
    }
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(output)


if __name__ == "__main__":
    main()
