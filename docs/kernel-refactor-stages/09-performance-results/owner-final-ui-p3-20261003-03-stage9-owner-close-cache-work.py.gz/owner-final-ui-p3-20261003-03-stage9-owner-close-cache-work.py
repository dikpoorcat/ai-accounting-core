"""P3 cache access diagnostics, not timing or a synthetic 120-month DB claim.

Two real fixture closes authenticate the requested rows and leaves. Unrequested
cache keys extend only the in-memory container shape to 12/48/120 months; their
sentinel values must never be consumed. Native dictionary unions are retained
and their input sizes recorded. Membership/get calls are actual caller visits.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
import tempfile
import traceback
from collections import Counter
from contextlib import contextmanager
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "src"), str(ROOT / "tests" / "kernel")]

from stage9_metrics import measure_work  # noqa: E402
from test_engine import engine as engine_fixture  # noqa: E402
from test_full_accounting_period_scopes import series  # noqa: E402

from ai_accounting.kernel import read_indexes  # noqa: E402
from ai_accounting.kernel.contracts import KernelError  # noqa: E402
from ai_accounting.kernel.query_reads import QueryReads  # noqa: E402


class CountedKeys:
    def __init__(self, owner):
        self.owner = owner
        self.view = dict.keys(owner)

    def __iter__(self):
        for key in self.view:
            self.owner.counts[self.owner.label + ":keys_iterated"] += 1
            yield key

    def __len__(self):
        return len(self.view)

    def __or__(self, other):
        self.owner.counts["native_key_union_calls"] += 1
        self.owner.counts["native_key_union_input_entries"] += len(self) + len(other)
        return self.view | other.view


class CountedDict(dict):
    def __init__(self, values, label, counts):
        super().__init__(values)
        self.label, self.counts = label, counts

    def keys(self):
        return CountedKeys(self)

    def __or__(self, other):
        self.counts["native_dict_union_calls"] += 1
        self.counts["native_dict_union_input_entries"] += len(self) + len(other)
        # Still execute the native dictionary operation, including RHS priority.
        return dict.__or__(self, other)

    def __contains__(self, key):
        self.counts[self.label + ":contains"] += 1
        return dict.__contains__(self, key)

    def __getitem__(self, key):
        self.counts[self.label + ":getitem"] += 1
        return dict.__getitem__(self, key)

    def get(self, key, default=None):
        self.counts[self.label + ":get"] += 1
        return dict.get(self, key, default)


def bounded_authoritative(self, *, periods, through_period=None):
    requested = tuple(sorted(set(periods)))
    if any(type(period) is not int for period in requested):
        raise ValueError("authoritative close periods must be integer ordinals")
    if not self._snapshot_active:
        return read_indexes.authoritative_close_rows(
            self.connection, periods=requested, through_period=through_period,
        )[0]
    missing = [period for period in requested
               if period not in self._authoritative_closes and period not in self._closes]
    if missing:
        rows, headers = read_indexes.authoritative_close_rows(
            self.connection, periods=missing, through_period=through_period,
        )
        self._authoritative_closes.update({row["period"]: row for row in rows})
        self._close_headers.update(headers)
    result = []
    for period in requested:
        if through_period is not None and period > through_period:
            continue
        row = (self._authoritative_closes.get(period)
               if period in self._authoritative_closes else self._closes.get(period))
        if row is not None:
            result.append(row)
    return result


def bounded_references(self, references):
    references = list(references)
    if not self._snapshot_active:
        return read_indexes.verify_close_references(self.connection, references)
    fields = ("close_period", "path", "position", "reference_type", "reference_id", "related_id")
    pending, keys = [], set()
    for reference in references:
        values = tuple(reference[field] for field in fields)
        key = tuple(map(type, values)) + values
        if key not in self._verified_close_references and key not in keys:
            pending.append(reference)
            keys.add(key)
    if pending:
        verified = {
            period: self._close_manifests[period]
            for period in {reference["close_period"] for reference in pending}
            if period in self._close_manifests
            and (period in self._closes or period in self._authoritative_closes)
        }
        read_indexes.verify_close_references(
            self.connection, pending, _verified_manifests=verified,
            _verified_headers=self._close_headers,
            _verified_storage_parts=self._verified_close_storage_parts,
        )
        self._verified_close_references.update(keys)


@contextmanager
def variant(bounded):
    if bounded:
        with patch.object(QueryReads, "authoritative_close_rows", bounded_authoritative), \
                patch.object(QueryReads, "verify_close_references", bounded_references):
            yield
    else:
        yield


def cache_probe(engine, size, bounded, shape="mixed"):
    accesses = Counter()

    def operation():
        with QueryReads.snapshot(engine) as reads:
            rows = reads.authoritative_close_rows(periods=MONTHS)
            if shape == "mixed":
                reads.close_rows(periods=(MONTHS[0],))
            reference = dict(reads.connection.execute(
                "SELECT * FROM close_reference WHERE close_period=? AND path=? LIMIT 1",
                (MONTHS[0], read_indexes.CLOSE_VOUCHERS),
            ).fetchone())
            # These keys measure unrelated cache size only; they assert neither
            # actual DB closes nor successful historical content verification.
            padding = {MONTHS[0] - 1000 - i: object() for i in range(size - len(MONTHS))}
            reads._closes = CountedDict(
                {**(padding if shape == "mixed" else {}), **reads._closes},
                "full_closes", accesses,
            )
            reads._authoritative_closes = CountedDict(
                {**padding, **reads._authoritative_closes}, "authority_closes", accesses,
            )
            reads._close_manifests = CountedDict(reads._close_manifests, "manifests", accesses)
            accesses.clear()
            before = Counter(reads.connection.counts)
            with variant(bounded):
                actual = reads.authoritative_close_rows(periods=MONTHS)
                # A pending leaf must still be independently compared to the
                # cached complete root or exact authenticated header.
                reads.verify_close_references([reference])
            target_work = Counter(reads.connection.counts) - before
            assert [row["period"] for row in actual] == list(MONTHS)
            assert all(not isinstance(row, object) or hasattr(row, "keys") for row in actual)
            assert all(actual[i] is rows[i] for i in range(len(rows)))
            return {"accesses": dict(accesses), "target_sql_work": dict(target_work)}

    work, result = measure_work(engine, operation)
    return {**result, "owned_request_work": work}


def expect_failure(call):
    try:
        call()
    except KernelError as error:
        return {"code": error.code, "reason": error.details.get("reason")}
    raise AssertionError("bad reference unexpectedly passed")


def boundaries(engine, bounded):
    results = []
    with variant(bounded), QueryReads.snapshot(engine) as reads:
        authority = reads.authoritative_close_rows(periods=MONTHS)
        assert not reads._closes and not reads._close_manifests
        references = [dict(reads.connection.execute(
            "SELECT * FROM close_reference WHERE close_period=? AND path=? LIMIT 1",
            (month, read_indexes.CLOSE_VOUCHERS),
        ).fetchone()) for month in MONTHS]
        calls = []
        original = read_indexes.verify_close_references

        def capture(connection, values, **options):
            calls.append(len(values))
            return original(connection, values, **options)

        with patch.object(read_indexes, "verify_close_references", capture):
            reads.verify_close_references([references[0], references[0]])
            successful = set(reads._verified_close_references)
            parts = dict(reads._verified_close_storage_parts)
            reads.verify_close_references([references[0]])
            assert calls == [1], "an exact success should suppress only its identical leaf"
            bad = {**references[1], "reference_id": "synthetic-wrong-id"}
            failure = expect_failure(lambda: reads.verify_close_references([references[1], bad]))
            assert reads._verified_close_references == successful
            assert reads._verified_close_storage_parts == parts
            failure_again = expect_failure(lambda: reads.verify_close_references([references[1], bad]))
            assert reads._verified_close_references == successful
            assert len(calls) == 3, "a failed batch must be checked again"
            # Boolean zero and integer zero must never share the success key.
            boolean_position = {**references[0], "position": False}
            typed_failure = expect_failure(lambda: reads.verify_close_references([boolean_position]))
            assert reads._verified_close_references == successful
        assert not reads._closes and not reads._close_manifests
        sources = []
        original_sources = read_indexes.verify_sources

        def source_capture(connection, kind, rows):
            sources.append((kind, len(rows)))
            return original_sources(connection, kind, rows)

        with patch.object(read_indexes, "verify_sources", source_capture):
            reads.close_rows(periods=(MONTHS[0],))
        assert sources == [("close", 1)], "authority-only success cannot certify full reference multiset"
        # Same immutable data, distinct row objects: preserve existing RHS
        # preference without using weaker proof as a full-proof marker.
        weak = dict(authority[0])
        reads._authoritative_closes[MONTHS[0]] = weak
        preferred = reads.authoritative_close_rows(periods=(MONTHS[0],))
        assert preferred[0] is weak
        assert reads.authoritative_close_rows(periods=MONTHS, through_period=MONTHS[0]) == [weak]
        assert reads.authoritative_close_rows(periods=()) == []
        before_authority, before_headers = dict(reads._authoritative_closes), dict(reads._close_headers)
        with patch.object(read_indexes, "authoritative_close_rows", side_effect=RuntimeError("synthetic fault")):
            try:
                reads.authoritative_close_rows(periods=(MONTHS[-1] + 1,))
            except RuntimeError:
                pass
            else:
                raise AssertionError("fault must propagate")
        assert reads._authoritative_closes == before_authority and reads._close_headers == before_headers
        results.extend((
            {"exact_hit_and_duplicate_batch": "passed"},
            {"failed_leaf_batch_keeps_prior_success_only": failure},
            {"failed_leaf_batch_rechecks": failure_again},
            {"typed_boolean_position_rejected": typed_failure},
            {"authority_not_full_multiset_proof": "passed"},
            {"rhs_priority_cutoff_empty_input": "passed"},
            {"authority_fault_no_new_cache": "passed"},
        ))
    assert not reads._authoritative_closes and not reads._verified_close_references
    results.append({"snapshot_exit_resets": "passed"})
    return results


class HashKey(str):
    calls = Counter()

    def __hash__(self):
        type(self).calls["hash"] += 1
        return str.__hash__(self)

    def __eq__(self, other):
        type(self).calls["equal"] += 1
        return str.__eq__(self, other)


def keyview_probe(size):
    # The native dict_keys operator is retained; hashable string subclasses only
    # expose actual operand hash/equality visits. This is not a timing proxy.
    cache = {HashKey(f"cached-{i}"): None for i in range(size)}
    requested = {"cached-0", "absent"}
    HashKey.calls.clear()
    missing = requested - cache.keys()
    native = dict(HashKey.calls)
    HashKey.calls.clear()
    bounded_missing = {key for key in requested if key not in cache}
    bounded = dict(HashKey.calls)
    assert missing == bounded_missing == {"absent"}
    return {"cache_keys": size, "native_keyview_difference": native,
            "requested_membership": bounded}


def manifest():
    paths = sorted((ROOT / "src" / "ai_accounting" / "kernel").rglob("*.py"))
    return {str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths}


def main():
    global MONTHS
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--group", choices=("all", "authority-only"), default="all")
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    before = manifest()
    with args.output.open("x+", encoding="utf-8") as target:
        report = {"status": "running", "kind": "synthetic_cache_shape_work_not_timing",
                  "group": args.group,
                  "source_sha256": before, "cache_cases": [], "boundaries": [],
                  "keyview_cases": [], "errors": [],
                  "scope": "2 real fixture closes; padding keys measure only unrequested container size"}

        def checkpoint():
            target.seek(0)
            json.dump(report, target, indent=2, ensure_ascii=False)
            target.write("\n")
            target.truncate()
            target.flush()

        checkpoint()
        try:
            with tempfile.TemporaryDirectory(prefix="stage9-close-cache-", dir=ROOT / ".tmp") as name:
                engine = engine_fixture.__wrapped__(Path(name))
                MONTHS = tuple(sorted(series(engine, months=2)))
                shape = "authority-only" if args.group == "authority-only" else "mixed"
                for size in (12, 48, 120):
                    report["cache_cases"].append({
                        "cache_months": size, "requested_keys": 2, "shape": shape,
                        "native": cache_probe(engine, size, False, shape),
                        "bounded": cache_probe(engine, size, True, shape),
                    })
                    checkpoint()
                if args.group == "all":
                    for bounded in (False, True):
                        report["boundaries"].append({"bounded": bounded,
                                                     "checks": boundaries(engine, bounded)})
                        checkpoint()
                    for size in (12, 48, 120, 2000):
                        report["keyview_cases"].append(keyview_probe(size))
                        checkpoint()
            report["source_unchanged"] = before == manifest()
            if not report["source_unchanged"]:
                raise RuntimeError("production source changed; not a fixed candidate")
            report["status"] = "diagnostic_completed"
            checkpoint()
        except BaseException as error:
            report["status"] = "failed"
            report["source_unchanged"] = before == manifest()
            report["errors"].append({"type": type(error).__name__, "message": str(error),
                                     "traceback": traceback.format_exc()})
            checkpoint()
            raise
    print(json.dumps({"status": report["status"], "output": str(args.output)}))


if __name__ == "__main__":
    main()
