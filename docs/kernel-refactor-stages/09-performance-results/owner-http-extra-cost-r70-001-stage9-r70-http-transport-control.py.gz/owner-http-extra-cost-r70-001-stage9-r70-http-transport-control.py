"""Synthetic transport control only: no DB, Vue, business verification or 500ms acceptance.

Run explicitly with --execute after the owner authorizes the measurement window.
Uses unchanged fixed-r70 create_server and Handler.reply, plus local reply instrumentation.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import socket
import subprocess
import sys
import threading
import time
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

WORKSPACE = Path(__file__).resolve().parents[1]
SOURCE = WORKSPACE / ".tmp/stage9-build-source-owner-r70-release"
SOURCE_SHA = "402024802800938685bfb59983e6d717ae32fa55c555bad0a3ced3f3d8a8e404"
MANIFEST_SHA = "e41c270d929a371fa2f4afad6a301ae012dea3a7174a39e46b14824c7f297398"
NODE = Path("D:/Program Files/nodejs/node.exe")
PLAYWRIGHT = "C:/Users/MD01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright"
SIZES = (136, 4096, 32768, 131072)
ORDER = (False, True, True, False)
SIMULATION_TOKEN = "stage9-synthetic-transport-only-not-a-real-credential"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def source_guard():
    raw = (SOURCE / "source-manifest.json").read_bytes()
    manifest = json.loads(raw)
    if sha(raw) != MANIFEST_SHA or manifest["sha256"] != SOURCE_SHA:
        raise ValueError("Fixed-r70 source manifest changed")
    # Source I/O is performed before any timed browser fetch, without DB reads.
    for relative, digest in manifest["files"].items():
        path = (SOURCE / relative).resolve()
        if not path.is_relative_to(SOURCE.resolve()) or sha(path.read_bytes()) != digest:
            raise ValueError(f"Fixed-r70 source file mismatch: {relative}")
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(SOURCE / "src"))
    from ai_accounting.kernel import http
    if Path(http.__file__).resolve() != (SOURCE / "src/ai_accounting/kernel/http.py").resolve():
        raise ValueError("Mixed-source HTTP import")
    return http


def payload(size):
    prefix, suffix = b'{"padding":"', b'"}'
    value = prefix + b"A" * (size - len(prefix) - len(suffix)) + suffix
    if len(value) != size:
        raise ValueError("Payload size mismatch")
    return value


class SyntheticService:
    """Only the already-serialized dashboard_context route; no storage/security objects."""

    def dispatch(self, command, query, *, session_token, response_format):
        if command != "dashboard_context" or response_format != "http_json":
            raise ValueError("Only simulated serialized dashboard_context is supported")
        if session_token != SIMULATION_TOKEN or set(query) != {"size", "sample"}:
            raise ValueError("Only synthetic local requests are supported")
        return payload(int(query["size"])) if int(query["size"]) in SIZES else self.reject()

    @staticmethod
    def reject():
        raise ValueError("Unknown payload size")


def instrument(server, enabled, block, records, lock):
    handler = server.RequestHandlerClass
    baseline = handler.disable_nagle_algorithm
    if baseline is not False:
        raise ValueError("Expected unchanged r70 inherited default disable_nagle_algorithm=False")
    if enabled:
        handler.disable_nagle_algorithm = True
    original = handler.reply

    def measured_reply(self, status, body, content_type="application/json; charset=utf-8", **kwargs):
        query = parse_qs(urlsplit(self.path).query)
        is_sample = urlsplit(self.path).path == "/api/dashboard/context"
        before = self.connection.getsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY)
        started = time.perf_counter_ns()
        try:
            return original(self, status, body, content_type, **kwargs)
        finally:
            ended = time.perf_counter_ns()
            if is_sample:
                with lock:
                    records.append({
                        "block": block, "disable_nagle_algorithm": enabled,
                        "sample": query.get("sample", [None])[0],
                        "requested_size": int(query.get("size", ["0"])[0]),
                        "status": status, "reply_body_bytes": len(body),
                        "reply_body_sha256": sha(body),
                        "reply_ms": (ended - started) / 1e6,
                        "tcp_nodelay_before": before,
                        "tcp_nodelay_after": self.connection.getsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY),
                        "server_protocol_version": self.protocol_version,
                        "client_request_version": self.request_version,
                    })
    handler.reply = measured_reply
    return {"block": block, "disable_nagle_algorithm": enabled,
            "inherited_default": baseline, "url": f"http://127.0.0.1:{server.server_port}"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execute", action="store_true", help="Explicitly permit synthetic transport measurement")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--samples", type=int, default=11)
    parser.add_argument("--warmups", type=int, default=3)
    parser.add_argument("--channel", choices=["msedge"], default="msedge")
    args = parser.parse_args()
    if not args.execute:
        parser.error("Preparation only: --execute is required to run the measurement")
    if args.samples < 11 or args.warmups < 3:
        parser.error("Each block/size requires at least warm3 and measured11")
    output = args.output.resolve()
    if output.parent != (WORKSPACE / ".tmp").resolve() or not output.name.startswith("stage9-") or output.suffix != ".json":
        raise ValueError("Output must be a new stage9-*.json directly under workspace .tmp")
    directory = output.with_suffix("")
    if output.exists() or directory.exists():
        raise FileExistsError("Output or companion directory already exists; no overwrite")
    if not NODE.is_file() or not Path(PLAYWRIGHT).is_dir():
        raise FileNotFoundError("Required Node/Playwright runtime unavailable")
    http = source_guard()
    # Exclusive creation precedes any server/browser activity.
    directory.mkdir()
    static = directory / "static"
    static.mkdir()
    with (static / "index.html").open("x", encoding="utf-8") as handle:
        handle.write("<!doctype html><meta charset=utf-8><title>Synthetic transport control</title><p>Simulated JSON; no Vue or business data.</p>")
    records, lock, servers, threads, blocks = [], threading.Lock(), [], [], []
    result = {"status": "starting", "scope": "synthetic HTTP transport control; no business verification or 500ms acceptance",
              "source_sha256": SOURCE_SHA, "source_manifest_sha256": MANIFEST_SHA,
              "order": ["off", "on", "on", "off"], "sizes": list(SIZES),
              "samples_per_size_per_block": args.samples, "warmups_per_size_per_block": args.warmups,
              "reply_ms_scope": "Handler.reply send calls only; not client receive completion or TCP acknowledgement"}
    with output.open("x", encoding="utf-8") as report:
        try:
            for block, enabled in enumerate(ORDER):
                server, _ = http.create_server(SyntheticService(), static_directory=static, token=SIMULATION_TOKEN)
                servers.append(server)
                blocks.append(instrument(server, enabled, block, records, lock))
                thread = threading.Thread(target=server.serve_forever, daemon=True)
                threads.append(thread)
                thread.start()
            config = {"blocks": blocks, "sizes": list(SIZES), "samples": args.samples,
                      "warmups": args.warmups, "channel": args.channel,
                      "playwright_module": PLAYWRIGHT, "simulation_token": SIMULATION_TOKEN}
            config_path, browser_path = directory / "config.json", directory / "browser.json"
            with config_path.open("x", encoding="utf-8") as handle:
                json.dump(config, handle)
            process = subprocess.run([str(NODE), str(Path(__file__).with_suffix(".cjs")),
                                      str(config_path), str(browser_path)],
                                     capture_output=True, text=True, encoding="utf-8", timeout=900)
            with (directory / "node-stdout.log").open("x", encoding="utf-8") as handle:
                handle.write(process.stdout)
            with (directory / "node-stderr.log").open("x", encoding="utf-8") as handle:
                handle.write(process.stderr)
            if process.returncode:
                raise RuntimeError(f"Browser driver failed: exit {process.returncode}")
            browser = json.loads(browser_path.read_text(encoding="utf-8"))
            expected_count = 4 * len(SIZES) * (args.samples + args.warmups)
            if len(browser["samples"]) != expected_count or len(records) != expected_count:
                raise ValueError("Browser/server sample counts differ")
            by_id = {row["sample"]: row for row in records}
            if len(by_id) != expected_count:
                raise ValueError("Server sample IDs are not unique")
            for row in browser["samples"]:
                server_row = by_id[row["sample"]]
                expected = payload(row["size"])
                if (not row["raw_bytes_equal"] or row["status"] != 200
                        or row["body_bytes"] != len(expected) or row["body_sha256"] != sha(expected)
                        or server_row["reply_body_sha256"] != sha(expected)
                        or server_row["status"] != 200
                        or server_row["tcp_nodelay_before"] != int(ORDER[row["block"]])
                        or server_row["tcp_nodelay_after"] != int(ORDER[row["block"]])):
                    raise ValueError(f"Response or actual TCP_NODELAY mismatch: {row['sample']}")
                row["server"] = server_row
            result.update(status="complete", browser=browser,
                          total_samples=expected_count, measured_samples=4 * len(SIZES) * args.samples,
                          conclusion="Control observations only; class setting alone does not establish a Nagle root cause")
        except BaseException as exc:
            result.update(status="failed", error=f"{type(exc).__name__}: {exc}", server_samples=records)
            raise
        finally:
            for server in servers:
                server.shutdown()
                server.server_close()
            for thread in threads:
                thread.join(timeout=5)
            json.dump(result, report, ensure_ascii=False, indent=2)
            report.write("\n")
    print(json.dumps({"status": result["status"], "output": str(output)}))


if __name__ == "__main__":
    main()
