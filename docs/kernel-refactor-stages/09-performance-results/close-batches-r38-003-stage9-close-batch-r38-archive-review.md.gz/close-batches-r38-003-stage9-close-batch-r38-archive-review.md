# r38 精确关账内容批读：归档与报告复核

只读复核，GPT-6 Sol / high；未运行测试、插桩、计时或大范围扫描。核对时 `stage9-main48-verification-r38.json` 状态仍为 `measuring`，本文件不把它写成通过。

## 证据性质

| 证据 | 当前结论 | 性质 |
| --- | --- | --- |
| `.tmp/stage9-group-r38/result.json`、两片日志及 JUnit | 固定候选摘要 `f1929d...`；仓库源码前后摘要同为 `157f34...`；24 文件，184+182=366 项通过，两个进程退出码均为 0 | **本组固定源码回归**，不是第 9 阶段全量或浏览器验收 |
| `.tmp/stage9-close-batch-response-parity-r38-v2.json` 及 12／48 月各六入口原始响应 | 12 对均只在 `generated_at`、`data.generated_at`、`checked_at`、`read_context.read_version` 变化，业务字段相同 | **原生响应对照诊断**；并非整页 30 次验收 |
| `.tmp/stage9-close-batch-work-comparison-r38.json`、r37/r38 profile JSON | 48 月 SQL 次数 context 354→31、brief 父路径 1185→595、funds 495→269、assets 1220→622、reports 635→312，employees 287 不变；funds VM 862800→863000 | **插桩工作量诊断**；brief 仅父进程，排除 3 worker 总量；并行于回归／核验，不可据耗时判断净收益 |
| `.tmp/stage9-position-missing-r37-probe.json` | r37 反向缺 typed 分类查询替代方案的负面工作量，含 2M VM 中断上限 | **未采用方案诊断**；不表示缺行检查可排除 |
| `.tmp/stage9-main12-browser-diagnostic-r37.json` | 每页 5 次、带 HTTP 插桩 | **旧候选定位诊断**；不是 r38 整页结果或最终 30 次验收 |
| `.tmp/stage9-main48-verification-r38.json` | 观察时 `measuring` | **正在进行的完整核验**；只在最终状态、覆盖与 limitations 由原始结果证实后才能写成通过 |
| 独占净耗时、主 120 月、五页每页 30 次 | 尚无本组完成结果 | **正式验收待做**；不能改写为排除或已证净收益 |

## 建议归档的本组原始文件

1. **候选身份和测试链**：`.tmp/stage9-prepare-r38.log`、`.tmp/stage9-release-candidate-work-r38/candidate-provenance.json`、`.tmp/stage9-group-r38/result.json`、`.tmp/stage9-group-r38-tests.txt`、`.tmp/stage9-group-r38.log`、`.tmp/stage9-group-r38/shard-{1,2}.log`、`.tmp/stage9-group-r38/shard-{1,2}-junit.xml`。保留 JUnit 逐项和原 stdout，不只留汇总。候选快照本体很大，可保留源摘要与下述定向 diff；不要把隔离候选称为仓库正式冻结。
2. **r37→r38 代码对照**：归档基于 `.tmp/stage9-build-source-r37-release` 与 `.tmp/stage9-build-source-r38-release` 的定向 unified diff，至少覆盖 `src/ai_accounting/kernel/{close_storage.py,query_reads.py,reports.py}`、`tests/kernel/{test_close_management_sections.py,test_t7_quarter_coverage.py}`，并把新建的 `tests/kernel/test_close_storage_batch_io.py` 作为新增文件列明。已对这些已知路径读哈希：前三个生产文件及两份既有测试变化，`test_query_reads.py`、`test_close_accounting_filter.py` 未变；没有执行整个候选目录差异扫描。diff 应记录所比候选和两端摘要，别以工作区 `git diff` 冒充 r37→r38。
3. **工作量和原始响应**：`.tmp/stage9-remaining-profile-{r37,r38}.json`、同名 `.py`、`.log`；两候选 12／48 月 `context/brief/funds/employees/assets/reports` 的 `*.response.json`（各 12 份）、需要复算热点的 `*.pstats` 与 `*.txt`；`.tmp/stage9-close-batch-work-comparison-r38.json`。后者的 `equal_except_generated_at=false` 对多数页只是未排除构建绑定 `read_version`，所以不能作为最终 parity 结论。
4. **完整响应对照的修正轨迹**：`.tmp/stage9-close-batch-response-parity-r38.json`（首轮，允许字段漏列导致误报）、`-v2.json`（修订结果）、`.tmp/stage9-close-batch-response-parity-r38.py` 与其导入的 `.tmp/stage9-native-close-batch-ab.py`。保留首轮失败，不把它写成业务差异；记录 `read_version` 排除依据和 12 个原始响应文件的 SHA。
5. **未采用方案与基线浏览器诊断**：`.tmp/stage9-position-missing-r37-probe.py/.json`；`.tmp/stage9-main12-browser-diagnostic-r37.json/.log` 及实际运行脚本／窗口记录（若另存）。2M VM 中断与带插桩浏览器样本都须原样保留。
6. **完整核验完成后追加**：`.tmp/stage9-main48-verification-r38.json/.log`、当前两份 `-progress-stack*.txt` 可作为过程证据；最终归档须以 `status=complete`、覆盖、limitations、源码身份和真实预览结果为准。目前零字节日志和 `measuring` JSON 只能标进行中，不能当成功回执。若验证失败，原失败也保留。

上述文件建议压缩至 `docs/kernel-refactor-stages/09-performance-results/` 的本组证据包并列一个文件／SHA 清单；不应将整个临时源码副本、样本数据库或 `.pstats` 展开文本塞入主报告。当前目录只见 `exact-close-content-batches.md`，未见 r38 本组原始证据包。

## 现有正式报告需要补清的地方

- `exact-close-content-batches.md` 的 366 回归与 12 对 parity 说法有原始证据；应给读者可追到的组回执、JUnit、parity v2、工作量 JSON 和候选身份清单链接。将 `f1929d...`（隔离候选）与 `157f34...`（组回归仓库源码）分别注明其摘要对象。
- 首轮批头正常路径报错及首轮响应对照误报是两类不同失败。报告目前都简述了修正，但归档须各保留失败输入／输出和修正后的测试或对照；若批头失败的原日志未独立保存，明确标“原日志未找到”，不可从最终 366 通过反推原失败记录已归档。
- 报告写了 `新增存储 13 项、消费者 7 项`，但本组总数来自 JUnit 184+182；建议用 JUnit 测试名对应这两个定向小组，避免把 20 项另加到 366。CLI/MCP/close/integrity/repair/backup/v1 是共用路径和受影响组覆盖；未单独给出 r38 原生 CLI/MCP 或完整备份／修复任务结果时，不写成那些入口已独立验收。
- 简报工作量表必须一直保留 **parent-only** 字样；全进程总 SQL／CPU、完整热刷新时延与收益仍未知。64 个键约束的是一轮原文装载，已核解码缓存会随请求增长；现有报告这两点已写清，归档摘要不要省掉。
- `r38` 48 月完整核验仍在运行；正式文档中“仍待验证”的措辞正确。待最终结果出来再按实际状态、coverage、limitations、预览及环境更新，不能用逐表复制、12 月或 366 项回归代替。主 120 月与正式浏览器 30 次也保持待验状态。

首轮日志来源已向运行者复核：消费者首轮 5 失败／1 通过及修正后定向 7 通过均直接输出在工具记录中，没有单独保存本地日志。此后固定源码组的 JUnit 和日志完整保留。`stage9-close-leaf-batch-tests.log` 属于更早的其他测试，不作为本轮失败证据；不重新构造一份看似原始的日志。
