import ctypes
from pathlib import Path
kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)
kernel32.GetCurrentThread.restype = ctypes.c_void_p
kernel32.QueryThreadCycleTime.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_ulonglong)]
kernel32.QueryThreadCycleTime.restype = ctypes.c_int
thread_handle = kernel32.GetCurrentThread()
def thread_cycles():
    count = ctypes.c_ulonglong()
    if not kernel32.QueryThreadCycleTime(thread_handle, ctypes.byref(count)):
        raise ctypes.WinError(ctypes.get_last_error())
    return count.value
source = Path(__file__).with_name('stage9-strict-line-validator-candidate-20261003-probe.py').read_text(encoding='utf-8')
source = source.replace('time.thread_time_ns()', 'thread_cycles()').replace('cpu_us_per_call', 'cpu_kcycles_per_call').replace('raw_cpu_us', 'raw_cpu_kcycles')
exec(compile(source, str(Path(__file__)), 'exec'))