import ctypes
from pathlib import Path
kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)
kernel32.GetCurrentThread.restype = ctypes.c_void_p
kernel32.QueryThreadCycleTime.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_ulonglong)]
kernel32.QueryThreadCycleTime.restype = ctypes.c_int
thread_handle = kernel32.GetCurrentThread()
def thread_cycles():
    count = ctypes.c_ulonglong()
    if not kernel32.QueryThreadCycleTime(thread_handle, ctypes.byref(count)):
        raise ctypes.WinError(ctypes.get_last_error())
    return count.value
source = Path(__file__).with_name('stage9-strict-line-validator-candidate-20261003-probe.py').read_text(encoding='utf-8')
source = source.replace('time.thread_time_ns()', 'thread_cycles()').replace('cpu_us_per_call', 'cpu_kcycles_per_call').replace('raw_cpu_us', 'raw_cpu_kcycles')
old_block = '''        if result and (len(result) < 2 or integrity.checked(debit_total) != integrity.checked(credit_total)):
            return OLD(lines, component, ident, opening=opening)
    except (ValidationError, ValueError):
        return OLD(lines, component, ident, opening=opening)
'''
new_block = '''        balanced = not result or len(result) >= 2 and integrity.checked(debit_total) == integrity.checked(credit_total)
    except (ValidationError, ValueError):
        return OLD(lines, component, ident, opening=opening)
    if not balanced:
        return OLD(lines, component, ident, opening=opening)
'''
assert source.count(old_block) == 1
source = source.replace(old_block, new_block)
# Failure fallback itself is outside try: preserve one original identifier coercion.
source = source.replace("checked_cases = 0", '''class CountingIdentifier:
    def __init__(self): self.calls = 0
    def __str__(self):
        self.calls += 1
        return 'ident-'+str(self.calls)
for bad in ([row()], [row(2),row(0,1)]):
    errors = []
    for fn in (OLD,candidate):
        ident = CountingIdentifier()
        try: fn(bad, 'synthetic', ident)
        except Exception as exc:
            errors.append((type(exc),exc.args,exc.details,ident.calls))
    assert errors[0] == errors[1], errors
checked_cases = 0''')
exec(compile(source, str(Path(__file__)), 'exec'))