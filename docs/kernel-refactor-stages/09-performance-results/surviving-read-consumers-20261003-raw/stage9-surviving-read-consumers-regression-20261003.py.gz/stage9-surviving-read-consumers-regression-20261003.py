import ast
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

root = Path(__file__).resolve().parents[1]
prefix = root / '.tmp/stage9-surviving-read-consumers-regression-20261003'
files = """test_verified_money_summary.py
test_funds_verified_money_effects.py
test_owner_funds_summary_scope.py
test_funds_bounded_reads.py
test_resident_reads.py
test_resident_read_guard_work.py
test_foundation_runtime.py
test_dashboard_projection.py
test_dashboard_transport.py""".splitlines()
nodes = """test_dashboard_funds_alignment.py::test_account_filter_covers_movements_beyond_the_first_500
test_dashboard_funds_alignment.py::test_http_fund_filters_and_cursors_are_company_scoped
test_funds_historical_account_identities.py::test_public_historical_zero_accounts_match_complete_scope_with_less_source_payload
test_funds_historical_account_identities.py::test_fixed_v1_keeps_complete_historical_source_reader
test_dashboard_reports_adapter.py::test_owner_report_keeps_authoritative_source_integrity_boundaries
test_dashboard_reports_adapter.py::test_closed_owner_report_export_uses_the_exact_preview
test_maintenance.py::test_source_damage_cannot_be_repaired_or_disguised
test_runtime_backup.py::test_online_backup_includes_committed_wal_and_is_standalone
test_runtime_backup.py::test_initial_portable_round_trip_and_rollover_are_verified
test_close_preview_intent.py::test_active_intent_keeps_only_immutable_exact_summary_and_no_caller_alias
test_offline_upgrade.py::test_nonempty_v1_frozen_adoption_survives_changed_v2_current_model""".splitlines()
selection = ['tests/kernel/' + x for x in files + nodes]
assert len(selection) == len(set(selection))
for node in nodes:
    filename, name = node.split('::')
    tree = ast.parse((root / 'tests/kernel' / filename).read_text(encoding='utf-8'))
    assert any(isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == name
               for n in tree.body), node
for filename in files:
    assert (root / 'tests/kernel' / filename).is_file(), filename
paths = {x.split('::')[0] for x in selection} | {
 'src/ai_accounting/kernel/runtime.py',
 'src/ai_accounting/kernel/resident_reads.py',
 'src/ai_accounting/kernel/dashboard_funds.py'}
hashes = {p: hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sorted(paths)}
command = [sys.executable, '-X', 'utf8', '-m', 'pytest', '-q', *selection,
           '--junitxml=' + str(prefix.with_suffix('.xml'))]
for suffix in ('.xml', '.log', '.json'):
    assert not prefix.with_suffix(suffix).exists(), suffix
started = time.time()
print(json.dumps({'status': 'starting', 'files': len(files), 'nodes': len(nodes),
                  'log': str(prefix.with_suffix('.log'))}), flush=True)
with prefix.with_suffix('.log').open('x', encoding='utf-8') as log:
    child = subprocess.Popen(command, cwd=root, stdout=log, stderr=subprocess.STDOUT)
    print(json.dumps({'child_pid': child.pid}), flush=True)
    result = child.wait()
record = {'started_unix': started, 'elapsed_seconds': time.time()-started,
          'exit_code': result, 'command': command, 'files_before': hashes,
          'files_unchanged': all(hashlib.sha256((root/p).read_bytes()).hexdigest() == h
                                 for p, h in hashes.items())}
prefix.with_suffix('.json').write_text(json.dumps(record, ensure_ascii=False, indent=2)+'\n',
                                     encoding='utf-8')
print(json.dumps({k: v for k, v in record.items() if k not in {'command', 'files_before'}}),
      flush=True)
sys.exit(result)
