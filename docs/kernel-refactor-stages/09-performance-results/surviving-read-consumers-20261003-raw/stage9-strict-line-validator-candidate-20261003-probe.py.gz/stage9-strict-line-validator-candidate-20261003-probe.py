import sys
sys.dont_write_bytecode = True
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
import json, random, statistics, time
from contextlib import nullcontext
from pydantic_core import SchemaValidator, ValidationError, core_schema as cs
from ai_accounting.kernel import integrity, content_history_context as context, types

MAX = types.MAX_FEN
OLD = integrity._lines
TEXT = cs.str_schema(strict=True, min_length=1)
AMOUNT = cs.int_schema(strict=True, ge=0, le=MAX)
def validator(opening):
    return SchemaValidator(cs.list_schema(cs.typed_dict_schema({
        'account': cs.typed_dict_field(TEXT),
        'debit': cs.typed_dict_field(AMOUNT),
        'credit': cs.typed_dict_field(AMOUNT),
        'cashflow': cs.typed_dict_field(cs.none_schema() if opening else cs.nullable_schema(TEXT)),
    }, strict=True, extra_behavior='forbid'), strict=True))
VALIDATORS = (validator(False), validator(True))
FAST_COUNT = 0

def candidate(lines, component, ident, *, opening=False):
    global FAST_COUNT
    # Non-plain subclasses keep original accepted types, exceptions and access behavior.
    if context.source_encoding() is not types or type(lines) is not list or type(opening) is not bool:
        return OLD(lines, component, ident, opening=opening)
    result = []
    debit_total = credit_total = 0
    for line in lines:
        if type(line) is not dict or any(type(key) is not str for key in line):
            return OLD(lines, component, ident, opening=opening)
        account = line.get('account')
        debit = line.get('debit')
        credit = line.get('credit')
        cashflow = line.get('cashflow')
        if (type(account) is not str or type(debit) is not int or type(credit) is not int
            or cashflow is not None and type(cashflow) is not str
            or bool(debit) == bool(credit)):
            return OLD(lines, component, ident, opening=opening)
        result.append((account, debit, credit, cashflow))
        debit_total += debit
        credit_total += credit
    try:
        VALIDATORS[opening].validate_python(lines)
        # Validator proves every amount nonnegative and in range, so prefix sums
        # are monotonic. Last sum checked is equivalent to checking every prefix.
        if result and (len(result) < 2 or integrity.checked(debit_total) != integrity.checked(credit_total)):
            return OLD(lines, component, ident, opening=opening)
    except (ValidationError, ValueError):
        return OLD(lines, component, ident, opening=opening)
    FAST_COUNT += 1
    return result

class IntChild(int): pass
class StrChild(str): pass
class ListChild(list): pass
class DictChild(dict): pass
class OddStr(str):
    def __bool__(self): return False
class OddDict(dict):
    def __getitem__(self, key):
        if key == 'debit': return 2
        return super().__getitem__(key)
class ExplodingDict(dict):
    def __iter__(self): raise RuntimeError('original shape access failed')
class FalseList(list):
    def __bool__(self): return False

def row(debit=1, credit=0, account='1001', cashflow=None):
    return dict(account=account, debit=debit, credit=credit, cashflow=cashflow)
def pair(amount=1, account='1001', cashflow=None):
    return [row(amount, 0, account, cashflow), row(0, amount, account, cashflow)]
def signature(fn, lines, opening):
    try:
        result = fn(lines, 'synthetic', 'line-id', opening=opening)
        return ('ok', result, [[type(v).__name__ for v in line] for line in result])
    except Exception as exc:
        return ('error', type(exc).__module__, type(exc).__name__, exc.args,
                getattr(exc, 'code', None), getattr(exc, 'details', None))

cases = [('empty', [], False), ('two', pair(), False), ('one', [row()], False),
         ('none', None, False), ('tuple', tuple(pair()), False),
         ('list-subclass', ListChild(pair()), False), ('false-list', FalseList(pair()), False),
         ('dict-subclass', [DictChild(x) for x in pair()], False),
         ('dict-override', [OddDict(x) for x in pair()], False),
         ('dict-explodes', [ExplodingDict(x) for x in pair()], False),
         ('str-subclass', pair(account=StrChild('1001')), False),
         ('str-bool-override', pair(account=OddStr('1001')), False),
         ('key-subclass', [{StrChild(k):v for k,v in x.items()} for x in pair()], False),
         ('unicode', pair(account='汉字\U0001f642\ud800', cashflow='现金流\n\t'), False),
         ('opening-ok', pair(), True), ('opening-flow', pair(cashflow='operating'), True),
         ('opening-int', pair(), 1), ('opening-none', pair(), None),
         ('max', pair(MAX), False), ('cumulative-overflow', pair(MAX) + pair(1), False),
         ('later-malformed-before-sum-overflow', pair(MAX) + pair(1) + [{}], False),
         ('individual-overflow-before-later-invalid', [row(MAX+1), {}], False),
         ('invalid-before-overflow', [{}]+pair(MAX+1), False),
         ('one-overflow', [row(MAX+1)], False),
         ('two-unbalanced', [row(2), row(0,1)], False),
         ('large-1000', pair(500) * 500, False),
         ('large-10000', pair(500) * 5000, False)]
for key in ('account','debit','credit','cashflow'):
    values = {'account': ['', None, 1, [], StrChild('ok'), OddStr('ok'), ' ', '\x00'],
              'debit': [True, False, 1.0, None, '1', -1, MAX+1, IntChild(1), 0, MAX],
              'credit': [True, False, 1.0, None, '1', -1, MAX+1, IntChild(0), 1, MAX],
              'cashflow': ['', True, 1, [], StrChild('ok'), OddStr('ok'), ' ', '\x00']}[key]
    for value in values:
        lines = pair()
        lines[0][key] = value
        cases.append((f'{key}:{type(value).__name__}:{repr(value)}', lines, False))
    lines = pair(); del lines[0][key]
    cases.append((f'missing:{key}', lines, False))
for item in [None, 1, [], (), 'line', {'account':'1001'}, dict(row(), extra=1)]:
    cases.append((f'invalid-row:{repr(item)}', [item]+pair(), False))
rng = random.Random(9)
for i in range(100):
    lines = sum((pair(rng.randint(1,10**10), account='科目-'+str(i), cashflow=None if i%2 else '流')
                 for _ in range(rng.randint(1,20))), [])
    cases.append((f'random-{i}', lines, False))
checked_cases = 0
for history in (None,1):
    with nullcontext() if history is None else context.historical_content(history):
        for name, lines, opening in cases:
            before = signature(OLD, lines, opening)
            after = signature(candidate, lines, opening)
            assert before == after, (history,name,before,after)
            checked_cases += 1
print(json.dumps({'exact_synthetic_cases': checked_cases, 'successful_native_calls': FAST_COUNT,
                  'pydantic_core_version': __import__('pydantic_core').__version__}, ensure_ascii=True))

# A small isolated CPU diagnostic. No DB, services or wall-clock acceptance.
benchmarks = [('2-lines', pair(500), 800), ('20-lines', pair(500)*10, 150),
              ('1000-lines', pair(500)*500, 8)]
for name, lines, reps in benchmarks:
    for fn in (OLD,candidate): fn(lines,'synthetic','bench')
    samples = {'old':[], 'native-candidate':[]}
    for trial in range(5):
        order = [('old',OLD),('native-candidate',candidate)]
        if trial%2: order.reverse()
        for label,fn in order:
            begin = time.thread_time_ns()
            for _ in range(reps): fn(lines,'synthetic','bench')
            samples[label].append((time.thread_time_ns()-begin)/reps/1000)
    medians = {key: statistics.median(values) for key,values in samples.items()}
    print(json.dumps({'rows':name,'reps_per_sample':reps,'samples':5,'cpu_us_per_call':medians,
                      'candidate_reduction_percent':100*(1-medians['native-candidate']/medians['old']),
                      'raw_cpu_us':samples}, ensure_ascii=True))