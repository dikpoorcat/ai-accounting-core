# Stage 9 resident 主文件中间守卫合并

2026-10-03。仅修改 runtime.py / resident_reads.py 及新增定向测试；未读取真实业务库，未修改 5173、资料、身份、draft/0、固定源、封包、主文档或 Git 提交。

## 已证实的重复与处理

warm resident 的原调用链是 pool._signature → public validate_reused_read_connection → pool._signature。三处都 require_local_database + assert_private_file；前后两处另有 stat 的 (st_dev, st_ino) 比较。主文件中间检查与前检查处于同一借用过程，未跨请求重用 ACL 证明。

现在 pool 仅在本次 _signature 完成路径、ACL、stat 且匹配 idle 文件身份后，调用 runtime._validate_reused_read_connection_at_private_path。此内部 continuation 接 Path，不接受用户 flag 或缓存证明。public validate_reused_read_connection 保留完整前路径/ACL 检查并调用同一 continuation。没有开放新客户端接口。

前后 _signature 完全保留，且最终检查仍位于 SQLite 设置、结构与身份核验之后、交付业务读取之前。sidecar 不在前主文件守卫覆盖范围，仍逐项 reject_reparse_path + assert_private_file，tighten=False，不能自动修复不安全权限。SQLite DBCONFIG、attached limit、五项 PRAGMA、cache_size、实际 sqlite_schema SQL 指纹、schema_meta/history、公司/税号/数据库身份、异常 discard、事务 rollback、authorizer/trace/progress 清理均保留。

## 实际工作量对照

新增 tests/kernel/test_resident_read_guard_work.py::test_warm_borrow_merges_only_middle_main_guard 分别在当前与 historical_content(1) 上下文运行。control 精确恢复原 warm 路由，即 pool 中间调用 public validator。它不是增加虚构业务读：两边完整真实 SQLite 校验和业务 SELECT 相同，trace SQL 序列逐项相等，结构 SQL 确实出现。

Windows 计数包装执行原 _assert_private_handle，真实 GetSecurityInfo 与 ACE 校验仍运行；路径包装执行原 require_local_database。合成真实 WAL/SHM 都存在。结果：

| 工作 | 原 public 中间路由 | 内部 continuation | 保留含义 |
| --- | ---: | ---: | --- |
| main local-path 检查 | 3 | 2 | 本次借用前后 |
| OS 私有 ACL 核验总数 | 5 | 4 | main 两次 + WAL/SHM 各一次 |
| main ACL 核验 | 3 | 2 | 本次借用前后 |
| WAL/SHM ACL 核验 | 各 1 | 各 1 | 独立实际对象 |
| SQLite SQL 序列 | 相同 | 相同 | 包含 actual SQL fingerprint 与身份 |

没有 CPU/浏览器/TTFB 测量；不能从这些工作量推断具体毫秒改善。1053 对象指纹属于固定 fa5c probe 的已有事实，本次不会用 schema_version cookie 代替它，也未新增跨请求业务 proof cache。

## 入口同类排查

| 路径 | 代码位置 | 处理决定 / 必要范围 | 验证边界 |
| --- | --- | --- | --- |
| 五页 context | service.py:456,480; dashboard.context; storage.py:307; resident_reads.py:110 | 公司绑定 defer 后首借用完整结构/身份；warm 借用适用本次合并 | pool 合成回归已跑，未重跑真实五页 |
| 五页 summary/default/detail/过滤/分页 | service.py:689 的 _HTTP_DASHBOARD_COMMANDS; QueryReads.snapshot | 同一 pool，每借用前后 guard，业务验证原样 | 未逐 URL 重跑；业务范围没有修改 |
| 目录 catalog | catalog.py:94,158,466 | 目录连接及其自身 fingerprint 仍必要，不属于 resident company 中间重复 | 未改目录；独立 runtime 验证已跑，未目录大回归 |
| CLI/MCP 普通业务与完整详情 | service.engine 默认 dashboard_read=False; catalog.py:473–490; storage.py:307 | 公共独立 connect 与 bind 的早期验证原样。绑定和后续操作是不同用途，不在本次合并 | 静态查得未改；未逐 CLI/MCP 回放 |
| 完整核验 | maintenance.py:12–20 | store.connection 后完整业务 integrity，不能用 pool ACL 合并省略成员、金额、来源检查 | 未执行大完整核验；这里只改前守卫的重复执行 |
| close/close preview | periods.py:695; service.py:414; engine transaction | 正式写入连接、预览 read-version race checks 保留 | 未写入/关账测试 |
| repair | maintenance.py:106 | 修复后的 verify_schema 与引用核验反映变化后的对象，必须保留 | 未执行维修 |
| backup/recover | backup.py:653,682,1284,1288 | source 与 candidate/恢复后库是不同对象/时间边界，独立路径、ACL、结构及内容核验必要 | 未运行备份/恢复；不存在本次 private helper 调用 |
| fixed v1 | content_history_context.py:16; content_v1.py:560; Store.connection | 版本化业务读取仍走公共 runtime/Store；guard continuation 无业务版本分支 | warm work 在 v1 上下文通过；未新造 released v1 包，也不宣称完整 v1 内容回归 |

全源码调用点查得 private continuation 仅 guarded public wrapper 与 pool 本次已核实路径两处。默认独立入口没有跳过路径/ACL 的参数。跨请求仍只缓存 SQLite 连接与旧 inode signature，旧 signature 必须与新 _signature 比较，不能代替新 ACL 检查。

## 定向回执

首轮：test_resident_read_guard_work.py + test_resident_reads.py，18 PASS / 1 FAIL。失败是新增 standalone 损坏断言误写 schema_mismatch；实际已正确抛出 KernelError(schema_fingerprint_mismatch)，并非守卫未拒绝。改为精确错误码，同时补 authorizer 清理覆盖。

复验：上述两文件 20 PASS（29.23s）。新增真实 Windows ACL 放宽通过 SetSecurityInfo 操作合成文件，覆盖借用前主 ACL、结构验证后主 ACL、WAL ACL、standalone public 前 ACL，均拒绝；restore 使用原 ensure_private_file。另有 unsafe DBCONFIG discard、standalone actual schema drift、authorizer 清理；现有 resident 测试覆盖真实文件更换、结构漂移、税号错误、foreign_keys/cache_size 改变、异常事务 discard、trace/progress 清理、线程等待及上限。

独立 runtime/sidecar：test_foundation_runtime.py -k 'validated_private_connection_opens_once or sidecar_prepare or runtime_retains_private_sidecars or verifier_meta_structure_history_identity_share_one_wal_snapshot'，8 PASS / 43 deselected（5.57s）。包含 standalone read/write、sidecar lifecycle/race bounded retry 与结构/历史/身份同 WAL snapshot。

两组共 28 PASS。没有大回归、qualification、浏览器、封包、数据库建库服务任务或 Git 提交；仅测试自身按已授权范围创建临时合成库。交接后停 IO，组级最终验证由 root 统一执行。
