"""Withdraw only the measured candidate; preserve source and unrun test evidence."""
import hashlib
import json
from pathlib import Path
import shutil

W = Path(__file__).resolve().parents[1]
B = W / '.tmp/stage9-build-source-directory-key-lookup-20261004'
C = W / '.tmp/stage9-build-source-compact-accounting-directory-20261004'
source = Path('src/ai_accounting/kernel/close_storage.py')
test = W / 'tests/kernel/test_close_compact_directory_work.py'
saved_test = W / '.tmp/stage9-compact-directory-unrun-extended-tests-20261004.py'


def sha(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


assert all(path.resolve().is_relative_to(W) for path in (test, saved_test, W / source))
assert sha(W / source) == sha(C / source)
assert not saved_test.exists()
before = sha(W / source)
test_sha = sha(test)
shutil.copyfile(B / source, W / source)
assert sha(W / source) == sha(B / source)
test.rename(saved_test)
assert sha(saved_test) == test_sha and not test.exists()
receipt = {
    'status': 'withdrawn', 'reason': 'same-window pure native assets median rose 50.28105ms; '
    'all descriptor SHA/scan retained but Python regex walk cost exceeds saved JSON allocation',
    'candidate_source_sha256': json.loads((C / 'source-manifest.json').read_text('utf-8'))['sha256'],
    'production_before_sha256': before, 'production_after_sha256': sha(W / source),
    'saved_unrun_extended_tests': str(saved_test), 'saved_unrun_extended_tests_sha256': test_sha,
    'old_reference_test_repair_retained': True,
    'no_database_frontend_contract_or_fixed_v1_changes': True,
}
with (W / '.tmp/stage9-compact-directory-withdrawal-20261004.json').open('x', encoding='utf-8') as handle:
    json.dump(receipt, handle, indent=2)
print(json.dumps(receipt), flush=True)
