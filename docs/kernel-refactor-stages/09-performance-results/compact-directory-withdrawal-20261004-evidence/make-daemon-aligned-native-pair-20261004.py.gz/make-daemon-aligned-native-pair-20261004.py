from pathlib import Path
W=Path(__file__).resolve().parents[1]
for label in ('baseline','current'):
    src=W/f'.tmp/stage9-directory-key-lookup-native-{label}-20261004.py'
    dst=W/f'.tmp/stage9-daemon-aligned-directory-native-{label}-20261004.py'
    assert not dst.exists()
    s=src.read_text('utf-8')
    s=s.replace(f'stage9-directory-key-lookup-native-{label}-20261004.json',f'stage9-daemon-aligned-directory-native-{label}-20261004.json')
    needle="bundle=production_bundle(); assert bundle.status=='draft'"
    assert needle in s
    s=s.replace(needle,"from ai_accounting.kernel.daemon import _prepare_static_runtime\n    prepared_bundle, prepared_models = _prepare_static_runtime()\n    bundle=production_bundle(); assert bundle is prepared_bundle\n    assert bundle.status=='draft'",1)
    s=s.replace("'script_sha256':sha(__file__),'before':before,", "'script_sha256':sha(__file__),'before':before,'runtime_setup': 'actual daemon _prepare_static_runtime; existing static model preparation retained, no GC policy change',")
    with dst.open('x',encoding='utf-8') as f:f.write(s)
