"""One fixed-source regression group, never a timing or qualification run."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

W = Path(__file__).resolve().parents[1]
S = W / '.tmp/stage9-build-source-compact-accounting-directory-20261004'
OUT = W / '.tmp/stage9-compact-directory-regression-20261004'
EXTRA = ('test_close_compact_directory_work', 'test_close_reference_selection_work', 'test_history_reads_v1_warm_cache', 'test_offline_upgrade_history_preservation', 'test_resident_service', 'test_foundation_backup', 'test_close_direct_contract', 'test_close_review_lifecycle') + ('test_close_cached_descriptor_work', 'test_period_balance_freeze', 'test_close_descriptor_work', 'test_close_physical_batch', 'test_close_reference_physical_batch', 'test_close_accounting_filter', 'test_asset_owner_frozen_scope', 'test_asset_owner_kind_sources', 'test_asset_owner_outcome_reads', 'test_asset_owner_outcome_reuse', 'test_dashboard_workforce_assets', 'test_dashboard_bounded_reads', 'test_dashboard_reports_adapter', 'test_dashboard_funds_alignment', 'test_period_balance_index_scope', 'test_query_reads', 'test_integrity_asset_card_close', 'test_frozen_voucher_header_binding', 'test_read_repair_version', 'test_runtime_backup')


def sha(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def main():
    assert Path(sys.prefix).resolve() == W / '.tmp-kernel-venv'
    assert not any(Path(str(OUT) + suffix).exists() for suffix in ('.json', '.log', '.xml'))
    manifest_path = S / 'source-manifest.json'
    manifest = json.loads(manifest_path.read_text('utf-8'))
    assert manifest['status'] == 'complete'
    sys.path.insert(0, str(S / 'scripts'))
    import snapshot_stage9_source as snapshot
    assert snapshot._inventory(S) == manifest['files'] == snapshot._inventory(W)
    files = {'tests/kernel/' + name + '.py' for name in EXTRA}
    assert all((W / name).is_file() for name in files)
    command = [sys.executable, '-B', '-X', 'utf8', '-m', 'pytest', *sorted(files),
               '-q', '--junitxml=' + str(OUT) + '.xml']
    result = {
        'status': 'started', 'source_sha256': manifest['sha256'],
        'source_manifest_sha256': sha(manifest_path),
        'files': sorted(files), 'command': command,
        'scope': 'affected native readers, five-page projections, current/fixed-v1 history, '
                 'integrity, repair and backup synthetic regressions; no performance claim',
    }
    start = time.perf_counter()
    with Path(str(OUT) + '.log').open('xb') as log:
        run = subprocess.run(command, cwd=W, stdout=log, stderr=subprocess.STDOUT, check=False)
    result['elapsed_seconds'] = time.perf_counter() - start
    result['exit_code'] = run.returncode
    result['source_inventory_unchanged'] = (
        snapshot._inventory(W) == snapshot._inventory(S) == manifest['files']
    )
    for suffix in ('.log', '.xml'):
        path = Path(str(OUT) + suffix)
        if path.is_file():
            result[suffix[1:] + '_sha256'] = sha(path)
    if Path(str(OUT) + '.xml').is_file():
        suites = ET.parse(str(OUT) + '.xml').getroot()
        result['counts'] = {key: sum(int(s.attrib.get(key, 0)) for s in suites.iter('testsuite'))
                            for key in ('tests', 'failures', 'errors', 'skipped')}
    result['status'] = 'passed' if run.returncode == 0 and result['source_inventory_unchanged'] else 'failed'
    Path(str(OUT) + '.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), 'utf-8')
    print(json.dumps(result, ensure_ascii=False), flush=True)
    assert result['status'] == 'passed'


if __name__ == '__main__':
    main()
