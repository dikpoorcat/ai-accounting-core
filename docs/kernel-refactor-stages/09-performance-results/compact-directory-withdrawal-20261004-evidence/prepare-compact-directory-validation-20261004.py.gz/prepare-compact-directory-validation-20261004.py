"""Prepare isolated evidence helpers, never alter product files or data."""
import hashlib
import json
from pathlib import Path

W = Path(__file__).resolve().parents[1]
S = W / '.tmp/stage9-build-source-compact-accounting-directory-20261004'
B = W / '.tmp/stage9-build-source-directory-key-lookup-20261004'


def sha(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def create(name, content):
    path = W / '.tmp' / name
    if path.exists():
        assert path.read_text('utf-8') == content
        return
    with path.open('x', encoding='utf-8', newline='\n') as handle:
        handle.write(content)


new = json.loads((S / 'source-manifest.json').read_text('utf-8'))
old = json.loads((B / 'source-manifest.json').read_text('utf-8'))
diff = {
    name: {'before': old['files'].get(name), 'after': new['files'].get(name)}
    for name in sorted(set(old['files']) | set(new['files']))
    if old['files'].get(name) != new['files'].get(name)
}
assert set(diff) == {
    'src/ai_accounting/kernel/close_storage.py',
    'tests/kernel/test_close_compact_directory_work.py',
}
receipt = {
    'status': 'verified', 'before_source_sha256': old['sha256'],
    'source_sha256': new['sha256'], 'source_manifest_sha256': sha(S / 'source-manifest.json'),
    'file_count': new['file_count'], 'differences': diff,
    'frontend_contract_fixed_v1_unchanged': True,
}
create('stage9-compact-directory-source-diff-20261004.json', json.dumps(receipt, indent=2) + '\n')
script = (W / '.tmp/run-directory-key-lookup-20261004.py').read_text('utf-8')
script = script.replace('stage9-build-source-directory-key-lookup-20261004', S.name)
script = script.replace('stage9-directory-key-lookup-regression-20261004', 'stage9-compact-directory-regression-20261004')
extra = (
    'test_close_compact_directory_work', 'test_close_reference_selection_work',
    'test_history_reads_v1_warm_cache', 'test_offline_upgrade_history_preservation',
    'test_resident_service', 'test_foundation_backup', 'test_close_direct_contract',
    'test_close_review_lifecycle',
)
assert all((W / 'tests/kernel' / (name + '.py')).is_file() for name in extra)
script = script.replace("EXTRA = (", 'EXTRA = ' + repr(extra) + ' + (', 1)
create('run-compact-directory-regression-20261004.py', script)
for stem in ('stage9-directory-key-lookup-profile-20261004',
             'stage9-daemon-aligned-directory-native-current-20261004'):
    script = (W / '.tmp' / (stem + '.py')).read_text('utf-8')
    target = ('stage9-compact-directory-profile-20261004' if 'profile' in stem
              else 'stage9-daemon-aligned-compact-native-current-20261004')
    script = script.replace('stage9-build-source-directory-key-lookup-20261004', S.name)
    script = script.replace(stem + '.json', target + '.json')
    script = script.replace(old['sha256'], new['sha256'])
    script = script.replace(sha(B / 'source-manifest.json'), sha(S / 'source-manifest.json'))
    script = script.replace("m['file_count']==770", "m['file_count']==" + str(new['file_count']))
    script = script.replace('stage9-directory-key-lookup-source-diff-20261004.json',
                            'stage9-compact-directory-source-diff-20261004.json')
    if 'profile' in stem:
        # Match daemon initialization while preserving instrumented-only scope.
        script = script.replace("bundle=production_bundle();", "from ai_accounting.kernel.daemon import _prepare_static_runtime\n    prepared_bundle, prepared_models = _prepare_static_runtime()\n    bundle=production_bundle(); assert bundle is prepared_bundle;")
    create(target + '.py', script)
print(json.dumps(receipt), flush=True)
