import hashlib
import json
from pathlib import Path

W = Path(__file__).resolve().parents[1]
S = W / '.tmp/stage9-build-source-directory-key-lookup-test-repair-20261004'
B = W / '.tmp/stage9-build-source-directory-key-lookup-20261004'
manifest = json.loads((S / 'source-manifest.json').read_text('utf-8'))
before = json.loads((B / 'source-manifest.json').read_text('utf-8'))
diff = {name: {'before': before['files'].get(name), 'after': manifest['files'].get(name)}
        for name in sorted(set(before['files']) | set(manifest['files']))
        if before['files'].get(name) != manifest['files'].get(name)}
assert set(diff) == {'tests/kernel/test_close_reference_selection_work.py'}
with (S / 'source-manifest.json').open('rb') as handle:
    manifest_sha = hashlib.file_digest(handle, 'sha256').hexdigest()
value = {'status': 'verified', 'source_sha256': manifest['sha256'],
         'source_manifest_sha256': manifest_sha, 'file_count': manifest['file_count'],
         'before_source_sha256': before['sha256'], 'differences': diff,
         'all_production_frontend_contract_fixed_v1_bytes_unchanged': True}
with (W / '.tmp/stage9-directory-test-repair-source-diff-20261004.json').open('x', encoding='utf-8') as handle:
    json.dump(value, handle, indent=2)
script = (W / '.tmp/run-directory-key-lookup-20261004.py').read_text('utf-8')
script = script.replace('stage9-build-source-directory-key-lookup-20261004', S.name)
script = script.replace('stage9-directory-key-lookup-regression-20261004', 'stage9-directory-test-repair-regression-20261004')
start = script.index('EXTRA = ')
end = script.index('\n', start)
modules = ('test_close_reference_selection_work', 'test_frozen_voucher_header_binding',
           'test_accounting_candidate_integrity', 'test_close_reference_physical_batch')
script = script[:start] + 'EXTRA = ' + repr(modules) + script[end:]
with (W / '.tmp/run-directory-test-repair-regression-20261004.py').open('x', encoding='utf-8') as handle:
    handle.write(script)
print(json.dumps(value), flush=True)
