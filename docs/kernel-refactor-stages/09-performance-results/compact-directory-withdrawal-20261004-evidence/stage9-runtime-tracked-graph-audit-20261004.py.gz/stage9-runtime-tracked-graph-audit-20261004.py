"""Import/object census only. No database read or performance acceptance."""
import gc
import hashlib
import importlib
import json
from pathlib import Path
import sys
import time
from collections import Counter

W = Path(__file__).resolve().parents[1]
S = W / '.tmp/stage9-build-source-directory-key-lookup-20261004'
OUT = W / '.tmp/stage9-runtime-tracked-graph-audit-20261004-r2.json'
assert Path(sys.prefix).resolve() == W / '.tmp-kernel-venv'
assert not OUT.exists()
sys.path.insert(0, str(S / 'scripts'))
import stage9_source
stage9_source.configure_source(S, W)
import snapshot_stage9_source as ss
m = json.loads((S / 'source-manifest.json').read_text('utf-8'))
assert m['sha256'] == '8473af5ed77f9c079bdf02912bca9c5070735a12a555df9601d22fd9e7fcb582'
assert ss._inventory(S) == m['files']

def census(label):
    start = time.perf_counter()
    counts, sizes, dict_shapes = Counter(), Counter(), Counter()
    objs = gc.get_objects()
    for o in objs:
        t = type(o)
        module = getattr(t, '__module__', '?')
        name = getattr(t, '__qualname__', '?')
        key = (module if type(module) is str else '<descriptor>') + '.' + (name if type(name) is str else '<descriptor>')
        counts[key] += 1
        try: sizes[key] += sys.getsizeof(o)
        except (TypeError, ValueError): pass
        if t is dict:
            if 'type' in o and type(o['type']) is str:
                dict_shapes['type:' + o['type']] += 1
            elif '__pydantic_core_schema__' in o:
                dict_shapes['model_namespace'] += 1
    n = len(objs)
    del objs
    return {'phase': label, 'tracked_objects': n, 'types': counts.most_common(30),
            'shallow_bytes': sizes.most_common(20), 'dict_shapes': dict_shapes.most_common(30),
            'gc_count': gc.get_count(), 'gc_stats': gc.get_stats(),
            'fixed_v1_modules': sorted(k for k in sys.modules if k.startswith('ai_accounting') and '_v1' in k),
            'modules': len(sys.modules), 'diagnostic_ms': (time.perf_counter()-start)*1000}

out = {'scope': 'diagnostic imports and tracked graph; does not read database or disable/change GC',
       'source_sha256': m['sha256'], 'phases': [census('before_runtime_imports')]}
for module in ('ai_accounting.kernel.types', 'ai_accounting.kernel.engine',
               'ai_accounting.kernel.dashboard', 'ai_accounting.kernel.catalog',
               'ai_accounting.kernel.response_contracts', 'ai_accounting.kernel.service'):
    start = time.perf_counter()
    try: importlib.import_module(module)
    except ModuleNotFoundError as exc:
        out.setdefault('import_errors', []).append({'module': module, 'missing': exc.name})
        continue
    phase = census(module)
    phase['import_ms'] = (time.perf_counter()-start)*1000 - phase['diagnostic_ms']
    out['phases'].append(phase)
out['source_inventory_unchanged'] = ss._inventory(S) == m['files']
out['status'] = 'diagnostic_complete'
with OUT.open('x', encoding='utf-8') as f: json.dump(out, f, ensure_ascii=False, indent=2)
for p in out['phases']:
    print(json.dumps({k:p[k] for k in ('phase','tracked_objects','types','fixed_v1_modules')},ensure_ascii=False))
