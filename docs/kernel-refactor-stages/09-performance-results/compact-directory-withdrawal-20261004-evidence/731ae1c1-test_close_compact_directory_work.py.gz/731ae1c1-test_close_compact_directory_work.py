"""Sparse native lookups retain full text authentication and fallback semantics."""

import json
import sqlite3
from contextlib import contextmanager
from dataclasses import replace
from types import SimpleNamespace

import pytest

from ai_accounting.kernel import close_storage
from ai_accounting.kernel.content_history_context import historical_content
from ai_accounting.kernel.contracts import KernelError
from ai_accounting.kernel.key_membership_filter import build_keys_filter
from ai_accounting.kernel.query_reads import QueryReads
from ai_accounting.kernel.types import canonical


@pytest.fixture
def storage():
    connections = []

    def make(count=32, *, transform=None, bad_block=False):
        connection = sqlite3.connect(":memory:")
        connections.append(connection)
        connection.row_factory = sqlite3.Row
        connection.executescript(
            "CREATE TABLE period_close(period INTEGER PRIMARY KEY);"
            + close_storage.CLOSE_STORAGE_DDL
        )
        # Explicit corruption cases also test the decoder below SQLite's normal
        # JSON constraint. Only this newly created in-memory fixture bypasses it.
        connection.execute("PRAGMA ignore_check_constraints=ON")
        headers = []
        for period in (1, 2):
            connection.execute("INSERT INTO period_close VALUES(?)", (period,))
            directories = {}
            for field in close_storage.ACCOUNTING_FIELDS:
                records = []
                for bucket in range(count):
                    body = canonical([[bucket, {"id": f"{period}-{field}-{bucket}"}]])
                    block_sha = close_storage._sha(body)
                    directory = canonical([[0, block_sha.hex(), 1]])
                    directory_sha = close_storage._sha(directory)
                    connection.execute(
                        "INSERT INTO close_storage_directory VALUES(?,?,?,?,?)",
                        (period, field, bucket, directory, directory_sha),
                    )
                    connection.execute(
                        "INSERT INTO close_storage_block VALUES(?,?,?,?,?,?)",
                        (period, field, bucket, 0, body, block_sha),
                    )
                    records.append([bucket, directory_sha.hex(), 1])
                directories[field] = records
            value = {"directories": directories, "subject_filter": build_keys_filter([])}
            text = canonical(value)
            if transform is not None:
                text = transform(text, value, period)
            connection.execute(
                "INSERT INTO close_storage_subroot VALUES(?,?,?,?)",
                (period, "accounting", text, close_storage._sha(text)),
            )
            headers.append(close_storage.CloseHeader(
                period, b"l" * 32, bytes([period]) * 32,
                {"subroots": {"accounting": close_storage._sha(text).hex()}},
            ))
        if bad_block:
            connection.execute(
                "UPDATE close_storage_block SET content='[]' "
                "WHERE period=2 AND field='vouchers' AND bucket=?", (count - 1,),
            )
        connection.execute("PRAGMA ignore_check_constraints=OFF")
        connection.commit()
        connection.execute("PRAGMA query_only=ON")

        class Store:
            registry = SimpleNamespace(content_version=2)

            @contextmanager
            def connection(self, *, read_only=False):
                assert read_only
                try:
                    yield connection
                finally:
                    connection.rollback()

        return SimpleNamespace(store=Store()), headers

    yield make
    for connection in connections:
        connection.close()


def read_buckets(reads, headers, selected, *, compact=True):
    roots = (
        close_storage._families_many(reads.connection, headers, "accounting")
        if compact else tuple(
            close_storage._family(reads.connection, header, "accounting") for header in headers
        )
    )
    parts = reads._verified_close_storage_parts
    close_storage._prime_buckets_many(reads.connection, [
        (header, root, field, selected)
        for header, root in zip(headers, roots, strict=True)
        for field in close_storage.ACCOUNTING_FIELDS
    ], parts)
    return {key: value for key, value in parts.items() if key[2] == "bucket"}


@pytest.mark.parametrize("count", [32, 128, 256])
def test_sparse_descriptor_materialization_does_not_grow(storage, monkeypatch, count):
    engine, headers = storage(count)
    original = close_storage._CompactAccountingDirectory.get
    materialized = []

    def counted(self, bucket, default=None):
        value = original(self, bucket, default)
        if value is not None:
            materialized.append(value)
        return value

    monkeypatch.setattr(close_storage._CompactAccountingDirectory, "get", counted)
    with QueryReads.snapshot(engine) as reads:
        actual = read_buckets(reads, headers, {0, 300})
        assert len(materialized) == 4
        assert actual[1, headers[0].storage_digest, "bucket", "adopted_results", 0] == {
            0: {"id": "1-adopted_results-0"}
        }
        assert actual[2, headers[1].storage_digest, "bucket", "vouchers", 300] == {}
        materialized.clear()
        read_buckets(reads, headers, {0, 300})
        assert not materialized
    with QueryReads.snapshot(engine) as reads:
        assert read_buckets(reads, headers, {0, 300}, compact=False) == actual


def altered(case):
    def transform(text, value, _period):
        records = value["directories"]["adopted_results"]
        if case == "spacing":
            return json.dumps(value)
        if case == "field_order":
            return json.dumps({"subject_filter": value["subject_filter"],
                               "directories": value["directories"]}, separators=(",", ":"))
        if case == "duplicate_top_key":
            return '{"directories":{},' + text[1:]
        if case == "duplicate_filter_key":
            return text.replace('"bit_count":8', '"bit_count":123,"bit_count":8')
        if case == "duplicate_bucket":
            records.append([0, "0" * 64, 999])
        elif case == "unsorted":
            records.reverse()
        elif case == "bool_bucket":
            records[0][0] = False
        elif case == "float_bucket":
            records[0][0] = 0.0
        elif case == "large_count":
            records[-1][2] = 10**10
        elif case == "nested_filter":
            value["subject_filter"]["unselected"] = {"nested": []}
        elif case == "unselected_bad_entry":
            records[-1] = []
        elif case == "trailing_comma":
            return text.replace('],"vouchers":', ',],"vouchers":', 1)
        elif case == "broken_filter":
            return text[:text.index('"subject_filter":')] + '"subject_filter":{broken}}'
        return canonical(value)
    return transform


@pytest.mark.parametrize("case", [
    "spacing", "field_order", "duplicate_top_key", "duplicate_filter_key",
    "duplicate_bucket", "unsorted", "bool_bucket", "float_bucket", "large_count",
    "nested_filter", "unselected_bad_entry", "trailing_comma", "broken_filter",
])
def test_noncanonical_data_retains_original_read_and_error(storage, case):
    engine, headers = storage(transform=altered(case))

    def observed(compact):
        with QueryReads.snapshot(engine) as reads:
            try:
                return "returned", read_buckets(reads, headers, {0}, compact=compact)
            except (KernelError, IndexError, KeyError, TypeError, ValueError) as exc:
                assert not reads._verified_close_storage_parts
                return "rejected", type(exc), getattr(exc, "code", None), str(exc)

    assert observed(True) == observed(False)


@pytest.mark.parametrize("mode", ["unowned", "v1"])
def test_noneligible_family_keeps_original_json(storage, mode):
    engine, headers = storage()
    if mode == "unowned":
        with engine.store.connection(read_only=True) as connection:
            connection.execute("BEGIN")
            roots = close_storage._families_many(connection, headers, "accounting")
    else:
        with QueryReads.snapshot(engine) as reads, historical_content(1):
            roots = close_storage._families_many(reads.connection, headers, "accounting")
    assert all(type(root["directories"]["adopted_results"]) is list for root in roots)


@pytest.mark.parametrize("mode", ["token", "root", "period", "field", "other_connection"])
def test_compact_family_does_not_escape_its_source_scope(storage, mode):
    engine, headers = storage()
    with QueryReads.snapshot(engine) as reads:
        root = close_storage._families_many(reads.connection, headers, "accounting")[0]
        connection, header, field = reads.connection, headers[0], "adopted_results"
        if mode == "token":
            reads._snapshot_token = object()
        elif mode == "root":
            header = replace(header, storage_digest=b"x" * 32)
        elif mode == "period":
            header = replace(header, period=3)
        elif mode == "field":
            root = {"directories": {"vouchers": root["directories"]["adopted_results"]}}
            field = "vouchers"
        elif mode == "other_connection":
            other, _ = storage()
            with other.store.connection(read_only=True) as connection:
                with pytest.raises(KernelError, match="关账私有存储"):
                    close_storage._directory_index(connection, header, root, field)
                return
        with pytest.raises(KernelError, match="关账私有存储"):
            close_storage._directory_index(connection, header, root, field)


def test_compact_family_preserves_late_failure_atomicity(storage):
    engine, headers = storage(bad_block=True)
    with QueryReads.snapshot(engine) as reads:
        prior = read_buckets(reads, headers, {0})
        before = dict(reads._verified_close_storage_parts)
        for _ in range(2):
            with pytest.raises(KernelError) as failure:
                read_buckets(reads, headers, {0, 31})
            assert failure.value.code == "content_integrity_failed"
            assert reads._verified_close_storage_parts == before
            assert {key: value for key, value in before.items() if key[2] == "bucket"} == prior


@pytest.mark.parametrize("path", ["single_cached", "single_empty", "batch_cached", "batch_empty",
                                  "reference_cached"])
@pytest.mark.parametrize("scope", ["new_token", "v1"])
def test_cached_and_negative_compact_consumers_still_check_scope(storage, path, scope):
    engine, headers = storage()
    with QueryReads.snapshot(engine) as reads:
        header = headers[0]
        root = close_storage._families_many(reads.connection, headers, "accounting")[0]
        parts = reads._verified_close_storage_parts
        close_storage._prime_buckets(reads.connection, header, root, "adopted_results", {0}, parts)
        parts[header.period, header.storage_digest, "family", "accounting"] = root
        parts["subject", "calculation", "ref"] = "owner"
        parts[header.period, header.storage_digest, "bucket", "adopted_results",
              close_storage._bucket("owner")] = {
            0: {"subject_id": "owner", "calculation_id": "ref"}
        }
        if scope == "new_token":
            reads._snapshot_token = object()

        def attempt():
            if path == "reference_cached":
                return close_storage.reference_leaf(
                    reads.connection, header, "adopted_results[*].calculation_id", 0, "ref",
                    _parts=parts,
                )
            buckets = set() if path.endswith("empty") else {0}
            if path.startswith("single"):
                return close_storage._prime_buckets(
                    reads.connection, header, root, "adopted_results", buckets, parts,
                )
            return close_storage._prime_buckets_many(
                reads.connection, [(header, root, "adopted_results", buckets)], parts,
            )

        before = dict(parts)
        with historical_content(1 if scope == "v1" else 0):
            with pytest.raises(KernelError, match="关账私有存储"):
                attempt()
        assert parts == before


def test_later_json_error_is_not_replaced_by_earlier_filter_error(storage):
    def transformed(text, value, period):
        if period == 1:
            value["subject_filter"]["hash_count"] = False
            return canonical(value)
        return altered("broken_filter")(text, value, period)

    engine, headers = storage(transform=transformed)
    with QueryReads.snapshot(engine) as reads:
        with pytest.raises(KernelError) as failure:
            close_storage._families_many(reads.connection, headers, "accounting")
        assert failure.value.details["record_id"] == "2"
        assert failure.value.details["reason"] == "storage_subroot_invalid"
        assert not reads._verified_close_storage_parts
