"""Read-only synthetic comparison of daemon static preparation and GC pauses."""

import argparse
import gc
import json
import statistics
import time
from collections import defaultdict
from pathlib import Path

from ai_accounting.kernel import daemon
from ai_accounting.kernel.catalog import Catalog
from ai_accounting.kernel.dashboard import Dashboard
from ai_accounting.kernel.engine import Engine
from ai_accounting.kernel.resident_reads import ResidentReadPool


parser = argparse.ArgumentParser()
parser.add_argument("--without-freeze", action="store_true")
args = parser.parse_args()

if args.without_freeze:
    original_freeze = gc.freeze
    gc.freeze = lambda: None
try:
    bundle, models = daemon._prepare_static_runtime()
finally:
    if args.without_freeze:
        gc.freeze = original_freeze

assert models is daemon._STATIC_RUNTIME[1]
freeze_count = gc.get_freeze_count()
root = Path(__file__).resolve().parent / "stage9-journal-main-12"
assert root.is_dir()
pool = ResidentReadPool()
catalog = Catalog(root, bundle)
companies = catalog.companies()
assert len(companies) == 1 and companies[0]["name"].startswith("阶段九合成")
page = Dashboard(Engine(catalog.bind(companies[0]["id"], read_pool=pool)))

events = defaultdict(list)
started = {}
iteration = [-1]


def callback(phase, info):
    generation = info["generation"]
    if phase == "start":
        started[generation] = time.perf_counter()
    else:
        elapsed = (time.perf_counter() - started.pop(generation, time.perf_counter())) * 1000
        events[(iteration[0], generation)].append(
            (elapsed, info.get("collected", 0), info.get("uncollectable", 0))
        )


gc.callbacks.append(callback)
rows = []
try:
    for index in range(11):
        iteration[0] = index
        start = time.perf_counter()
        response = page.brief("2016-12", limit=100, preparation="complete")
        elapsed = (time.perf_counter() - start) * 1000
        assert response["data"]["period_preparation"] is not None
        del response
        rows.append(
            {
                "iteration": index,
                "elapsed_ms": elapsed,
                "gc": {
                    str(gen): events[(index, gen)] for gen in (0, 1, 2)
                },
            }
        )
finally:
    gc.callbacks.remove(callback)
    pool.close()

gen2_ms = sum(item[0] for row in rows for item in row["gc"]["2"])
result = {
    "note": "synthetic read-only diagnostic; not acceptance timing",
    "without_freeze": args.without_freeze,
    "freeze_count_at_first_business_read": freeze_count,
    "warm_median_ms": statistics.median(row["elapsed_ms"] for row in rows[1:]),
    "gen2_total_ms": gen2_ms,
    "gen2_count": sum(len(row["gc"]["2"]) for row in rows),
    "rows": rows,
}
suffix = "without-freeze" if args.without_freeze else "with-freeze"
Path(__file__).with_name(f"stage9-daemon-static-gc-{suffix}.json").write_text(
    json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
)
print(json.dumps({key: value for key, value in result.items() if key != "rows"}, indent=2))
