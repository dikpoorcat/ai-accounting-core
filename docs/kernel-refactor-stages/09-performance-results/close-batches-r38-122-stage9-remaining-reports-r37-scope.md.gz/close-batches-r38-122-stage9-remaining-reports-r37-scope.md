# r37 剩余报表／资产性能：只读范围复核

固定源码为 `.tmp/stage9-build-source-r37-release`，SHA-256 `eee15731556fd7087541bf867eef166aa1006c59d5b3ad65e86a0313d40cb996`。本轮只读源码及既有诊断；未改生产文件、未跑新数据库探针、测试或计时。r37 五模块八处索引反转查询已修正，26 文件 336 项回归和主 12 月完整核验／真实关账预览通过；主 48 月完整核验、r37 五页浏览器时延仍未完成。最新独占五页计时属于 **r32**，不能记作 r37：48 月报表中位 616.2 ms、30/30 超线，资产中位 471.9 ms、2/30 超线。r33 报表计数双覆盖索引、r34 采用 authority SQL 批量化均在 r32 后，尚无同条件浏览器净收益。

## 已实证：真实工作与已排除的重复

| 根因范围 | 证据和 r37 当前行为 | 判断 |
| --- | --- | --- |
| 季报技术计数 `Reports.browser_report_details` | `reports.py:1916` 对公开计划的每个 `report_fact_id` 精确查 `fact_revision.subject_id → subject.kind`，只返回分类／所得税确认两个数。r30 48 月为 19,746 ID、约 256.7k VM、1 行 16 B；r33 原 PK 回查约 189 MB 进程读，新增两张 ID 前导覆盖索引后约 34 MB、CPU 约 172–188→47–63 ms，计数仍 19,729／16。r37 SQL 明确 `INDEXED BY` 这两张索引。 | 增长随公开计划真实历史 ID 数；已完成一项有实证的窄修复。r33 覆盖索引的整页收益尚未独占复测。不能按 typed 表、可修目录或减少计划历史范围代替权威 kind。 |
| 往来 `party_balance_rows → _party_delta` | `report_projection.py:786,813` 同快照按 cutoff/source 缓存成功结果；`_party_delta:265` 按 period/source/classification refs 缓存，`read_report_flow` 也按月复用。r24 主 48 月真实 HTTP／简报 worker：往来首次 938 份、后续报表 1,003 份，937 份交集只核读一次正文，后批只补 66 份；投影解码 1,004 次，等于并集。两个 party cutoff 为前一年末与本季末不同事实范围。 | 约 481 ms 的 r33 `party_balance_rows` profile 含贡献与 flow 子调用，不是可整体省掉的重复。开放贡献主体、anchor/body、依赖及分类都参与当期证明；没有已证 >50 ms 同源二次装载。 |
| 报表索引点查及进程 I/O | r30 48 月 deferred 季报约 1.20M VM、26,961 行、10.95 MB SQL 值；进程读取请求 47.15 MB，12 月为 1.84 MB。`read_open_contributions`、来源字节、依赖及当期凭证按精确 ID／期间查，输出字节随 12→48 月仅增约 1.22 MB。 | 进程请求不是物理盘读取；现有 EQP 未显示贡献正文无关全表扫。两阶段 header/rowid body 已作 r2 AB，48 月全页 VM +10,075、CPU 增，无稳定 I/O 收益，不重试。 |
| 资产卡来源／owner | `dashboard.py:4166` `_asset_card_sources` 四组最新卡选头、仅对被选事实取标量；简报只取卡数量、状态、项目余额，不读全部历史消费正文。`_assets:4261` 为所有卡计算金额／总数及筛选，才分页取来源详情。r27 48 月资产页取得、窄 owner、完整 owner 各有 47 个关账 slice；324 个唯一冻结块、683,247 B，不是同块重复物理读取。r32 同页先 `verify_sql_outcomes` 严格解析 192 个结果，`_selected_asset_member_heads` 对其中 96 个 owner 再取并解析约 1.10 MB，ID 全重合；但仍须 `digest(outcome)`、完整成员目录、依赖、顺序及身份比对。 | owner 二次正文／解析是已证同快照重复，私有 parsed-object 缓存上界只见数十 ms 且增加约 4.36 MiB 对象，未证明窄生命周期和坏源等价，不实施该缓存。资产页 r32 仅 2/30 超线，r34 后未测，先看净时延再定是否需要更改。 |
| 资产准备历史结果 | `domains/assets._required_asset_work` 用全部历史 `asset_consumption` 的 period、asset_id、completed_months 形成每卡连续月，并由 `Periods.collect_current_readiness` 保存精确 trace。r33 48 月 1,128 个该类唯一计算，占 1,428 次 `Store.calculation` 的 79%；所有 ID 不同。 | 这是完整准备的历史候选与来源证明，旧源损坏、缺成员、更正及 trace 不能由最新 47 份替代；r30 标量／latest 原型未证明等价，不重试。 |

## 尚待证：先观测，再决定是否实施窄修复

1. **先完成 r37 的独占五页整页计时和配套只读工作量归因。** 特别区分 r33 覆盖索引及 r34 `_selected_accounting` 两条 authority SQL 批读后的报表、资产净收益；r32 时间和 r33 插桩不可外推。若五页仍超线，分别记录报表 `browser_report_details`、`party_balance_rows`、`_report` 及资产 `_asset_card_sources`、owner、准备的同一请求 CPU、SQL VM／返回字节／精确 ID 数。不要把含子调用的 profile 时间相加。
2. **报表页仅有小而安全的待证范围：** 检查 r37 两张覆盖索引在新建 48／120 月合成库的实际 `EXPLAIN QUERY PLAN`、请求字节与完整页面时间；若仍见 scan，按给定精确 ID 的连接驱动与现有 `INDEXED BY` 做局部修复，同时保留 ID 计数和缺行 inner-join 语义。r37 这条 SQL 已明确索引，当前没有新退化证据，不能预先再改。
3. **资产 owner 若仍是主要缺口，先按 `fast_assets` 命中 owner 精确列清首次 `verify_sql_outcomes` 与二次读取的 ID／字节／解析 CPU，确认是否有窄的同一快照结果传递接口。** 任何实现须仅持有命中 owner，保留完整目录／摘要／依赖／身份核验，验证坏 outcome、坏成员、冲正和无命中。此前先宽后筛扩大零资产范围；窄加剩余原型需要跨层显式 proof，未证损坏 AB；不要重做 parsed 对象全缓存。
4. **`_assets` 当前仍对已由 `verify_sql_outcomes` 通过的单项 `asset_consumption` 再用 SQL `json_extract` 求金额／原因（`dashboard.py:4423–4467`）。** 这是静态可见的同请求第二次 outcome 字节访问；尚无具体重合 ID、返回字节或 CPU 证据，且 fallback 卡需要历史金额与 `zero_reason`。如资产实测仍超线，可只量该精确集合；不能直接删严格原文验证或把 SQL JSON 提取当 rawJSON 快路。
5. **报表 fallback／异常根与 120 月仍未量。** r24/r30 的成功根与 12／48 月样本不能证明坏根、异常分类、无 checkpoint 或 120 月范围；按真实分支必要性单列诊断，完整保留 fallback 和拒绝行为。当前没有足以实施的新报表算法改动。

## 调用方边界

| 消费者 | r37 共享关系和不能外推的范围 |
| --- | --- |
| 五页 | 季报 `Dashboard.quarterly_report→Reports._report(open/closed)→browser_report_details` 使用同一 `QueryReads`；简报的 `check_report_readiness→_report(_issues_only=True)` 在独立 worker 事务，不生成公开全量 ID 技术计数。简报 `_long_term_assets` 与资产 `_assets` 共用 `_asset_card_sources` 函数，但发生在各自请求；资金、员工页另有各自历史采用范围。`Dashboard._position` 与同快照报表可调用 `party_balance_rows` 成功缓存。 |
| CLI／MCP／service | `dashboard_quarterly_report` 同样调用浏览器技术计数；公开 `report`、`preview_export`／`confirm_export` 经完整 `_report`，保留全量来源 ID 和计划摘要，但没有 `browser_report_details` 两计数。CLI/MCP 的 dashboard 资产页走同 `_assets`；公开业务详情经 `BusinessQueries` 自己的主体／成员选择。 |
| 关账／准备 | `Periods.preview_close/close`、`BusinessQueries._period_readiness`、`check_report_readiness` 消费 issues-only 报表及资产历史准备 trace，在各自事务核验冻结来源；不能复用页面技术计数或 owner 成功对象。 |
| 完整核验／维修 | `integrity.verify_integrity→compare_open_contributions` 独立从权威源重建；`maintenance` 在修复前后完整核验并 `repair_open_contributions`。不是页面 `read_open_contributions` 的相同快照命中。资产成员和冻结采用也须独立内容检查。 |
| 备份／恢复 | `backup` 便携包和恢复走完整内容／合同核验，不能用页面当前 proof 或技术计数代替。 |
| 固定 v1 | `report_projection_v1`、`report_flow_v1`、`report_open_contribution_v1` 与 `history_reads_v1` 自有选择和历史 comparer；r37 的索引反转修复中 v1 精确 ID 查询单独调整。current 的 party 缓存、owner 传递或其他快路不能直接移入 v1。 |

证据主要见 `docs/kernel-refactor-stages/09-performance-results/` 的 `grouped-r32-browser-results.md`、`report-cover-r33.md`、`parent-report-profile-r33.md`、`grouped-report-party-overlap-r24.md`、`report-process-io-r30.md`、`payroll-head-and-asset-owner-r32.md`、`grouped-asset-owner-r27.md`、`index-query-plan-regression.md`，以及 `.tmp/stage9-asset-latest-read-scope-r34.md`。本记录只划清实施顺序和证明边界，不声称第 9 阶段性能已通过。
