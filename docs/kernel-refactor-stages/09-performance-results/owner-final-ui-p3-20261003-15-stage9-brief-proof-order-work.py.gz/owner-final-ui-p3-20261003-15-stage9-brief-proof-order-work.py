"""Process-local default brief proof-order work, never page timing acceptance."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
import tempfile
import traceback
from collections import Counter
from contextlib import contextmanager
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "src"), str(ROOT / "tests" / "kernel")]

from stage9_metrics import measure_work  # noqa: E402
from test_integrity_content import damage  # noqa: E402
from test_payroll_corrections import Company  # noqa: E402

from ai_accounting.kernel import dashboard, query_reads  # noqa: E402
from ai_accounting.kernel.contracts import KernelError  # noqa: E402
from ai_accounting.kernel.domains.cash import CashFunding  # noqa: E402
from ai_accounting.kernel.domains.transactions import Expense  # noqa: E402
from ai_accounting.kernel.types import YearMonth, canonical  # noqa: E402


def manifest():
    return {
        str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in sorted((ROOT / "src" / "ai_accounting" / "kernel").rglob("*.py"))
    }


def build(path, *, close_january=False):
    company = Company(path / "company.sqlite")
    for month in (1, 2, 3):
        period = f"2026-{month:02}"
        ids = []
        for number in range(6):
            subject = f"expense-{month}-{number}"
            company.save(Expense(
                period=YearMonth(period), counterparty_id="supplier-" + subject,
                amount_fen=10000 + number, expense_class="administration",
                creditor_kind="supplier",
            ), subject)
            ids.append(subject)
        if month == 1:
            company.save(CashFunding(
                period=YearMonth(period), actual_date="2026-01-01", owner_id="owner",
                cash_account_id="cash", funding_kind="capital", amount_fen=1000000,
            ), "funding")
            ids.append("funding")
        company.publish(*ids)
        if month == 1 and close_january:
            company.close(period)
    return company


def visible(response):
    response = {**response, "data": dict(response["data"])}
    response["data"].pop("generated_at", None)
    return response


@contextmanager
def observer(events):
    original = query_reads.verify_open_voucher_scope
    original_heads = query_reads._verify_publication_voucher_head_batch

    def scope(connection, through_period, **options):
        before = Counter(connection.counts)
        reads = query_reads._active_fact_reads.get()
        successful_before = dict(reads._verified_open_voucher_scopes)
        result = original(connection, through_period, **options)
        events.append({
            "event": "scope", "through": through_period,
            "posting_period": options.get("posting_period"),
            "prior_scopes": {str(key): value for key, value in successful_before.items()},
            "counters": dict(Counter(connection.counts) - before),
        })
        return result

    def heads(connection, rows, reads, scope_heads=None):
        events.append({"event": "heads", "rows": len(rows),
                       "physical_carried": scope_heads is not None})
        return original_heads(connection, rows, reads, scope_heads)

    with patch.object(query_reads, "verify_open_voucher_scope", scope), \
            patch.object(query_reads, "_verify_publication_voucher_head_batch", heads):
        yield


@contextmanager
def reordered(enabled):
    original = dashboard._brief_amounts

    def amounts(snap):
        # Only this known default brief request is changed. No snapshot-wide
        # hook, extra trust flag, cross-request cache or new calculation exists.
        snap.reads.verify_open_voucher_scope(snap.month)
        return original(snap)

    if enabled:
        with patch.object(dashboard, "_brief_amounts", amounts):
            yield
    else:
        yield


def measure(company, period, *, section=None, order=False):
    events = []
    with reordered(order and section is None), observer(events):
        work, response = measure_work(
            company.engine, lambda: dashboard.Dashboard(company.engine).brief(
                period, section=section, limit=20,
            ),
        )
    return {"work": work, "scope_events": events}, visible(response)


def pair(company, period, *, section=None):
    native, response = measure(company, period, section=section)
    ordered, compared = measure(company, period, section=section, order=True)
    assert response == compared, "order changed a complete response value"
    return {"period": period, "section": section, "native": native, "wide_first": ordered,
            "visible_digest": hashlib.sha256(canonical(response).encode()).hexdigest()}


def failure(company, period, *, order):
    try:
        measure(company, period, order=order)
    except KernelError as error:
        assert error.code == "content_integrity_failed"
        return {"code": error.code, "component": error.details.get("component"),
                "reason": error.details.get("reason")}
    raise AssertionError("damaged required source was accepted")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    before = manifest()
    with args.output.open("x+", encoding="utf-8") as target:
        report = {"status": "running", "source_sha256": before, "cases": [],
                  "boundaries": [], "errors": [],
                  "scope": "new synthetic production-bundle companies, work not latency"}

        def checkpoint():
            target.seek(0)
            json.dump(report, target, ensure_ascii=False, indent=2)
            target.write("\n")
            target.truncate()
            target.flush()

        checkpoint()
        try:
            with tempfile.TemporaryDirectory(prefix="stage9-proof-order-", dir=ROOT / ".tmp") as name:
                path = Path(name)
                for case, closed in (("multi_open", False), ("closed_jan", True)):
                    folder = path / case
                    folder.mkdir()
                    company = build(folder, close_january=closed)
                    periods = ("2026-03", "2026-02", "2026-01")
                    for period in periods:
                        report["cases"].append({"fixture": case, **pair(company, period)})
                        checkpoint()
                    if not closed:
                        for section in ("activity", "vouchers", "open_items"):
                            report["cases"].append({
                                "fixture": case, **pair(company, "2026-03", section=section),
                            })
                            checkpoint()
                        damage(company.engine, "voucher_current",
                               "DELETE FROM voucher_current WHERE voucher_id="
                               "(SELECT voucher_id FROM calculation_publication "
                               "WHERE subject_id='expense-1-0')")
                        report["boundaries"].append({
                            "damage": "other_required_open_month_head",
                            "native": failure(company, "2026-03", order=False),
                            "wide_first": failure(company, "2026-03", order=True),
                        })
                        checkpoint()
                folder = path / "future_damaged"
                folder.mkdir()
                company = build(folder)
                damage(company.engine, "calculation_publication",
                       "DELETE FROM calculation_publication WHERE subject_id='expense-3-0'",
                       foreign_keys=False)
                report["boundaries"].append({
                    "damage": "future_removed_publication_current_rejects",
                    "native": failure(company, "2026-03", order=False),
                    "wide_first": failure(company, "2026-03", order=True),
                })
                checkpoint()
                # Historical brief also renders present settlement state. A
                # future broken publication is therefore still a required
                # current-state source even though its money cutoff is earlier.
                report["boundaries"].append({
                    "damage": "future_removed_publication_historical_current_settlement_rejects",
                    "native": failure(company, "2026-02", order=False),
                    "wide_first": failure(company, "2026-02", order=True),
                })
                checkpoint()
            report["source_unchanged"] = before == manifest()
            assert report["source_unchanged"], "production source changed during diagnosis"
            report["status"] = "diagnostic_completed"
            checkpoint()
        except BaseException as error:
            report["status"] = "failed"
            report["source_unchanged"] = before == manifest()
            report["errors"].append({"type": type(error).__name__, "message": str(error),
                                     "traceback": traceback.format_exc()})
            checkpoint()
            raise
    print(json.dumps({"status": report["status"], "output": str(args.output)}))


if __name__ == "__main__":
    main()
