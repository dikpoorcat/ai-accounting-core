# r38 关账桶跨月批读独立只读审查

审查模型：GPT-6 Sol / high。范围：r37 剩余性能诊断、阶段 9 文档、当前工作区的 `close_storage.py`、`query_reads.py`、`reports.py`、固定 v1 读者及直接调用方。本文是源码审查；未执行重型性能或完整核验，其他代理正在修改的代码须以最后固定源码再验证。

## 已发现并交办的实际错误

`close_storage.verified_headers` 首版批 SQL 返回 `(period, storage_digest)` 与 `(source_id, source_digest)`，却将整行交给 `verified_header`，后者用 `storage[0]`、`marker[0]` 读取摘要。因此正常关账头被误判为 `storage_root_digest_mismatch`。季度报表相关测试在正常 3 月关账触发同一错误，证明不是仅静态猜测。已立即通知主代理；复看当前工作区，查询已改为把两种摘要放在首列。**修正已落地，尚不能把本审查写成测试通过。**后续须用不经 `authoritative_close_rows` 预热头缓存的真实多月 `reports._closed_report_fact_sources(..., reads=None)` 或 `QueryReads.close_readiness_checks` 成功路径复验，并覆盖 marker 损坏拒绝。现有 `test_close_accounting_filter.py` 成功用例先调用 `authoritative_close_rows`，会预先填入 `_close_headers`，因此无法发现批头错误。

## 本组调用边界

- r37 诊断中，12／48 月 `context` 各按 11／47 月逐个取关账根、marker、management subroot、目录与块；`reports` 的同类 readiness 读也分别有 11／47 次。`brief` 的桶目录与块选择各有 66／280 次，`funds` 各 22／94 次，`assets` 各 66／282 次。`BusinessQueries._selected_accounting` 已接 `QueryReads.close_accounting_many`；报告来源读走 `Reports._closed_report_fact_sources` → `close_readiness_checks` 或直接批读。五页的复用点确实跨 `context`、准备／简报、资金、资产、报表，不应只测单一页面。
- CLI／MCP 共用 `service` 的 `period_readiness` 和业务读取；关账核对详情的 `_render_frozen_keys` 仍按单个选定关账头调用 `read_accounting`／`read_section`，没有同一批跨月桶需求。正式 close、完整 integrity、repair、backup／restore 继续调用 `decode_close` 全量重建与完整目录核对；这些入口不能改走局部桶作为完整证明。固定 v1 经 `content_history_context.close_reader()` 选择 `close_storage_v1`；`QueryReads.close_accounting_many` 对 v1 明确退回逐月 `close_accounting`，`reports` 无 `reads` 时也逐月选 v1 的 `verified_header`／`read_readiness_check`。本组当前批 helper 只在 current reader 使用。

## 失败缓存与拒绝条件复核

- `QueryReads._staged_close_headers` 先局部收集，`close_readiness_checks` 只在 `read_readiness_checks_many` 整组返回后更新 `_close_headers`／`_close_sections`。`close_accounting_many` 同样在整组 `read_accounting_many` 返回后发布新头与切片。原本已在同快照独立核验成功的头不属于此次失败组的新发布。
- `close_storage.read_accounting_many` 的 `new_parts`、`new_positions` 是整组局部写层；各月 `read_accounting` 成功只写入该层，所有月份成功后才更新调用方的 `_verified_close_storage_parts` 与位置缓存。后续桶或 authority 比对失败时局部层丢弃。`QueryReads.snapshot` 退出重置缓存并禁止事务切换。代码路径符合“整组成功发布”；损坏末月后检查四种缓存仍为空的定向测试需要在固定源码通过，尤其避免先用 `authoritative_close_rows` 把头预置后误判新增头发布。
- `_stored_bucket_chunks` 每轮只查询最多 64 个精确 `(period, field, bucket)` 键的目录和原块；返回前一轮原文没有进入长期缓存，长期缓存仅存通过 `_bucket_rows` 摘要、块数和解码检查后的 `by_position`。`ACCOUNTING_FIELDS` 仅为 `adopted_results`、`vouchers`，readiness 只取指定 `readiness:<name>`。在正常主键约束下，同桶额外 `part` 使原块数与目录描述数不符；缺块使数目不符或指定 part 缺失；正文或摘要损坏也拒绝。若以“缺一块加一额外块”保持数目，逐个指定 part 仍会发现缺块。跨桶／跨字段的孤儿目录和原块属于 `decode_close` 全量核验，不是局部读取承诺。
- 64 是**原文桶键批次**上界，不是整个请求已核解码内容的内存上界；`new_parts` 按所请求月与命中桶累积。这符合同快照复用设计，后续工作量记录应分别给出原文峰值和已核缓存规模，不把两者混称。

## 固定源码收口建议

1. 在批头首列修正后，跑正常多月季度来源与 readiness 的无缓存路径，再做一处晚月 marker／subroot／目录／额外块损坏，确认正常路径能到业务断言，失败路径的四种新缓存都不发布。记录修正前失败和修正后结果，勿改写原失败。
2. 对同一组 12／48／120 月精确主体，对照单月读与跨月批读的切片及完整页面响应，并记录 SQL VM、返回行／字节、原文批次数和峰值。r37 插桩只是待优化基线，不能代替 r38 结果或独占五页计时。
3. 保留 v1 非空历史独立校验，以及 close／integrity／repair／backup 的全量解码与额外目录／块拒绝；这些边界已在代码中分开，需由固定源码的相关定向回归确认。

## 末次只读复核：`AccountingBucketSelection` 与回调分块

主代理通知本组修改已完成、13 项定向测试通过；本次未运行测试，只对新源码复核。`_AccountingBucketSelection` 仅由 `read_accounting_many` 在同一次循环中从已认证 accounting subroot 的 filter 算出，传给同组的 `read_accounting`。`for_close` 同时比对连接对象、期间、存储根摘要和完整主体集合；`_AccountingAuthorityBatch` 另比对连接、根、高水位与主体。因此正常内部调用没有把一月或一组主体的桶结果借给另一组。filter 缓存与桶缓存以 `(period, storage_digest, ...)` 为键；纯哈希位置以 `(key, bit_count)` 复用，但每次仍读取当前已认证 filter 的 bits。未看到新缓存跨快照或跨根使用。

`_read_stored_bucket_chunks` 现在每 64 个精确键调用一次 `consume`，回调只将 `_bucket_rows` 已核验、且位置唯一的解码结果写入局部 `parts`。回调异常时后续 `clear()` 不执行，但栈退回会丢弃这轮原文容器；此前成功块只存在本次 `new_parts`，`read_accounting_many` 末尾的公开缓存更新不会执行。之后任一月的 authority／成员检查失败同理不发布 `new_parts`／`new_positions`，`QueryReads` 也不发布新 headers／slices。未发现这两处改动引入新的失败缓存漏洞。

这两个私有参数不是对任意外部调用者的安全边界；代码内唯一生产构造点受上述同组关系约束。原文读取上界仍是每批最多 64 个桶键，并非总解码缓存的字节硬上限。以上是源码结论，不把 13 项测试代替完整核验或性能验收。
