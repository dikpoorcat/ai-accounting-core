import json
from pathlib import Path
import subprocess
import sys
ROOT=Path(__file__).resolve().parents[1]
prefix=ROOT/'.tmp/stage9-r76-owner-read-lifecycle-constructor'
log=Path(str(prefix)+'-tests.log');assert not log.exists()
args=[sys.executable,'-X','utf8','-m','pytest','-q','tests/kernel/test_close_review_lifecycle.py']
with log.open('w',encoding='utf-8') as stream:
    result=subprocess.run(args,cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT,text=True)
output=Path(str(prefix)+'-tests.json');assert not output.exists()
output.write_text(json.dumps({'argv':args,'exit_code':result.returncode,'log':str(log.relative_to(ROOT))},indent=2),encoding='utf-8')
print(json.dumps({'exit_code':result.returncode,'log':str(log.relative_to(ROOT))}))
