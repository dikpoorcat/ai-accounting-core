# Asset member identity overlap — prepared, not executed

Exclusive helper `.tmp/stage9-asset-member-identity-overlap.py` binds fixed source `1c37c576cb0026b0b39c199b74672a60890c43a7d9e2b944416179fe2bf398e9`, source manifest bytes, complete module inventory, and main12 receipt `066dff5d70b1ae0a37d6f8f615c4242af2c0f6a6269c507f062a4a7bb739fa58`. Only existing synthetic root `.tmp/stage9-owner-main12-r43`, 2016-12, is accepted. Builder checkpoint, catalog/company identity, released schema and state are checked before/after. Catalog and company writes are rejected; unfinished operations stop rather than recover.

Exactly one normal `Dashboard.assets(period, limit=20, preparation="deferred")` call runs. A process-local wrapper records the untouched `_asset_member_identity_events` caller, actual owned snapshot, selected event count, exact unique owner IDs and authenticated selection kinds, frozen-owner IDs, requested asset IDs, successful identity-cache key presence, selection object reuse and existing full-member cache keys. It calls the original method with identical arguments and returns the identical result object. No source or proof implementation is replaced; complete selected owner-directory checks remain in place. Only returned owner/member/subject/asset identity tuples are recorded by the wrapper, never result or fact bodies.

Pairwise output includes exact owner intersection/union and returned owner/member intersection, retaining all IDs. The complete normal asset response and canonical response hash are saved, including amounts and summary. There is no second comparison read, new financial qualification, fullverify or preview. Failure keeps partial calls/logs and attempts ending guards; an unexpected unsupported selection is a recorded failure, not a guessed scope.

This is call-scope diagnosis, with no timer or work instrumentation. Owner overlap establishes repeated directory input, not identical proof duties or net benefit; filtering returned identities cannot shrink the complete owner proof. A successful existing owner-selection cache does not imply the member directory has been cached. Default main12 only: fixed-v1, fallback, custom filters/paging, main48/main120 and any optimization remain untested.

Root-controlled command after scheduling:

```powershell
.tmp-kernel-venv/Scripts/python.exe -B .tmp/stage9-asset-member-identity-overlap.py --report-sha256 066dff5d70b1ae0a37d6f8f615c4242af2c0f6a6269c507f062a4a7bb739fa58 --output .tmp/stage9-asset-member-identity-overlap-main12-1c37.json
```

Both output JSON and its `.log` must be absent. Standard output can be preserved separately by root. Preparation has not imported or executed the helper, run syntax checks/tests, opened any database, or modified production/fixed source. No implementation decision follows without actual overlap evidence and a subsequent benefit/proof assessment.
