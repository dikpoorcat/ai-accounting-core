# 主12报表已保存ResourceTiming归因

只解析现有3份JSON及source manifest元数据，未启动DB/浏览器/服务/新计时。全30次原timestamps与派生值见 stage9-main12-draft-report-resource-attribution-r2.json；r1派生版本未填source SHA/root而保留，r2仅补实际manifest SHA与synthetic_root。源浏览器原件完全未改。

|条件|report elapsed min/median/max|page等待responseStart min/median/max|render尾 min/median/max|超500|
|---|---|---|---|---|
|22ef draft主12，2016-12，本轮r1|396.3/436.3/536.7|362.6/402.0/506.7|21.3/29.6/41.2|1/30|
|1c37 released主12，2016-12，旧month-reads|395.8/417.2/457.4|368.4/389.1/432.0|21.5/29.1/40.6|0/30|
|6688 released主48，2019-12，旧reference-group|456.0/477.2/576.5|419.4/445.7/538.6|21.6/34.1/41.3|5/30|

三个条件不同source/format/root（且第三不同规模/季度），不是受控优化前后，也不归因月份发现收益/退化。controller证明本轮owned copy/qualification已暂停CPU并正常恢复，这是隔离证据，不证明本单个长请求根因。

本轮30个样本均只有1context+1quarterly-report，diagnostics空。page开始在click后0.4–0.8ms、context后0.1–0.3ms；context请求duration50–67ms（median56.3），page在等待context响应前就启动，实际并行。page发请求前1.2–2.1ms、响应接收0.3–1.0ms；没有重复默认请求或全页串行context迹象。

唯一慢样本为第2次：click3077.0，context start3077.4/request3078.6/responseStart3143.7/end3144.4；page start3077.6/request3079.0/responseStart3585.7/end3586.4；render3613.7。page等待506.7ms、duration508.8ms、接收0.7ms、render尾27.3ms（低于本轮29.6中位）。比中位多的主要部分在请求等待，非额外DOM尾延迟。该等待包含HTTP排队/调度/服务/security/catalog/engine/读取/合同响应，ResourceTiming不能把它等同某函数CPU。

根因组线索沿实际正常路径：HTTP/security/catalog/engine的公共每请求开销；report_projection期初/期末party余额、历史close-bound readiness/classification、开放contribution源/金额/relations核验及合同序列化是报表必要读范围。既有月份发现组不直接解释单个报表slow；两批贡献合计1004、缓存交集命中，不能重复算读两次。同样不能从该单样本新做GC/窗口/own-line孤立优化。准备一次22ef当前季度cProfile用于函数职责归因，非500ms复验，不重新六页work。

## 单次cProfile准备命令（未执行）

脚本 stage9-draft-period-main48-report-cprofile.py复用已知主48readonly bootstrap，固定22ef source/a73d construction report、实际draft factory/绑定/身份/epochs/checkpoint守卫。仅正常quarterly_report一次，保存完整profile条目+self/cumulative/calls、原.pstats及响应clock/SHA；没有预热、metrics/allpage/全verify/preview/native。默认明确current_source_full_verification=false，可提供实际完成的22ef当前资格report+SHA进行核对，不能假填。原work-first不重跑。

```powershell
& .tmp-kernel-venv/Scripts/python.exe -B -X utf8 .tmp/stage9-draft-period-main48-report-cprofile.py --months 48 --book-report .tmp/stage9-owner-main48-draft-period-group-construction-input.json --report-sha256 a73ded22688073e7aecb7a79d56a6e31d9d6be202e1083738b091d42d3671d93 --output .tmp/stage9-draft-period-main48-report-profile-first.json
```

JSON与同stem.pstats均must-new，root协调后独立运行；未执行任何诊断或编译检查。可选 --qualification-report <实际新资格报告> --qualification-sha256 <实际SHA>。此工具是native cProfile，不测HTTP/序列化边界之外的网络调度，也不声称复现主12第2次slow。以后关联当前source正常dispatch诊断须root另决定，不扩本任务。
