"""Pinned, read-only instrumented diagnostic; this is never browser acceptance timing."""

from __future__ import annotations

import cProfile
import hashlib
import json
import pstats
import sys
from contextlib import contextmanager
from pathlib import Path

WORKSPACE = Path(__file__).resolve().parents[1]
SOURCE = WORKSPACE / ".tmp/stage9-build-source-owner-draft-period-group-20261003"
MANIFEST = SOURCE / "source-manifest.json"
import argparse

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--months', type=int, choices=(48,), required=True)
parser.add_argument('--book-report', type=Path, required=True)
parser.add_argument('--report-sha256', required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--qualification-report', type=Path)
parser.add_argument('--qualification-sha256')

args = parser.parse_args()
BOOK_REPORT = args.book_report.resolve(strict=True)
OUTPUT = args.output.resolve()
assert BOOK_REPORT.is_relative_to(WORKSPACE / '.tmp')
assert OUTPUT.is_relative_to(WORKSPACE / '.tmp') and not OUTPUT.exists()
SOURCE_SHA256 = '22ef17f6aa6b40025eaf9fe939a209f15f7d4c73605e982925859fe42a1cfff3'
REPORT_SHA256 = 'a73ded22688073e7aecb7a79d56a6e31d9d6be202e1083738b091d42d3671d93'
assert args.report_sha256 == REPORT_SHA256, "Only this pinned draft construction input is permitted"
assert BOOK_REPORT == (WORKSPACE / '.tmp/stage9-owner-main48-draft-period-group-construction-input.json').resolve()
assert OUTPUT.name.startswith('stage9-draft-period-main48-report-profile-')
PSTATS = OUTPUT.with_suffix('.pstats')
assert not PSTATS.exists()


def file_hash(path):
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def main():
    require(
        Path(sys.prefix).resolve() == (WORKSPACE / ".tmp-kernel-venv").resolve(),
        "Use the repository virtual environment",
    )
    require(not OUTPUT.exists(), "Diagnostic output must not exist")
    manifest_hash = file_hash(MANIFEST)
    require(file_hash(BOOK_REPORT) == REPORT_SHA256, "Pinned verified report bytes changed")
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    require(
        manifest["status"] == "complete"
        and manifest["sha256"] == SOURCE_SHA256
        and Path(manifest["target"]).resolve() == SOURCE.resolve(),
        "Wrong source manifest",
    )

    # Bootstrap only from the fixed candidate, before importing any accounting module.
    sys.path.insert(0, str(SOURCE / "scripts"))
    import stage9_source

    stage9_source.require_source_module(stage9_source, SOURCE, "scripts/stage9_source.py")
    stage9_source.configure_source(SOURCE, WORKSPACE)
    import benchmark_stage9_browser
    import snapshot_stage9_source


    from ai_accounting.kernel import catalog as catalog_module
    from ai_accounting.kernel import dashboard as dashboard_module
    from ai_accounting.kernel import engine as engine_module
    from ai_accounting.kernel import resident_reads, schema_bundle
    from ai_accounting.kernel.types import canonical
    from ai_accounting.kernel.versions import database_format

    for module, relative in (
        (snapshot_stage9_source, "scripts/snapshot_stage9_source.py"),
        (benchmark_stage9_browser, "scripts/benchmark_stage9_browser.py"),

        (catalog_module, "src/ai_accounting/kernel/catalog.py"),
        (dashboard_module, "src/ai_accounting/kernel/dashboard.py"),
        (engine_module, "src/ai_accounting/kernel/engine.py"),
        (resident_reads, "src/ai_accounting/kernel/resident_reads.py"),
        (schema_bundle, "src/ai_accounting/kernel/schema_bundle.py"),
    ):
        stage9_source.require_source_module(module, SOURCE, relative)

    def check_source():
        inventory = snapshot_stage9_source._inventory(SOURCE)
        require(
            inventory == manifest["files"]
            and snapshot_stage9_source._digest(inventory) == SOURCE_SHA256,
            "Fixed source bytes drifted",
        )
        require(
            file_hash(MANIFEST) == manifest_hash and file_hash(BOOK_REPORT) == REPORT_SHA256,
            "Pinned attestations drifted",
        )

    check_source()
    book = json.loads(BOOK_REPORT.read_text(encoding="utf-8"))
    period = book['period']
    require(book['status'] == 'copied_content_unverified' and book['content_verified'] is False,
            'Construction input must not be relabelled qualification')
    require(book['requested_months'] == 48 and book['employee_count'] == 50
            and book['monthly_business_count'] == 1000
            and book['distribution'] == 'mixed_cumulative', 'Wrong sample dimensions')
    root = stage9_source.synthetic_path(Path(book['root']), WORKSPACE)
    require(root == WORKSPACE / '.tmp/stage9-draft-fixture-main48-20261003', 'Wrong draft root')
    company = book['company']
    require(company['id'] == 'c73e4f4d144340c98ade475b8dd8c8b9'
            and company['database_id'] == '6cc5f6cbe6cd402ebdfd072195398780'
            and company['taxpayer_id'] == '91310000123456789S'
            and company['name'] == '阶段九合成规模企业'
            and Path(company['path']).resolve() == root / company['taxpayer_id'] / 'company.sqlite',
            'Wrong synthetic business identity')
    checkpoint_path = root / 'stage9-builder.json'
    checkpoint_hash = file_hash(checkpoint_path)
    checkpoint = json.loads(checkpoint_path.read_text(encoding='utf-8'))
    dimensions = benchmark_stage9_browser.qualification_dimensions(book)
    require(checkpoint['company'] == company and checkpoint['snapshots'] == book['snapshots']
            and all(checkpoint.get(key) == value for key, value in dimensions.items())
            and len(checkpoint.get('business_subjects', [])) == 48000
            and len(checkpoint.get('epochs', [])) == 6
            and all(type(value) is int for value in checkpoint['epochs']),
            'Checkpoint mismatch')
    expected_state = checkpoint['epochs']
    qualification = None
    qualification_hash = None
    if args.qualification_report is not None:
        require(args.qualification_sha256 is not None, 'Qualification SHA required')
        qualification_path = args.qualification_report.resolve(strict=True)
        require(qualification_path.parent == WORKSPACE / '.tmp', 'Qualification must be synthetic')
        qualification_hash = file_hash(qualification_path)
        require(qualification_hash == args.qualification_sha256, 'Qualification bytes changed')
        qualified = json.loads(qualification_path.read_text(encoding='utf-8'))
        benchmark_stage9_browser.require_report_source(qualified, SOURCE)
        require(benchmark_stage9_browser.validate_book_report(
            qualified, company_name=company['name']) == period, 'Qualification period mismatch')
        require(qualified['company'] == company and Path(qualified['root']).resolve() == root
                and qualified['verified_open_preview']['state'] == expected_state
                and qualified['qualification']['checkpoint_sha256'] == checkpoint_hash,
                'Qualification does not bind current sample')
        qualification = {'path': str(qualification_path), 'sha256': qualification_hash}
        del qualified
    expected_identity = {
        "company_id": company["id"],
        "database_id": company["database_id"],
        "taxpayer_id": company["taxpayer_id"],
    }
    integrity_contract = book["copy_provenance"]["target_company_format"]
    del checkpoint, book
    require(
        (root / "catalog.sqlite").is_file() and Path(company["path"]).is_file(),
        "Existing databases are required",
    )

    class ReadOnlyCatalog(catalog_module.Catalog):
        @contextmanager
        def connection(self, *, read_only=False, _cross_thread=False):
            require(read_only, "Diagnostic forbids catalog writes")
            with super().connection(read_only=True, _cross_thread=_cross_thread) as connection:
                yield connection

        def recover_operations(self):
            # Never resume pending publications during a read diagnostic.
            with self.connection(read_only=True) as connection:
                count = connection.execute(
                    "SELECT count(*) FROM company_operation WHERE status!='succeeded'"
                ).fetchone()[0]
            require(
                count == 0, "Catalog has unfinished operations; diagnostic will not recover them"
            )

    bundle = schema_bundle.production_bundle()
    require(bundle.status == 'draft' and dict(bundle.current_versions) == {'company': 0, 'catalog': 0}, 'Actual factory must be draft0')
    catalog = ReadOnlyCatalog(root, bundle)
    require(
        catalog.database_format()["status"] == "draft"
        and catalog.database_format()["version"] == 0,
        "Wrong catalog contract",
    )
    companies = catalog.companies()
    require(
        [row for row in companies if row["id"] == company["id"]] == [company],
        "Catalog company identity changed",
    )
    with catalog.connection(read_only=True) as connection:
        catalog_identity = dict(connection.execute("SELECT * FROM catalog_identity").fetchone())

    pool = resident_reads.ResidentReadPool(maximum=4)
    store = catalog.bind(company["id"], read_pool=pool)
    original_connection = store.connection

    @contextmanager
    def read_only_connection(*, read_only=False):
        require(read_only, "Diagnostic forbids company writes")
        with original_connection(read_only=True) as connection:
            yield connection

    store.connection = read_only_connection
    engine = engine_module.Engine(store)
    dashboard = dashboard_module.Dashboard(
        engine, company_name=company["name"], companies=companies
    )
    year, month = map(int, period.split("-"))
    quarter = (month - 1) // 3 + 1

    def check_state():
        if qualification is not None:
            require(file_hash(Path(qualification['path'])) == qualification_hash,
                    'Current qualification bytes drifted')
        with store.connection(read_only=True) as connection:
            connection.execute("BEGIN")
            state = list(connection.execute("SELECT * FROM state WHERE id=1").fetchone())
            identity = dict(
                connection.execute(
                    "SELECT company_id,taxpayer_id,database_id FROM identity WHERE id=1"
                ).fetchone()
            )
            require(
                state == expected_state and identity == expected_identity,
                "Company identity, business state or repair revision changed",
            )
            require(
                database_format(connection, bundle=bundle) == integrity_contract,
                "Company format differs from verified source",
            )
        with catalog.connection(read_only=True) as connection:
            require(
                dict(connection.execute("SELECT * FROM catalog_identity").fetchone())
                == catalog_identity,
                "Catalog identity changed",
            )
        require(catalog.companies() == companies, "Catalog registration changed")
        require(file_hash(checkpoint_path) == checkpoint_hash, "Construction checkpoint changed")
        return {"state": state, "identity": identity, "catalog_identity": catalog_identity}


    report = {
        'status': 'diagnostic_started', 'scope': 'single_quarterly_report_cprofile',
        'source': str(SOURCE), 'source_sha256': SOURCE_SHA256,
        'source_manifest_sha256': manifest_hash,
        'construction_input': str(BOOK_REPORT), 'construction_input_sha256': REPORT_SHA256,
        'current_qualification': qualification,
        'current_source_full_verification': qualification is not None,
        'old_qualification_inherited': False, 'browser_acceptance': False,
        'root': str(root), 'period': period, 'year': year, 'quarter': quarter,
        'checkpoint_sha256': checkpoint_hash, 'script_sha256': file_hash(Path(__file__)),
        'notes': ['One actual quarterly_report only; cProfile is instrumented attribution, not latency acceptance.',
                  'No all-page work, warmups, alternating native, full verification or preview performed.'],
    }
    with OUTPUT.open('x', encoding='utf-8') as output:
        try:
            report['before'] = check_state()
            profiler = cProfile.Profile()
            profiler.enable()
            try:
                response = dashboard.quarterly_report(year, quarter, preparation='deferred')
            finally:
                profiler.disable()
                profiler.dump_stats(str(PSTATS))
                stats = pstats.Stats(profiler)
                report['profile'] = [
                    {'file': key[0], 'line': key[1], 'function': key[2],
                     'primitive_calls': value[0], 'calls': value[1],
                     'self_ms': value[2] * 1000, 'cumulative_ms': value[3] * 1000}
                    for key, value in sorted(stats.stats.items(), key=lambda item: item[1][3], reverse=True)
                ]
                report['pstats'] = {'path': str(PSTATS), 'sha256': file_hash(PSTATS)}
            report['response_clock'] = {'generated_at': response.get('generated_at'),
                'data_generated_at': response.get('data', {}).get('generated_at'),
                'checked_at': response.get('checked_at')}
            report['complete_response_sha256'] = hashlib.sha256(canonical(response).encode()).hexdigest()
            report['after'] = check_state()
            check_source()
            report['status'] = 'diagnostic_complete'
        except BaseException as error:
            report.update(status='diagnostic_failed', error_type=type(error).__name__, error=str(error))
            raise
        finally:

            json.dump(report, output, ensure_ascii=False, indent=2)
            output.write('\n')
            pool.close()
    print(json.dumps({'status': report['status'], 'browser_acceptance': False}, ensure_ascii=False))


if __name__ == '__main__':
    main()


