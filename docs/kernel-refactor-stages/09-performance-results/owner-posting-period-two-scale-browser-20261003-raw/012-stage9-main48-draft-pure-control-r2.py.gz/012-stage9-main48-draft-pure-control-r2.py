"""Pause only this run's known synthetic copy for one browser window."""
import ctypes
from ctypes import wintypes
import json
import subprocess
import time
from pathlib import Path

workspace = Path(__file__).resolve().parents[1]
ready = workspace / '.tmp/stage9-owner-main48-draft-period-group-timing-r2.ready.json'
start = workspace / '.tmp/stage9-owner-main48-draft-period-group-timing-r2.start.json'
report = workspace / '.tmp/stage9-owner-main48-draft-period-group-browser-r2.json'
control = workspace / '.tmp/stage9-main48-draft-pure-control-r2.json'
assert ready.is_file() and not start.exists() and not control.exists()
browser_pid = 40440
targets = {
    57784: (55364, 'scripts/prepare_stage9_draft_book.py', 'stage9-draft-fixture-main120-20261003'),
}
kernel = ctypes.WinDLL('kernel32', use_last_error=True)
nt = ctypes.WinDLL('ntdll')
kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
kernel.OpenProcess.restype = wintypes.HANDLE
kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
kernel.WaitForSingleObject.restype = wintypes.DWORD
kernel.CloseHandle.argtypes = [wintypes.HANDLE]
nt.NtSuspendProcess.argtypes = [wintypes.HANDLE]
nt.NtSuspendProcess.restype = ctypes.c_long
nt.NtResumeProcess.argtypes = [wintypes.HANDLE]
nt.NtResumeProcess.restype = ctypes.c_long

class FILETIME(ctypes.Structure):
    _fields_ = [('low', wintypes.DWORD), ('high', wintypes.DWORD)]

kernel.GetProcessTimes.argtypes = [wintypes.HANDLE, *([ctypes.POINTER(FILETIME)] * 4)]

def times(handle):
    values = [FILETIME() for _ in range(4)]
    assert kernel.GetProcessTimes(handle, *[ctypes.byref(v) for v in values])
    return dict(zip(('creation', 'exit', 'kernel', 'user'),
                    [v.high * 2**32 + v.low for v in values]))

def description(pid):
    ps = (f"Get-CimInstance Win32_Process -Filter 'ProcessId={pid}' | "
          "Select-Object ProcessId,ParentProcessId,CommandLine | ConvertTo-Json -Compress")
    result = subprocess.run(['powershell', '-NoProfile', '-Command', ps],
                            capture_output=True, text=True, check=True)
    return json.loads(result.stdout) if result.stdout.strip() else None

signal = json.loads(ready.read_text())
assert signal['pid'] == browser_pid and Path(signal['output']).resolve() == report
browser = description(browser_pid)
assert browser and 'scripts/benchmark_stage9_browser.py' in browser['CommandLine']
assert 'stage9-owner-main48-draft-period-group-browser-r2.json' in browser['CommandLine']
browser_handle = kernel.OpenProcess(0x0400 | 0x00100000, False, browser_pid)
assert browser_handle
handles, paused = {}, []
state = {'status': 'control_started', 'scope': 'owned_synthetic_jobs_only',
         'browser_pid': browser_pid, 'started_epoch': time.time(), 'targets': {}}
try:
    for pid, (parent, script, marker) in targets.items():
        item = description(pid)
        if item is None:
            state['targets'][str(pid)] = {'already_finished': True}
            continue
        assert item['ParentProcessId'] == parent and script in item['CommandLine']
        assert marker in item['CommandLine'], 'Refuse unrelated process'
        handle = kernel.OpenProcess(0x0800 | 0x0400 | 0x00100000, False, pid)
        assert handle
        handles[pid] = handle
        if kernel.WaitForSingleObject(handle, 0) == 258:
            assert nt.NtSuspendProcess(handle) == 0, 'Unable to pause owned job'
            paused.append(pid)
            state['targets'][str(pid)] = {'paused_epoch': time.time(), 'before': times(handle)}
        else:
            state['targets'][str(pid)] = {'already_finished': True}
    time.sleep(10)
    assert kernel.WaitForSingleObject(browser_handle, 0) == 258
    with start.open('x', encoding='utf-8') as out:
        json.dump({'status': 'pure_timing_released', 'owned_synthetic_paused': paused,
                   'epoch': time.time()}, out)
    state['timing_released_epoch'] = time.time()
    print(json.dumps({'status': 'pure_timing_released', 'paused': paused}), flush=True)
    deadline = time.monotonic() + 600
    while kernel.WaitForSingleObject(browser_handle, 1000) == 258:
        assert time.monotonic() < deadline, 'Browser window exceeded ten minutes'
    assert report.is_file(), 'Browser exited without final report'
    timing = json.loads(report.read_text(encoding='utf-8'))
    state['browser_status'] = timing['status']
    for pid in paused:
        target = state['targets'][str(pid)]
        target['after'] = times(handles[pid])
        target['cpu_unchanged'] = all(target['before'][k] == target['after'][k]
                                       for k in ('kernel', 'user'))
        assert target['cpu_unchanged'], 'Paused job consumed CPU during timing'
    state['status'] = 'timing_finished'
except BaseException as error:
    state['status'] = 'control_failed'
    state['error'] = {'type': type(error).__name__, 'message': str(error)}
    raise
finally:
    for pid in paused:
        resumed = nt.NtResumeProcess(handles[pid])
        state['targets'][str(pid)]['resume_status'] = resumed
        state['targets'][str(pid)]['resumed_epoch'] = time.time()
        if resumed != 0:
            state['status'] = 'resume_failed'
    for handle in handles.values():
        kernel.CloseHandle(handle)
    kernel.CloseHandle(browser_handle)
    state['finished_epoch'] = time.time()
    with control.open('x', encoding='utf-8') as out:
        json.dump(state, out, ensure_ascii=False, indent=2)
    print(json.dumps({'status': state['status'], 'control': str(control)}), flush=True)
    assert all(state['targets'][str(pid)].get('resume_status') == 0 for pid in paused)
