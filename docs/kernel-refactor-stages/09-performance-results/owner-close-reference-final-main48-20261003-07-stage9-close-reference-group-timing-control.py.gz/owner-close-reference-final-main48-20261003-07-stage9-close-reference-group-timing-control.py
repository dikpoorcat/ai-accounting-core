"""Release one explicit current-qualified browser; pause only two pinned synthetic copies."""

import argparse
import ctypes
import hashlib
import json
import os
import subprocess
import sys
import time
from ctypes import wintypes
from datetime import datetime
from pathlib import Path

WORKSPACE = Path(__file__).resolve().parents[1]
VENV = WORKSPACE / ".tmp-kernel-venv/Scripts/python.exe"
RUNTIME = Path(
    "C:/Users/MD01/AppData/Roaming/uv/python/cpython-3.12.13-windows-x86_64-none/python.exe"
)
WAIT_OBJECT_0, WAIT_TIMEOUT = 0, 258
QUERY_SYNCHRONIZE = 0x0400 | 0x00100000
SUSPEND_RESUME = 0x0800
DEMO_PID = 48684
SEALED_SOURCE = WORKSPACE / ".tmp/stage9-build-source-owner-reference-group-20261003-release"
SEALED_SHA = "6688df6c46f5416ca03917def0d29a701cb20e8ae45b962c59df4a1290f8da62"
SEALED_MANIFEST_SHA = "9de4a38ae2f93fc575d5a68898ad3cba334ab4dc5786c67731a6c1eead1d52b5"
COPIES = (
    dict(
        name="independent120",
        pid=52844,
        parent=32836,
        script=".tmp/stage9-prepare-independent-month-reads.py",
        case="independent120",
        source=".tmp/stage9-build-source-owner-month-reads-20261003-release",
        target=".tmp/stage9-independent120-month-reads-candidate-20261003",
        child_creation="2026-10-03T09:37:15.588843+08:00",
        parent_creation="2026-10-03T09:37:15.57724+08:00",
        already_completed=False,
    ),
    dict(
        name="pressure12",
        pid=56788,
        parent=54572,
        script=".tmp/stage9-prepare-pressure-close-proof-groups.py",
        case="pressure12",
        source=".tmp/stage9-build-source-owner-close-proof-groups-20261003-release",
        target=".tmp/stage9-pressure12-close-proof-groups-candidate-20261003",
        already_completed=True,
    ),
)


def require(value, message):
    if not value:
        raise RuntimeError(message)


def process_snapshot():
    command = (
        "Get-CimInstance Win32_Process | Select-Object ProcessId,ParentProcessId,CommandLine,"
        "@{Name='CreationDate';Expression={$_.CreationDate.ToString('o')}},ExecutablePath "
        "| ConvertTo-Json -Compress"
    )
    result = subprocess.run(
        ["powershell", "-NoProfile", "-Command", command],
        capture_output=True,
        text=True,
        check=True,
    )
    rows = json.loads(result.stdout) if result.stdout.strip() else []
    return rows if isinstance(rows, list) else [rows]


def row_for(rows, pid):
    return next((row for row in rows if row["ProcessId"] == pid), None)


def arguments(command):
    count = ctypes.c_int()
    shell = ctypes.WinDLL("shell32", use_last_error=True)
    shell.CommandLineToArgvW.argtypes = [wintypes.LPCWSTR, ctypes.POINTER(ctypes.c_int)]
    shell.CommandLineToArgvW.restype = ctypes.POINTER(wintypes.LPWSTR)
    memory = shell.CommandLineToArgvW(command, ctypes.byref(count))
    require(bool(memory), "Cannot parse process command line")
    try:
        return [memory[i] for i in range(count.value)]
    finally:
        kernel.LocalFree.argtypes = [ctypes.c_void_p]
        kernel.LocalFree.restype = ctypes.c_void_p
        kernel.LocalFree(memory)


def option(args, name):
    if name in args:
        index = args.index(name)
        require(args.count(name) == 1 and index + 1 < len(args), "Ambiguous process option")
        return args[index + 1]
    values = [arg[len(name) + 1 :] for arg in args if arg.startswith(name + "=")]
    require(len(values) == 1, "Required process option missing or repeated")
    return values[0]


def absolute(value):
    selected = Path(value)
    return (selected if selected.is_absolute() else WORKSPACE / selected).resolve()


def times(handle):
    values = [FILETIME() for _ in range(4)]
    require(
        kernel.GetProcessTimes(handle, *[ctypes.byref(value) for value in values]),
        "Cannot read process CPU times",
    )
    return dict(
        zip(
            ("creation", "exit", "kernel", "user"),
            [value.high * 2**32 + value.low for value in values],
            strict=True,
        )
    )


def active(handle):
    status = kernel.WaitForSingleObject(handle, 0)
    require(status in (WAIT_OBJECT_0, WAIT_TIMEOUT), "Cannot inspect process state")
    return status == WAIT_TIMEOUT


def delta(before, after):
    return sum(after[key] - before[key] for key in ("kernel", "user")) / 10_000_000


kernel = ctypes.WinDLL("kernel32", use_last_error=True)
nt = ctypes.WinDLL("ntdll")
kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
kernel.OpenProcess.restype = wintypes.HANDLE
kernel.CloseHandle.argtypes = [wintypes.HANDLE]
kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
kernel.WaitForSingleObject.restype = wintypes.DWORD
nt.NtSuspendProcess.argtypes = [wintypes.HANDLE]
nt.NtSuspendProcess.restype = ctypes.c_long
nt.NtResumeProcess.argtypes = [wintypes.HANDLE]
nt.NtResumeProcess.restype = ctypes.c_long


class FILETIME(ctypes.Structure):
    _fields_ = [("low", wintypes.DWORD), ("high", wintypes.DWORD)]


kernel.GetProcessTimes.argtypes = [wintypes.HANDLE, *([ctypes.POINTER(FILETIME)] * 4)]
kernel.GetProcessTimes.restype = wintypes.BOOL


def file_hash(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def stable_row(row):
    return {
        key: row[key]
        for key in ("ProcessId", "ParentProcessId", "CommandLine", "CreationDate", "ExecutablePath")
    }


def validate_copy(row, spec, *, parent=False):
    if row is None:
        return None
    require(not spec["already_completed"], "Completed pressure PID was reused; do not touch it")
    pid = spec["parent"] if parent else spec["pid"]
    require(row["ProcessId"] == pid, "Unexpected owned copy PID")
    if not parent:
        require(row["ParentProcessId"] == spec["parent"], "Unexpected copy parent; do not touch it")
    require(
        datetime.fromisoformat(row["CreationDate"])
        == datetime.fromisoformat(spec["parent_creation" if parent else "child_creation"]),
        "Owned copy creation identity changed; do not touch reused PID",
    )
    require(
        absolute(row["ExecutablePath"]) == (VENV if parent else RUNTIME),
        "Unexpected owned executable",
    )
    args = arguments(row["CommandLine"])
    require(absolute(args[0]) == (VENV if parent else RUNTIME), "Unexpected copy argv executable")
    require(
        any(
            absolute(arg) == WORKSPACE / spec["script"]
            for arg in args[1:]
            if not arg.startswith("-")
        ),
        "Unexpected owned copy script",
    )
    require(option(args, "--case") == spec["case"], "Unexpected owned copy case")
    for name, expected in (("--target-source", spec["source"]), ("--target-root", spec["target"])):
        require(
            absolute(option(args, name)) == WORKSPACE / expected, "Unexpected copy source/target"
        )
    return stable_row(row)


def browser_matches(row, source, book, report, ready, start):
    command = row.get("CommandLine") or ""
    if "benchmark_stage9_browser.py" not in command:
        return False
    args = arguments(command)
    try:
        if not any(
            absolute(arg) == WORKSPACE / "scripts/benchmark_stage9_browser.py"
            for arg in args[1:]
            if not arg.startswith("-")
        ):
            return False
        for name, expected in (
            ("--source", source),
            ("--output", report),
            ("--timing-ready-file", ready),
            ("--timing-start-file", start),
        ):
            if absolute(option(args, name)) != expected:
                return False
        qualified = "--qualify-output" if "--qualify-output" in args else "--book-report"
        if absolute(option(args, qualified)) != book:
            return False
        require(
            not any(
                flag in args
                for flag in (
                    "--instrument",
                    "--layout-only",
                    "--navigation-only",
                    "--switch-book-report",
                )
            ),
            "This controller releases only pure five-page hot refresh",
        )
        for name, expected in (("--repeats", "30"), ("--warmups", "3")):
            if name in args:
                require(option(args, name) == expected, "Pure timing sample contract changed")
        return True
    except RuntimeError:
        raise


def source_and_book(source, book_path, sha):
    require(file_hash(book_path) == sha, "Explicit qualification report SHA changed")
    book = json.loads(book_path.read_text("utf-8"))
    require(
        book.get("status") == "complete" and absolute(book["source"]) == source,
        "Only current-source complete qualification may release pure timing",
    )
    qualification = book.get("qualification", {})
    manifest_path = source / "source-manifest.json"
    manifest_sha = file_hash(manifest_path)
    require(
        source == SEALED_SOURCE and manifest_sha == SEALED_MANIFEST_SHA,
        "Explicit reference-group source seal differs",
    )
    require(
        qualification.get("source_manifest_sha256") == manifest_sha,
        "Qualification does not bind this sealed manifest",
    )
    manifest = json.loads(manifest_path.read_text("utf-8"))
    require(
        manifest.get("status") == "complete" and absolute(manifest["target"]) == source,
        "Source must be explicitly sealed",
    )
    sys.path.insert(0, str(WORKSPACE / "scripts"))
    import benchmark_stage9_browser
    import snapshot_stage9_source

    require(manifest["sha256"] == SEALED_SHA, "Reference-group source SHA differs")
    files = snapshot_stage9_source._inventory(source)
    require(
        files == manifest["files"]
        and len(files) == manifest["file_count"]
        and snapshot_stage9_source._digest(files) == manifest["sha256"],
        "Sealed source bytes changed",
    )
    company_name = book.get("company", {}).get("name")
    require(
        company_name in {"阶段九合成规模企业", "阶段九合成独立业务企业"},
        "Only named synthetic sample companies are allowed",
    )
    period = benchmark_stage9_browser.validate_book_report(book, company_name=company_name)
    benchmark_stage9_browser.require_report_source(book, source)
    preview = book["verified_open_preview"]
    require(absolute(preview["source"]) == source, "Preview belongs to a different candidate")
    require(
        preview["company_id"] == book["company"]["id"]
        and preview["database_id"] == book["company"]["database_id"],
        "Qualification identity mismatch",
    )
    require(book["measurements"] == {}, "Qualification cannot inherit timing")
    root = absolute(book["root"])
    require(
        root.is_relative_to(WORKSPACE / ".tmp"), "Only isolated synthetic qualification is allowed"
    )
    checkpoint = root / (
        "stage9-independent-builder.json"
        if book["distribution"] == "independent_local_pairs"
        else "stage9-builder.json"
    )
    require(
        file_hash(checkpoint) == qualification["checkpoint_sha256"], "Qualified checkpoint changed"
    )
    return dict(
        source_sha256=manifest["sha256"],
        manifest_sha256=manifest_sha,
        book_report_sha256=sha,
        company_id=book["company"]["id"],
        period=period,
        checkpoint_sha256=qualification["checkpoint_sha256"],
    )


def active_owned_group_jobs(rows):
    result = []
    for row in rows:
        command = row.get("CommandLine") or ""
        if not any(
            family in command
            for family in ("reference-group-regression", "reference-group-native-work")
        ):
            continue
        selected = []
        for arg in arguments(command)[1:]:
            if arg.startswith("-"):
                continue
            path = absolute(arg)
            if (
                path.parent == WORKSPACE / ".tmp"
                and path.suffix == ".py"
                and any(
                    family in path.name
                    for family in ("reference-group-regression", "reference-group-native-work")
                )
            ):
                selected.append(path.name)
        if selected:
            result.append(
                dict(pid=row["ProcessId"], parent_pid=row["ParentProcessId"], scripts=selected)
            )
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--book-report", type=Path, required=True)
    parser.add_argument("--report-sha256", required=True)
    parser.add_argument(
        "--output", type=Path, required=True, help="new browser report path ending -browser.json"
    )
    args = parser.parse_args()
    require(Path(sys.prefix).resolve() == VENV.parent.parent, "Use repository venv")
    source, book, report = map(absolute, (args.source, args.book_report, args.output))
    require(
        source.is_relative_to(WORKSPACE / ".tmp")
        and source.name.startswith("stage9-build-source-"),
        "Only explicit isolated sealed source is allowed",
    )
    require(
        book.is_relative_to(WORKSPACE / ".tmp")
        and report.parent == WORKSPACE / ".tmp"
        and report.name.startswith("stage9-")
        and report.name.endswith("-browser.json"),
        "Output/input scope invalid",
    )
    prefix = str(report)[: -len("-browser.json")]
    ready, start, control = (
        Path(prefix + suffix)
        for suffix in ("-timing-ready.json", "-timing-start.json", "-timing-control.json")
    )
    require(
        not report.exists() and not start.exists() and not control.exists(), "Outputs must be new"
    )
    state = dict(
        status="waiting_for_qualified_ready",
        controller_pid=os.getpid(),
        source=str(source),
        book_report=str(book),
        output=str(report),
        ready=str(ready),
        start=str(start),
        scope="only_two_explicit_owned_synthetic_copy_tasks",
        demo_modified=False,
        started_epoch=time.time(),
        copies=[],
        resume_errors=[],
    )
    handles, suspended = {}, []
    with control.open("x", encoding="utf-8") as output:
        try:
            rows = process_snapshot()
            matches = [
                row for row in rows if browser_matches(row, source, book, report, ready, start)
            ]
            leaves = [
                row
                for row in matches
                if not any(other["ParentProcessId"] == row["ProcessId"] for other in matches)
            ]
            require(len(leaves) == 1, "Require exactly one matching actual browser process")
            browser = stable_row(leaves[0])
            browser_pid = browser["ProcessId"]
            require(absolute(browser["ExecutablePath"]) == RUNTIME, "Unexpected browser runtime")
            handles["browser"] = kernel.OpenProcess(QUERY_SYNCHRONIZE, False, browser_pid)
            require(handles["browser"], "Cannot observe actual browser process")
            require(
                stable_row(row_for(process_snapshot(), browser_pid)) == browser,
                "Browser PID identity changed",
            )
            state.update(browser=browser, browser_times=times(handles["browser"]))
            deadline = time.monotonic() + 3600
            while not ready.is_file():
                require(active(handles["browser"]), "Browser exited before actual ready")
                require(time.monotonic() < deadline, "Ready wait timed out")
                time.sleep(1)
            signal = json.loads(ready.read_text("utf-8"))
            require(
                signal["status"] == "timing_ready"
                and signal["pid"] == browser_pid
                and absolute(signal["output"]) == report,
                "Ready signal binding mismatch",
            )
            state["ready_signal"] = signal
            state["ready_sha256"] = file_hash(ready)
            rows = process_snapshot()
            blocked = active_owned_group_jobs(rows)
            state["owned_group_jobs_at_ready"] = blocked
            if blocked:
                print(
                    json.dumps(dict(status="waiting_for_owned_group_jobs", jobs=blocked)),
                    flush=True,
                )
            group_deadline = time.monotonic() + 600
            while blocked:
                require(
                    active(handles["browser"]), "Browser exited while waiting for owned group jobs"
                )
                require(
                    time.monotonic() < group_deadline,
                    "Owned group jobs did not finish before gate deadline",
                )
                time.sleep(3)
                rows = process_snapshot()
                blocked = active_owned_group_jobs(rows)
            state["owned_group_jobs_before_suspend"] = blocked
            state["qualification"] = source_and_book(source, book, args.report_sha256)
            rows = process_snapshot()
            require(
                stable_row(row_for(rows, browser_pid)) == browser,
                "Browser identity changed before suspend",
            )
            for spec in COPIES:
                child, parent = row_for(rows, spec["pid"]), row_for(rows, spec["parent"])
                item = dict(name=spec["name"], pid=spec["pid"], parent_pid=spec["parent"])
                state["copies"].append(item)
                if child is None:
                    if parent is not None:
                        validate_copy(parent, spec, parent=True)  # Never touch a reused parent.
                    item.update(
                        status="already_finished_no_suspend", parent_present=parent is not None
                    )
                    continue
                child_identity = validate_copy(child, spec)
                parent_identity = validate_copy(parent, spec, parent=True)
                require(parent_identity is not None, "Owned child without expected launcher")
                item.update(
                    process_identities=dict(child=child_identity, parent=parent_identity),
                    status="validated",
                )
                for role, identity in (("parent", parent_identity), ("child", child_identity)):
                    name = spec["name"] + ":" + role
                    handle = kernel.OpenProcess(
                        QUERY_SYNCHRONIZE | SUSPEND_RESUME, False, identity["ProcessId"]
                    )
                    require(handle, "Cannot open explicitly owned copy")
                    handles[name] = handle
                    current = row_for(process_snapshot(), identity["ProcessId"])
                    require(
                        current is not None and stable_row(current) == identity,
                        "Owned PID changed before suspend",
                    )
                    if not active(handle):
                        item[role] = dict(status="finished_before_suspend")
                        continue
                    status = nt.NtSuspendProcess(handle)
                    if status != 0 and not active(handle):
                        item[role] = dict(status="finished_before_suspend")
                        continue
                    require(status == 0, "Owned copy suspension failed")
                    suspended.append((name, item, role))
                    item[role] = dict(
                        status="suspended",
                        suspend_status=status,
                        suspended_epoch=time.time(),
                        after_suspend=times(handle),
                    )
            demo = row_for(rows, DEMO_PID)
            if demo is not None:
                handles["demo"] = kernel.OpenProcess(QUERY_SYNCHRONIZE, False, DEMO_PID)
                require(handles["demo"], "Cannot observe existing demo")
                state["demo_before_quiet"] = times(handles["demo"])
            require(
                not active_owned_group_jobs(process_snapshot()),
                "Owned group job started before quiet interval",
            )
            time.sleep(10)
            require(active(handles["browser"]), "Browser exited during quiet interval")
            for name, item, role in suspended:
                after = times(handles[name])
                item[role]["before_timing"] = after
                item[role]["quiet_cpu_seconds"] = delta(item[role]["after_suspend"], after)
                require(item[role]["quiet_cpu_seconds"] == 0, "Suspended owned copy used CPU")
            require(
                not active_owned_group_jobs(process_snapshot()),
                "Owned group job active after quiet interval",
            )
            if "demo" in handles:
                state["demo_before_timing"] = times(handles["demo"])
                state["demo_quiet_cpu_seconds"] = delta(
                    state["demo_before_quiet"], state["demo_before_timing"]
                )
            state["environment_note"] = (
                "Pinned copies paused; demo observed. No arbitrary CPU or system-zero gate."
            )
            with start.open("x", encoding="utf-8") as release:
                json.dump(
                    dict(
                        status="pure_timing_released",
                        epoch=time.time(),
                        controller_pid=os.getpid(),
                        paused_processes=[name for name, _, _ in suspended],
                    ),
                    release,
                )
            state["timing_released_epoch"] = time.time()
            print(
                json.dumps(
                    dict(status="timing_released", paused=[name for name, _, _ in suspended])
                ),
                flush=True,
            )
            require(
                kernel.WaitForSingleObject(handles["browser"], 600_000) == WAIT_OBJECT_0,
                "Browser timing window timed out",
            )
            require(report.is_file(), "Actual browser exited without report")
            timing = json.loads(report.read_text("utf-8"))
            state.update(browser_status=timing["status"], browser_report_sha256=file_hash(report))
            for name, item, role in suspended:
                after = times(handles[name])
                item[role]["after_timing"] = after
                item[role]["timing_cpu_seconds"] = delta(item[role]["before_timing"], after)
                require(item[role]["timing_cpu_seconds"] == 0, "Owned copy used CPU during timing")
            if "demo" in handles:
                state["demo_after_timing"] = times(handles["demo"])
                state["demo_timing_cpu_seconds"] = delta(
                    state["demo_before_timing"], state["demo_after_timing"]
                )
            state["qualification_after"] = source_and_book(source, book, args.report_sha256)
            require(
                state["qualification_after"] == state["qualification"],
                "Qualification/source changed",
            )
            state["status"] = "timing_finished"
        except BaseException as error:
            state.update(
                status="control_failed", error=dict(type=type(error).__name__, message=str(error))
            )
            raise
        finally:
            for name, item, role in reversed(suspended):
                try:
                    status = nt.NtResumeProcess(handles[name])
                    item[role].update(resume_status=status, resumed_epoch=time.time())
                    if status != 0:
                        state["resume_errors"].append(dict(process=name, status=status))
                    item[role]["after_resume"] = times(handles[name])
                    item[role]["active_after_resume"] = active(handles[name])
                except BaseException as error:
                    state["resume_errors"].append(
                        dict(process=name, error_type=type(error).__name__, message=str(error))
                    )
            if state["resume_errors"]:
                state["status"] = "resume_failed"
            for handle in handles.values():
                if handle:
                    kernel.CloseHandle(handle)
            state["finished_epoch"] = time.time()
            json.dump(state, output, ensure_ascii=False, indent=2)
            output.write("\n")
            output.flush()
            print(json.dumps(dict(status=state["status"], control=str(control))), flush=True)
            require(
                not state["resume_errors"],
                "Owned copy resume failed; explicit intervention required",
            )


if __name__ == "__main__":
    main()
