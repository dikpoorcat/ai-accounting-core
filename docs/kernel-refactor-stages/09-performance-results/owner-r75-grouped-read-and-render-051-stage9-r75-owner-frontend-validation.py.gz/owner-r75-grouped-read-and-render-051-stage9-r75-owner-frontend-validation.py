import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]
PREFIX = ROOT / '.tmp/stage9-r75-owner-frontend'
NODE = Path('C:/Users/MD01/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe')
NPM = Path('D:/Program Files/nodejs/node_modules/npm/bin/npm-cli.js')
VENV = ROOT / '.tmp-kernel-venv/Scripts'
files = sorted(set(
    list((ROOT / 'frontend/src/views').glob('*.vue'))
    + list((ROOT / 'frontend/tests').rglob('*'))
    + list((ROOT / 'frontend/src/api/generated').rglob('*'))
    + [ROOT / 'frontend/vite.config.ts', ROOT / 'AGENTS.md', ROOT / 'frontend/package.json']
))
def hashes():
    return {str(p.relative_to(ROOT)).replace('\\', '/'): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in files if p.is_file()}
def group_hash(values):
    return hashlib.sha256(json.dumps(values, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
output = Path(str(PREFIX) + '-validation.json')
assert not output.exists(), output
assert NODE.is_file() and NPM.is_file()
env = os.environ.copy()
env['PATH'] = str(NODE.parent) + os.pathsep + str(VENV) + os.pathsep + env.get('PATH', '')
env['PYTHON'] = str(VENV / 'python.exe')
env.pop('NODE_ENV', None)
before = hashes()
result = {'scope': 'one_full_frontend_test_then_release_build_not_browser_acceptance',
          'node': str(NODE), 'python': str(VENV / 'python.exe'), 'npm_cli': str(NPM),
          'node_version': subprocess.check_output([str(NODE), '--version'], text=True).strip(),
          'before': before, 'before_group_sha256': group_hash(before), 'commands': []}
Path(str(PREFIX) + '-commands.json').write_text(json.dumps({
    'cwd': str(ROOT / 'frontend'), 'argv': [[str(NODE), str(NPM), 'test'], [str(NODE), str(NPM), 'run', 'build:release']],
    'python_launcher': '.tmp-kernel-venv/Scripts/python.exe -X utf8',
    'environment': {'PATH_prefix': [str(NODE.parent), str(VENV)], 'PYTHON': env['PYTHON'], 'NODE_ENV': 'unset'},
    'build_includes': ['contracts:check', 'type-check', 'vite build --mode release']}, ensure_ascii=False, indent=2), encoding='utf-8')
for name, args in [('test', ['test']), ('build', ['run', 'build:release'])]:
    log = Path(str(PREFIX) + '-' + name + '.log')
    assert not log.exists(), log
    started = time.time()
    with log.open('w', encoding='utf-8') as stream:
        completed = subprocess.run([str(NODE), str(NPM), *args], cwd=ROOT / 'frontend', env=env,
                                   stdout=stream, stderr=subprocess.STDOUT, text=True)
    command = {'name': name, 'argv': [str(NODE), str(NPM), *args], 'exit_code': completed.returncode,
               'elapsed_seconds': round(time.time() - started, 3), 'log': str(log.relative_to(ROOT))}
    result['commands'].append(command)
    print(json.dumps(command), flush=True)
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    if completed.returncode:
        break
after = hashes()
result.update(after=after, after_group_sha256=group_hash(after),
              changed_files=[p for p in sorted(set(before) | set(after)) if before.get(p) != after.get(p)],
              complete=len(result['commands']) == 2 and all(c['exit_code'] == 0 for c in result['commands']))
output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'complete': result['complete'], 'changed_files': result['changed_files']}), flush=True)
