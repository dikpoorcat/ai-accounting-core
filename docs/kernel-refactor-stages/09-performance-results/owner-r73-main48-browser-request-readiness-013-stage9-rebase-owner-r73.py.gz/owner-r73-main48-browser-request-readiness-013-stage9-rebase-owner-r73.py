"""Copy only three pinned synthetic histories to the fixed r73 candidate.

The unchanged r49 executor owns identity, exact DDL delta, raw rowid/byte,
foreign-key, full registered content, real open-preview and publication checks.
This wrapper cannot resume, attest only, bypass verification or choose a root.
"""

from __future__ import annotations

import argparse
import contextlib
import hashlib
import importlib.util
import json
import stat
import subprocess
import sys
import traceback
from pathlib import Path, PurePosixPath
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
EXECUTOR = Path(__file__).with_name("stage9-rebase-owner-r49.py")
EXECUTOR_SHA256 = "8711ee4a99043ee573dceec995d6f311ca97714ee9bae1019a09c9f9c4a603e4"
NEW_TREE = "stage9-build-source-owner-r73-release"
NEW_SNAPSHOT = "420ceb395fc5aec17ddaedf8914c7fc8de640da9f08cb35aded8a3a99a4eb7f4"
NEW_COMPANY = "c9f9f7051bca67f1241ee5c89676fb9476bc819dc8f92c1a0c0bd1e940f459cb"
CATALOG = "b484d315272bb64de3856b458f04d2d4881da05db7552250864260916c69a4ee"
NEW_CONTENT = "8abdbad6e6dca035c948daaf8a254743282c72a2198fd28caa852d9593b895a1"
APPROVED = {
    "main120": "stage9-release-main-120",
    "independent48": "stage9-release-independent-48",
    "independent120": "stage9-release-independent-120",
}
HISTORICAL_ORIGINS = {
    "stage9-build-source-r22-release": "stage9-release-candidate-work-r22",
    "stage9-build-source-r11-release": "stage9-release-candidate-work-r11",
    "stage9-build-source-r30-release": "stage9-release-candidate-work-r30",
}
HISTORICAL_ROOTS = (
    "src/ai_accounting", "tests/kernel", "tests/pure", "scripts",
    "frontend/dist", "frontend/tests",
)
HISTORICAL_TOP_FILES = frozenset({
    "pyproject.toml", "tests/conftest.py", "frontend/package.json",
    "frontend/package-lock.json", "frontend/vite.config.ts", "frontend/tsconfig.json",
})


def _unique_pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate historical manifest field")
        result[key] = value
    return result


def _manifest_digest(files):
    # Exact original snapshot_stage9_source._digest algorithm, including JSON defaults.
    encoded = json.dumps(files, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _historical_scope(name):
    if not isinstance(name, str) or not name or "\\" in name or ":" in name:
        return False
    path = PurePosixPath(name)
    if (path.is_absolute() or path.as_posix() != name
            or any(part in {".", "..", "__pycache__"} for part in path.parts)):
        return False
    if name in HISTORICAL_TOP_FILES:
        return True
    for prefix in HISTORICAL_ROOTS:
        if name.startswith(prefix + "/"):
            return ((not prefix.startswith("tests") or path.suffix == ".py")
                    and (prefix != "scripts" or path.suffix in {".py", ".ps1"}))
    return False


def _plain_path(path, tree):
    current = path
    while True:
        if current.is_symlink() or current.is_junction():
            raise ValueError("Historical snapshot contains a linked path")
        if current == tree:
            break
        if current.parent == current:
            raise ValueError("Historical manifest path escapes its source tree")
        current = current.parent
    if not path.resolve().is_relative_to(tree.resolve()):
        raise ValueError("Historical manifest path escapes its source tree")


def _verify_historical_manifest(tree, expected, *, origin):
    """Authenticate this historical file set without adding current required files.

    Only the dispatcher below supplies real CASE pins. This pure primitive is
    also exercised on tiny isolated manifest fixtures; it never configures or
    executes historical source, handles databases, or publishes business proof.
    """
    tree = Path(tree).resolve(strict=True)
    manifest_path = tree / "source-manifest.json"
    _plain_path(manifest_path, tree)
    if not stat.S_ISREG(manifest_path.stat().st_mode):
        raise ValueError("Historical source manifest is not a regular file")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"),
                          object_pairs_hook=_unique_pairs)
    files = manifest.get("files")
    if (manifest.get("status") != "complete"
            or manifest.get("source") != str(origin)
            or manifest.get("target") != str(tree)
            or manifest.get("sha256") != expected
            or not isinstance(files, dict) or not files
            or type(manifest.get("file_count")) is not int
            or manifest["file_count"] != len(files)):
        raise ValueError("Historical snapshot marker or CASE identity changed")
    for name, sha in files.items():
        if (not _historical_scope(name) or not isinstance(sha, str)
                or len(sha) != 64 or any(char not in "0123456789abcdef" for char in sha)):
            raise ValueError("Historical manifest path or byte hash is invalid")
    if _manifest_digest(files) != expected:
        raise ValueError("Historical manifest aggregate differs from its CASE")
    actual_paths = set(HISTORICAL_TOP_FILES)
    for relative in HISTORICAL_ROOTS:
        directory = tree / relative
        _plain_path(directory, tree)
        for path in directory.rglob("*"):
            _plain_path(path, tree)
            if path.is_file():
                name = path.relative_to(tree).as_posix()
                if _historical_scope(name):
                    actual_paths.add(name)
    if actual_paths != files.keys():
        raise ValueError("Historical snapshot eligible file inventory changed")
    actual = {}
    sizes = {}
    for name in files:
        path = tree / name
        _plain_path(path, tree)
        before = path.stat()
        if not stat.S_ISREG(before.st_mode) or before.st_size < 0:
            raise ValueError("Historical snapshot declaration is not a regular file")
        with path.open("rb") as handle:
            actual[name] = hashlib.file_digest(handle, "sha256").hexdigest()
        after = path.stat()
        if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) != (
                after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns):
            raise ValueError("Historical snapshot file changed during hashing")
        sizes[name] = before.st_size
    if actual != files or _manifest_digest(actual) != expected:
        raise ValueError("Historical snapshot actual bytes differ from its CASE")
    return {"file_count": len(actual), "bytes": sum(sizes.values()), "sha256": expected}


def executor():
    with EXECUTOR.open("rb") as handle:
        actual = hashlib.file_digest(handle, "sha256").hexdigest()
    if actual != EXECUTOR_SHA256:
        raise ValueError("Pinned r49 executor changed")
    spec = importlib.util.spec_from_file_location("stage9_owner_r73_fixture", EXECUTOR)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.NEW_TREE = NEW_TREE
    module.NEW_SNAPSHOT = NEW_SNAPSHOT
    module.NEW_COMPANY = NEW_COMPANY
    module.CATALOG = CATALOG
    module.NEW_CONTENT = NEW_CONTENT
    module.CASES = {name: module.CASES[name] for name in APPROVED.values()}
    module.RESUMABLE_STAGING = frozenset()
    current_guard = module._require_snapshot
    old_cases = {case["source_tree"]: case for case in module.CASES.values()}

    def require_snapshot(tree, expected=NEW_SNAPSHOT):
        tree = Path(tree).resolve(strict=True)
        if tree == ROOT / ".tmp" / NEW_TREE:
            if expected != NEW_SNAPSHOT:
                raise ValueError("Current r73 snapshot pin changed")
            return current_guard(tree, NEW_SNAPSHOT)
        case = old_cases.get(tree.name)
        if (tree.parent != ROOT / ".tmp" or case is None
                or expected != case["source_snapshot"]):
            raise ValueError("Historical snapshot is not one of the exact approved CASE sources")
        return _verify_historical_manifest(
            tree, expected, origin=ROOT / ".tmp" / HISTORICAL_ORIGINS[tree.name],
        )

    module._require_snapshot = require_snapshot
    return module


def paths(module, selection):
    source_name = APPROVED[selection]
    case = module.CASES[source_name]
    target_name = module._target_name(case)
    base = ROOT / ".tmp"
    args = SimpleNamespace(
        workspace=ROOT,
        source_root=base / source_name,
        target_root=base / target_name,
        source=base / case["source_tree"],
        target_source=base / NEW_TREE,
        source_report=base / case["report"],
        dry_run=False,
        resume_staging=None,
        attest_copy_only=False,
    )
    return args, {
        "log": base / (target_name + "-rebase.log"),
        "report": base / (target_name + "-rebase.json"),
        "command": base / (target_name + "-rebase-command.txt"),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", required=True, choices=tuple(APPROVED))
    selection = parser.parse_args().case
    expected_python = ROOT / ".tmp-kernel-venv" / "Scripts" / "python.exe"
    if Path(sys.executable).resolve() != expected_python.resolve():
        raise ValueError("Use the repository virtual environment")
    module = executor()
    args, output = paths(module, selection)
    module._paths(args, ROOT)
    if any(path.exists() for path in output.values()):
        raise ValueError("Exclusive constructor log/report/command already exists")
    command = subprocess.list2cmdline([
        str(expected_python), "-X", "utf8", str(Path(__file__).resolve()),
        "--case", selection,
    ])
    with output["command"].open("x", encoding="utf-8") as handle:
        handle.write(command + "\n")
    result = {
        "selection": selection,
        "target_source": str(args.target_source),
        "target_snapshot_sha256": NEW_SNAPSHOT,
        "executor_sha256": EXECUTOR_SHA256,
        "command": command,
    }
    print(json.dumps({"status": "starting", **result}, ensure_ascii=False), flush=True)
    with output["log"].open("x", encoding="utf-8", buffering=1) as log:
        with contextlib.redirect_stdout(log), contextlib.redirect_stderr(log):
            try:
                result.update(module.rebase(args))
                print(json.dumps(result, ensure_ascii=False, indent=2))
            except BaseException as error:
                result.update(status="failed_not_certified", error=str(error))
                traceback.print_exc()
                with output["report"].open("x", encoding="utf-8") as report:
                    json.dump(result, report, ensure_ascii=False, indent=2)
                    report.write("\n")
                raise
    with output["report"].open("x", encoding="utf-8") as report:
        json.dump(result, report, ensure_ascii=False, indent=2)
        report.write("\n")
    print(json.dumps(result, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
