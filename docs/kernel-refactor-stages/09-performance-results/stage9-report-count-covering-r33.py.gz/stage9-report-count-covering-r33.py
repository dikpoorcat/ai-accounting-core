"""Private read-only-source / copied-database report count index experiment."""

from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import sys
import time
from pathlib import Path


WORKSPACE = Path(__file__).resolve().parents[1]
SOURCE = WORKSPACE / ".tmp/stage9-build-source-r33-release"
BOOK_REPORT = WORKSPACE / ".tmp/stage9-release-main-48-verified-r32.json"
CLONE = WORKSPACE / ".tmp/stage9-report-count-covering-r33/company.sqlite"
OUTPUT = WORKSPACE / ".tmp/stage9-report-count-covering-r33.json"
SQL = (
    "SELECT count(*) FILTER (WHERE s.kind=?),"
    "count(*) FILTER (WHERE s.kind=?) FROM json_each(?) ids "
    "JOIN fact_revision f ON f.id=ids.value JOIN subject s ON s.id=f.subject_id"
)
INDEXES = {
    "fact": "CREATE INDEX stage9_cover_fact_id_subject ON fact_revision(id,subject_id)",
    "subject": "CREATE INDEX stage9_cover_subject_id_kind ON subject(id,kind)",
}


def io_read_bytes():
    try:
        import psutil

        return psutil.Process().io_counters().read_bytes
    except (AttributeError, ImportError, OSError):
        return None


def measure_query(connection, parameters):
    vm = 0

    def progress():
        nonlocal vm
        vm += 100
        return 0

    connection.set_progress_handler(progress, 100)
    before = io_read_bytes()
    cpu_start = time.process_time_ns()
    wall_start = time.perf_counter_ns()
    cursor = connection.execute(SQL, parameters)
    rows = cursor.fetchall()
    cursor.close()
    elapsed_wall = (time.perf_counter_ns() - wall_start) / 1e6
    elapsed_cpu = (time.process_time_ns() - cpu_start) / 1e6
    after = io_read_bytes()
    connection.set_progress_handler(None, 0)
    return {
        "result": rows,
        "row_count": len(rows),
        "result_bytes": len(json.dumps(rows, separators=(",", ":")).encode()),
        "vm_approx": vm,
        "process_read_bytes_delta": None if before is None or after is None else after - before,
        "diagnostic_wall_ms": elapsed_wall,
        "diagnostic_cpu_ms": elapsed_cpu,
    }


def normalized_response(response):
    def scrub(value):
        if isinstance(value, dict):
            return {k: scrub(v) for k, v in value.items() if k in () or k not in {"generated_at", "checked_at", "read_version"}}
        if isinstance(value, list):
            return [scrub(item) for item in value]
        return value

    return scrub(response)


def main():
    if OUTPUT.exists():
        raise RuntimeError("Preserve existing diagnostic output")
    if Path(sys.prefix).resolve() != WORKSPACE / ".tmp-kernel-venv":
        raise RuntimeError("Use repository virtual environment")
    book = json.loads(BOOK_REPORT.read_text(encoding="utf-8"))
    if book["status"] != "complete" or book.get("integrity", {}).get("status") != "verified":
        raise RuntimeError("Book report is not independently verified")
    original = Path(book["company"]["path"])
    if not original.is_file() or not original.is_relative_to(WORKSPACE / ".tmp"):
        raise RuntimeError("Expected existing synthetic company under .tmp")
    if not CLONE.exists():
        CLONE.parent.mkdir(parents=True, exist_ok=False)
        print("Backing up verified synthetic source into isolated clone", flush=True)
        source_db = sqlite3.connect(f"file:{original.as_posix()}?mode=ro", uri=True)
        clone_db = sqlite3.connect(CLONE)
        source_db.backup(clone_db, pages=8192)
        source_db.close()
        clone_db.close()
    sys.path.insert(0, str(SOURCE / "src"))
    from ai_accounting.kernel.daemon import _prepare_static_runtime
    from ai_accounting.kernel.dashboard import Dashboard
    from ai_accounting.kernel.engine import Engine
    from ai_accounting.kernel.query_reads import QueryReads
    from ai_accounting.kernel.reports import Reports, ReportClassification, ReportIncomeTaxConfirmation
    from ai_accounting.kernel.storage import Store
    from ai_accounting.kernel.types import canonical
    from ai_accounting.kernel.permissions import ensure_private_directory, adopt_private_file

    ensure_private_directory(CLONE.parent)
    adopt_private_file(CLONE)
    bundle = _prepare_static_runtime()[0]
    identity = book["company"]
    store = Store(CLONE, bundle, identity["id"], identity["database_id"], taxpayer_id=identity["taxpayer_id"])
    engine = Engine(store)
    reports = Reports(engine)
    with QueryReads.snapshot(engine) as reads:
        plan = reports._report(2019, 4, source="open", connection=reads.connection, reads=reads)
    ids = plan["report_fact_ids"]
    parameters = (ReportClassification.kind, ReportIncomeTaxConfirmation.kind, canonical(ids))
    output = {
        "status": "diagnostic",
        "source": str(SOURCE),
        "book_report": str(BOOK_REPORT),
        "book_verification_source": book["source"],
        "original_db": str(original),
        "clone": str(CLONE),
        "clone_bytes_before_indexes": CLONE.stat().st_size,
        "plan_ids": len(ids),
        "plan_id_digest": hashlib.sha256(canonical(ids).encode()).hexdigest(),
        "variants": [],
        "note": "Copied synthetic DB only; not browser latency acceptance or original DB modification.",
    }
    reference = normalized_response(Dashboard(engine).quarterly_report(2019, 4, preparation="deferred"))
    output["baseline_full_response_sha256"] = hashlib.sha256(
        json.dumps(reference, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()
    baseline_counts = None
    with sqlite3.connect(CLONE) as connection:
        for name in ("baseline", "fact_cover", "subject_cover", "both_cover"):
            if name == "subject_cover":
                connection.execute("DROP INDEX stage9_cover_fact_id_subject")
            if name == "both_cover":
                connection.execute(INDEXES["fact"])
            if name == "fact_cover":
                connection.execute(INDEXES["fact"])
            if name == "subject_cover":
                connection.execute(INDEXES["subject"])
            connection.commit()
            eqp = [tuple(row) for row in connection.execute("EXPLAIN QUERY PLAN " + SQL, parameters)]
            samples = [measure_query(connection, parameters) for _ in range(4)]
            counts = samples[-1]["result"]
            if baseline_counts is None:
                baseline_counts = counts
            variant = {
                "name": name,
                "eqp": eqp,
                "samples": samples,
                "counts_equal_to_baseline": counts == baseline_counts,
                "clone_bytes": CLONE.stat().st_size,
            }
            output["variants"].append(variant)
            print(name, "VM", samples[-1]["vm_approx"], "counts_equal", counts == baseline_counts, flush=True)
    OUTPUT.write_text(json.dumps(output, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(OUTPUT)


if __name__ == "__main__":
    main()
