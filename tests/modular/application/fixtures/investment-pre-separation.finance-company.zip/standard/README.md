# 合成前版投资公司 · 标准业务文档

这里保存当前正确事实，用于查阅及简化重建。机器读取入口是 current.json。本说明由同一套 JSON 生成。

统一社会信用代码：913100000000000001
建账月份：2026-01
已进入的工作末月：2026-08
当前集合：`8e50d8fa1ddb24ffa91d3241d427b46a204e19f75735728a0b3b50f66972a03c`

## 当前内容

- [facts:investment:2026-07](parts/investment--2026-07--c91b31f7bce70dda0c01d08b96973d333abc3970aa739e7026b819bdb807f47e.json)
- [facts:opening:2026-01](parts/opening--2026-01--46be788b771b24a4f5280e61b7aa83a2ef2cfa63237d7bce590b693feaa45421.json)
- [facts:operations:2026-08](parts/operations--2026-08--9a8c57b7b74fb51f92b6af94618bd6fdbd363b443243f804bda225334d7458c7.json)
- [facts:taxes:2026-01](parts/taxes--2026-01--04985381fbd904a2e8b99ae7466dcf361f826eab432f8f043b5869f69727eabc.json)
- [facts:taxes:2026-07](parts/taxes--2026-07--998c17ebc247cf1d9fafd568ef1bbe5ef01ecb20c5b6078db704d691059de065.json)
- [objects](parts/objects--98cf6434e2102f73d51933ac73613ec89f5b3c1fc9b162ef21e0314db62c2e7f.json)
- [sources:00000000-0000-0000-0000-000000000191](parts/sources--00000000-0000-0000-0000-000000000191--6c80ee8cfe195d1f3a7486f1c8f4922802219a66a59651f3ed1eb72043ba67f8.json)
- [sources:613d0a17-fe6a-5d27-9e5d-29cc60b3022e](parts/sources--613d0a17-fe6a-5d27-9e5d-29cc60b3022e--2c793957f9a6ffaeaaeb0c16396013b1c096c5c02e9aa9427f4e696b64dfb77f.json)
- [work](parts/work--8d178e1ea26ecc287af9d447d2ca4c459c95b1bdd1965bdb1cf84772164086c4.json)

已替换的开放期错误、旧编号及操作过程不在这里保存；真实收付款、退款和损失仍是业务事实。
