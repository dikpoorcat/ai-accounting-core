# 合成前版投资公司 · 标准业务文档

这里保存当前正确事实，用于查阅及简化重建。机器读取入口是 current.json。本说明由同一套 JSON 生成。

统一社会信用代码：913100000000000001
建账月份：2026-01
已进入的工作末月：2026-08
当前集合：`c1dbd64392088affcc808a4da9783e7ea1049fbf2ca100993234749b66bb8426`

## 当前内容

- [facts:investment:2026-07](parts/investment--2026-07--8b50ec5e54130618a629777c7d04ab9e95b360abfd1d3e2fc1a3c5a4d493033f.json)
- [facts:opening:2026-01](parts/opening--2026-01--07c4893d144f6996d05016d709c5c0b92d0a2bde073be172cadd0c2d59ea1c4e.json)
- [facts:operations:2026-08](parts/operations--2026-08--367bbaf83d1b05816eaed89410f6cba270cb40825592c77fb8a8c457dd9d606f.json)
- [facts:taxes:2026-01](parts/taxes--2026-01--04985381fbd904a2e8b99ae7466dcf361f826eab432f8f043b5869f69727eabc.json)
- [facts:taxes:2026-07](parts/taxes--2026-07--08a52f51a8ae79e575ad531fa958f03de260614d58ee267c951d7bee9188ae5b.json)
- [objects](parts/objects--98cf6434e2102f73d51933ac73613ec89f5b3c1fc9b162ef21e0314db62c2e7f.json)
- [sources:00000000-0000-0000-0000-000000000191](parts/sources--00000000-0000-0000-0000-000000000191--46fcf47627f66fb92d2310e1920f639e8bcc845f64446d490ca6320b9bebbfd5.json)
- [sources:613d0a17-fe6a-5d27-9e5d-29cc60b3022e](parts/sources--613d0a17-fe6a-5d27-9e5d-29cc60b3022e--2c793957f9a6ffaeaaeb0c16396013b1c096c5c02e9aa9427f4e696b64dfb77f.json)
- [work](parts/work--8d178e1ea26ecc287af9d447d2ca4c459c95b1bdd1965bdb1cf84772164086c4.json)

已替换的开放期错误、旧编号及操作过程不在这里保存；真实收付款、退款和损失仍是业务事实。
